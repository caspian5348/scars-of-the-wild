export const MULTIPLAYER_SESSION_KEY = 'scars-of-the-wild.coop.session.v1';
export const MULTIPLAYER_RESUME_KEY = 'scars-of-the-wild.coop.resume.v1';
const RESUME_DISABLED_KEY = 'scars-of-the-wild.coop.resume-disabled.v1';

function browserStorage(kind) { try { return globalThis[kind]; } catch { return undefined; } }
function normalizeSession(value) {
  try {
    if (!value || typeof value.token !== 'string' || !value.token || typeof value.baseUrl !== 'string') return null;
    const url = new URL(value.baseUrl);
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    return { baseUrl: url.origin, token: value.token, playerId: value.playerId, code: value.code, name: value.name || 'Survivor' };
  } catch { return null; }
}
function storedSession(storage, key) { try { return normalizeSession(JSON.parse(storage?.getItem(key) || 'null')); } catch { return null; } }
function sameSession(a, b) { return !!a && !!b && a.token === b.token && a.baseUrl === b.baseUrl; }

/** A tab keeps its own identity; a new tab can recover the last saved survivor. */
export function readMultiplayerSession(storage = browserStorage('sessionStorage'), fallbackStorage = browserStorage('localStorage')) {
  const current = storedSession(storage, MULTIPLAYER_SESSION_KEY);
  if (current) {
    // Upgrade sessions created before persistent reconnect support without
    // replacing another tab's more recently saved survivor.
    if (!storedSession(fallbackStorage, MULTIPLAYER_RESUME_KEY)) {
      try { fallbackStorage?.setItem(MULTIPLAYER_RESUME_KEY, JSON.stringify(current)); } catch { }
    }
    return current;
  }
  try { if (storage?.getItem(RESUME_DISABLED_KEY) === '1') return null; } catch { }
  const restored = storedSession(fallbackStorage, MULTIPLAYER_RESUME_KEY);
  if (restored) {
    try { storage?.setItem(MULTIPLAYER_SESSION_KEY, JSON.stringify(restored)); } catch { }
  }
  return restored;
}

export function writeMultiplayerSession(value, storage = browserStorage('sessionStorage'), fallbackStorage = browserStorage('localStorage')) {
  const normalized = normalizeSession(value);
  if (!normalized) throw new TypeError('The multiplayer session is invalid.');
  const serialized = JSON.stringify(normalized); let saved = false;
  try { if (storage) { storage.setItem(MULTIPLAYER_SESSION_KEY, serialized); storage.removeItem(RESUME_DISABLED_KEY); saved = true; } } catch { }
  try { if (fallbackStorage) { fallbackStorage.setItem(MULTIPLAYER_RESUME_KEY, serialized); saved = true; } } catch { }
  if (!saved) throw new Error('This browser could not save your multiplayer reconnect identity.');
}

export function clearMultiplayerSession(storage = browserStorage('sessionStorage'), fallbackStorage = browserStorage('localStorage'), expectedSession) {
  const current = storedSession(storage, MULTIPLAYER_SESSION_KEY), expected = normalizeSession(expectedSession) || current;
  if (!expectedSession || sameSession(current, expected)) {
    try { storage?.removeItem(MULTIPLAYER_SESSION_KEY); storage?.setItem(RESUME_DISABLED_KEY, '1'); } catch { }
  }
  // An unrelated tab may have hosted or joined another room more recently.
  if (sameSession(storedSession(fallbackStorage, MULTIPLAYER_RESUME_KEY), expected)) {
    try { fallbackStorage?.removeItem(MULTIPLAYER_RESUME_KEY); } catch { }
  }
}

function requestId() {
  return globalThis.crypto?.randomUUID?.() || `action-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

export class MultiplayerError extends Error {
  constructor(message, code, status = 0) { super(message); this.name = 'MultiplayerError'; this.code = code; this.status = status; }
}

export async function multiplayerRequest(baseUrl, path, { token, body, signal } = {}) {
  let response;
  try {
    response = await fetch(new URL(path, baseUrl), {
      method: body === undefined ? 'GET' : 'POST', cache: 'no-store', signal: signal || globalThis.AbortSignal?.timeout?.(10000),
      headers: { ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) })
    });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new MultiplayerError('Cannot reach the co-op server. Keep the host server running and check your connection.', 'connection_unavailable');
  }
  let data;
  try { data = await response.json(); } catch { throw new MultiplayerError('The co-op server returned an unreadable response.', 'invalid_response', response.status); }
  if (!response.ok) throw new MultiplayerError(data.error || 'The server could not complete this request.', data.code || 'request_failed', response.status);
  return data;
}

/** Commands are never silently retried. The event stream reconnects without changing the survivor token. */
export function createMultiplayerClient({ baseUrl, token, onSnapshot = () => {}, onStatus = () => {} }) {
  const origin = new URL(baseUrl).origin;
  let latest = null, source = null, stopped = true, generation = 0, reconnectTimer = null, checking = false;
  const status = (state, message) => onStatus({ state, message });
  const accept = snapshot => {
    if (!snapshot || typeof snapshot.code !== 'string' || !Array.isArray(snapshot.players)) throw new MultiplayerError('The room update was incomplete.', 'invalid_snapshot');
    if (latest && Number.isFinite(latest.serverTime) && Number.isFinite(snapshot.serverTime) && snapshot.serverTime < latest.serverTime) return latest;
    latest = snapshot;
    onSnapshot(snapshot);
    return snapshot;
  };
  const terminal = error => error.status === 401 || error.status === 403 || error.status === 404;
  function closeStream() { source?.close(); source = null; clearTimeout(reconnectTimer); reconnectTimer = null; }
  async function verifyReconnect(turn) {
    if (stopped || turn !== generation || checking) return;
    checking = true;
    try {
      const data = await multiplayerRequest(origin, `/api/session?token=${encodeURIComponent(token)}`);
      if (!stopped && turn === generation) accept(data.snapshot);
    } catch (error) {
      if (!stopped && turn === generation && terminal(error)) { closeStream(); stopped = true; status('expired', error.message); }
    } finally { checking = false; }
  }
  async function connect() {
    closeStream(); stopped = false;
    const turn = ++generation;
    status('connecting', 'Connecting to your co-op room…');
    try {
      const data = await multiplayerRequest(origin, `/api/session?token=${encodeURIComponent(token)}`);
      if (stopped || turn !== generation) return latest;
      accept(data.snapshot);
      source = new EventSource(new URL(`/api/events?token=${encodeURIComponent(token)}`, origin));
      source.onopen = () => { if (!stopped && turn === generation) status('connected', 'Connected to the co-op server'); };
      source.addEventListener('snapshot', event => {
        if (stopped || turn !== generation) return;
        try { accept(JSON.parse(event.data)); status('connected', 'Connected to the co-op server'); }
        catch { status('reconnecting', 'Waiting for a complete room update…'); }
      });
      source.addEventListener('replaced', () => {
        if (stopped || turn !== generation) return;
        closeStream(); stopped = true; ++generation;
        status('replaced', 'This survivor is connected in another tab. Continue there, or reconnect here.');
      });
      source.onerror = () => {
        if (stopped || turn !== generation) return;
        status('reconnecting', 'Connection interrupted. Reconnecting as the same survivor…');
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(() => { void verifyReconnect(turn); }, 1200);
      };
      return latest;
    } catch (error) {
      if (!stopped && turn === generation) { closeStream(); stopped = true; status(terminal(error) ? 'expired' : 'offline', error.message); }
      throw error;
    }
  }
  async function command(body) {
    if (stopped) throw new MultiplayerError('Connect to your room before taking this action.', 'not_connected');
    const data = await multiplayerRequest(origin, '/api/session', { token, body });
    if (data.snapshot) accept(data.snapshot);
    return data;
  }
  return {
    connect,
    action: action => command({ type: 'action', action: { ...action, id: action.id || requestId() } }),
    move: player => command({ type: 'move', ...player }),
    profile: profile => command({ type: 'profile', ...profile }),
    ready: ready => command({ type: 'ready', ready: !!ready }),
    start: () => command({ type: 'start' }),
    death: cause => command({ type: 'death', cause }),
    leave: async () => { const result = await command({ type: 'leave' }); closeStream(); stopped = true; ++generation; clearMultiplayerSession(undefined, undefined, { baseUrl: origin, token }); status('disconnected', 'Left the co-op room'); return result; },
    disconnect: () => { closeStream(); stopped = true; ++generation; status('disconnected', 'Disconnected'); },
    snapshot: () => latest
  };
}
