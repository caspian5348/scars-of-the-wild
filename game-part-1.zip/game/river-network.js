/** One connected watershed, shared by terrain, water, vegetation and the map. */
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a));return t*t*(3-2*t);};
export function riverX(z){return Math.sin(z*.013)*26+Math.sin(z*.006+.3)*18;}
export const RIVER_MOUTH={x:riverX(550),z:550};
const tributaries={
  west:[{x:-300,z:-380},{x:-340,z:-210},{x:-140,z:-265},{x:riverX(-80),z:-80}],
  east:[{x:380,z:-160},{x:292,z:-5},{x:295,z:205},{x:riverX(220),z:220}],
};
const descriptions={main:'Wildwater River',west:'Rainforest River',east:'Glowwater River'};
export function riverPathPoint(id,t){
  t=clamp(t);
  if(id==='main'){
    const z=-905+t*1810;
    return {x:riverX(z),z,halfWidth:10.4+Math.sin(z*.021)*1.25+smooth(415,575,z)*23};
  }
  const p=tributaries[id];if(!p)throw new Error(`Unknown river branch: ${id}`);
  const s=1-t,x=s*s*s*p[0].x+3*s*s*t*p[1].x+3*s*t*t*p[2].x+t*t*t*p[3].x;
  const z=s*s*s*p[0].z+3*s*s*t*p[1].z+3*s*t*t*p[2].z+t*t*t*p[3].z;
  return {x,z,halfWidth:7.9+Math.sin(t*9+(id==='east'?1:0))*.7+t*1.3};
}
const paths=['main','west','east'].map(id=>{const count=id==='main'?605:181;return {id,name:descriptions[id],points:Array.from({length:count},(_,i)=>riverPathPoint(id,i/(count-1)))};});
// Avoid allocating snapshots inside the terrain's hundreds of thousands of samples.
export function riverPaths(){return paths;}
const segments=paths.flatMap(path=>path.points.slice(1).map((b,i)=>{
  const a=path.points[i],dx=b.x-a.x,dz=b.z-a.z,length=Math.hypot(dx,dz),width=Math.max(a.halfWidth,b.halfWidth);
  return {id:path.id,a,b,dx,dz,length,length2:length*length,width,minX:Math.min(a.x,b.x),maxX:Math.max(a.x,b.x),minZ:Math.min(a.z,b.z),maxZ:Math.max(a.z,b.z)};
}));
function buildTree(parts){
  const node={minX:Infinity,maxX:-Infinity,minZ:Infinity,maxZ:-Infinity,width:0};
  for(const s of parts){node.minX=Math.min(node.minX,s.minX);node.maxX=Math.max(node.maxX,s.maxX);node.minZ=Math.min(node.minZ,s.minZ);node.maxZ=Math.max(node.maxZ,s.maxZ);node.width=Math.max(node.width,s.width);}
  if(parts.length<=8){node.parts=parts;return node;}
  const key=node.maxX-node.minX>node.maxZ-node.minZ?'x':'z';
  parts.sort((a,b)=>(a.a[key]+a.b[key])-(b.a[key]+b.b[key]));
  const middle=parts.length>>1;node.left=buildTree(parts.slice(0,middle));node.right=buildTree(parts.slice(middle));return node;
}
const tree=buildTree(segments);
const bound=(node,x,z)=>Math.hypot(Math.max(node.minX-x,0,x-node.maxX),Math.max(node.minZ-z,0,z-node.maxZ))-node.width;
export function riverSampleAt(x,z){
  let best=Infinity,result=null;
  function visit(node){
    if(bound(node,x,z)>best)return;
    if(node.parts){for(const s of node.parts){
      const t=clamp(((x-s.a.x)*s.dx+(z-s.a.z)*s.dz)/s.length2),cx=s.a.x+s.dx*t,cz=s.a.z+s.dz*t;
      const distance=Math.hypot(x-cx,z-cz),halfWidth=s.a.halfWidth+(s.b.halfWidth-s.a.halfWidth)*t,bankDistance=distance-halfWidth;
      if(bankDistance<best){best=bankDistance;result={id:s.id,x:cx,z:cz,distance,halfWidth,bankDistance,flowX:s.dx/s.length,flowZ:s.dz/s.length};}
    }return;}
    const a=bound(node.left,x,z),b=bound(node.right,x,z);
    if(a<b){visit(node.left);visit(node.right);}else{visit(node.right);visit(node.left);}
  }
  visit(tree);return result;
}
export const riverDistanceAt=(x,z)=>riverSampleAt(x,z).distance;
export const riverBankDistanceAt=(x,z)=>riverSampleAt(x,z).bankDistance;
