/** Appearance data is intentionally independent of Three.js and the save format. */
export const SKIN_TONES = Object.freeze([
  {label:'Fair',color:'#e2b797'}, {label:'Light tan',color:'#c58e6b'},
  {label:'Warm brown',color:'#a76f50'}, {label:'Medium brown',color:'#855137'},
  {label:'Deep brown',color:'#633c29'}, {label:'Dark',color:'#412a21'},
].map(Object.freeze));
export const CLOTHING_COLORS = Object.freeze(Object.fromEntries(Object.entries({
  moss:{label:'Moss',color:'#555c40'},slate:{label:'Slate',color:'#505c61'},
  sand:{label:'Sand',color:'#a39371'},rust:{label:'Rust',color:'#855543'},
}).map(([key,value])=>[key,Object.freeze(value)])));
export const HAIR_COLORS = Object.freeze(Object.fromEntries(Object.entries({
  black:{label:'Black',color:'#24221f'},brown:{label:'Brown',color:'#49372a'},
  auburn:{label:'Auburn',color:'#74432f'},blond:{label:'Blond',color:'#a78c5b'},
  gray:{label:'Gray',color:'#96958b'},
}).map(([key,value])=>[key,Object.freeze(value)])));
export const DEFAULT_CHARACTER = Object.freeze({version:1,name:'Survivor',skinTone:2,
  bodyType:'balanced',hairStyle:'cropped',hairColor:'brown',topColor:'moss',sleeve:'rolled',scar:'none'});
const choice=(value,choices,fallback)=>choices.includes(value)?value:fallback;
export function normalizeCharacterProfile(value) {
  const source=value&&typeof value==='object'&&!Array.isArray(value)?value:{};
  const plainName=typeof source.name==='string'?source.name.normalize('NFC')
    .replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f<>]/g,'')
    .replace(/\s+/g,' ').trim():'';
  return {version:1,name:[...plainName].slice(0,24).join('')||DEFAULT_CHARACTER.name,
    skinTone:Number.isInteger(source.skinTone)&&source.skinTone>=0&&source.skinTone<SKIN_TONES.length?source.skinTone:DEFAULT_CHARACTER.skinTone,
    bodyType:choice(source.bodyType,['slender','balanced','broad'],DEFAULT_CHARACTER.bodyType),
    hairStyle:choice(source.hairStyle,['cropped','swept','tied','shaved'],DEFAULT_CHARACTER.hairStyle),
    hairColor:choice(source.hairColor,Object.keys(HAIR_COLORS),DEFAULT_CHARACTER.hairColor),
    topColor:choice(source.topColor,Object.keys(CLOTHING_COLORS),DEFAULT_CHARACTER.topColor),
    sleeve:choice(source.sleeve,['rolled','long'],DEFAULT_CHARACTER.sleeve),
    scar:choice(source.scar,['none','brow','cheek'],DEFAULT_CHARACTER.scar)};
}
