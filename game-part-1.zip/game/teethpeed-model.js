import * as THREE from './vendor/three.module.js';
import {createTeethpeedAnatomy,createTergiteGeometry,createMembraneGeometry,createLegLinkGeometry,createClawGeometry} from './teethpeed-anatomy.js';
import {createTeethpeedMaterials} from './teethpeed-materials.js';

const TAU=Math.PI*2,COUNT=21,PITCH=.151,DUTY=.70,STRIDE=.52;
const UP=new THREE.Vector3(0,1,0);
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const random=(a,b=0)=>{const n=Math.sin(a*127.1+b*311.7)*43758.5453;return n-Math.floor(n);};
const vec=()=>new THREE.Vector3();

/** Local -Z is forward; +Y points away from the ground or trunk. */
export function createTeethpeedModel({surfaceTexture}={}) {
  const group=new THREE.Group();group.name='Teethpeed articulated centipede';
  const finish=createTeethpeedMaterials({surfaceTexture}),materials=finish.materials;
  const anatomy=createTeethpeedAnatomy({materials});group.add(anatomy.group);
  const geometries=new Set(),batches=[],dummy=new THREE.Object3D(),direction=vec(),midpoint=vec();
  const own=g=>{
    if(!g.attributes.color){const colors=new Float32Array(g.attributes.position.count*3);colors.fill(1);g.setAttribute('color',new THREE.BufferAttribute(colors,3));}
    geometries.add(g);return g;
  };
  function batch(g,material,count,name,shadow=true) {
    const mesh=new THREE.InstancedMesh(g,material,count);mesh.name=name;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);mesh.frustumCulled=false;
    mesh.castShadow=shadow;mesh.receiveShadow=true;group.add(mesh);batches.push(mesh);return mesh;
  }
  function place(mesh,index,p,s,angles=null) {
    dummy.position.copy(p);dummy.scale.set(...s);
    if(angles?.isQuaternion)dummy.quaternion.copy(angles);else if(angles)dummy.rotation.set(...angles,'YXZ');else dummy.rotation.set(0,0,0);
    dummy.updateMatrix();mesh.setMatrixAt(index,dummy.matrix);
  }
  function link(mesh,index,a,b,radius,endRadius=radius) {
    direction.subVectors(b,a);const length=Math.max(.0001,direction.length());
    dummy.position.copy(a).add(b).multiplyScalar(.5);
    dummy.quaternion.setFromUnitVectors(UP,direction.multiplyScalar(1/length));
    dummy.scale.set(radius,length,endRadius);dummy.updateMatrix();mesh.setMatrixAt(index,dummy.matrix);
  }
  const shields=[0,1,2].map(seed=>batch(own(createTergiteGeometry(seed)),materials.shell,7,'Overlapping dorsal shields'));
  const membranes=batch(own(createMembraneGeometry()),materials.membrane,COUNT,'Continuous flexible abdomen');
  const legGeometry=own(createLegLinkGeometry());
  const limbs=batch(legGeometry,materials.limb,COUNT*2*4,'Coxa femur tibia and tarsus');
  const claws=batch(own(createClawGeometry()),materials.mandible,COUNT*2,'Ground gripping tarsal claws');
  const antennae=batch(legGeometry,materials.limb,48,'Tapered sensory antennae');
  const hairGeometry=own(new THREE.CylinderGeometry(.16,1,1,3,1));
  const bodyHairs=batch(hairGeometry,materials.hair,COUNT*12,'Fine cuticular sensory hairs',false);
  const legHairs=batch(hairGeometry,materials.hair,COUNT*2*4,'Tactile leg setae',false);
  const antennaHairs=batch(hairGeometry,materials.hair,48,'Antennal sensory setae',false);
  // Local contact occlusion preserves small-scale grounding below the canopy,
  // where the broad sun shadow cannot resolve a claw or a thin abdomen.
  const contactMaterial=new THREE.MeshBasicMaterial({color:'#141711',transparent:true,opacity:.29,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});
  contactMaterial.onBeforeCompile=shader=>{
    shader.vertexShader='varying vec2 vContactUv;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <uv_vertex>','#include <uv_vertex>\nvContactUv=uv;');
    shader.fragmentShader='varying vec2 vContactUv;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <alphatest_fragment>','diffuseColor.a *= pow(max(0.0,1.0-length(vContactUv*2.0-1.0)),1.6);\n#include <alphatest_fragment>');
  };
  const contactGeometry=own(new THREE.PlaneGeometry(1,1));contactGeometry.rotateX(-Math.PI/2);
  const contact=batch(contactGeometry,contactMaterial,COUNT+42,'Soft ground contact occlusion',false);contact.receiveShadow=false;contact.renderOrder=1;
  const segments=Array.from({length:COUNT},(_,i)=>({
    z:.335+i*PITCH,width:(.229+.018*Math.sin(i/COUNT*Math.PI))*(1-.43*Math.pow(i/(COUNT-1),3.6)),p:vec(),yaw:0,right:vec(),normal:vec(),back:vec(),q:new THREE.Quaternion(),
  }));
  const color=new THREE.Color();
  for(let i=0;i<COUNT;i++) {
    color.setRGB(.90+random(i)*.09,.88+random(i)*.08,.85+random(i)*.09);
    shields[i%3].setColorAt(Math.floor(i/3),color);
  }
  const feet=Array.from({length:COUNT*2},(_,i)=>({
    segment:Math.floor(i/2),side:i%2?1:-1,phase:0,ready:false,plant:vec(),start:vec(),target:vec(),local:vec(),
    hip:vec(),coxa:vec(),knee:vec(),ankle:vec(),tip:vec(),axis:vec(),bend:vec(),
  }));
  const inverse=new THREE.Matrix4(),basis=new THREE.Matrix4(),root=vec(),lastRoot=vec(),trail=[],sampleA=vec(),sampleB=vec(),desired=vec(),projectWorld=vec(),contactNormal=vec(),headNormal=vec();
  const groundNormal=vec(),headBack=vec(),headRight=vec(),headTurn=new THREE.Quaternion();
  const diagnostics={segments:COUNT,legPairs:COUNT,plantedFeet:42,swingingFeet:0,stepCycle:0,maxFootPenetration:0,
    bodyLength:4.33,headHeight:.21,virtualCrawl:false,climbBlend:0,trunkSupportedSegments:0,groundSupportedSegments:COUNT,trailResets:0,resetReason:'initial'};
  let previousTime=null,cycle=0,disposed=false;
  function seedTrail() {
    trail.length=0;
    for(let z=0;z<=4.6;z+=.08)trail.push(new THREE.Vector3(0,0,z).applyMatrix4(group.matrixWorld));
    for(const foot of feet)foot.ready=false;
  }
  function sampleTrail(distance,out) {
    let travelled=0;
    for(let i=1;i<trail.length;i++) {
      const length=trail[i].distanceTo(trail[i-1]);
      if(travelled+length>=distance){out.copy(trail[i-1]).lerp(trail[i],(distance-travelled)/Math.max(length,.00001));return out.applyMatrix4(inverse);}
      travelled+=length;
    }
    return out.copy(trail[trail.length-1]).applyMatrix4(inverse);
  }
  function animate({time=0,speed=0,climbing=false,climbBlend,attacking=0,groundAt=()=>0,groundHeightAt=null,climbRadius=1.8,climbTaper=.035,climbTree=null}={}) {
    if(disposed)return;
    const attachment=Number.isFinite(climbBlend)?clamp(climbBlend):(climbing?1:0),worldGround=typeof groundHeightAt==='function';
    group.updateWorldMatrix(true,false);inverse.copy(group.matrixWorld).invert();root.setFromMatrixPosition(group.matrixWorld);
    const resetReason=previousTime===null?'initial':time<previousTime?'time-reversed':root.distanceTo(lastRoot)>2.5?'teleport':null,reset=resetReason!==null;
    const dt=reset?0:clamp(time-previousTime,0,.10),moved=reset?0:root.distanceTo(lastRoot);
    if(reset){seedTrail();diagnostics.trailResets++;diagnostics.resetReason=resetReason;}
    const virtual=speed>.03&&moved<.00008;
    if(!virtual&&moved>.002) {
      trail[0].copy(root);
      if(root.distanceTo(trail[1])>.04)trail.unshift(root.clone());
      if(trail.length>270)trail.length=270;
    }
    const radius=Math.max(.28,climbRadius);
    const surface=(x,z)=>{if(climbing){const r=Math.max(.28,radius-z*climbTaper);return Math.sqrt(Math.max(.005,r*r-x*x))-radius-.08;}const y=groundAt(x,z);return Number.isFinite(y)?y:0;};
    function trunkAt(y) {
      const t=clamp((y-climbTree.h+.08)/climbTree.height)*10,lo=Math.floor(t),hi=Math.min(10,lo+1),blend=t-lo;
      const variant=Number.isFinite(climbTree.variant)?climbTree.variant:(parseInt(String(climbTree.id||'').split('-').at(-1),10)||0)%2;
      const point=j=>{const f=j/10;return {x:Math.sin(f*2.6+variant)*f*.55,z:Math.sin(f*3.9)*f*.46,r:(1-.945*Math.pow(f,.76))*(1+Math.sin(j*1.7)*.035)};};
      const a=point(lo),b=point(hi),x=(a.x+(b.x-a.x)*blend)*climbTree.radius,z=(a.z+(b.z-a.z)*blend)*climbTree.radius,angle=climbTree.angle||0;
      return {x:climbTree.x+Math.cos(angle)*x+Math.sin(angle)*z,z:climbTree.z-Math.sin(angle)*x+Math.cos(angle)*z,r:Math.max(.12,(a.r+(b.r-a.r)*blend)*climbTree.radius)};
    }
    let lastTrunkSupport=0;
    function floorAt(x,z) {const y=groundHeightAt(x,z);return Number.isFinite(y)?y:root.y;}
    function floorNormal(x,z,out,detail) {
      if(detail)out.set(-(floorAt(x+.12,z)-floorAt(x-.12,z))/.24,1,-(floorAt(x,z+.12)-floorAt(x,z-.12))/.24).normalize();
      else out.set(0,1,0);
      return out;
    }
    // Each historical body/foot point chooses its own surface. The rounded
    // corner is a real quarter-circle, so repeatedly projecting a planted foot
    // does not progressively pull it toward the tree/ground intersection.
    function project(p,out,clearance=0,normal=contactNormal) {
      lastTrunkSupport=0;
      if(climbTree) {
        projectWorld.copy(p).applyMatrix4(group.matrixWorld);const tree=trunkAt(projectWorld.y);
        let dx=projectWorld.x-tree.x,dz=projectWorld.z-tree.z,length=Math.hypot(dx,dz);
        if(length<.0001){dx=1;dz=0;length=1;}
        dx/=length;dz/=length;
        let supportRadius=tree.r+clearance,supportY=projectWorld.y,radialNormal=1,verticalNormal=0;
        if(worldGround) {
          const floor=floorAt(projectWorld.x,projectWorld.z),corner=.62;
          const lateral=length-tree.r-clearance,height=projectWorld.y-floor-clearance;
          if(lateral>=corner&&height<=corner) {
            supportRadius=Math.max(length,tree.r+clearance);supportY=floor+clearance;radialNormal=0;verticalNormal=1;
          } else if(height>=corner&&lateral<=corner) {
            supportY=Math.max(projectWorld.y,floor+clearance);
          } else {
            let angle;
            if(lateral>=corner&&height>=corner) {
              // Only off-surface/teleport samples reach this region; select a
              // continuous fallback using the root's supplied attachment pose.
              angle=(1-attachment)*Math.PI/2;
            } else angle=Math.atan2(Math.max(0,corner-height),Math.max(0,corner-lateral));
            radialNormal=Math.cos(angle);verticalNormal=Math.sin(angle);
            supportRadius=tree.r+clearance+corner*(1-radialNormal);
            supportY=floor+clearance+corner*(1-verticalNormal);
          }
          floorNormal(projectWorld.x,projectWorld.z,groundNormal,normal!==contactNormal);
        } else groundNormal.set(0,1,0);
        lastTrunkSupport=radialNormal;
        normal.set(dx*radialNormal,0,dz*radialNormal).addScaledVector(groundNormal,verticalNormal).normalize();
        projectWorld.set(tree.x+dx*supportRadius,supportY,tree.z+dz*supportRadius);
        out.copy(projectWorld).applyMatrix4(inverse);normal.transformDirection(inverse);return out;
      }
      if(worldGround) {
        projectWorld.copy(p).applyMatrix4(group.matrixWorld);
        floorNormal(projectWorld.x,projectWorld.z,normal,normal!==contactNormal);
        projectWorld.y=floorAt(projectWorld.x,projectWorld.z)+clearance;
        out.copy(projectWorld).applyMatrix4(inverse);normal.transformDirection(inverse);return out;
      }
      out.copy(p);out.y=surface(p.x,p.z)+clearance;
      if(normal!==contactNormal)normal.set(-(surface(p.x+.12,p.z)-surface(p.x-.12,p.z))/.24,1,-(surface(p.x,p.z+.12)-surface(p.x,p.z-.12))/.24).normalize();
      else normal.set(0,1,0);
      lastTrunkSupport=climbing?1:0;return out;
    }
    cycle+=dt*Math.max(0,speed)/STRIDE;
    const breath=Math.sin(time*1.7)*.0016,pace=clamp(speed/4.45),turnWave=virtual?.013:0;
    let bodyHairIndex=0,trunkSupportedSegments=0;
    for(let i=0;i<COUNT;i++) {
      const segment=segments[i],z=segment.z;
      sampleTrail(z,segment.p);sampleTrail(z-.035,sampleA);sampleTrail(z+.035,sampleB);
      segment.yaw=Math.atan2(sampleB.x-sampleA.x,sampleB.z-sampleA.z);
      segment.p.x+=(Math.sin(cycle*TAU-i*.57)*turnWave+Math.sin(i*.31)*.018)*(1-attachment);
      const clearance=.185+breath-.020*Math.pow(i/(COUNT-1),3);
      project(segment.p,segment.p,clearance,segment.normal);segment.support=lastTrunkSupport;
      if(segment.support>.025)trunkSupportedSegments++;
      project(sampleA,sampleA,clearance);project(sampleB,sampleB,clearance);
      segment.back.subVectors(sampleB,sampleA).addScaledVector(segment.normal,-segment.back.dot(segment.normal));
      if(segment.back.lengthSq()<.0000001) {
        if(i>0)segment.back.copy(segments[i-1].back);else segment.back.set(0,0,1);
        segment.back.addScaledVector(segment.normal,-segment.back.dot(segment.normal));
        if(segment.back.lengthSq()<.0000001)segment.back.set(1,0,0).addScaledVector(segment.normal,-segment.normal.x);
      }
      segment.back.normalize();segment.right.crossVectors(segment.normal,segment.back).normalize();segment.back.crossVectors(segment.right,segment.normal).normalize();
      segment.q.setFromRotationMatrix(basis.makeBasis(segment.right,segment.normal,segment.back));
      place(shields[i%3],Math.floor(i/3),segment.p,[segment.width,.172,PITCH*.65],segment.q);
      desired.copy(segment.p).addScaledVector(segment.normal,-.051);
      place(membranes,i,desired,[segment.width*.91,.047,PITCH*1.23],segment.q);
      project(segment.p,desired,.003);
      place(contact,i,desired,[segment.width*2.65,1,PITCH*2.3],segment.q);
      for(let j=0;j<12;j++) {
        const side=j%2?1:-1,u=random(i*17+j),v=random(j,i),localX=side*segment.width*(.80+u*.16),localZ=(v-.5)*PITCH;
        sampleA.set(localX,.011+(.96-Math.abs(localX/segment.width))*.15,localZ).applyQuaternion(segment.q).add(segment.p);
        sampleB.copy(sampleA).addScaledVector(segment.right,side*(.011+u*.009)).addScaledVector(segment.normal,.014+v*.012).addScaledVector(segment.back,.004);
        link(bodyHairs,bodyHairIndex++,sampleA,sampleB,.00055+u*.0002);
      }
    }
    desired.set(0,0,0);project(desired,anatomy.group.position,.210+breath,headNormal);
    headBack.set(0,0,1).addScaledVector(headNormal,-headNormal.z);
    if(headBack.lengthSq()<.0000001)headBack.copy(segments[0].back);
    headBack.normalize();headRight.crossVectors(headNormal,headBack).normalize();headBack.crossVectors(headRight,headNormal).normalize();
    anatomy.group.quaternion.setFromRotationMatrix(basis.makeBasis(headRight,headNormal,headBack));
    anatomy.group.quaternion.multiply(headTurn.setFromAxisAngle(UP,Math.sin(time*.71)*.007));
    anatomy.group.updateMatrix();
    const bite=clamp((attacking-.08)/.92);
    for(const jaw of anatomy.jaws)jaw.group.rotation.y=-jaw.side*(.032+Math.sin(bite*Math.PI*.87)*.30);
    let planted=0,swinging=0,maxPenetration=0,legHairIndex=0;
    for(let index=0;index<feet.length;index++) {
      const foot=feet[index],s=segments[foot.segment],side=foot.side;
      const rear=foot.segment===COUNT-1,fullSpread=s.width+.410+(random(index,7)-.5)*.024;
      const spread=fullSpread+(Math.min(fullSpread,radius*.93)-fullSpread)*s.support,phase=(cycle-foot.segment*.173+(side>0?.5:0)+20)%1;
      function landing(ahead=0) {
        const lateral=side*spread,longitudinal=(rear?.39:.17)+(random(index,4)-.5)*.048+ahead;
        desired.copy(s.p).addScaledVector(s.right,lateral).addScaledVector(s.back,longitudinal);
        return project(desired,desired,.005);
      }
      if(!foot.ready) {
        foot.plant.copy(landing(speed>.03?(clamp(phase/DUTY)-.5)*STRIDE*DUTY:0)).applyMatrix4(group.matrixWorld);
        foot.start.copy(foot.plant);foot.target.copy(foot.plant);foot.ready=true;foot.phase=phase;
      }
      const swingingNow=speed>.03&&phase>=DUTY;
      if(speed>.03&&phase<foot.phase&&dt>0) {
        foot.plant.copy(landing((phase/DUTY-.5)*STRIDE*DUTY)).applyMatrix4(group.matrixWorld);
      }
      let lift=0;
      if(swingingNow) {
        if(foot.phase<DUTY||reset)foot.start.copy(foot.plant);
        foot.target.copy(landing(-STRIDE*DUTY*.5)).applyMatrix4(group.matrixWorld);
        const t=(phase-DUTY)/(1-DUTY),eased=t*t*(3-2*t);
        foot.local.copy(foot.start).lerp(foot.target,eased).applyMatrix4(inverse);
        lift=Math.sin(t*Math.PI)*(.034+pace*.035);project(foot.local,foot.local,.005+lift);
        foot.plant.copy(foot.local).applyMatrix4(group.matrixWorld);swinging++;
      } else {
        foot.local.copy(foot.plant).applyMatrix4(inverse);
        if(virtual&&dt>0&&speed>.03)foot.local.addScaledVector(s.back,speed*dt);
        project(foot.local,foot.local,.005);
        foot.plant.copy(foot.local).applyMatrix4(group.matrixWorld);planted++;
      }
      foot.phase=phase;
      foot.hip.copy(s.p).addScaledVector(s.right,side*s.width*.87).addScaledVector(s.normal,-.027);
      foot.coxa.copy(foot.hip).addScaledVector(s.right,side*.079).addScaledVector(s.normal,.004);
      foot.ankle.copy(foot.local).addScaledVector(s.right,-side*.028).addScaledVector(s.normal,.035);
      foot.axis.subVectors(foot.ankle,foot.coxa);const distance=Math.max(.001,foot.axis.length());foot.axis.multiplyScalar(1/distance);
      // Connected two-bone IK: the foot stays planted while the body passes it.
      const femur=.309,tibia=.366,d=Math.min(distance,femur+tibia-.002);
      const along=(femur*femur-tibia*tibia+d*d)/(2*d),height=Math.sqrt(Math.max(.001,femur*femur-along*along));
      // Centipede knees sweep behind the body in a nearly horizontal plane.
      foot.bend.copy(s.back).addScaledVector(s.right,side*.15).addScaledVector(s.normal,.10);foot.bend.addScaledVector(foot.axis,-foot.axis.dot(foot.bend)).normalize();
      foot.knee.copy(foot.coxa).addScaledVector(foot.axis,along).addScaledVector(foot.bend,height);
      link(limbs,index*4,foot.hip,foot.coxa,.037);
      link(limbs,index*4+1,foot.coxa,foot.knee,.029);
      link(limbs,index*4+2,foot.knee,foot.ankle,.019);
      link(limbs,index*4+3,foot.ankle,foot.local,.010);
      foot.tip.copy(foot.local).addScaledVector(s.right,side*.011).addScaledVector(s.back,-.032);project(foot.tip,foot.tip,.0015+lift);
      link(claws,index,foot.local,foot.tip,.008);
      project(foot.tip,desired,0);maxPenetration=Math.max(maxPenetration,desired.sub(foot.tip).dot(contactNormal));
      project(foot.local,desired,.003);
      const contactSize=swingingNow?.002:.067;
      place(contact,COUNT+index,desired,[contactSize,1,contactSize],s.q);
      for(let j=0;j<4;j++) {
        sampleA.copy(j<2?foot.coxa:foot.knee).lerp(j<2?foot.knee:foot.ankle,j%2?.67:.34);
        sampleB.copy(sampleA).addScaledVector(s.right,side*.018).addScaledVector(s.normal,.010).addScaledVector(s.back,.013);
        link(legHairs,legHairIndex++,sampleA,sampleB,.00055);
      }
    }
    let antennaIndex=0;
    for(const rootInfo of anatomy.antennaRoots) {
      const side=rootInfo.side,origin=rootInfo.position,sweep=Math.sin(time*1.07+side*.78)*.14+Math.sin(time*2.6+side)*.025;
      for(let i=0;i<24;i++) {
        function antennaPoint(t,out) {
          out.set(origin.x+side*(t*.47+Math.sin(t*Math.PI)*.055+sweep*t*t),
            origin.y+Math.sin(t*Math.PI)*.075-t*.028+Math.sin(time*1.3+t*4+side)*t*.035,
            origin.z-t*.81+Math.sin(time*.8+side)*t*t*.06);
          return out.applyMatrix4(anatomy.group.matrix);
        }
        antennaPoint(i/24,sampleA);antennaPoint((i+1)/24,sampleB);
        link(antennae,antennaIndex,sampleA,sampleB,.0185*(1-i/27));
        midpoint.copy(sampleA).lerp(sampleB,.6);desired.copy(midpoint);desired.x+=side*.009;desired.y+=.009;
        link(antennaHairs,antennaIndex,midpoint,desired,.00045);antennaIndex++;
      }
    }
    for(const mesh of batches)mesh.instanceMatrix.needsUpdate=true;
    diagnostics.plantedFeet=planted;diagnostics.swingingFeet=swinging;diagnostics.stepCycle=Number((cycle%1).toFixed(4));
    diagnostics.maxFootPenetration=Number(Math.max(0,maxPenetration).toFixed(5));diagnostics.virtualCrawl=virtual;
    diagnostics.climbBlend=attachment;diagnostics.trunkSupportedSegments=trunkSupportedSegments;diagnostics.groundSupportedSegments=COUNT-trunkSupportedSegments;
    previousTime=time;lastRoot.copy(root);
  }
  animate();
  return {group,animate,getDiagnostics:()=>({...diagnostics}),dispose(){
    if(disposed)return;disposed=true;group.removeFromParent();anatomy.dispose();
    for(const mesh of batches)mesh.dispose();for(const geometry of geometries)geometry.dispose();contactMaterial.dispose();finish.dispose();
  }};
}
