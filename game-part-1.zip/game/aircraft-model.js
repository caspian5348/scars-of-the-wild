import * as THREE from './vendor/three.module.js';

const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const mix=(a,b,t)=>a+(b-a)*t;
const TAU=Math.PI*2;
const sections=[[-6.9,.025,.03],[-6.65,.39,.02],[-6.1,.79,0],[-5.3,1.04,0],[-4.35,1.23,0],[-2.9,1.27,0],[-.6,1.24,0],[1.8,1.01,.03],[3.6,.70,.12],[5.25,.38,.24],[6.6,.13,.36],[6.85,.035,.38]];
function profile(z) {
  for(let i=1;i<sections.length;i++)if(z<=sections[i][0]){const a=sections[i-1],b=sections[i],t=clamp((z-a[0])/(b[0]-a[0]));return [mix(a[1],b[1],t),mix(a[2],b[2],t)];}
  return sections.at(-1).slice(1);
}
const cabinWindows=[[-3.87,-3.13],[-2.71,-1.97],[-1.55,-.81],[-.39,.35],[.77,1.51]];
const cockpitWindows=[[-5.85,-4.35,.18,1.45],[-5.85,-4.35,1.69,Math.PI-.18]];
const windows=[...cockpitWindows,...cabinWindows.flatMap(([a,b])=>[[a,b,.11,.62],[a,b,Math.PI-.62,Math.PI-.11]])];
const cowling=[-6.36,-5.87,.23,Math.PI-.23];
const inRect=(z,a,r)=>z>r[0]-1e-7&&z<r[1]+1e-7&&a>r[2]-1e-7&&a<r[3]+1e-7;
function hullPoint(z,a,offset=0) {const [r,y]=profile(z);return [Math.cos(a)*(r+offset),y+Math.sin(a)*(r*.89+offset),z];}
function geometry(positions,indices,uvs,colors) {
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));if(colors)g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
  if(indices)g.setIndex(indices);g.computeVertexNormals();return g;
}
function hullPatch(z0,z1,a0,a1,offset=0,zSteps=14,aSteps=18) {
  const p=[],uv=[],ind=[];
  for(let iz=0;iz<=zSteps;iz++)for(let ia=0;ia<=aSteps;ia++){
    const z=mix(z0,z1,iz/zSteps),a=mix(a0,a1,ia/aSteps);p.push(...hullPoint(z,a,offset));uv.push((z+6.9)/3.1,a/Math.PI*1.8);
    if(iz<zSteps&&ia<aSteps){const k=iz*(aSteps+1)+ia;ind.push(k,k+1,k+aSteps+1,k+1,k+aSteps+2,k+aSteps+1);}
  }
  return geometry(p,ind,uv);
}
function fuselage() {
  const zs=[...new Set([...sections.map(s=>s[0]),...Array.from({length:85},(_,i)=>mix(-6.9,6.85,i/84)),...windows.flatMap(w=>[w[0],w[1]]),cowling[0],cowling[1]])].sort((a,b)=>a-b);
  const angles=[...new Set([...Array.from({length:65},(_,i)=>i/64*TAU),...windows.flatMap(w=>[w[2],w[3]]),cowling[2],cowling[3]])].sort((a,b)=>a-b);
  const p=[],uv=[],ind=[];
  for(let iz=0;iz<zs.length;iz++)for(let ia=0;ia<angles.length;ia++) {
    p.push(...hullPoint(zs[iz],angles[ia]));uv.push((zs[iz]+6.9)/3.1,angles[ia]/Math.PI*1.8);
    if(iz===zs.length-1||ia===angles.length-1)continue;
    const z=(zs[iz]+zs[iz+1])*.5,a=(angles[ia]+angles[ia+1])*.5;
    if(windows.some(w=>inRect(z,a,w))||inRect(z,a,cowling))continue;
    const k=iz*angles.length+ia;ind.push(k,k+1,k+angles.length,k+1,k+angles.length+1,k+angles.length);
  }
  return geometry(p,ind,uv);
}
function curve(points,radius=.025,steps=18,radial=6) {return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),steps,radius,radial,false);}
function part(g,color='#ffffff',position=[0,0,0],rotation=[0,0,0],scale=[1,1,1]) {
  const m=new THREE.Matrix4().compose(new THREE.Vector3(...position),new THREE.Quaternion().setFromEuler(new THREE.Euler(...rotation)),new THREE.Vector3(...scale));g.applyMatrix4(m);return {g,color};
}
function merge(parts) {
  const p=[],uv=[],n=[],colors=[];
  for(const {g:original,color} of parts){const g=original.index?original.toNonIndexed():original,tint=new THREE.Color(color),pos=g.attributes.position,norm=g.attributes.normal,u=g.attributes.uv;
    for(let i=0;i<pos.count;i++){p.push(pos.getX(i),pos.getY(i),pos.getZ(i));n.push(norm.getX(i),norm.getY(i),norm.getZ(i));uv.push(u?.getX(i)||0,u?.getY(i)||0);colors.push(tint.r,tint.g,tint.b);}
    if(g!==original)g.dispose();original.dispose();
  }
  const g=geometry(p,null,uv,colors);g.setAttribute('normal',new THREE.Float32BufferAttribute(n,3));return g;
}
function prism(points,thickness=.10) {
  const shape=new THREE.Shape();points.forEach(([x,z],i)=>i?shape.lineTo(x,-z):shape.moveTo(x,-z));shape.closePath();
  const g=new THREE.ExtrudeGeometry(shape,{depth:thickness,bevelEnabled:true,bevelSize:.026,bevelThickness:.025,bevelSegments:2,steps:1});g.rotateX(-Math.PI/2);return g;
}
function panelTexture() {
  const width=512,height=256,data=new Uint8Array(width*height*4),relief=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const h=(Math.sin(x*91.73+y*18.17)*43758.54)%1,grain=Math.abs(h),seam=x%128<1||y%128<1;
    const rivet=(x%128===5||x%128===123)&&(y%13===3||y%13===4);
    const scratch=Math.sin(x*.046+y*2.1)>.998&&grain>.68;
    const v=Math.round(233+grain*18-(seam?45:0)-(rivet?85:0)-(scratch?30:0));const i=(y*width+x)*4;
    data.set([v,Math.max(0,v-2),Math.max(0,v-6),255],i);
    const r=seam?70:rivet?76:Math.round(122+grain*14);relief.set([r,r,r,255],i);
  }
  const make=(bytes,srgb)=>{const texture=new THREE.DataTexture(bytes,width,height,THREE.RGBAFormat);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.generateMipmaps=true;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.anisotropy=4;if(srgb)texture.colorSpace=THREE.SRGBColorSpace;texture.needsUpdate=true;return texture;};
  return {map:make(data,true),bumpMap:make(relief,false)};
}
function wingShape(x) {
  const t=clamp((x-.74)/8.86),round=clamp((x-8.70)/.90);
  return {leading:mix(-2.05,-1.40,t)+round*.79,trailing:mix(.65,1.20,t)-round*.12,y:.65+clamp((x-4.5)/5.1)*.12};
}
function wingGeometry(side,x0,x1,t0=0,t1=1) {
  const p=[],uv=[],ind=[],spanSteps=Math.max(3,Math.ceil((x1-x0)*5)),chordSteps=Math.max(4,Math.ceil((t1-t0)*22));
  for(const surface of [-1,1]) {
    const start=p.length/3;
    for(let ix=0;ix<=spanSteps;ix++)for(let it=0;it<=chordSteps;it++) {
      const x=mix(x0,x1,ix/spanSteps),t=mix(t0,t1,it/chordSteps),s=wingShape(x),thickness=(.19-clamp((x-7.5)/2.1)*.12)*(Math.sqrt(t)*1.05-t*.92),camber=Math.sin(t*Math.PI)*.052;
      p.push(side*x,s.y+camber+surface*thickness,mix(s.leading,s.trailing,t));uv.push(x/2.4,t);
      if(ix<spanSteps&&it<chordSteps){const k=start+ix*(chordSteps+1)+it;const face=[k,k+1,k+chordSteps+1,k+1,k+chordSteps+2,k+chordSteps+1];if(side*surface<0)face.reverse();ind.push(...face);}
    }
  }
  const surfaceSize=(spanSteps+1)*(chordSteps+1);
  for(const ix of [0,spanSteps])for(let it=0;it<chordSteps;it++) {
    const a=ix*(chordSteps+1)+it,b=a+surfaceSize;
    ind.push(a,b,a+1,a+1,b,b+1);
  }
  for(const it of [0,chordSteps])for(let ix=0;ix<spanSteps;ix++) {
    const a=ix*(chordSteps+1)+it,b=a+surfaceSize,next=a+chordSteps+1;
    ind.push(a,next,b,next,next+surfaceSize,b);
  }
  return geometry(p,ind,uv);
}
function nacelle(side) {
  const profiles=[[-3.34,.30],[-3.22,.48],[-3.02,.59],[-2.64,.61],[-1.84,.56],[-1.12,.43],[-.69,.12]],p=[],uv=[],ind=[];
  for(let i=0;i<profiles.length;i++)for(let a=0;a<=36;a++) {
    const theta=a/36*TAU,[z,r]=profiles[i];p.push(side*4.15+Math.cos(theta)*r,.42+Math.sin(theta)*r*.93,z);uv.push((z+3.34)*1.4,a/36);
    if(i<profiles.length-1&&a<36){const k=i*37+a;ind.push(k,k+1,k+37,k+1,k+38,k+37);}
  }
  return geometry(p,ind,uv);
}
function propellerBlade(angle,startT=0,endT=1) {
  const p=[],uv=[],ind=[],rows=20;
  for(const face of [-1,1])for(let i=0;i<=rows;i++)for(let edge=0;edge<2;edge++) {
    const t=mix(startT,endT,i/rows),r=.19+t*1.42,w=.045+Math.pow(Math.sin(t*Math.PI),.65)*.15,sweep=t*t*.10;
    const x=(edge?1:-1)*w+sweep,y=r,z=face*.018+((edge?1:-1)*w)*(.38-t*.27),c=Math.cos(angle),s=Math.sin(angle);
    p.push(x*c-y*s,x*s+y*c,z);uv.push(edge,t);
    if(i<rows){const k=(face===-1?0:(rows+1)*2)+i*2; if(edge===0){if(face===1)ind.push(k,k+1,k+2,k+1,k+3,k+2);else ind.push(k,k+2,k+1,k+1,k+2,k+3);}}
  }
  return geometry(p,ind,uv);
}

/** Flight center and axes match the crash timeline: 19.2m span, local nose −Z. */
export function createAircraftModel() {
  const group=new THREE.Group();group.name='Expedition twin-engine bush plane';
  const resources=new Set(),own=value=>{resources.add(value);return value;},textures=panelTexture();Object.values(textures).forEach(own);
  const cream=own(new THREE.MeshStandardMaterial({...textures,color:'#e4dfcd',vertexColors:true,metalness:.35,roughness:.58,bumpScale:.014,side:THREE.DoubleSide}));
  const green=own(new THREE.MeshStandardMaterial({...textures,color:'#42604f',vertexColors:true,metalness:.28,roughness:.62,bumpScale:.014,side:THREE.DoubleSide}));
  const trim=own(new THREE.MeshStandardMaterial({color:'#bfc0b3',vertexColors:true,metalness:.68,roughness:.33}));
  const dark=own(new THREE.MeshStandardMaterial({color:'#29302c',vertexColors:true,metalness:.22,roughness:.65}));
  const rubber=own(new THREE.MeshStandardMaterial({color:'#222321',vertexColors:true,metalness:0,roughness:.92}));
  const glass=own(new THREE.MeshPhysicalMaterial({color:'#97bcc0',vertexColors:true,metalness:.03,roughness:.10,transparent:true,opacity:.36,depthWrite:false,clearcoat:1,clearcoatRoughness:.06,side:THREE.DoubleSide}));
  const scorch=own(new THREE.MeshStandardMaterial({color:'#29291f',vertexColors:true,metalness:.1,roughness:.99,side:THREE.DoubleSide}));
  const parts=new Map(),damagePanels=[],propellers=[],gear=[],deform=[];
  function add(g,mat=cream,color='#ffffff',position,rotation,scale){if(!parts.has(mat))parts.set(mat,[]);parts.get(mat).push(part(g,color,position,rotation,scale));}
  const box=(size,mat,pos,rot,color='#ffffff')=>add(new THREE.BoxGeometry(...size),mat,color,pos,rot);
  function strut(a,b,r=.025,mat=trim,color='#ffffff') {const start=new THREE.Vector3(...a),end=new THREE.Vector3(...b),d=end.clone().sub(start),g=new THREE.CylinderGeometry(r,r,d.length(),8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()));g.translate(...start.add(end).multiplyScalar(.5).toArray());add(g,mat,color);}
  function mesh(g,mat,name,parent=group){const m=new THREE.Mesh(own(g),mat);m.name=name;m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
  function panel(g,name) {g.computeBoundingBox();const center=g.boundingBox.getCenter(new THREE.Vector3());g.translate(-center.x,-center.y,-center.z);const m=mesh(g,cream,name);m.position.copy(center);damagePanels.push({mesh:m,homePosition:m.position.clone(),homeQuaternion:m.quaternion.clone(),homeScale:m.scale.clone()});return m;}

  add(fuselage());
  panel(merge([part(hullPatch(...cowling,0,7,16),'#fbf7e7')]),'Breakaway forward top cowling');
  for(const window of windows) {
    const [z0,z1,a0,a1]=window;
    add(hullPatch(z0,z1,a0,a1,.008,8,9),glass);
    const outline=[];
    for(let i=0;i<=8;i++)outline.push(hullPoint(mix(z0,z1,i/8),a0,.021));
    for(let i=1;i<=9;i++)outline.push(hullPoint(z1,mix(a0,a1,i/9),.021));
    for(let i=1;i<=8;i++)outline.push(hullPoint(mix(z1,z0,i/8),a1,.021));
    for(let i=1;i<=9;i++)outline.push(hullPoint(z0,mix(a1,a0,i/9),.021));
    add(curve(outline,.028,42,6),cream,'#d0ccb9');
  }
  // A real cockpit behind the open glazing: seats, harnesses, floor, controls, and instrument faces.
  box([1.74,.10,3.4],dark,[0,-.66,-3.8]);
  box([1.60,.35,.17],dark,[0,-.08,-5.47],[.18,0,0]);
  for(const side of [-1,1]) {
    box([.48,.14,.61],rubber,[side*.42,-.46,-4.65]);box([.49,.67,.12],rubber,[side*.42,-.10,-4.26],[-.15,0,0]);
    box([.27,.19,.12],rubber,[side*.42,.29,-4.21],[-.15,0,0]);
    for(const offset of [-.10,.10])strut([side*.42+offset,.19,-4.36],[side*.42+offset,-.42,-4.77],.018,dark,'#aa9e74');
    strut([side*.42,-.43,-5.15],[side*.42,-.09,-5.02],.027,trim);
    add(curve([[side*.42-.15,-.045,-5.05],[side*.42-.13,.04,-5.02],[side*.42+.13,.04,-5.02],[side*.42+.15,-.045,-5.05]],.021,13,6),dark);
    for(let i=0;i<3;i++){const g=new THREE.CylinderGeometry(.073,.073,.018,20);g.rotateX(Math.PI/2);g.translate(side*.39+(i-1)*.18,.0,-5.369);add(g,trim);const face=new THREE.CircleGeometry(.058,18);face.translate(side*.39+(i-1)*.18,.0,-5.356);add(face,dark);}
  }
  box([.18,.29,.72],dark,[0,-.46,-4.89]);strut([0,-.30,-4.90],[0,-.09,-5.00],.016,trim);
  for(const z of [-2.8,-1.5,-.2,.95])for(const side of [-1,1]){box([.53,.12,.63],rubber,[side*.55,-.59,z]);box([.53,.65,.10],rubber,[side*.55,-.22,z+.25],[-.12,0,0]);}

  // Forest-green belt and fine warm stripe follow the actual curved fuselage.
  for(const [a,b] of [[TAU-.31,TAU+.045],[Math.PI-.045,Math.PI+.31]]) {
    add(hullPatch(-5.45,5.62,a,b,.015,64,6),green);
    add(hullPatch(-5.44,5.60,b+.012,b+.042,.020,64,2),cream,'#bea668');
  }
  for(const side of [-1,1]) {
    const doorSide=side===1?[-.65,.77]:[Math.PI-.77,Math.PI+.65],door=[];
    for(let i=0;i<=14;i++)door.push(hullPoint(-.71,mix(...doorSide,i/14),.021));
    for(let i=0;i<=14;i++)door.push(hullPoint(mix(-.71,1.75,i/14),doorSide[1],.021));
    for(let i=0;i<=14;i++)door.push(hullPoint(1.75,mix(doorSide[1],doorSide[0],i/14),.021));
    for(let i=0;i<=14;i++)door.push(hullPoint(mix(1.75,-.71,i/14),doorSide[0],.021));
    add(curve(door,.010,64,5),dark);
    box([.045,.06,.27],trim,[side*1.24,-.13,-.46]);
    box([.44,.055,1.0],dark,[side*1.17,-1.00,.31]);
    for(const z of [-.58,1.61])box([.06,.28,.06],trim,[side*1.13,-.24,z]);
  }

  for(const side of [-1,1]) {
    const tipStart=side===-1?8.25:9.6;
    for(const [start,end] of [[.74,1.8],[1.8,5.8],[5.8,8.15],[8.15,tipStart]]) {
      if(end<=start)continue;
      add(wingGeometry(side,start,end,0,.755));
      if(side===1&&start===5.8)panel(merge([part(wingGeometry(side,start,end,.768,1),'#d9d9c8')]),'Breakaway starboard outer flap');
      else add(wingGeometry(side,start,end,.768,1),cream,'#d8d9c8');
    }
    if(side===-1)panel(merge([part(wingGeometry(side,8.25,9.6),'#e0dfca')]),'Breakaway port wingtip');
    for(const x of [2.2,3.2,5.7,7.6,8.18]) {
      const s=wingShape(x);add(curve([[side*x,s.y+.05,s.leading+.07],[side*x,s.y+.15,mix(s.leading,s.trailing,.33)],[side*x,s.y+.07,s.trailing-.04]],.007,14,5),dark,'#a5a596');
    }
    add(wingGeometry(side,7.63,8.16,.04,.73),green,'#c4d1bb',[0,.007,0]);
    strut([side*.87,-.61,.18],[side*5.10,.61,-.45],.043,trim);
    strut([side*.97,-.59,.67],[side*4.75,.61,.37],.034,trim);
    add(nacelle(side));
    add(new THREE.TorusGeometry(.475,.033,8,32),trim,'#ffffff',[side*4.15,.42,-3.225]);
    add(new THREE.CylinderGeometry(.442,.442,.055,32),dark,'#ffffff',[side*4.15,.42,-3.242],[Math.PI/2,0,0]);
    for(let i=0;i<7;i++){const a=mix(.24,Math.PI-.24,i/6);add(curve([[side*4.15+Math.cos(a)*.606,.42+Math.sin(a)*.567,-2.60],[side*4.15+Math.cos(a)*.596,.42+Math.sin(a)*.557,-2.22]],.016,5,5),dark);}
    box([.38,.14,.47],dark,[side*4.15,-.13,-2.66]);
    strut([side*4.62,.17,-1.70],[side*4.74,.04,-1.30],.066,dark);
    add(prism([[side*.13,4.52],[side*2.62,5.16],[side*3.22,6.38],[side*3.06,6.55],[side*.16,6.39]],.10),cream,'#ffffff',[0,.50,0]);
    add(prism([[side*.24,6.12],[side*2.98,6.31],[side*3.06,6.50],[side*.24,6.36]],.025),green,'#ffffff',[0,.52,0]);
  }
  const finShape=new THREE.Shape();finShape.moveTo(4.35,.50);finShape.bezierCurveTo(4.90,1.10,5.42,3.32,5.72,3.42);finShape.lineTo(6.50,3.50);finShape.quadraticCurveTo(6.60,3.49,6.61,3.30);finShape.lineTo(6.78,.50);finShape.closePath();
  const fin=new THREE.ExtrudeGeometry(finShape,{depth:.12,bevelEnabled:true,bevelSize:.025,bevelThickness:.022,bevelSegments:2,steps:1});fin.rotateY(-Math.PI/2);add(fin,green,'#ffffff',[.06,0,0]);
  for(const side of [-1,1]) {
    add(curve([[side*.091,.70,6.45],[side*.091,1.70,6.39],[side*.091,3.29,6.30]],.012,18,5),dark);
    const crest=new THREE.CircleGeometry(.26,32);crest.rotateY(side*Math.PI/2);crest.translate(side*.096,2.47,5.99);add(crest,cream,'#d4c397');
  }
  strut([0,1.06,-1.0],[0,1.90,-.76],.016,dark);strut([0,1.90,-.76],[0,3.30,5.91],.009,dark);

  for(const [mat,items] of parts) {
    const m=mesh(merge(items),mat,mat===glass?'Curved glazing over open cabin cutouts':mat===green?'Forest-green livery and tail':mat===cream?'Riveted airframe and airfoil wings':'Airframe fittings and cockpit');
    if(mat!==glass)deform.push({mesh:m,base:m.geometry.attributes.position.array.slice()});
  }
  for(const side of [-1,1]) {
    const propeller=new THREE.Group();propeller.name=side===-1?'Port propeller':'Starboard propeller';propeller.position.set(side*4.15,.42,-3.49);group.add(propeller);
    const spinner=new THREE.SphereGeometry(1,22,14);spinner.scale(.28,.28,.39);spinner.translate(0,0,.07);mesh(merge([part(spinner,'#d8d7bf')]),cream,'Streamlined propeller spinner',propeller);
    const blades=[];
    for(let i=0;i<3;i++) {
      const angle=i/3*TAU;blades.push(part(propellerBlade(angle),'#57594f'));
      const tip=propellerBlade(angle,.88,1),p=tip.attributes.position;
      for(let j=0;j<p.count;j++)p.setZ(j,p.getZ(j)-.002);
      tip.computeVertexNormals();blades.push(part(tip,'#d9c88b'));
    }
    mesh(merge(blades),cream,'Three twisted oval propeller blades with pale tips',propeller);propellers.push(propeller);
    const leg=new THREE.Group();leg.name=side===-1?'Port main landing gear':'Starboard main landing gear';leg.position.set(side*1.49,-.45,-.86);group.add(leg);
    const gearMetal=[];
    const support=new THREE.CylinderGeometry(.071,.085,1.22,12);support.translate(side*.13,-.53,0);support.rotateZ(-side*.18);gearMetal.push(part(support,'#b5b6a8'));
    const hub=new THREE.CylinderGeometry(.185,.185,.33,22);hub.rotateZ(Math.PI/2);hub.translate(side*.24,-1.14,0);gearMetal.push(part(hub,'#d0cdb8'));
    for(let i=0;i<6;i++){const a=i/6*TAU,g=new THREE.CylinderGeometry(.025,.025,.35,7);g.rotateZ(Math.PI/2);g.translate(side*.24,-1.14+Math.sin(a)*.13,Math.cos(a)*.13);gearMetal.push(part(g,'#717365'));}
    mesh(merge(gearMetal),trim,'Oleo strut axle and recessed wheel hub',leg);
    const tire=new THREE.TorusGeometry(.335,.155,12,32);tire.rotateY(Math.PI/2);tire.translate(side*.24,-1.14,0);mesh(merge([part(tire)]),rubber,'Rounded heavy bush tire',leg);gear.push(leg);
  }
  const tailTire=new THREE.TorusGeometry(.17,.073,9,20);tailTire.rotateY(Math.PI/2);tailTire.translate(0,-.08,5.89);mesh(merge([part(tailTire)]),rubber,'Tail wheel');
  const scars=[part(hullPatch(-6.28,-4.73,3.3,5.1,.026,18,13),'#55503c'),part(new THREE.SphereGeometry(1,16,10),'#393b32',[-4.15,.43,-1.35],[0,0,0],[.59,.55,.54])];
  const damage=mesh(merge(scars),scorch,'Impact scorches and exposed crumpled metal');damage.visible=false;
  let disposed=false,lastDamage=-1;
  function setDamage(amount) {
    amount=Number.isFinite(amount)?clamp(amount):0;if(disposed||amount===lastDamage)return;lastDamage=amount;damage.visible=amount>.13;damage.scale.setScalar(.65+amount*.35);
    for(const {mesh:m,base} of deform) {
      const p=m.geometry.attributes.position;
      for(let i=0;i<p.count;i++) {
        const x=base[i*3],y=base[i*3+1],z=base[i*3+2],nose=clamp((-z-4.65)/2.25),leftWing=x<-1.6&&z>-2.1&&z<1.45?clamp((-x-1.6)/8):0;
        p.setXYZ(i,x+amount*nose*.075*Math.sin(y*18+z*9),y-amount*leftWing*.68+amount*nose*.12*Math.sin(x*13+z*7),z+amount*nose*.44);
      }
      p.needsUpdate=true;m.geometry.computeVertexNormals();m.geometry.computeBoundingSphere();
    }
  }
  return {group,propellers,gear,damagePanels,setDamage,dispose(){if(disposed)return;disposed=true;group.removeFromParent();for(const resource of resources)resource.dispose();resources.clear();group.clear();}};
}
