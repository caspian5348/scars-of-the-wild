// Original music for Glowhaven. All nodes use the game's existing context/bus.
export const SANCTUARY_BAR_SECONDS=8;
export const SANCTUARY_SCORE=Object.freeze([
  {chord:[50,57,61,64],notes:[[.4,69,3.1],[3.2,66,3],[6.3,64,2.9]]},
  {chord:[47,54,57,62],notes:[[1.0,66,3.6],[4.7,62,3.5]]},
  {chord:[43,50,57,59],notes:[[.6,62,3],[3.6,66,3.1],[6.0,69,3.2]]},
  {chord:[45,52,59,62],notes:[[1.1,71,3.5],[4.9,69,3.2]]},
  {chord:[50,54,57,64],notes:[[.7,66,3.2],[4.1,64,3.3],[6.5,62,3.0]]},
  {chord:[47,54,61,62],notes:[[1.2,61,3.3],[4.6,64,3.5]]},
  {chord:[43,50,54,59],notes:[[.7,62,3.3],[4.1,59,3.4]]},
  {chord:[50,54,57,59],notes:[[1.0,61,3.5],[4.3,62,4.2]]},
].map(bar=>Object.freeze({chord:Object.freeze(bar.chord),notes:Object.freeze(bar.notes.map(Object.freeze))})));
const frequency=midi=>440*2**((midi-69)/12);
const MAX_VOICES=18,OUTPUT_LEVEL=.66,PIANO_LEVEL=.047,PAD_LEVEL=.0065;

/** Frame-driven scheduling has no intervals and never creates an AudioContext. */
export function createSanctuaryMusic(context,destination){
  const owned=new Set(),voices=new Set(),own=node=>(owned.add(node),node);
  const input=own(context.createGain()),tone=own(context.createBiquadFilter()),dry=own(context.createGain()),wet=own(context.createGain()),room=own(context.createConvolver()),output=own(context.createGain());
  tone.type='lowpass';tone.frequency.value=2080;tone.Q.value=.35;dry.gain.value=.87;wet.gain.value=.18;output.gain.value=0;
  input.connect(tone);tone.connect(dry).connect(output);tone.connect(room).connect(wet).connect(output);output.connect(destination);
  const impulse=context.createBuffer(2,Math.ceil(context.sampleRate*2.8),context.sampleRate);let seed=53018;
  for(let channel=0;channel<2;channel++){
    const data=impulse.getChannelData(channel);let last=0;
    for(let i=0;i<data.length;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;last=last*.70+(seed/4294967296*2-1)*.30;const t=i/context.sampleRate;data[i]=t<.021?0:last*Math.exp(-t*2.2)*.61;}
  }
  room.buffer=impulse;
  let playing=false,disposed=false,fadingUntil=0,nextBar=0,barIndex=0,bars=0,notes=0,starts=0;
  function stopVoice(v){
    if(v.ended)return;v.ended=true;voices.delete(v);
    for(const oscillator of v.oscillators){oscillator.onended=null;try{oscillator.stop(context.currentTime);}catch{}}
    for(const node of v.nodes){try{node.disconnect();}catch{}}
  }
  function clear(){for(const v of [...voices])stopVoice(v);}
  function setOutput(value,seconds){
    const now=context.currentTime,param=output.gain;
    if(param.cancelAndHoldAtTime)param.cancelAndHoldAtTime(now);else{const level=param.value;param.cancelScheduledValues(now);param.setValueAtTime(level,now);}
    if(seconds>0)param.linearRampToValueAtTime(value,now+seconds);else param.setValueAtTime(value,now);
  }
  function voice(midi,start,duration,kind,pan){
    if(voices.size>=MAX_VOICES)stopVoice(voices.values().next().value);
    const gain=context.createGain(),filter=context.createBiquadFilter(),panner=context.createStereoPanner();
    const v={start,end:start+duration+.08,gain,oscillators:[],nodes:[gain,filter,panner],ended:false};voices.add(v);
    filter.type='lowpass';filter.frequency.value=kind==='pad'?780:1850;filter.Q.value=.38;panner.pan.value=pan;
    gain.connect(filter).connect(panner).connect(input);
    const peak=kind==='pad'?PAD_LEVEL:PIANO_LEVEL;gain.gain.setValueAtTime(.00001,start);
    if(kind==='pad'){
      gain.gain.linearRampToValueAtTime(peak,start+1.8);
      gain.gain.setValueAtTime(peak*.76,start+duration-2.5);
      gain.gain.exponentialRampToValueAtTime(.00001,start+duration);
    }else{
      gain.gain.linearRampToValueAtTime(peak,start+.018);
      gain.gain.exponentialRampToValueAtTime(peak*.43,start+.48);
      gain.gain.exponentialRampToValueAtTime(.00001,start+duration);
    }
    const partials=kind==='pad'?[[1,1,-2.5],[1,.45,2.5],[2,.045,0]]:[[1,1,0],[2,.18,-1],[3,.04,1.5]];
    let ended=0;
    for(const[multiple,amplitude,detune]of partials){
      const oscillator=context.createOscillator(),level=context.createGain();oscillator.type='sine';oscillator.frequency.value=frequency(midi)*multiple;oscillator.detune.value=detune;level.gain.value=amplitude;
      oscillator.connect(level).connect(gain);v.oscillators.push(oscillator);v.nodes.push(oscillator,level);
      oscillator.onended=()=>{if(++ended===partials.length)stopVoice(v);};oscillator.start(start);oscillator.stop(v.end);
    }
  }
  function schedule(){
    const now=context.currentTime;
    for(const v of [...voices])if(v.end<now-.1)stopVoice(v);
    if(!playing||disposed||context.state!=='running')return;
    if(nextBar<now-.5)nextBar=now+.10;
    while(nextBar<now+.45){
      const bar=SANCTUARY_SCORE[barIndex%SANCTUARY_SCORE.length];
      bar.chord.forEach((midi,i)=>voice(midi,nextBar,9.5,'pad',(i-1.5)*.14));
      bar.notes.forEach(([offset,midi,duration],i)=>voice(midi,nextBar+offset,duration,'piano',i%2?.17:-.15));
      bars++;notes+=bar.notes.length;barIndex++;nextBar+=SANCTUARY_BAR_SECONDS;
    }
  }
  function play(){
    if(disposed||playing||context.state!=='running')return;
    // Re-entry cannot retain a second copy of the old phrase or its future notes.
    clear();playing=true;fadingUntil=0;starts++;nextBar=context.currentTime+.10;
    setOutput(0,0);setOutput(OUTPUT_LEVEL,1.65);schedule();
  }
  function pause(immediate=false){
    if(disposed)return;
    if(immediate){if(!playing&&!fadingUntil&&!voices.size)return;playing=false;fadingUntil=0;setOutput(0,0);clear();return;}
    if(!playing)return;playing=false;const now=context.currentTime,fade=1.3;fadingUntil=now+fade;setOutput(0,fade);
    for(const v of [...voices]){
      if(v.start>now){stopVoice(v);continue;}
      const param=v.gain.gain;if(param.cancelAndHoldAtTime)param.cancelAndHoldAtTime(now);else param.cancelScheduledValues(now);
      param.setTargetAtTime(.00001,now,.32);v.end=Math.min(v.end,now+fade);
      for(const oscillator of v.oscillators)try{oscillator.stop(v.end);}catch{}
    }
  }
  function update({inSanctuary=false,active=false,enabled=true,hidden=false}={}){
    if(disposed)return;
    if(!active||!enabled||hidden||context.state!=='running'){pause(true);return;}
    if(inSanctuary)play();else pause();
    if(fadingUntil&&context.currentTime>=fadingUntil){clear();fadingUntil=0;}
    schedule();
  }
  function getDiagnostics(){return{state:disposed?'disposed':playing?'playing':fadingUntil?'fading':'paused',bar:barIndex%SANCTUARY_SCORE.length,bars,notes,starts,voices:voices.size,oscillators:voices.size*3,maxVoices:MAX_VOICES,timers:0,pianoLevel:PIANO_LEVEL,padLevel:PAD_LEVEL,outputLevel:OUTPUT_LEVEL};}
  function dispose(){if(disposed)return;pause(true);disposed=true;for(const node of owned)node.disconnect();owned.clear();room.buffer=null;}
  return Object.freeze({play,pause,update,dispose,getDiagnostics});
}
export const create=createSanctuaryMusic;
