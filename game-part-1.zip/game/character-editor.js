import * as THREE from './vendor/three.module.js';
import {DEFAULT_CHARACTER,normalizeCharacterProfile,SKIN_TONES,CLOTHING_COLORS,HAIR_COLORS} from './character-profile.js';
import {createCharacterModel} from './character-model.js';
import {preloadScannedHead} from './scanned-character-head.js';
import {HDRLoader} from './vendor/HDRLoader.js';

export function createCharacterEditor({onConfirm=()=>{},onCancel=()=>{}}={}) {
  const element=document.createElement('section');element.className='character-editor';element.hidden=true;
  element.setAttribute('role','dialog');element.setAttribute('aria-modal','true');element.setAttribute('aria-labelledby','character-editor-title');
  element.innerHTML=`<div class="ce-shell">
    <header class="ce-header"><div><p class="ce-eyebrow">SCARS OF THE WILD <span> / </span> A NEW LIFE</p><h1 id="character-editor-title">Create your survivor</h1><p class="ce-subtitle">One life. Make it yours.</p></div><div class="ce-header-mark" aria-hidden="true">S<span>/</span>W</div></header>
    <div class="ce-layout">
      <form class="ce-controls" aria-label="Survivor appearance" novalidate>
        <div class="ce-section-title"><span>01</span><h2>Identity</h2></div>
        <label class="ce-field">Survivor name<input name="name" type="text" maxlength="48" autocomplete="off" spellcheck="false" aria-describedby="ce-name-note"></label><p id="ce-name-note" class="ce-note">Up to 24 characters. Your appearance stays with this life.</p>
        <fieldset class="ce-choice-set"><legend>Build</legend><div class="ce-segmented" data-group="bodyType"></div></fieldset>
        <fieldset class="ce-choice-set"><legend>Skin tone</legend><div class="ce-swatches" data-group="skinTone"></div></fieldset>
        <div class="ce-section-title"><span>02</span><h2>Hair &amp; features</h2></div>
        <div class="ce-field-pair"><label class="ce-field">Hair style<select name="hairStyle"><option value="cropped">Cropped</option><option value="swept">Swept back</option><option value="tied">Tied back</option><option value="shaved">Shaved</option></select></label><label class="ce-field">Facial scar<select name="scar"><option value="none">None</option><option value="brow">Brow</option><option value="cheek">Cheek</option></select></label></div>
        <fieldset class="ce-choice-set"><legend>Hair color</legend><div class="ce-swatches" data-group="hairColor"></div></fieldset>
        <div class="ce-section-title"><span>03</span><h2>Clothing</h2></div>
        <fieldset class="ce-choice-set"><legend>Shirt color</legend><div class="ce-swatches" data-group="topColor"></div></fieldset>
        <fieldset class="ce-choice-set"><legend>Sleeves</legend><div class="ce-segmented" data-group="sleeve"></div></fieldset>
        <p class="ce-appearance-note">Appearance is personal. Every survivor starts on equal footing.</p>
      </form>
      <section class="ce-preview" aria-label="Live survivor preview">
        <div class="ce-preview-heading"><span>YOUR SURVIVOR</span><div class="ce-view-toggle"><button type="button" data-view="body" aria-pressed="true">Full body</button><button type="button" data-view="face" aria-pressed="false">Portrait</button></div></div>
        <div class="ce-canvas-wrap"><canvas aria-label="Three-dimensional preview of your survivor. Use the rotation control to turn the character."></canvas><p class="ce-render-failure" hidden>The 3D preview could not start. Your appearance choices can still be saved.</p><p class="ce-model-status" role="status" hidden>Preparing your survivor…</p></div>
        <div class="ce-preview-caption"><p class="ce-preview-name">Survivor</p><p class="ce-preview-detail">Balanced build · Moss shirt</p></div>
        <div class="ce-rotation"><button type="button" data-turn="-30" aria-label="Rotate survivor left">↶</button><label>Rotate preview<input type="range" min="-180" max="180" value="-14" step="1" aria-label="Preview rotation"></label><button type="button" data-turn="30" aria-label="Rotate survivor right">↷</button></div>
      </section>
    </div>
    <footer class="ce-footer"><button type="button" class="ce-back">Back</button><p>Nothing is waiting to save you.<br><strong>Stay alive.</strong></p><button type="button" class="ce-confirm">Start journey <span aria-hidden="true">→</span></button></footer>
  </div>`;
  document.body.append(element);
  const form=element.querySelector('form'),nameInput=form.elements.name,confirm=element.querySelector('.ce-confirm');
  const caption=element.querySelector('.ce-preview-name'),detail=element.querySelector('.ce-preview-detail');
  const canvas=element.querySelector('canvas'),canvasWrap=element.querySelector('.ce-canvas-wrap');
  const rotation=element.querySelector('[aria-label="Preview rotation"]');
  let profile=normalizeCharacterProfile(DEFAULT_CHARACTER),previousFocus=null,visible=false,disposed=false,model=null,renderer=null,view='face',environmentTarget=null;
  const modelStatus=element.querySelector('.ce-model-status');
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(32,1,.05,30),modelStage=new THREE.Group();scene.add(modelStage);
  scene.add(new THREE.HemisphereLight('#e4e7de','#302c26',.5));
  const key=new THREE.DirectionalLight('#fff4e6',2.25);key.position.set(-1.5,2.8,2.4);key.castShadow=true;key.shadow.mapSize.set(1024,1024);key.shadow.camera.left=-1;key.shadow.camera.right=1;key.shadow.camera.top=2;key.shadow.camera.bottom=-1;key.shadow.normalBias=.006;key.shadow.bias=-.0002;key.shadow.radius=4;scene.add(key);
  const fill=new THREE.DirectionalLight('#dce2e5',.95);fill.position.set(2.8,1.8,2.2);scene.add(fill);
  const rim=new THREE.DirectionalLight('#d0baa0',1.15);rim.position.set(.7,2.4,-2.1);scene.add(rim);
  const groundGeo=new THREE.CircleGeometry(1.4,64),groundMat=new THREE.ShadowMaterial({color:'#080a07',opacity:.45});
  const ground=new THREE.Mesh(groundGeo,groundMat);ground.rotation.x=-Math.PI/2;ground.position.y=.004;ground.receiveShadow=true;scene.add(ground);
  try {renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'low-power'});renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.setClearColor(0x000000,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.92;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;}
  catch(error){canvas.hidden=true;element.querySelector('.ce-render-failure').hidden=false;console.warn('Character preview renderer unavailable',error);}
  preloadScannedHead().catch(()=>{});
  if(renderer)new HDRLoader().loadAsync(new URL('./assets/sky/partly-cloudy-2k.hdr',import.meta.url).href).then(texture=>{
    if(disposed){texture.dispose();return;}
    const pmrem=new THREE.PMREMGenerator(renderer);environmentTarget=pmrem.fromEquirectangular(texture);scene.environment=environmentTarget.texture;scene.environmentIntensity=.4;texture.dispose();pmrem.dispose();render(0);
  }).catch(()=>{});
  function size(){if(!renderer||!visible)return;const width=Math.max(1,canvasWrap.clientWidth),height=Math.max(1,canvasWrap.clientHeight);renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();setCamera();}
  function setCamera(){
    if(view==='face'){camera.position.set(.015,1.624,.66);camera.lookAt(0,1.59,.015);ground.visible=false;}
    else {const z=Math.max(3.22,2.1/Math.max(.58,camera.aspect));camera.position.set(.055,1.12,z);camera.lookAt(0,.93,0);ground.visible=true;}
  }
  const resizeObserver=new ResizeObserver(size);resizeObserver.observe(canvasWrap);
  function choices(group,entries,swatches=false){
    const parent=element.querySelector(`[data-group="${group}"]`);
    for(const [value,label,color] of entries){
      const button=document.createElement('button');button.type='button';button.className=swatches?'ce-swatch':'ce-choice';button.dataset.value=String(value);button.setAttribute('aria-pressed','false');
      button.setAttribute('aria-label',`${group==='skinTone'?'Skin tone':group==='hairColor'?'Hair color':group==='topColor'?'Shirt color':group==='bodyType'?'Build':'Sleeves'}: ${label}`);
      if(swatches){const chip=document.createElement('span');chip.className='ce-swatch-chip';chip.style.setProperty('--ce-swatch',color);chip.setAttribute('aria-hidden','true');button.append(chip);}
      const text=document.createElement('span');text.textContent=label;button.append(text);button.addEventListener('click',()=>change(group,group==='skinTone'?Number(value):value));parent.append(button);
    }
  }
  choices('bodyType',[['slender','Slender'],['balanced','Balanced'],['broad','Broad']]);
  choices('skinTone',SKIN_TONES.map((entry,index)=>[index,entry.label,entry.color]),true);
  choices('hairColor',Object.entries(HAIR_COLORS).map(([id,entry])=>[id,entry.label,entry.color]),true);
  choices('topColor',Object.entries(CLOTHING_COLORS).map(([id,entry])=>[id,entry.label,entry.color]),true);
  choices('sleeve',[['rolled','Rolled sleeves'],['long','Long sleeves']]);
  function refreshControls(){
    for(const group of ['bodyType','skinTone','hairColor','topColor','sleeve'])for(const button of element.querySelectorAll(`[data-group="${group}"] button`))button.setAttribute('aria-pressed',String(button.dataset.value===String(profile[group])));
    for(const key of ['hairStyle','scar'])form.elements[key].value=profile[key];
    caption.textContent=profile.name;detail.textContent=`${profile.bodyType[0].toUpperCase()+profile.bodyType.slice(1)} build · ${CLOTHING_COLORS[profile.topColor].label} shirt`;
    element.dataset.bodyType=profile.bodyType;element.dataset.skinTone=String(profile.skinTone);element.dataset.sleeve=profile.sleeve;
  }
  function change(key,value){profile=normalizeCharacterProfile({...profile,[key]:value});refreshControls();if(key==='name')return;replaceModel();}
  function replaceModel(){
    if(model)model.dispose();model=createCharacterModel(profile);const current=model;
    model.root.visible=false;modelStatus.hidden=false;modelStatus.textContent='Preparing your survivor…';canvas.setAttribute('aria-busy','true');
    modelStage.add(model.root);modelStage.rotation.y=Number(rotation.value)*Math.PI/180;
    Promise.resolve(model.ready).then(loaded=>{if(disposed||model!==current)return;current.root.visible=loaded!==false;modelStatus.hidden=loaded!==false;modelStatus.textContent=loaded===false?'The survivor model could not load. Reload to try again.':'';canvas.setAttribute('aria-busy','false');canvas.dataset.modelLoaded=String(loaded!==false);render(0);});render(0);
  }
  nameInput.addEventListener('input',()=>change('name',nameInput.value));
  nameInput.addEventListener('blur',()=>{nameInput.value=profile.name;});
  for(const key of ['hairStyle','scar'])form.elements[key].addEventListener('change',()=>change(key,form.elements[key].value));
  form.addEventListener('submit',event=>event.preventDefault());
  rotation.addEventListener('input',()=>{modelStage.rotation.y=Number(rotation.value)*Math.PI/180;render(0);});
  for(const button of element.querySelectorAll('[data-turn]'))button.addEventListener('click',()=>{rotation.value=String(Math.max(-180,Math.min(180,Number(rotation.value)+Number(button.dataset.turn))));rotation.dispatchEvent(new Event('input'));});
  for(const button of element.querySelectorAll('[data-view]'))button.addEventListener('click',()=>{view=button.dataset.view;for(const other of element.querySelectorAll('[data-view]'))other.setAttribute('aria-pressed',String(other===button));setCamera();render(0);});
  const cancel=()=>{close();onCancel();};
  element.querySelector('.ce-back').addEventListener('click',cancel);
  confirm.addEventListener('click',()=>{profile=normalizeCharacterProfile({...profile,name:nameInput.value});const chosen={...profile};close();onConfirm(chosen);});
  function onKey(event){
    if(!visible)return;
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();cancel();return;}
    if(event.key==='Tab'){
      const focusable=[...element.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled])')].filter(node=>node.getClientRects().length);
      const first=focusable[0],last=focusable[focusable.length-1];
      if(event.shiftKey&&(document.activeElement===first||!element.contains(document.activeElement))){event.preventDefault();last?.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||!element.contains(document.activeElement))){event.preventDefault();first?.focus();}
    }
    // Keep movement and inventory shortcuts inside the modal while editing text.
    event.stopPropagation();
  }
  element.addEventListener('keydown',onKey);element.addEventListener('keyup',event=>event.stopPropagation());
  element.addEventListener('pointerdown',event=>event.stopPropagation());element.addEventListener('click',event=>event.stopPropagation());
  function open(value=DEFAULT_CHARACTER,{continuing=false}={}){
    if(disposed)return;previousFocus=document.activeElement;profile=normalizeCharacterProfile(value);visible=true;element.hidden=false;
    element.dataset.continuing=String(continuing);element.querySelector('.ce-eyebrow').lastChild.textContent=continuing?' YOUR LIFE':' A NEW LIFE';
    confirm.replaceChildren(document.createTextNode(continuing?'Enter wilderness ':'Start journey '));const arrow=document.createElement('span');arrow.setAttribute('aria-hidden','true');arrow.textContent='→';confirm.append(arrow);
    nameInput.value=profile.name;rotation.value='-10';view='face';for(const button of element.querySelectorAll('[data-view]'))button.setAttribute('aria-pressed',String(button.dataset.view==='face'));
    refreshControls();size();replaceModel();nameInput.focus({preventScroll:true});
  }
  function close(){visible=false;element.hidden=true;if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});}
  function render(dt){if(!visible||disposed)return;model?.update(dt);if(renderer)renderer.render(scene,camera);}
  return {element,open,close,update:render,getProfile:()=>({...profile}),
    dispose(){if(disposed)return;close();disposed=true;resizeObserver.disconnect();model?.dispose();groundGeo.dispose();groundMat.dispose();environmentTarget?.dispose();renderer?.dispose();element.remove();}};
}
