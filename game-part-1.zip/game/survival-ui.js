import {ITEMS,RECIPES,BUILDINGS} from './survival-catalog.js';
const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const title=id=>ITEMS[id]?.name||String(id||'Unknown item').replaceAll('_',' ');
export function createSurvivalUI({getSystem,onClose,onCraft,onEquip,onConsume,onBuild,onDrop,onRepair,onStorage,species={}}){
  const overlay=el('section','survival-overlay');overlay.id='survival-panel';overlay.hidden=true;overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Inventory and crafting');
  const shell=el('div','survival-shell'),header=el('header','survival-header'),heading=el('div'),headingTitle=el('h2',null,'Make a life here.');headingTitle.id='survival-panel-title';heading.append(el('p','eyebrow','SCARS OF THE WILD / SURVIVAL'),headingTitle);overlay.setAttribute('aria-labelledby',headingTitle.id);
  const close=el('button','utility-button','Return to wilderness  I / Esc');close.type='button';close.onclick=onClose;header.append(heading,close);
  const tabs=el('nav','survival-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Survival sections');
  const status=el('p','survival-status'),content=el('div','survival-content'),notice=el('p','survival-notice');content.id='survival-panel-content';content.setAttribute('role','tabpanel');content.tabIndex=-1;notice.setAttribute('role','status');notice.setAttribute('aria-live','polite');notice.setAttribute('aria-atomic','true');
  shell.append(header,tabs,status,content,notice,el('footer','survival-footer','E gather / interact · F or click use weapon · I inventory · B building · R rotate placement · 1–6 quick equip · Stay alive.'));overlay.append(shell);document.querySelector('#game').append(overlay);
  let tab='inventory',selected=null,storageId=null,storageItems=[],previousFocus=null;
  const recipeFilters={craft:{query:'',availableOnly:false},build:{query:'',availableOnly:false}};
  const tabButtons=new Map();for(const [id,name] of [['inventory','Inventory'],['craft','Crafting'],['build','Building'],['journal','Field journal'],['storage','Storage']]){const b=el('button','survival-tab',name);b.id=`survival-tab-${id}`;b.type='button';b.setAttribute('role','tab');b.setAttribute('aria-controls',content.id);b.onclick=()=>{tab=id;notice.textContent='';render();};tabs.append(b);tabButtons.set(id,b);}
  function action(label,fn,disabled=false,focusKey=''){const b=el('button','survival-action',label);b.type='button';b.disabled=disabled;b.onclick=fn;if(focusKey)b.dataset.focusKey=focusKey;return b;}
  function stackDetails(slot,elapsed){
    const item=ITEMS[slot.id]||{},details=[];
    if(slot.durability!==undefined)details.push(slot.durability<=0?'Broken':`Durability ${Math.round(slot.durability)}/${item.durability||Math.round(slot.durability)}`);
    if(slot.expiresAt!==undefined){const remaining=slot.expiresAt-elapsed;details.push(remaining<=0?'Spoiled':remaining<60?'Spoils in under 1 minute':`Fresh for ${Math.ceil(remaining/60)} minutes`);}
    return details.join(' · ');
  }
  function costText(cost,state){return Object.entries(cost||{}).map(([id,n])=>`${title(id)} ${getSystem().count(id)}/${n}`).join(' · ');}
  function resultText(result){return typeof result==='string'?result:result?.message||result?.reason||'';}
  function render(){
    const sys=getSystem();if(!sys)return;const focused=document.activeElement,focusKey=content.contains(focused)?focused.dataset.focusKey:null;
    const selection=focusKey&&typeof focused.selectionStart==='number'?{start:focused.selectionStart,end:focused.selectionEnd}:null;
    const state=sys.snapshot(),inventory=state.inventory||[],weight=inventory.reduce((n,s)=>n+(ITEMS[s.id]?.weight||0)*s.count,0),capacity=sys.getCapacity?.();
    status.textContent=`${inventory.length}${capacity?`/${capacity.slots}`:''} slots · ${weight.toFixed(1)}${capacity?`/${capacity.weight}`:''} kg · Hunger ${Math.round(state.hunger??100)}% · Water ${Math.round(state.thirst??100)}% · ${state.discoveredBiomes?.length||0} biomes understood`;
    if(tab==='storage'&&!storageId)tab='inventory';
    for(const [id,b] of tabButtons){b.classList.toggle('selected',id===tab);b.setAttribute('aria-selected',String(id===tab));b.tabIndex=id===tab?0:-1;b.hidden=id==='storage'&&!storageId;}
    content.setAttribute('aria-labelledby',tabButtons.get(tab)?.id||'survival-tab-inventory');
    content.replaceChildren();
    if(tab==='inventory'){
      if(!inventory.some(slot=>slot.uid===selected))selected=inventory[0]?.uid||null;
      const grid=el('div','inventory-grid');grid.setAttribute('aria-label','Inventory slots');
      for(const slot of inventory){const item=ITEMS[slot.id]||{},button=el('button','inventory-slot');button.type='button';button.classList.toggle('equipped',Object.values(state.equipment||{}).includes(slot.uid));button.classList.toggle('selected',selected===slot.uid);
        const glyph=el('span',`item-glyph ${item.kind||''}`,item.tool==='axe'?'⚒':item.tool==='pickaxe'?'⛏':item.kind==='food'?'♧':item.kind==='weapon'?'↗':item.kind==='material'?'◇':'✦');glyph.setAttribute('aria-hidden','true');button.dataset.focusKey=`item-${slot.uid}`;button.setAttribute('aria-pressed',String(selected===slot.uid));
        button.append(glyph,el('strong',null,item.name||slot.id),el('small',null,`${slot.count} × ${item.weight||0} kg${stackDetails(slot,state.elapsed)?` · ${stackDetails(slot,state.elapsed)}`:''}${Object.values(state.equipment||{}).includes(slot.uid)?' · Equipped':''}`));button.onclick=()=>{selected=slot.uid;render();};grid.append(button);}
      if(!inventory.length)grid.append(el('p','empty-inventory','Your pack is empty. Gather loose branches, stones and plant fiber to make your first tools.'));
      const detail=el('aside','item-detail'),slot=inventory.find(s=>s.uid===selected)||inventory[0];if(slot){const item=ITEMS[slot.id]||{};detail.append(el('p','eyebrow',item.kind||'ITEM'),el('h3',null,item.name||slot.id),el('p',null,item.description||''));
        if(item.tier)detail.append(el('p','recipe-meta',`Tool tier ${item.tier}`));if(stackDetails(slot,state.elapsed))detail.append(el('p','recipe-meta',stackDetails(slot,state.elapsed)));
        if(item.slot)detail.append(action('Equip',()=>showResult(onEquip(slot.uid),`Equipped ${title(slot.id)}.`),false,`equip-${slot.uid}`));
        if(item.nutrition)detail.append(action('Use / consume',()=>showResult(onConsume(slot.uid),`Used ${title(slot.id)}.`),false,`consume-${slot.uid}`));
        if(item.repair)detail.append(action('Repair',()=>showResult(onRepair(slot.uid),`Repaired ${title(slot.id)}.`),false,`repair-${slot.uid}`));
        detail.append(action('Drop one',()=>showResult(onDrop(slot.uid),`Dropped ${title(slot.id)}.`),false,`drop-${slot.uid}`));
      }else detail.append(el('h3',null,'Begin with the ground.'),el('p',null,'Loose resources can be picked up by hand. An axe cuts standing trees, and a pickaxe breaks mineral deposits.'));
      content.append(grid,detail);
    }else if(tab==='craft'||tab==='build'){
      const section=tab,crafting=section==='craft',filter=recipeFilters[section],catalog=crafting?RECIPES:BUILDINGS;
      const browser=el('div','recipe-browser'),toolbar=el('div','recipe-toolbar'),searchLabel=el('label','recipe-search-label'),search=el('input','recipe-search');
      search.id=`survival-search-${section}`;search.type='search';search.placeholder=crafting?'Tools, materials, food…':'Shelters, stations, storage…';search.value=filter.query;search.autocomplete='off';search.dataset.focusKey=`search-${section}`;
      searchLabel.htmlFor=search.id;searchLabel.append(el('span',null,crafting?'Search recipes':'Search buildings'),search);
      const availableLabel=el('label','recipe-available-toggle'),available=el('input');available.type='checkbox';available.checked=filter.availableOnly;available.dataset.focusKey=`available-${section}`;availableLabel.append(available,el('span',null,'Available now'));
      toolbar.append(searchLabel,availableLabel);
      const summary=el('p','recipe-summary'),list=el('div','recipe-list recipe-grid');summary.id=`recipe-summary-${section}`;summary.setAttribute('role','status');summary.setAttribute('aria-live','polite');search.setAttribute('aria-describedby',summary.id);
      const entries=Object.entries(catalog).map(([id,recipe])=>{
        const check=crafting?sys.canCraft(id):sys.canBuild(id),available=typeof check==='boolean'?check:!!check?.ok;
        const outputId=Object.keys(recipe.outputs||{})[0],product=ITEMS[outputId];
        const name=crafting?(product?.name||recipe.name.replace(/^craft\s+/i,'')):recipe.name;
        const searchText=[name,recipe.name,recipe.description,recipe.station,Object.keys(recipe.cost||{}).map(title).join(' '),Object.keys(recipe.outputs||{}).map(title).join(' ')].filter(Boolean).join(' ').toLowerCase();
        return{id,recipe,check,available,name,product,outputId,searchText};
      }).sort((a,b)=>Number(b.available)-Number(a.available));
      function renderRecipes(){
        const query=filter.query.trim().toLowerCase(),matching=entries.filter(entry=>!query||entry.searchText.includes(query));
        const visible=matching.filter(entry=>!filter.availableOnly||entry.available);list.replaceChildren();
        summary.textContent=`${visible.length} ${crafting?'recipes':'buildings'} shown · ${matching.filter(entry=>entry.available).length} available now`;
        for(const entry of visible){
          const{id,recipe,check,available:ready,name,product,outputId}=entry,row=el('article','recipe-card compact-recipe-card');row.classList.toggle('locked',!ready);
          const text=el('div','recipe-copy'),heading=el('div','recipe-heading');heading.append(el('h3',null,name));
          if(crafting&&recipe.outputs?.[outputId]>1)heading.append(el('span','recipe-yield',`Makes ${recipe.outputs[outputId]}`));
          text.append(heading);
          if(recipe.description&&recipe.description!==recipe.name&&recipe.description!==name)text.append(el('p','recipe-description',recipe.description));
          const costs=el('div','recipe-cost-chips');
          for(const[itemId,needed]of Object.entries(recipe.cost||{})){const have=sys.count(itemId),chip=el('span',`recipe-cost-chip ${have>=needed?'enough':'short'}`,`${title(itemId)} ${have}/${needed}`);chip.setAttribute('aria-label',`${title(itemId)}, ${have} of ${needed} required`);costs.append(chip);}
          text.append(costs);
          const station=recipe.station?`Near ${BUILDINGS[recipe.station]?.name||recipe.station.replaceAll('_',' ')}`:'By hand';
          text.append(el('p','recipe-meta',`${station}${product?.tier?` · Tier ${product.tier}`:''}${recipe.requiresFoundation?' · Snaps to a foundation':''}`));
          const feedback=el('p',ready?'recipe-ready':'recipe-block',ready?'Ready to make':resultText(check));feedback.id=`recipe-feedback-${section}-${id}`;text.append(feedback);
          const button=action(crafting?'Craft':'Place',()=>{if(crafting)showResult(onCraft(id),`Crafted ${name}.`);else onBuild(id);},!ready,`${section}-${id}`);
          button.setAttribute('aria-label',`${crafting?'Craft':'Place'} ${name}`);button.setAttribute('aria-describedby',feedback.id);
          row.append(text,button);list.append(row);
        }
        if(!visible.length){const empty=el('div','recipe-empty');empty.append(el('h3',null,'Nothing matches yet.'),el('p',null,filter.availableOnly?'Try another search, gather supplies, or move near the required station.':'Try a tool, food, material or station name.'));
          empty.append(action('Clear filters',()=>{filter.query='';filter.availableOnly=false;search.value='';available.checked=false;renderRecipes();search.focus();},false,`clear-${section}`));list.append(empty);}
      }
      search.oninput=()=>{filter.query=search.value;renderRecipes();};available.onchange=()=>{filter.availableOnly=available.checked;renderRecipes();};
      renderRecipes();browser.append(toolbar,summary,list);content.append(browser);
    }else if(tab==='journal'){
      const list=el('div','journal-grid');const known=new Set(state.discoveredBiomes||[]);list.append(el('article','journal-card','Explore and gather to learn new materials. Workbenches refine your equipment; furnaces turn ores into metal. Cave minerals, obsidian and frost crystals unlock the strongest equipment.'));
      for(const [id,s] of Object.entries(species)){const homes=s.biomes||[s.biome].filter(Boolean),seen=homes.some(b=>known.has(b)),card=el('article','journal-card');card.append(el('p','eyebrow',homes.join(' / ').toUpperCase()),el('h3',null,seen?s.name:'Unstudied wildlife'),el('p',null,seen?(s.description||`${s.behavior||s.temperament||'Wild'} animal. Watch its movement and keep your distance.`):'Explore its habitat to add this animal to your field notes.'));list.append(card);}
      content.append(list);
    }else if(tab==='storage'){
      const list=el('div','recipe-list');list.append(el('h3',null,'Camp storage'));
      function transferRow(slot,direction){
        const taking=direction==='take',row=el('article','recipe-card'),copy=el('div'),controls=el('div');
        copy.append(el('h3',null,`${title(slot.id)} × ${slot.count}`));
        const details=stackDetails(slot,state.elapsed);if(details)copy.append(el('p','recipe-meta',details));
        if(!taking&&Object.values(state.equipment||{}).includes(slot.uid))copy.append(el('p','recipe-meta','Equipped — storing it will unequip it.'));
        const verb=taking?'Take':'Store',success=taking?'Taken from storage.':'Stored safely.';
        controls.append(action(`${verb} one`,()=>showResult(onStorage(storageId,slot.uid,1,direction),success),false,`${direction}-${slot.uid}`));
        if(slot.count>1){controls.append(document.createTextNode(' '),action(`${verb} stack`,()=>showResult(onStorage(storageId,slot.uid,slot.count,direction),success),false,`${direction}-stack-${slot.uid}`));}
        row.append(copy,controls);return row;
      }
      if(!storageItems.length)list.append(el('p',null,'This chest is empty. Store supplies from your pack below.'));
      for(const slot of storageItems)list.append(transferRow(slot,'take'));
      list.append(el('h3',null,'Your pack'));
      if(!inventory.length)list.append(el('p',null,'Your pack is empty.'));
      for(const slot of inventory)list.append(transferRow(slot,'put'));
      content.append(list);
    }
    if(focusKey){const replacement=[...content.querySelectorAll('[data-focus-key]')].find(button=>button.dataset.focusKey===focusKey&&!button.disabled)||[...content.querySelectorAll('[data-focus-key]')].find(button=>button.dataset.focusKey===`item-${selected}`);(replacement||content).focus({preventScroll:true});if(selection&&replacement?.setSelectionRange)replacement.setSelectionRange(selection.start,selection.end);}
  }
  function showResult(result,success=''){
    if(result?.then){notice.textContent='Waiting for the server…';result.then(value=>{notice.textContent=resultText(value)||(value?.ok?success:'');render();}).catch(error=>{notice.textContent=error?.message||'The action could not reach the server.';});return;}
    notice.textContent=resultText(result)||(result?.ok?success:'');render();
  }
  overlay.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();onClose();return;}
    const visibleTabs=[...tabButtons.values()].filter(button=>!button.hidden);
    if(visibleTabs.includes(document.activeElement)&&['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){
      event.preventDefault();event.stopPropagation();const current=visibleTabs.indexOf(document.activeElement);
      const next=event.key==='Home'?0:event.key==='End'?visibleTabs.length-1:(current+(event.key==='ArrowRight'?1:-1)+visibleTabs.length)%visibleTabs.length;
      visibleTabs[next].click();visibleTabs[next].focus();return;
    }
    if(event.key==='Tab'){
      const focusable=[...overlay.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex="0"]')].filter(node=>!node.closest('[hidden]')&&node.tabIndex>=0);
      const first=focusable[0],last=focusable.at(-1);
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
    }
  });
  return{open(section='inventory'){if(overlay.hidden)previousFocus=document.activeElement;tab=tabButtons.has(section)?section:'inventory';notice.textContent='';overlay.hidden=false;render();close.focus();},
    close(){overlay.hidden=true;if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});previousFocus=null;},render,showResult,
    setStorage(id,items){storageId=id||null;storageItems=Array.isArray(items)?items:[];if(!overlay.hidden&&tab==='storage')render();},
    get visible(){return !overlay.hidden;},get tab(){return tab;},dispose(){overlay.remove();}};
}
