import * as THREE from './vendor/three.module.js';
import {STORM_CENTER} from './biomes.js';
import {createStormHurricane} from './storm-hurricane.js';
import {createStormNoiseTexture} from './storm-noise.js';

/** Local storm volume: weather follows the viewer while the biome controls its strength. */
export function createStormWeather({scene,heightAt,onThunder=()=>{}}) {
  const group=new THREE.Group();group.name='Storm rain, cloud ceiling and lightning';scene.add(group);
  const owned=[];
  const keep=value=>(owned.push(value),value);
  const stormNoise=keep(createStormNoiseTexture());
  const hurricane=createStormHurricane({scene,heightAt,noiseTexture:stormNoise});
  let randomState=42793;
  const random=()=>{randomState=(Math.imul(randomState,1664525)+1013904223)>>>0;return randomState/4294967296;};
  const clouds=keep(new THREE.ShaderMaterial({
    side:THREE.BackSide,transparent:true,depthWrite:false,fog:false,
    uniforms:{time:{value:0},strength:{value:0},flash:{value:0},lightningDirection:{value:new THREE.Vector3(0,.4,-1).normalize()},stormNoise:{value:stormNoise}},
    vertexShader:'varying vec3 ray;void main(){ray=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:`
      varying vec3 ray;uniform float time;uniform float strength;uniform float flash;uniform vec3 lightningDirection;uniform sampler2D stormNoise;
      void main(){vec3 dir=normalize(ray);vec2 p=dir.xz/max(.18,dir.y+.32)*3.2+vec2(time*.018,-time*.009);
        vec3 cloud=texture2D(stormNoise,p*.13+vec2(time*.0008,-time*.0004)).rgb;
        float billow=cloud.r;float folds=texture2D(stormNoise,p*.30+cloud.gb*.12-vec2(time*.001,0.)).g;
        vec3 c=mix(vec3(.027,.031,.046),vec3(.13,.14,.18),smoothstep(.26,.82,billow));
        c+=vec3(.018,.016,.027)*folds;c=mix(vec3(.12,.13,.17),c,smoothstep(-.18,.45,dir.y));
        float cloudLight=pow(max(0.,dot(dir,lightningDirection)),13.);
        c+=vec3(.58,.07,1.0)*flash*(.25+cloudLight);gl_FragColor=vec4(c,strength);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
  }));
  const sky=new THREE.Mesh(keep(new THREE.SphereGeometry(1100,24,16)),clouds);sky.renderOrder=-20;sky.frustumCulled=false;group.add(sky);
  const count=1500,positions=new Float32Array(count*6),seeds=Array.from({length:count},()=>({x:random()*80-40,y:random()*38,z:random()*80-40,length:.55+random()*.7}));
  const geometry=keep(new THREE.BufferGeometry());geometry.setAttribute('position',new THREE.BufferAttribute(positions,3).setUsage(THREE.DynamicDrawUsage));
  const rainMaterial=keep(new THREE.LineBasicMaterial({color:'#b4c8d2',transparent:true,opacity:.35,depthWrite:false}));
  const rain=new THREE.LineSegments(geometry,rainMaterial);rain.frustumCulled=false;group.add(rain);
  const splashGeometry=keep(new THREE.RingGeometry(.07,.095,8));splashGeometry.rotateX(-Math.PI/2);
  const splashMaterial=keep(new THREE.MeshBasicMaterial({color:'#afc0c8',transparent:true,opacity:.24,depthWrite:false,side:THREE.DoubleSide}));
  const splashes=keep(new THREE.InstancedMesh(splashGeometry,splashMaterial,70));splashes.frustumCulled=false;group.add(splashes);
  const splashSeeds=Array.from({length:70},()=>({x:random()*34-17,z:random()*34-17,phase:random(),y:0}));
  const dummy=new THREE.Object3D();let splashAnchor={x:Infinity,z:Infinity};
  const debrisGeo=keep(new THREE.BufferGeometry());debrisGeo.setAttribute('position',new THREE.Float32BufferAttribute([-.12,0,0,.16,.01,.015,.07,.05,.15],3));debrisGeo.computeVertexNormals();
  const debrisMaterial=keep(new THREE.MeshBasicMaterial({color:'#545448',side:THREE.DoubleSide,transparent:true,opacity:.8}));
  const debris=keep(new THREE.InstancedMesh(debrisGeo,debrisMaterial,72));debris.frustumCulled=false;debris.name='Wind-torn bark fragments';group.add(debris);
  const debrisSeeds=Array.from({length:72},()=>({x:random()*54,z:random()*54,y:random()*10,spin:random()*6.28,size:.45+random()*1.6}));
  const bolts=Array.from({length:4},()=>{
    const points=new Float32Array(768*3),geo=keep(new THREE.BufferGeometry());geo.setAttribute('position',new THREE.BufferAttribute(points,3).setUsage(THREE.DynamicDrawUsage));geo.setDrawRange(0,0);
    const material=keep(new THREE.LineBasicMaterial({color:'#e4cfff',transparent:true,opacity:0,depthWrite:false,fog:false,toneMapped:false,blending:THREE.AdditiveBlending}));
    const mesh=new THREE.LineSegments(geo,material);mesh.frustumCulled=false;mesh.visible=false;mesh.renderOrder=4;group.add(mesh);
    return{points,geo,material,mesh,age:10,duration:1,delay:0};
  });
  let nextStrike=1.2,burstCount=0,boltCount=0;const thunder=[];
  function drawBolt(bolt,origin,direction,crawler) {
    let offset=0;const nodes=[],length=crawler?75+random()*70:70+random()*65;
    function segment(a,b){if(offset+6<=bolt.points.length){bolt.points.set([a.x,a.y,a.z,b.x,b.y,b.z],offset);offset+=6;}}
    let previous=origin.clone();nodes.push(previous);
    for(let i=1;i<=30;i++) {
      const t=i/30,p=origin.clone();
      if(crawler){p.addScaledVector(direction,length*t);p.y+=Math.sin(t*4.3)*9+(random()-.5)*9;p.x+=(random()-.5)*6;p.z+=(random()-.5)*6;}
      else {p.y-=length*t;p.x+=Math.sin(t*10)*7+(random()-.5)*7;p.z+=Math.sin(t*8.1)*6+(random()-.5)*6;p.y=Math.max(heightAt(p.x,p.z)+1,p.y);}
      segment(previous,p);nodes.push(p);previous=p;
    }
    for(let branch=3;branch<27;branch+=3) {
      let p=nodes[branch].clone();const side=branch%2?1:-1;
      const spread=new THREE.Vector3(direction.z*side,-.18+random()*.36,-direction.x*side).normalize();
      for(let j=0;j<5;j++) {
        const next=p.clone().addScaledVector(spread,3+random()*4);next.y+=(random()-.65)*4;next.x+=(random()-.5)*3;next.z+=(random()-.5)*3;
        segment(p,next);
        if(j===2){const fork=next.clone().add(new THREE.Vector3((random()-.5)*13,-5-random()*5,(random()-.5)*13));segment(next,fork);}
        p=next;
      }
    }
    bolt.geo.setDrawRange(0,offset/3);bolt.geo.attributes.position.needsUpdate=true;
  }
  function strike(camera,time){
    nextStrike=time+.9+random()*1.6;burstCount++;
    const count=2+(random()>.40?1:0),baseAngle=random()*Math.PI*2;
    const radius=55+random()*135;
    let distance=0;
    for(let i=0;i<count;i++) {
      const angle=baseAngle+(i-(count-1)/2)*(.32+random()*.3),x=STORM_CENTER.x+Math.cos(angle)*radius,z=STORM_CENTER.z+Math.sin(angle)*radius*.82;
      distance=Math.hypot(x-camera.x,z-camera.z);
      const origin=new THREE.Vector3(x,heightAt(STORM_CENTER.x,STORM_CENTER.z)+112+random()*32,z);
      const direction=new THREE.Vector3(-Math.sin(angle),0,Math.cos(angle));
      drawBolt(bolts[i],origin,direction,random()>.30);bolts[i].age=0;bolts[i].delay=i*.13;bolts[i].duration=.75+random()*.42;
      if(i===0)clouds.uniforms.lightningDirection.value.copy(origin).sub(camera).normalize();boltCount++;
    }
    if(distance<520)thunder.push({remaining:.35+distance/343,strength:(.70+random()*.3)*(1-THREE.MathUtils.smoothstep(distance,240,520))});
  }
  return {
    update(time,dt,camera,strength,{reducedMotion=false,viewHeading=0}={}){
      const amount=THREE.MathUtils.clamp(strength,0,1),distance=Math.hypot(camera.x-STORM_CENTER.x,camera.z-STORM_CENTER.z);
      const distantVisibility=1-THREE.MathUtils.smoothstep(distance,1300,2150);
      group.visible=distantVisibility>.005;sky.visible=rain.visible=splashes.visible=debris.visible=amount>.005;
      sky.position.copy(camera);clouds.uniforms.time.value=time;clouds.uniforms.strength.value=amount;
      if(time>nextStrike&&distantVisibility>.01)strike(camera,time);
      let flash=0;
      for(const bolt of bolts){bolt.age+=dt;const age=bolt.age-bolt.delay;bolt.mesh.visible=age>=0&&age<bolt.duration;
        const pulse=bolt.mesh.visible?Math.min(1,age/.055)*Math.pow(1-age/bolt.duration,.65)*distantVisibility:0;
        bolt.material.opacity=pulse;flash=Math.max(flash,pulse);
      }
      clouds.uniforms.flash.value=reducedMotion?0:flash*.8;
      hurricane.update(time,camera,flash,{reducedMotion,localStrength:amount});
      for(let i=thunder.length-1;i>=0;i--){thunder[i].remaining-=dt;if(thunder[i].remaining<=0){onThunder(amount*thunder[i].strength);thunder.splice(i,1);}}
      if(amount<=.005)return 0;
      rainMaterial.opacity=amount*.38;geometry.setDrawRange(0,Math.floor(count*(.3+.7*amount))*2);
      const drift=time*(9.4+Math.sin(time*.3)*1.4);
      for(let i=0;i<count;i++){
        const s=seeds[i],x=camera.x+((s.x+drift)%80+80)%80-40,z=camera.z+s.z;
        const y=camera.y+21-((time*28+s.y)%38);positions.set([x,y,z,x+s.length*.62,y+s.length,z+s.length*.23],i*6);
      }
      geometry.attributes.position.needsUpdate=true;
      if(Math.hypot(splashAnchor.x-camera.x,splashAnchor.z-camera.z)>2){
        splashAnchor={x:camera.x,z:camera.z};for(const s of splashSeeds)s.y=heightAt(splashAnchor.x+s.x,splashAnchor.z+s.z)+.025;
      }
      splashMaterial.opacity=amount*.26;
      splashSeeds.forEach((s,i)=>{const phase=(time*1.7+s.phase)%1;dummy.position.set(splashAnchor.x+s.x,s.y,splashAnchor.z+s.z);dummy.scale.setScalar(phase<.7?phase*3:.001);dummy.updateMatrix();splashes.setMatrixAt(i,dummy.matrix);});splashes.instanceMatrix.needsUpdate=true;
      debrisMaterial.opacity=amount*.82;
      debrisSeeds.forEach((s,i)=>{const x=camera.x+((s.x+time*11)%54)-27,z=camera.z+((s.z+time*3)%54)-27;
        dummy.position.set(x,camera.y-1+(s.y+Math.sin(time*2+s.spin)*2+12)%12,z);dummy.rotation.set(time*3+s.spin,time*1.4+s.spin,time*2.1);dummy.scale.setScalar(s.size);dummy.updateMatrix();debris.setMatrixAt(i,dummy.matrix);});debris.instanceMatrix.needsUpdate=true;
      return reducedMotion?0:flash*.23*amount;
    },
    lightningState(){return{bursts:burstCount,bolts:boltCount,visible:bolts.filter(bolt=>bolt.mesh.visible).length,hurricane:hurricane.diagnostics()};},
    dispose(){group.removeFromParent();hurricane.dispose();owned.forEach(value=>value.dispose());}
  };
}
