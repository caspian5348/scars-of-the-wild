import * as THREE from './vendor/three.module.js';
/** A tree may occupy bark, canopy and vine batches; all parts share one stable ID. */
export function createTreeInstanceRegistry(){
  const entries=new Map(),felled=new Set(),zero=new THREE.Matrix4().makeScale(0,0,0);
  return {
    register(id,mesh,index,matrix){if(!id)return;if(!entries.has(id))entries.set(id,[]);entries.get(id).push({mesh,index,matrix:matrix.clone()});},
    setTreeFelled(id,value=true){if(!entries.has(id)||felled.has(id)===!!value)return false;value?felled.add(id):felled.delete(id);for(const part of entries.get(id)){part.mesh.setMatrixAt(part.index,value?zero:part.matrix);part.mesh.instanceMatrix.needsUpdate=true;}return true;},
    has:id=>entries.has(id),
  };
}
