import * as THREE from './vendor/three.module.js';

export const WORLD_SHADOW_EXTENT=260;
const SUN_OFFSET=new THREE.Vector3(-360,540,-390);

/** Keep a broad sun shadow map aligned to its own texel grid as the player moves. */
export function createWorldShadows({sun,renderer}) {
  const supported=Math.max(1,renderer?.capabilities?.maxTextureSize||4096);
  const resolution=2**Math.floor(Math.log2(Math.min(4096,supported)));
  const texel=WORLD_SHADOW_EXTENT*2/resolution;
  const axis=SUN_OFFSET.clone().normalize(),right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),axis).normalize();
  const up=new THREE.Vector3().crossVectors(axis,right).normalize();
  const target=new THREE.Vector3(),snapped=new THREE.Vector3();
  sun.castShadow=true;sun.shadow.mapSize.set(resolution,resolution);
  Object.assign(sun.shadow.camera,{left:-WORLD_SHADOW_EXTENT,right:WORLD_SHADOW_EXTENT,top:WORLD_SHADOW_EXTENT,bottom:-WORLD_SHADOW_EXTENT,near:1,far:1200});
  sun.shadow.camera.updateProjectionMatrix();sun.shadow.normalBias=.028;sun.shadow.bias=-.00005;
  return {
    update(player,groundY=player.y||0){
      target.set(player.x,groundY,player.z);
      const x=Math.round(target.dot(right)/texel)*texel,y=Math.round(target.dot(up)/texel)*texel,z=target.dot(axis);
      snapped.copy(right).multiplyScalar(x).addScaledVector(up,y).addScaledVector(axis,z);
      sun.target.position.copy(snapped);sun.position.copy(snapped).add(SUN_OFFSET);
    },
    diagnostics(){return{extent:WORLD_SHADOW_EXTENT,resolution,texelWorldSize:texel,target:snapped.toArray(),sunOffset:SUN_OFFSET.toArray()};}
  };
}
