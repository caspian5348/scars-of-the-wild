import {riverBankDistanceAt,riverX} from './river-network.js';
import {hasTeethpeedLineOfSight} from './teethpeed-senses.js';

export const BURROWPEED_COUNT=50;
export const BURROWPEED_PER_BIOME=25;
export const BURROWPEED_SPACING=30.48; // 100 feet, measured horizontally between dens.
export const BURROWPEED_DETECTION_RADIUS=10;
export const BURROWPEED_CHASE_SECONDS=10;
export const BURROWPEED_EMERGE_SECONDS=.85;
export const BURROWPEED_BURROW_SECONDS=1.1;
export const BURROWPEED_RETURN_SECONDS=2.4;
export const BURROWPEED_COOLDOWN_SECONDS=8;
export const BURROWPEED_REARM_RADIUS=14;
export const BURROWPEED_SPEED=4.65;
export const BURROWPEED_BITE_DAMAGE=22;
export const BURROWPEED_BITE_INTERVAL=1.8;
export const BURROWPEED_HEALTH=100;
export const BURROWPEED_LAYOUT_SEED='scars-world-burrows-v1';

const RADIUS=.72,GROUND_MIN=2.55,STEP=.05,EPS=1e-8,CELL=20;
const LOOT=Object.freeze({chitin:3,raw_meat:2,venom:1});
const STAGES=['buried','emerging','chasing','burrowing','returning','dead'];
const DURATIONS={emerging:BURROWPEED_EMERGE_SECONDS,chasing:BURROWPEED_CHASE_SECONDS,burrowing:BURROWPEED_BURROW_SECONDS,returning:BURROWPEED_RETURN_SECONDS};
const finite=Number.isFinite,plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const copy=p=>({x:p.x,y:p.y,z:p.z});
const point=p=>plain(p)&&[p.x,p.y,p.z].every(finite)&&Math.max(Math.abs(p.x),Math.abs(p.y),Math.abs(p.z))<100000;
const canonicalId=id=>typeof id==='string'&&/^burrowpeed-[0-4][0-9]$/.test(id);
const integer=v=>Number.isSafeInteger(v)&&v>=0;
const biomeId=(lookup,x,z)=>{const b=lookup(x,z);return typeof b==='string'?b:b?.id;};
const allowedBiome=id=>id==='forest'||id==='valley';
const angle=(dx,dz)=>Math.atan2(-dx,-dz);
const copyRecord=r=>({...r,position:copy(r.position),lastKnownPlayer:r.lastKnownPlayer?copy(r.lastKnownPlayer):null});

function randomFor(seed){
  let h=2166136261;for(const c of String(seed))h=Math.imul(h^c.charCodeAt(0),16777619);
  return ()=>{h+=0x6d2b79f5;let v=h;v=Math.imul(v^(v>>>15),v|1);v^=v+Math.imul(v^(v>>>7),v|61);return ((v^(v>>>14))>>>0)/4294967296;};
}

function colliderIndex(colliders){
  const grid=new Map();
  for(const c of colliders||[]){
    if(!c||![c.x,c.z,c.radius].every(finite)||c.radius<=0)continue;
    const reach=c.radius+2.2;
    for(let x=Math.floor((c.x-reach)/CELL);x<=Math.floor((c.x+reach)/CELL);x++)for(let z=Math.floor((c.z-reach)/CELL);z<=Math.floor((c.z+reach)/CELL);z++){
      const key=`${x}:${z}`;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(c);
    }
  }
  return grid;
}
const cellAt=(grid,x,z)=>grid.get(`${Math.floor(x/CELL)}:${Math.floor(z/CELL)}`)||[];

/** Fixed world layout, independent of the journey seed or the order of exploration. */
export function createBurrowpeedDens({heightAt,biomeAt,colliders=[],seed=BURROWPEED_LAYOUT_SEED}={}){
  if(typeof heightAt!=='function'||typeof biomeAt!=='function')throw new TypeError('Burrowpeed placement needs terrain height and biome queries.');
  const rng=randomFor(seed),grid=colliderIndex(colliders),dens=[];
  const bounds={forest:[-335,-65,-255,220],valley:[-320,350,-320,440]};
  function suitable(x,z,wanted){
    if(biomeId(biomeAt,x,z)!==wanted||riverBankDistanceAt(x,z)<5.2)return null;
    if(Math.hypot(x+65,z-95)<24||Math.hypot(x-riverX(-35),z+35)<24)return null;
    const y=heightAt(x,z);if(!finite(y)||y<GROUND_MIN)return null;
    for(const [dx,dz] of [[2,0],[-2,0],[0,2],[0,-2],[1.4,1.4],[-1.4,-1.4]]){
      const edge=heightAt(x+dx,z+dz);
      if(!finite(edge)||edge<GROUND_MIN||Math.abs(edge-y)>1.2||biomeId(biomeAt,x+dx,z+dz)!==wanted)return null;
    }
    for(const c of cellAt(grid,x,z))if(Math.hypot(x-c.x,z-c.z)<c.radius+2.1)return null;
    return {x,y,z};
  }
  for(const wanted of ['forest','valley']){
    const [x0,x1,z0,z1]=bounds[wanted],candidates=[];
    // A bounded blue-noise candidate pool spreads encounters through each biome,
    // while keeping the clearance rule even in dense or later-revised scenery.
    for(let i=0;i<24000&&candidates.length<2400;i++){
      const p=suitable(x0+rng()*(x1-x0),z0+rng()*(z1-z0),wanted);if(p)candidates.push(p);
    }
    for(let n=0;n<BURROWPEED_PER_BIOME;n++){
      let best=null,bestIndex=-1,bestDistance=-Infinity;
      for(let i=0;i<candidates.length;i++){
        const p=candidates[i];let nearest=dens.length?Infinity:1000;
        for(const d of dens)nearest=Math.min(nearest,distance(p,d.position));
        if(nearest>=BURROWPEED_SPACING&&nearest>bestDistance){best=p;bestIndex=i;bestDistance=nearest;}
      }
      if(!best)throw new Error(`Cannot place ${BURROWPEED_PER_BIOME} ${wanted} Burrowpeed dens with 100-foot clearance (${n} placed).`);
      const id=`burrowpeed-${String(dens.length).padStart(2,'0')}`;
      dens.push({id,denId:id,biome:wanted,x:best.x,y:best.y,z:best.z,position:copy(best),heading:rng()*Math.PI*2});
      candidates.splice(bestIndex,1);
    }
  }
  return dens;
}

/** Strict data-only validation. No random rolls, terrain access, or wall-clock catch-up. */
export function normalizeBurrowpeedState(value){
  if(value===undefined)return undefined;
  if(!plain(value)||value.version!==1||typeof value.seed!=='string'||!value.seed.length||value.seed.length>512||!finite(value.clock)||value.clock<0||!integer(value.revision)||!Array.isArray(value.records)||value.records.length>BURROWPEED_COUNT)return null;
  const seen=new Set(),records=[];
  for(const s of value.records){
    if(!plain(s)||!canonicalId(s.id)||s.denId!==s.id||seen.has(s.id)||!STAGES.includes(s.stage)||!point(s.position)||!finite(s.heading)||!integer(s.cycle)||!integer(s.revision))return null;
    if(!finite(s.health)||s.health<0||s.health>BURROWPEED_HEALTH||(s.stage==='dead')!==(s.health===0))return null;
    if(!finite(s.elapsed)||s.elapsed<0||s.elapsed>BURROWPEED_CHASE_SECONDS||!finite(s.remaining)||s.remaining<0||s.remaining>BURROWPEED_CHASE_SECONDS||!finite(s.progress)||s.progress<0||s.progress>1)return null;
    if(!finite(s.biteCooldown)||s.biteCooldown<0||s.biteCooldown>BURROWPEED_BITE_INTERVAL||!finite(s.cooldown)||s.cooldown<0||s.cooldown>BURROWPEED_COOLDOWN_SECONDS||typeof s.armed!=='boolean'||typeof s.harvested!=='boolean')return null;
    if(s.lastKnownPlayer!==null&&!point(s.lastKnownPlayer)||s.harvested&&s.stage!=='dead'||s.armed&&s.stage!=='buried')return null;
    const total=DURATIONS[s.stage];
    if(total&&(Math.abs(s.elapsed+s.remaining-total)>1e-5||Math.abs(s.progress-s.elapsed/total)>1e-5)||!total&&(s.elapsed!==0||s.remaining!==0||s.progress!==(s.stage==='dead'?1:0)))return null;
    records.push({id:s.id,denId:s.id,stage:s.stage,position:copy(s.position),heading:s.heading,remaining:s.remaining,progress:s.progress,health:s.health,cycle:s.cycle,revision:s.revision,elapsed:s.elapsed,biteCooldown:s.biteCooldown,cooldown:s.cooldown,armed:s.armed,harvested:s.harvested,lastKnownPlayer:s.lastKnownPlayer?copy(s.lastKnownPlayer):null});
    seen.add(s.id);
  }
  return {version:1,seed:value.seed,clock:value.clock,revision:value.revision,records};
}

/** All timers use supplied game time. Withholding update pauses every encounter. */
export function createBurrowpeedEncounters({dens=[],heightAt,colliders=[],biomeAt=()=>({id:'valley'}),isSafeAt=()=>false,seed='burrowpeed-journey',state,onDamage=()=>{},onEvent=()=>{},onChange=()=>{}}={}){
  if(typeof heightAt!=='function')throw new TypeError('Burrowpeed encounters need terrain height.');
  const restored=normalizeBurrowpeedState(state);
  if(state!==undefined&&restored===null)throw new TypeError('Invalid Burrowpeed save state.');
  const denMap=new Map(),records=new Map(),saved=new Map((restored?.records||[]).map(r=>[r.id,r]));
  const runSeed=restored?.seed??String(seed),initialColliders=Array.isArray(colliders)?colliders:[];
  let clock=restored?.clock??0,revision=restored?.revision??0,lastPlayer=null,grid=colliderIndex(initialColliders),colliderCount=initialColliders.length,disposed=false;
  for(const d of dens){
    const p=d?.position??d;
    if(!d||!canonicalId(d.id)||denMap.has(d.id)||!point(p))throw new TypeError('Invalid or duplicate Burrowpeed den.');
    const den={...d,id:d.id,denId:d.id,position:copy(p),heading:finite(d.heading)?d.heading:0};denMap.set(den.id,den);
    const r=saved.get(den.id);
    records.set(den.id,r?copyRecord(r):{id:den.id,denId:den.id,stage:'buried',position:copy(den.position),heading:den.heading,remaining:0,progress:0,health:BURROWPEED_HEALTH,cycle:0,revision:0,elapsed:0,biteCooldown:0,cooldown:0,armed:true,harvested:false,lastKnownPlayer:null});
  }
  if(dens.length>BURROWPEED_COUNT)throw new TypeError('Burrowpeed den limit exceeded.');
  function snapshot(){return {version:1,seed:runSeed,clock,revision,records:[...records.values()].map(copyRecord)};}
  function emit(type,r,extra={}){
    r.revision++;revision++;
    const event={type,id:r.id,denId:r.id,species:'burrowpeed',name:'Burrowpeed',position:copy(r.position),...extra};onEvent(event);onChange(snapshot(),event);
  }
  function habitat(x,z){return !isSafeAt(x,z)&&allowedBiome(biomeId(biomeAt,x,z));}
  function playerOnGround(p){const y=heightAt(p.x,p.z);return finite(y)&&y>=GROUND_MIN&&p.y>=y-.16&&p.y<=y+3.2&&habitat(p.x,p.z);}
  function refreshedColliders(){if(initialColliders.length!==colliderCount){grid=colliderIndex(initialColliders);colliderCount=initialColliders.length;}return initialColliders;}
  function sight(r,p){return hasTeethpeedLineOfSight({position:r.position,player:p,heightAt,colliders:refreshedColliders(),originEyeHeight:.32,playerEyeHeight:1.05});}
  function occupy(x,z){
    if(!habitat(x,z))return null;
    const y=heightAt(x,z);if(!finite(y)||y<GROUND_MIN)return null;
    for(const c of cellAt(grid,x,z))if(Math.hypot(x-c.x,z-c.z)<c.radius+RADIUS)return null;
    for(const [dx,dz] of [[RADIUS,0],[-RADIUS,0],[0,RADIUS],[0,-RADIUS]]){
      if(!habitat(x+dx,z+dz))return null;const edge=heightAt(x+dx,z+dz);
      if(!finite(edge)||edge<GROUND_MIN||Math.abs(edge-y)>.8)return null;
    }
    return y;
  }
  function stepTo(r,x,z){
    const y=occupy(x,z);if(y===null)return null;
    const ground=heightAt(r.position.x,r.position.z),length=Math.hypot(x-r.position.x,z-r.position.z);
    if(!finite(ground)||Math.abs(y-ground)>Math.max(.12,length*.85))return null;
    const mx=(r.position.x+x)/2,mz=(r.position.z+z)/2,my=occupy(mx,mz);
    if(my===null||Math.abs(my-ground)>Math.max(.10,length*.48))return null;
    return {x,y,z};
  }
  function stage(r,next){
    r.stage=next;r.elapsed=0;r.progress=next==='dead'?1:0;r.remaining=DURATIONS[next]??0;
    if(next!=='buried')r.armed=false;
  }
  function burrow(r,reason){if(r.stage==='burrowing'||r.stage==='returning'||r.stage==='buried'||r.stage==='dead')return;stage(r,'burrowing');r.cooldown=BURROWPEED_COOLDOWN_SECONDS;emit('burrow',r,{duration:BURROWPEED_BURROW_SECONDS,reason});}
  function advance(r,dt){const duration=DURATIONS[r.stage];r.elapsed=Math.min(duration,r.elapsed+dt);r.remaining=Math.max(0,duration-r.elapsed);r.progress=r.elapsed/duration;}
  function move(r,target,dt){
    const dx=target.x-r.position.x,dz=target.z-r.position.z,length=Math.hypot(dx,dz);if(length<=1.1)return;
    const desired=angle(dx,dz),stride=Math.min(BURROWPEED_SPEED*dt,length-1.1);
    for(const offset of [0,.35,-.35,.75,-.75,1.15,-1.15]){
      const heading=desired+offset,p=stepTo(r,r.position.x-Math.sin(heading)*stride,r.position.z-Math.cos(heading)*stride);
      if(p){r.position=p;let turn=((heading-r.heading+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;r.heading+=clamp(turn,-dt*5,dt*5);return;}
    }
  }
  function tick(r,dt,p,grounded){
    const den=denMap.get(r.id);
    r.biteCooldown=Math.max(0,r.biteCooldown-dt);
    if(r.stage==='dead')return;
    if(r.stage==='buried'){
      r.cooldown=Math.max(0,r.cooldown-dt);
      if(!r.armed&&r.cooldown<=EPS&&distance(p,den.position)>BURROWPEED_REARM_RADIUS){r.armed=true;emit('rearmed',r);}
      if(r.armed&&grounded&&distance(p,den.position)<=BURROWPEED_DETECTION_RADIUS+EPS&&occupy(den.position.x,den.position.z)!==null&&sight(r,p)){
        r.cycle++;r.lastKnownPlayer=copy(p);r.heading=angle(p.x-r.position.x,p.z-r.position.z);r.biteCooldown=.25;stage(r,'emerging');emit('emerge',r,{duration:BURROWPEED_EMERGE_SECONDS});
      }
      return;
    }
    if(['emerging','chasing'].includes(r.stage)&&(!habitat(p.x,p.z)||!habitat(r.position.x,r.position.z))){burrow(r,isSafeAt(p.x,p.z)?'safe-zone':'habitat');return;}
    if(r.stage==='emerging'){
      advance(r,dt);if(r.remaining<=EPS){stage(r,'chasing');emit('chase',r,{duration:BURROWPEED_CHASE_SECONDS});}return;
    }
    if(r.stage==='chasing'){
      const visible=grounded&&sight(r,p);if(visible)r.lastKnownPlayer=copy(p);
      if(r.lastKnownPlayer)move(r,r.lastKnownPlayer,Math.min(dt,r.remaining));
      if(visible&&distance(r.position,p)<=1.65&&Math.abs(r.position.y-p.y)<=1.6&&r.biteCooldown<=EPS&&sight(r,p)){
        r.biteCooldown=BURROWPEED_BITE_INTERVAL;onDamage(BURROWPEED_BITE_DAMAGE,'Burrowpeed',{...copyRecord(r),targetPlayerId:r.targetPlayerId});emit('bite',r,{damage:BURROWPEED_BITE_DAMAGE,cause:'Burrowpeed'});
      }
      advance(r,dt);if(r.remaining<=EPS)burrow(r,'timeout');return;
    }
    if(r.stage==='burrowing'){
      advance(r,dt);if(r.remaining<=EPS){stage(r,'returning');r.position=copy(den.position);r.heading=den.heading;emit('underground',r);}return;
    }
    if(r.stage==='returning'){
      advance(r,dt);if(r.remaining<=EPS){stage(r,'buried');r.position=copy(den.position);r.lastKnownPlayer=null;emit('returned',r);}return;
    }
  }
  function update(dt,player){
    if(disposed||!finite(dt)||dt<=0||dt>60||!point(player))return;
    lastPlayer=copy(player);refreshedColliders();let left=dt;
    const grounded=playerOnGround(lastPlayer);
    // Small physical steps prevent tunnelling. Stage boundaries subdivide steps
    // further, so the ten-second chase never gains an extra frame on reload.
    while(left>EPS){
      let slice=Math.min(STEP,left);
      for(const r of records.values())if(DURATIONS[r.stage]&&r.remaining>EPS)slice=Math.min(slice,r.remaining);
      clock+=slice;
      for(const r of records.values())tick(r,slice,lastPlayer,grounded);
      left-=slice;
    }
  }
  function updateMany(dt,players){
    const valid=Array.isArray(players)?players.filter(p=>point(p)&&p.alive!==false&&p.connected!==false):[];
    if(disposed||!finite(dt)||dt<=0||dt>60||!valid.length)return;
    refreshedColliders();let left=dt;
    while(left>EPS){
      let slice=Math.min(STEP,left);
      for(const r of records.values())if(DURATIONS[r.stage]&&r.remaining>EPS)slice=Math.min(slice,r.remaining);
      clock+=slice;
      for(const r of records.values()){
        const anchor=r.stage==='buried'?denMap.get(r.id).position:r.position;
        const eligible=valid.filter(p=>habitat(p.x,p.z)),pool=eligible.length?eligible:valid;
        const p=[...pool].sort((a,b)=>distance(a,anchor)-distance(b,anchor))[0];
        r.targetPlayerId=p.id;lastPlayer=p;
        // All survivors must leave a den before its ambush can rearm.
        const rearmBlocked=r.stage==='buried'&&!r.armed&&valid.some(v=>distance(v,denMap.get(r.id).position)<=BURROWPEED_REARM_RADIUS);
        const cooldown=r.cooldown;if(rearmBlocked)r.cooldown=Math.max(r.cooldown,slice+EPS*2);
        tick(r,slice,p,playerOnGround(p));
        if(rearmBlocked)r.cooldown=Math.max(0,cooldown-slice);
      }
      left-=slice;
    }
  }
  function details(r){const den=denMap.get(r.id);return {...copyRecord(r),kind:'burrowpeed',species:'burrowpeed',name:'Burrowpeed',denPosition:copy(den.position),biome:den.biome,tipsVisible:r.stage==='buried',grounded:true,...(r.targetPlayerId?{targetPlayerId:r.targetPlayerId}:{})};}
  function getDens(){return [...records.values()].map(details);}
  function getActive(){return [...records.values()].filter(r=>['emerging','chasing','burrowing'].includes(r.stage)||r.stage==='dead'&&!r.harvested).map(details);}
  function getChasers(player=lastPlayer){return point(player)&&playerOnGround(player)?[...records.values()].filter(r=>r.stage==='chasing'&&sight(r,player)).map(r=>({...details(r),state:'chase'})):[];}
  function damage(id,amount){
    const r=records.get(id);
    if(disposed||!r||!finite(amount)||amount<=0||!(['chasing'].includes(r.stage)||r.stage==='emerging'&&r.progress>.15))return {hit:false};
    const applied=Math.min(r.health,amount);r.health-=applied;
    if(r.health<=0){stage(r,'dead');r.health=0;r.biteCooldown=0;r.cooldown=0;r.lastKnownPlayer=null;emit('killed',r);}else emit('wounded',r,{damage:applied});
    return {hit:true,id:r.id,species:'burrowpeed',name:'Burrowpeed',damage:applied,killed:r.health===0};
  }
  function getLoot(id){const r=records.get(id);return r?.stage==='dead'&&!r.harvested?{...LOOT}:null;}
  function harvestCorpse(id,player=lastPlayer){
    const r=records.get(id),loot=getLoot(id);if(!loot||!player||distance(r.position,player)>3.5||Math.abs(r.position.y-player.y)>3.2||!sight(r,player))return null;
    r.harvested=true;emit('harvested',r,{loot:{...loot}});return loot;
  }
  function getNearbyTargets(options={},range=4){
    const origin=point(options.origin)?options.origin:point(options)?options:lastPlayer,reach=finite(options.range)?options.range:range;if(!origin)return [];
    return getActive().filter(r=>r.stage==='dead'||r.stage==='chasing'||r.stage==='emerging'&&r.progress>.15).map(r=>({...r,distance:distance(r.position,origin),health:r.health,maxHealth:BURROWPEED_HEALTH,dead:r.stage==='dead',harvestable:r.stage==='dead',...(r.stage==='dead'?{loot:{...LOOT}}:{})})).filter(r=>r.distance<=reach&&Math.abs(r.position.y-origin.y)<=Math.max(3.5,reach)).sort((a,b)=>a.distance-b.distance);
  }
  function dispose(){disposed=true;}
  return {update,updateMany,snapshot,getDens,getActive,getChasers,damage,getLoot,harvestCorpse,getNearbyTargets,dispose};
}
