import * as THREE from './vendor/three.module.js';

/**
 * Photographic bark at a physical UV scale. Textures belong to the caller;
 * use cloned maps with repeat (1, 1), and map roughly 2 local metres per tile.
 * Apply the decorator AFTER the shared wind hook so both shader edits survive.
 */
export function createJungleBarkMaterial({maps, normalStrength = 1.5} = {}) {
  return new THREE.MeshStandardMaterial({
    ...maps,
    color: '#fff9ed',
    vertexColors: true,
    roughness: 1,
    normalScale: new THREE.Vector2(normalStrength, normalStrength),
    side: THREE.DoubleSide,
  });
}

const barkFunctions = /* glsl */`
  varying vec3 vJungleBarkRest;
  varying float vJungleBarkSeed;

  float jungleBarkHash(vec3 p) {
    p = fract(p * .1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
  }

  float jungleBarkNoise(vec3 p) {
    vec3 cell = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(mix(jungleBarkHash(cell), jungleBarkHash(cell + vec3(1,0,0)), f.x),
          mix(jungleBarkHash(cell + vec3(0,1,0)), jungleBarkHash(cell + vec3(1,1,0)), f.x), f.y),
      mix(mix(jungleBarkHash(cell + vec3(0,0,1)), jungleBarkHash(cell + vec3(1,0,1)), f.x),
          mix(jungleBarkHash(cell + vec3(0,1,1)), jungleBarkHash(cell + vec3(1,1,1)), f.x), f.y), f.z);
  }
`;

/** Adds surface detail only; geometry, wind anchors, and climbing shape stay fixed. */
export function decorateJungleBarkMaterial(material) {
  if (material.userData.jungleBarkDecorated) return material;
  material.userData.jungleBarkDecorated = true;
  const priorCompile = material.onBeforeCompile;
  // Capture the old cache key now: Material's default derives it from the hook.
  const priorKey = material.customProgramCacheKey();
  material.onBeforeCompile = function (shader, renderer) {
    priorCompile.call(this, shader, renderer);
    shader.vertexShader = 'varying vec3 vJungleBarkRest;\nvarying float vJungleBarkSeed;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', /* glsl */`
      #include <begin_vertex>
      vJungleBarkRest = position;
      vJungleBarkSeed = 0.0;
      #ifdef USE_INSTANCING
        vJungleBarkSeed = fract(sin(dot(instanceMatrix[3].xz, vec2(12.9898,78.233))) * 43758.5453);
      #endif
    `);
    shader.fragmentShader = barkFunctions + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', /* glsl */`
      #include <color_fragment>
      vec3 barkP = vJungleBarkRest + vec3(vJungleBarkSeed * 27.0, 0.0, vJungleBarkSeed * 19.0);
      float barkPatch = jungleBarkNoise(barkP * vec3(2.6, 1.6, 2.6));
      float barkGrain = jungleBarkNoise(barkP * 13.0);
      // Small, broken patches retain the photographed plates and fissures.
      float barkLichen = smoothstep(.63, .79, barkPatch * .78 + barkGrain * .22);
      float barkLow = 1.0 - smoothstep(1.6, 6.0, vJungleBarkRest.y);
      float barkMoss = barkLow * smoothstep(.43, .72, barkPatch + barkGrain * .17);
      diffuseColor.rgb *= 1.12;
      diffuseColor.rgb = mix(diffuseColor.rgb, vec3(.21, .225, .15), barkLichen * .28);
      diffuseColor.rgb = mix(diffuseColor.rgb, vec3(.048, .077, .025), barkMoss * .27);
    `);
    // Blend a smaller-scale sample into the photographed tangent-space normal.
    // Mipmapping limits the detail with distance, avoiding shimmering noise.
    const normalChunk = THREE.ShaderChunk.normal_fragment_maps.replace(
      'mapN.xy *= normalScale;',
      `vec3 barkFineN = texture2D(normalMap, vNormalMapUv * 3.17 + vec2(.137,.381)).xyz * 2.0 - 1.0;
       mapN.xy = (mapN.xy + barkFineN.xy * .22) * normalScale;`
    );
    shader.fragmentShader = shader.fragmentShader.replace('#include <normal_fragment_maps>', normalChunk);
    shader.fragmentShader = shader.fragmentShader.replace('#include <roughnessmap_fragment>', /* glsl */`
      #include <roughnessmap_fragment>
      roughnessFactor = clamp(roughnessFactor, .84, 1.0);
    `);
  };
  material.customProgramCacheKey = () => `${priorKey}|jungle-photographic-bark-v1`;
  material.needsUpdate = true;
  return material;
}
