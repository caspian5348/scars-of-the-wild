import * as THREE from './vendor/three.module.js';
import { createAircraftModel } from './aircraft-model.js';

export const CRASH_TIMING=Object.freeze({duration:26,engineFailure:5.5,airframeStress:11.4,contact:16.2,impact:18.1,settled:23});
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
const mix=(a,b,t)=>a+(b-a)*t;
const seeded=seed=>()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};
const EVENTS=[['engine-failure','engineFailure'],['airframe-stress','airframeStress'],['water-contact','contact'],['impact','impact'],['settled','settled']];

function vaporTexture(){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=128;
  const ctx=canvas.getContext('2d'),rng=seeded(6327);
  for(let i=0;i<32;i++){
    const x=34+rng()*60,y=34+rng()*60,r=15+rng()*23,g=ctx.createRadialGradient(x,y,0,x,y,r);
    g.addColorStop(0,'#ffffff50');g.addColorStop(.48,'#ffffff2a');g.addColorStop(1,'#ffffff00');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);
  }
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;return texture;
}
function scrapGeometry(){
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([-.70,.01,-.65,.60,.04,-.45,.83,0,.47,-.42,.035,.70,0,.13,0],3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,1,1,0,1,.5,.5],2));g.setIndex([0,1,4,1,2,4,3,0,4,2,3,4]);g.computeVertexNormals();return g;
}

/** Deterministic arrival and river crash, followed by a persistent wreck. */
export function createCrashSequence({scene,camera,riverX,heightAt,waterLevel=2,onEvent=()=>{},reducedMotion=false},options={}){
  const callback=options.onEvent??onEvent,motionPreference=options.reducedMotion??reducedMotion;
  const model=createAircraftModel(),aircraft=model.group,propellers=model.propellers,gear=model.gear;
  aircraft.name='Expedition aircraft and river wreck';aircraft.visible=false;scene.add(aircraft);
  const effects=new THREE.Group(),debris=new THREE.Group();effects.name='Crash spray, smoke and ripples';debris.name='Detached aircraft panels';scene.add(effects,debris);debris.visible=false;
  const resources=new Set(),own=value=>(resources.add(value),value),rng=seeded(191287),dummy=new THREE.Object3D();
  const impact=new THREE.Vector3(riverX(-35),waterLevel+.28,-35),settled=new THREE.Euler(-.14,.13,Math.PI/12,'YXZ');
  const finalQuaternion=new THREE.Quaternion().setFromEuler(settled),survivor={x:riverX(-25)-27,z:-25,yaw:-1.18,pitch:-.12},v=new THREE.Vector3();
  // Existing interaction footprint and survivor location are unchanged.
  const colliders=[[0,-4.7,1.35],[0,-1.9,1.6],[0,1.1,1.6],[0,4.1,1.05],[-4.2,-1.3,1.5],[4.2,-1.3,1.5],[-7.1,-.3,1.35],[7.1,-.3,1.35]].map(([x,z,radius])=>{v.set(x,0,z).applyQuaternion(finalQuaternion).add(impact);return{x:v.x,z:v.z,radius};});
  const panelRest=[];
  for(let i=0;i<5;i++){const z=-45-rng()*13,x=riverX(z)-13-rng()*4;panelRest.push({position:new THREE.Vector3(x,heightAt(x,z)+.10,z),quaternion:new THREE.Quaternion().setFromEuler(new THREE.Euler(.07+rng()*.12,rng()*6.28,rng()*.14)),scale:.7+rng()*.9});}
  const scrapMaterial=own(new THREE.MeshStandardMaterial({color:'#a9ad9b',metalness:.48,roughness:.64,side:THREE.DoubleSide})),scraps=[];
  for(let i=0;i<5;i++){const mesh=new THREE.Mesh(own(scrapGeometry()),scrapMaterial);mesh.castShadow=mesh.receiveShadow=true;debris.add(mesh);scraps.push(mesh);}
  const panelRecords=model.damagePanels.map((panel,i)=>({...panel,parent:panel.mesh.parent,rest:panelRest[i%panelRest.length],detachTime:CRASH_TIMING.impact+i*.19,flight:2.3+i*.23}));
  const vapor=own(vaporTexture());
  const smokeMaterial=own(new THREE.MeshBasicMaterial({map:vapor,color:'#6f756e',transparent:true,opacity:.53,depthWrite:false,side:THREE.DoubleSide}));
  const smoke=own(new THREE.InstancedMesh(own(new THREE.PlaneGeometry(1,1)),smokeMaterial,36));smoke.name='Failing-engine smoke and cooling steam';smoke.frustumCulled=false;smoke.visible=false;smoke.instanceMatrix.setUsage(THREE.DynamicDrawUsage);effects.add(smoke);
  const smokeSeeds=Array.from({length:36},()=>({age:rng(),side:rng()*2-1,offset:rng()*Math.PI*2,rise:.85+rng()*.7}));
  const sprayMaterial=own(new THREE.MeshStandardMaterial({color:'#d9e9e5',roughness:.19,metalness:.05,transparent:true,opacity:.64,depthWrite:false}));
  const sprayCount=260,spray=own(new THREE.InstancedMesh(own(new THREE.IcosahedronGeometry(1,0)),sprayMaterial,sprayCount));spray.frustumCulled=false;spray.visible=false;spray.instanceMatrix.setUsage(THREE.DynamicDrawUsage);effects.add(spray);
  const droplets=Array.from({length:sprayCount},(_,i)=>({emission:i<110?CRASH_TIMING.contact+rng()*2.9:CRASH_TIMING.impact+rng()*.72,side:i%2?1:-1,lateral:5+rng()*14,forward:3+rng()*10,up:4+rng()*12,size:.045+rng()*.105,offset:rng()*2.3}));
  const mistMaterial=own(new THREE.MeshBasicMaterial({map:vapor,color:'#dce8e4',transparent:true,opacity:.49,depthWrite:false,side:THREE.DoubleSide}));
  const mist=own(new THREE.InstancedMesh(own(new THREE.PlaneGeometry(1,1)),mistMaterial,22));mist.frustumCulled=false;mist.visible=false;mist.instanceMatrix.setUsage(THREE.DynamicDrawUsage);effects.add(mist);
  const mistSeeds=Array.from({length:22},(_,i)=>({emission:CRASH_TIMING.contact+i*.115,side:i%2?1:-1,speed:2+rng()*4,life:2.1+rng()*1.2,size:2.5+rng()*3.8}));
  const ripples=Array.from({length:7},(_,i)=>{const mesh=new THREE.Mesh(own(new THREE.RingGeometry(.972,1,72)),own(new THREE.MeshBasicMaterial({color:'#c5d8d5',transparent:true,opacity:0,depthWrite:false,side:THREE.DoubleSide})));mesh.rotation.x=-Math.PI/2;mesh.visible=false;effects.add(mesh);return{mesh,emission:CRASH_TIMING.contact+i*.39};});

  const contactPoint=new THREE.Vector3(riverX(24),waterLevel+1.95,24);
  const approach=new THREE.CatmullRomCurve3([
    new THREE.Vector3(riverX(315)+19,Math.max(112,heightAt(riverX(315)+19,315)+73),315),
    new THREE.Vector3(riverX(245)+8,94,245),new THREE.Vector3(riverX(170)-3,72,170),
    new THREE.Vector3(riverX(102)+3,48,102),new THREE.Vector3(riverX(56)-1,25,56),contactPoint.clone()
  ],false,'centripetal');
  const flightDirection=new THREE.Vector3(),up=new THREE.Vector3(0,1,0),scratchQuaternion=new THREE.Quaternion();
  const impactStart=impact.clone().add(new THREE.Vector3(0,.52,6));
  // The strike camera stays above the open river, clear of both forested banks.
  const impactCamera=new THREE.Vector3(riverX(impactStart.z+23),impactStart.y+16.5,impactStart.z+23);
  const shoreCamera=new THREE.Vector3(riverX(survivor.z),waterLevel+13,survivor.z);
  const survivorCamera=new THREE.Vector3(survivor.x,heightAt(survivor.x,survivor.z)+1.72,survivor.z);
  const survivorLook=new THREE.Vector3(0,0,-24).applyEuler(new THREE.Euler(survivor.pitch,survivor.yaw,0,'YXZ')).add(survivorCamera);
  let time=0,atmosphereTime=0,active=false,done=false,disposed=false;
  const fired=new Set(),cameraPosition=new THREE.Vector3(),cameraTarget=new THREE.Vector3();
  function stageAt(t){return t>=CRASH_TIMING.duration?'done':t>=CRASH_TIMING.settled?'aftermath':t>=CRASH_TIMING.impact?'impact':t>=CRASH_TIMING.contact?'water-contact':t>=CRASH_TIMING.airframeStress?'loss-of-control':t>=CRASH_TIMING.engineFailure?'engine-failure':'approach';}
  function poseAt(t){
    t=clamp(t,0,CRASH_TIMING.duration);const position=new THREE.Vector3(),rotation=new THREE.Euler(0,0,0,'YXZ');
    if(t<CRASH_TIMING.contact){
      const progress=t/CRASH_TIMING.contact;approach.getPointAt(progress,position);approach.getTangentAt(progress,flightDirection);
      const failure=smooth((t-CRASH_TIMING.engineFailure)/3),stress=smooth((t-CRASH_TIMING.airframeStress)/3.2),align=smooth((t-14.9)/(CRASH_TIMING.contact-14.9));
      const yaw=Math.atan2(-flightDirection.x,-flightDirection.z),pitch=Math.asin(clamp(flightDirection.y,-1,1));
      const roll=Math.sin(t*1.32)*(.025+failure*.17)+Math.sin(t*2.8)*stress*.10-stress*.19;
      rotation.set(mix(pitch+Math.sin(t*2.1)*failure*.025,-.11,align),mix(yaw+Math.sin(t*.9)*failure*.035,.17,align),mix(roll,-.18,align),'YXZ');
    }else if(t<CRASH_TIMING.impact){
      const p=(t-CRASH_TIMING.contact)/(CRASH_TIMING.impact-CRASH_TIMING.contact);position.copy(contactPoint).lerp(impactStart,p);position.y+=Math.sin(p*Math.PI)*.47;
      rotation.set(mix(-.11,-.38,p)+Math.sin(p*Math.PI*4)*.025,.17+Math.sin(p*Math.PI)*.09,mix(-.18,-.58,p)+Math.sin(p*Math.PI*3)*.045,'YXZ');
    }else if(t<CRASH_TIMING.settled){
      const p=(t-CRASH_TIMING.impact)/(CRASH_TIMING.settled-CRASH_TIMING.impact),ease=1-Math.pow(1-p,3);
      position.copy(impact);position.z+=6*(1-ease)-12*Math.sin(p*Math.PI)*Math.exp(-p*.9);position.x+=Math.sin(p*Math.PI)*1.9*(1-p);position.y+=.52*(1-ease)+Math.sin(p*Math.PI*3)*Math.exp(-p*5)*.90;
      rotation.set(mix(-.38,settled.x,ease)+Math.sin(p*Math.PI*3)*.32*Math.exp(-p*3),mix(.17,settled.y,ease)+Math.sin(p*Math.PI*2)*.30*Math.exp(-p*2),mix(-.58,settled.z,ease)+Math.sin(p*Math.PI*2.5)*.58*Math.exp(-p*2)*(1-p),'YXZ');
    }else{position.copy(impact);rotation.copy(settled);}
    return{position,rotation,quaternion:new THREE.Quaternion().setFromEuler(rotation)};
  }
  function eventAt(type,at){const pose=poseAt(at);return{type,time:at,position:{x:pose.position.x,y:pose.position.y,z:pose.position.z},stage:stageAt(at)};}
  function emitCrossed(before,after){for(const[type,key]of EVENTS){const at=CRASH_TIMING[key];if(before<at&&after>=at&&!fired.has(type)){fired.add(type);callback(eventAt(type,at));}}}
  function leftPropAngle(t){const a=Math.max(0,t-CRASH_TIMING.engineFailure);return Math.min(t,CRASH_TIMING.engineFailure)*98+72/.30*(1-Math.exp(-a*.30))+Math.sin(a*13)*smooth(a)*.67;}
  function updateAirframe(){
    const pose=poseAt(time);aircraft.position.copy(pose.position);aircraft.quaternion.copy(pose.quaternion);aircraft.visible=true;
    const collision=smooth((time-CRASH_TIMING.contact)/(CRASH_TIMING.impact-CRASH_TIMING.contact+.8));
    const damage=time<CRASH_TIMING.contact?.08*smooth((time-CRASH_TIMING.engineFailure)/5):mix(.08,1,collision);model.setDamage(Math.round(damage*40)/40);
    const gearFold=smooth((time-CRASH_TIMING.contact)/1.25);gear[0].rotation.z=-.92*gearFold;gear[1].rotation.z=.49*gearFold;
    const stop=1-Math.pow(1-clamp((time-CRASH_TIMING.contact)/2.5),3),leftStop=leftPropAngle(CRASH_TIMING.contact),rightStop=CRASH_TIMING.contact*103;
    const leftRest=.46+Math.ceil((leftStop+10-.46)/(Math.PI*2))*Math.PI*2,rightRest=1.12+Math.ceil((rightStop+78-1.12)/(Math.PI*2))*Math.PI*2;
    propellers[0].rotation.z=time<CRASH_TIMING.contact?leftPropAngle(time):mix(leftStop,leftRest,stop);propellers[1].rotation.z=time<CRASH_TIMING.contact?time*103:mix(rightStop,rightRest,stop);propellers[0].children[1].rotation.x=-.5*collision;aircraft.updateMatrixWorld(true);
  }
  function positionPanels(){
    debris.visible=time>=CRASH_TIMING.impact;
    panelRecords.forEach((panel,i)=>{
      const age=time-panel.detachTime,mesh=panel.mesh;
      if(age<0){if(mesh.parent!==panel.parent)panel.parent.add(mesh);mesh.position.copy(panel.homePosition);mesh.quaternion.copy(panel.homeQuaternion);mesh.scale.copy(panel.homeScale);return;}
      if(mesh.parent!==debris)debris.add(mesh);
      const p=clamp(age/panel.flight),launch=poseAt(panel.detachTime),from=panel.homePosition.clone().applyQuaternion(launch.quaternion).add(launch.position);
      mesh.position.copy(from).lerp(panel.rest.position,p);mesh.position.y+=4*(4.4+i*.65)*p*(1-p);
      const spin=new THREE.Quaternion().setFromEuler(new THREE.Euler(age*(2.9+i*.3),age*1.4,age*2.1));mesh.quaternion.copy(launch.quaternion).multiply(panel.homeQuaternion).multiply(spin).slerp(panel.rest.quaternion,smooth((p-.65)/.35));mesh.scale.copy(panel.homeScale);
    });
    scraps.forEach((mesh,i)=>{const age=time-CRASH_TIMING.impact-.12-i*.13,p=clamp(age/(1.75+i*.15));mesh.visible=age>=0;mesh.position.copy(impactStart).lerp(panelRest[i].position,p);mesh.position.y+=4*(3.3+i*.4)*p*(1-p);mesh.quaternion.copy(panelRest[i].quaternion).multiply(scratchQuaternion.setFromEuler(new THREE.Euler(age*2.8*(1-p),0,age*1.5*(1-p))));mesh.scale.setScalar(panelRest[i].scale);});
  }
  function positionCamera(){
    const reduced=typeof motionPreference==='function'?!!motionPreference():!!motionPreference;
    if(time<CRASH_TIMING.impact){
      const failure=smooth((time-CRASH_TIMING.engineFailure)/3.2),stress=smooth((time-10.4)/4.8),contact=smooth((time-13.2)/2.4);
      const offset=new THREE.Vector3(mix(16,-18,failure),mix(10,6.5,failure),mix(31,-9,failure));offset.lerp(new THREE.Vector3(-20,9,22),stress);
      offset.applyAxisAngle(up,time>=CRASH_TIMING.contact?.17:aircraft.rotation.y);cameraPosition.copy(aircraft.position).add(offset);cameraTarget.copy(aircraft.position).add(new THREE.Vector3(0,.40,-1.3));
      cameraPosition.lerp(new THREE.Vector3(riverX(aircraft.position.z+23),aircraft.position.y+16.5,aircraft.position.z+23),contact);
      const vibration=reduced?.015:(.026+failure*.10+smooth((time-CRASH_TIMING.contact)/1.7)*.25);cameraPosition.x+=Math.sin(time*37)*vibration;cameraPosition.y+=Math.sin(time*51)*vibration*.65;
    }else if(time<CRASH_TIMING.settled){
      const age=time-CRASH_TIMING.impact,p=smooth(age/(CRASH_TIMING.settled-CRASH_TIMING.impact));cameraPosition.copy(impactCamera).lerp(shoreCamera,p);
      const shake=(reduced?.055:.88)*Math.exp(-age*2.7);cameraPosition.x+=Math.sin(age*61)*shake;cameraPosition.y+=Math.sin(age*83)*shake*.65;cameraPosition.z+=Math.sin(age*47)*shake*.4;
      cameraTarget.copy(impactStart).add(new THREE.Vector3(0,.4,-1.3)).lerp(impact.clone().add(new THREE.Vector3(0,.35,0)),p);
    }else{const p=smooth((time-CRASH_TIMING.settled)/(CRASH_TIMING.duration-CRASH_TIMING.settled));cameraPosition.copy(shoreCamera).lerp(survivorCamera,p);cameraPosition.y+=Math.sin(p*Math.PI)*13;cameraTarget.copy(impact).add(new THREE.Vector3(0,.35,0)).lerp(survivorLook,p);}
    const clearance=time>=CRASH_TIMING.settled?mix(4.2,1.72,smooth((time-CRASH_TIMING.settled)/3)):4.2;cameraPosition.y=Math.max(cameraPosition.y,heightAt(cameraPosition.x,cameraPosition.z)+clearance);camera.position.copy(cameraPosition);camera.lookAt(cameraTarget);
  }
  function updateEffects(){
    smoke.visible=aircraft.visible&&(done||time>=CRASH_TIMING.engineFailure+.35);
    if(smoke.visible){
      smokeMaterial.color.set(time<CRASH_TIMING.contact?'#646b62':'#aab8b4');smokeMaterial.opacity=done?.39:.53;
      smokeSeeds.forEach((seed,i)=>{const age=(atmosphereTime*.15+seed.age)%1,life=age*6.5,past=active?Math.max(CRASH_TIMING.engineFailure,time-age*4.8):CRASH_TIMING.duration;const pose=poseAt(past),origin=new THREE.Vector3(-4.15,.9,-1.32).applyQuaternion(pose.quaternion).add(pose.position);dummy.position.set(origin.x+life*.45+Math.sin(life+seed.offset)*age*.65,origin.y+life*seed.rise,origin.z+seed.side*age*1.5);dummy.quaternion.copy(camera.quaternion);const size=(1+age*5.9)*Math.pow(Math.sin(age*Math.PI),.55);dummy.scale.set(size,size*1.25,1);dummy.updateMatrix();smoke.setMatrixAt(i,dummy.matrix);});smoke.instanceMatrix.needsUpdate=true;
    }
    spray.visible=mist.visible=active&&time>=CRASH_TIMING.contact&&time<CRASH_TIMING.settled;
    if(spray.visible){
      droplets.forEach((drop,i)=>{const age=time-drop.emission,origin=poseAt(drop.emission).position,y=waterLevel+.13+drop.up*age-4.9*age*age;dummy.position.set(origin.x+drop.side*(drop.offset+drop.lateral*age),y,origin.z-2-drop.forward*age);dummy.rotation.set(drop.side*age,age*.5,drop.side*.35);const size=age>=0&&y>=waterLevel?drop.size:0;dummy.scale.set(size,size*(2.2+Math.abs(age)*.7),size);dummy.updateMatrix();spray.setMatrixAt(i,dummy.matrix);});spray.instanceMatrix.needsUpdate=true;
      mistSeeds.forEach((seed,i)=>{const age=time-seed.emission,p=age/seed.life,origin=poseAt(seed.emission).position;dummy.position.set(origin.x+seed.side*(2+Math.max(0,age)*seed.speed),waterLevel+.5+Math.sin(clamp(p)*Math.PI)*3.4,origin.z-1-age*3.1);dummy.quaternion.copy(camera.quaternion);const size=p>0&&p<1?seed.size*Math.sin(p*Math.PI):0;dummy.scale.set(size*1.25,size,1);dummy.updateMatrix();mist.setMatrixAt(i,dummy.matrix);});mist.instanceMatrix.needsUpdate=true;
    }
    for(const{mesh,emission}of ripples){const age=time-emission;mesh.visible=active&&age>0&&age<4.5;if(mesh.visible){const origin=poseAt(emission).position;mesh.position.set(origin.x,waterLevel+.045,origin.z);const radius=1.1+age*5.7;mesh.scale.set(radius,radius*.66,1);mesh.material.opacity=.19*(1-age/4.5);}}
  }
  function settleAircraft(){
    aircraft.position.copy(impact);aircraft.quaternion.copy(finalQuaternion);aircraft.visible=true;model.setDamage(1);gear[0].rotation.z=-.92;gear[1].rotation.z=.49;propellers[0].rotation.z=.46;propellers[1].rotation.z=1.12;propellers[0].children[1].rotation.x=-.5;aircraft.updateMatrixWorld(true);positionPanels();
  }
  return{
    survivor,colliders,
    getState(){return{time,duration:CRASH_TIMING.duration,stage:stageAt(time),active,done,position:{x:aircraft.position.x,y:aircraft.position.y,z:aircraft.position.z}};},
    start(){if(disposed)return;time=atmosphereTime=0;active=true;done=false;fired.clear();model.setDamage(0);gear.forEach(leg=>leg.rotation.set(0,0,0));propellers[0].children[1].rotation.x=0;updateAirframe();positionPanels();positionCamera();updateEffects();},
    update(dt){if(disposed)return done;dt=Number.isFinite(dt)?Math.max(0,dt):0;atmosphereTime+=dt;if(active){const previous=time;time=Math.min(CRASH_TIMING.duration,time+dt);updateAirframe();positionPanels();positionCamera();emitCrossed(previous,time);if(time>=CRASH_TIMING.duration){active=false;done=true;settleAircraft();}}updateEffects();return done;},
    finish(){if(disposed)return;time=CRASH_TIMING.duration;active=false;done=true;settleAircraft();updateEffects();},
    dispose(){if(disposed)return;disposed=true;effects.removeFromParent();debris.removeFromParent();model.dispose();for(const resource of resources)resource.dispose();resources.clear();}
  };
}
