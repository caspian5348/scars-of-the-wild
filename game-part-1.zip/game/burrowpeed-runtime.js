import * as THREE from './vendor/three.module.js';
import {createBurrowpeedEncounters} from './burrowpeed-encounters.js';
import {createBurrowpeedModel,createBurrowpeedTeethGeometry,createBurrowpeedTeethMaterial} from './burrowpeed-model.js';
import {biomeAt,isGlowSafeAt} from './biomes.js';
import {hasTeethpeedLineOfSight} from './teethpeed-senses.js';

const MAX_VIEWS=6,MAX_IDLE_VIEWS=2,VIEW_DISTANCE=105;
export function createBurrowpeedRuntime({scene,world,seed,state,surfaceTexture,prewarmedView,onDamage=()=>{},onEvent=()=>{},onChange=()=>{}}){
  const root=new THREE.Group();root.name='Burrowpeed ambushes';scene.add(root);
  const controller=createBurrowpeedEncounters({dens:world.burrowDens,heightAt:world.groundHeight,colliders:world.colliders,biomeAt,isSafeAt:isGlowSafeAt,seed,state,onDamage,onEvent,onChange});
  const geometry=createBurrowpeedTeethGeometry(),material=createBurrowpeedTeethMaterial(),markers=new THREE.InstancedMesh(geometry,material,world.burrowDens.length),dummy=new THREE.Object3D(),views=new Map();
  const up=new THREE.Vector3(0,1,0),normal=new THREE.Vector3(),tilt=new THREE.Quaternion(),yaw=new THREE.Quaternion();
  markers.name='Eight exposed tooth tips per buried Burrowpeed';markers.castShadow=true;markers.receiveShadow=true;markers.frustumCulled=false;root.add(markers);
  const idleViews=[];
  let lastPlayer=null,time=0,disposed=false,createdViews=0,reusedViews=0;
  // Ownership transfers with the already-rendered model. Retaining its resources
  // keeps the first encounter's shaders and buffers resident while it is hidden.
  if(prewarmedView){root.add(prewarmedView.group);prewarmedView.group.visible=false;idleViews.push(prewarmedView);}
  function release(id,view){
    views.delete(id);view.group.visible=false;
    if(idleViews.length<MAX_IDLE_VIEWS)idleViews.push(view);else view.dispose();
  }
  function acquire(id){
    let view=idleViews.pop();
    if(view)reusedViews++;else{view=createBurrowpeedModel({surfaceTexture});createdViews++;root.add(view.group);}
    view.group.visible=false;view.group.scale.set(1,1,1);view.group.rotation.set(0,0,0);views.set(id,view);return view;
  }
  function render(player=lastPlayer){
    if(disposed||!player)return;
    const dens=controller.getDens();
    dens.forEach((r,i)=>{
      const p=r.denPosition,h=world.groundHeight;
      normal.set(-(h(p.x+.3,p.z)-h(p.x-.3,p.z))/.6,1,-(h(p.x,p.z+.3)-h(p.x,p.z-.3))/.6).normalize();
      tilt.setFromUnitVectors(up,normal);yaw.setFromAxisAngle(up,r.heading||0);
      dummy.position.set(p.x,p.y,p.z);dummy.quaternion.copy(tilt).multiply(yaw);
      dummy.scale.setScalar(r.tipsVisible&&Math.hypot(p.x-player.x,p.z-player.z)<85?1:0);
      dummy.updateMatrix();markers.setMatrixAt(i,dummy.matrix);
    });markers.instanceMatrix.needsUpdate=true;
    const visible=controller.getActive().map(r=>({r,d:Math.hypot(r.position.x-player.x,r.position.z-player.z)})).filter(v=>v.d<VIEW_DISTANCE).sort((a,b)=>a.d-b.d).slice(0,MAX_VIEWS);
    const keep=new Set(visible.map(v=>v.r.id));for(const [id,view]of views)if(!keep.has(id))release(id,view);
    for(const {r}of visible){let view=views.get(r.id),fresh=!view;if(fresh)view=acquire(r.id);
      view.group.position.set(r.position.x,r.position.y,r.position.z);view.group.rotation.set(0,r.heading||0,0);
      const cosine=Math.cos(r.heading||0),sine=Math.sin(r.heading||0);
      const groundAt=(x,z)=>world.groundHeight(r.position.x+cosine*x+sine*z,r.position.z-sine*x+cosine*z)-r.position.y;
      // Reverse time once while hidden to reset the inherited planted-foot trail,
      // including reuse at the same den where no large teleport would reset it.
      if(fresh)view.animate({time:-1,stage:'chasing',progress:0,speed:0,groundHeightAt:world.groundHeight,groundAt});
      view.animate({time:r.stage==='dead'?0:time,stage:r.stage,progress:r.progress||0,speed:r.stage==='chasing'?4.65:0,groundHeightAt:world.groundHeight,groundAt});
      view.group.visible=true;
    }
  }
  function update(dt,player){if(disposed)return;lastPlayer=player;const elapsed=Math.max(0,Math.min(.25,Number.isFinite(dt)?dt:0));time+=elapsed;controller.update(elapsed,player);render(player);}
  function attack({origin,direction,range,damage}){
    const directionVector=new THREE.Vector3(direction.x,direction.y,direction.z).normalize();let target=null;
    for(const r of controller.getActive()){
      if(!['emerging','chasing'].includes(r.stage))continue;
      const p={...r.position,y:r.position.y+.36},delta=new THREE.Vector3(p.x-origin.x,p.y-origin.y,p.z-origin.z),along=delta.dot(directionVector);
      if(along<0||along>range||delta.addScaledVector(directionVector,-along).length()>1.0)continue;
      if(!hasTeethpeedLineOfSight({position:origin,player:p,heightAt:world.groundHeight,colliders:world.colliders,originEyeHeight:0,playerEyeHeight:0}))continue;
      if(!target||along<target.along)target={r,along};
    }
    if(!target)return{hit:false};const hit=controller.damage(target.r.id,damage);render();return hit;
  }
  return{update,render,attack,snapshot:controller.snapshot,getChasers:controller.getChasers,getDens:controller.getDens,getActive:controller.getActive,
    getNearbyTargets:controller.getNearbyTargets,getLoot:controller.getLoot,harvestCorpse:id=>{const result=controller.harvestCorpse(id);render();return result;},
    getDiagnostics(){const dens=controller.getDens(),stages={};for(const r of dens)stages[r.stage]=(stages[r.stage]||0)+1;return{total:dens.length,stages,views:views.size,idleViews:idleViews.length,allocatedViews:views.size+idleViews.length,maxViews:MAX_VIEWS,maxIdleViews:MAX_IDLE_VIEWS,createdViews,reusedViews,tipsVisible:dens.filter(d=>d.tipsVisible).length,
      records:controller.getActive().map(r=>({id:r.id,stage:r.stage,progress:r.progress,remaining:r.remaining,health:r.health,position:r.position})),nearest:lastPlayer?dens.map(r=>({id:r.id,position:r.denPosition,distance:Math.hypot(r.denPosition.x-lastPlayer.x,r.denPosition.z-lastPlayer.z),stage:r.stage})).sort((a,b)=>a.distance-b.distance).slice(0,3):[]};},
    dispose(){if(disposed)return;disposed=true;controller.dispose();root.removeFromParent();for(const view of new Set([...views.values(),...idleViews]))view.dispose();views.clear();idleViews.length=0;geometry.dispose();material.dispose();markers.dispose();}};
}
