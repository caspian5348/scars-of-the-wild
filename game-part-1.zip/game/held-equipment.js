import * as THREE from './vendor/three.module.js';
import {createFirstPersonBody} from './first-person-body.js';

const TAU=Math.PI*2,clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const point=value=>new THREE.Vector3(...value);
const flameVertex=`
  varying vec2 vUv;
  uniform float flameTime;
  uniform float flameSeed;
  void main(){
    vUv=uv;
    vec3 p=position;
    p.x+=(sin(uv.y*7.0-flameTime*4.8+flameSeed)*0.016+sin(flameTime*7.1+uv.y*11.0)*0.007)*uv.y*uv.y;
    gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);
  }
`;
const flameFragment=`
  varying vec2 vUv;
  uniform float flameTime;
  uniform float flameSeed;
  float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
  float noise(vec2 p){
    vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);
    return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),f.x),mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0)),f.x),f.y);
  }
  float fbm(vec2 p){return noise(p)*0.55+noise(p*2.03+4.2)*0.28+noise(p*4.07-7.6)*0.17;}
  void main(){
    float y=vUv.y;
    float turbulence=fbm(vec2(vUv.x*5.0+flameSeed,y*5.5-flameTime*2.3));
    float center=0.5+sin(y*8.5-flameTime*4.4+flameSeed)*0.09*y+(turbulence-0.5)*0.16*y;
    float width=0.34*pow(max(0.0,1.0-y),0.78)*(0.78+turbulence*0.48);
    float edge=1.0-smoothstep(width*0.54,width+0.025,abs(vUv.x-center));
    float tongue=1.0-smoothstep(0.68,1.0,y+(1.0-turbulence)*0.20);
    float alpha=edge*tongue*smoothstep(0.0,0.055,y)*(0.48+turbulence*0.38);
    if(alpha<0.012)discard;
    float heat=clamp((1.0-y)*0.9-abs(vUv.x-center)*1.35+turbulence*0.24,0.0,1.0);
    vec3 color=mix(vec3(0.75,0.10,0.013),vec3(1.0,0.49,0.075),smoothstep(0.08,0.58,heat));
    color=mix(color,vec3(1.0,0.88,0.49),smoothstep(0.58,0.95,heat));
    gl_FragColor=vec4(color*1.1,alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

/** Scanned close-range materials and shaped tools, with no new remote assets. */
export function createHeldEquipment(camera){
  const body=createFirstPersonBody(camera);
  const group=new THREE.Group();group.name='Held survival equipment';body.toolMount.add(group);
  const resources=new Set(),geometryCache=new Map(),models=new Map(),clock={value:0};
  let key='',current=null,swingRemaining=0,elapsed=0,disposed=false;
  const own=value=>{resources.add(value);return value;};
  const wood=own(new THREE.MeshStandardMaterial({color:'#ab977d',roughness:.98,normalScale:new THREE.Vector2(.42,.42)}));
  const stone=own(new THREE.MeshStandardMaterial({color:'#a4a79b',roughness:.94,normalScale:new THREE.Vector2(.56,.56),flatShading:true}));
  const copper=own(new THREE.MeshStandardMaterial({color:'#a17350',roughness:.62,metalness:.72,normalScale:new THREE.Vector2(.07,.07)}));
  const bronze=own(new THREE.MeshStandardMaterial({color:'#8a7a50',roughness:.59,metalness:.76,normalScale:new THREE.Vector2(.07,.07)}));
  const iron=own(new THREE.MeshStandardMaterial({color:'#7b8583',roughness:.58,metalness:.79,normalScale:new THREE.Vector2(.07,.07)}));
  const abyssal=own(new THREE.MeshStandardMaterial({color:'#3d5052',roughness:.48,metalness:.64,normalScale:new THREE.Vector2(.10,.10)}));
  const obsidian=own(new THREE.MeshStandardMaterial({color:'#242b2c',roughness:.27,metalness:.12,normalScale:new THREE.Vector2(.24,.24),flatShading:true}));
  const cord=own(new THREE.MeshStandardMaterial({color:'#88775a',roughness:1}));
  const darkCord=own(new THREE.MeshStandardMaterial({color:'#564b3b',roughness:1}));
  const char=own(new THREE.MeshStandardMaterial({color:'#28251f',roughness:1,normalScale:new THREE.Vector2(.48,.48)}));
  const ember=own(new THREE.MeshStandardMaterial({color:'#423026',emissive:'#db480d',emissiveIntensity:.75,roughness:1}));
  const light=new THREE.PointLight(0xffb879,0,18,2);light.name='Torch light';light.position.set(0,.405,.015);light.castShadow=false;group.add(light);

  // Textures load once per controller. A late load after disposal is released,
  // and every cached equipment model shares these materials and textures.
  const loader=new THREE.TextureLoader();
  function loadTexture(relative,color,apply){
    const texture=loader.load(new URL(relative,import.meta.url).href,loaded=>{
      if(disposed){loaded.dispose();return;}apply(loaded);
    },undefined,()=>{});
    texture.colorSpace=color?THREE.SRGBColorSpace:THREE.NoColorSpace;
    texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=4;own(texture);
  }
  function channel(materials,key,relative,color=false){loadTexture(relative,color,texture=>{for(const material of materials){material[key]=texture;material.needsUpdate=true;}});}
  channel([wood,char],'map','./assets/foliage/pine-bark_diff.jpg',true);
  channel([wood,char],'normalMap','./assets/foliage/pine-bark_nor_gl.jpg');
  channel([wood,char],'roughnessMap','./assets/foliage/pine-bark_rough.jpg');
  channel([stone],'map','./assets/materials/rock-albedo.jpg',true);
  channel([stone,copper,bronze,iron,abyssal,obsidian],'normalMap','./assets/materials/rock-normal.jpg');
  channel([stone,copper,bronze,iron,abyssal],'roughnessMap','./assets/materials/rock-roughness.jpg');

  function geometry(id,create){if(!geometryCache.has(id))geometryCache.set(id,own(create()));return geometryCache.get(id);}
  function mesh(parent,geo,material,position=[0,0,0],scale=null,rotation=null){
    const result=new THREE.Mesh(geo,material);result.position.set(...position);if(scale)result.scale.set(...scale);if(rotation)result.rotation.set(...rotation);
    result.castShadow=result.receiveShadow=true;parent.add(result);return result;
  }
  function tube(id,points,radius,taper=()=>1,{segments=32,sides=10,roughness=.018,bark=false}={}){
    return geometry(id,()=>{
      const curve=new THREE.CatmullRomCurve3(points.map(point)),shape=new THREE.TubeGeometry(curve,segments,radius,sides,false),positions=shape.attributes.position,uv=shape.attributes.uv;
      const center=new THREE.Vector3();
      for(let i=0;i<positions.count;i++){
        const t=Math.floor(i/(sides+1))/segments,a=(i%(sides+1))/sides*TAU;curve.getPointAt(t,center);
        const amount=taper(t)*(1+Math.sin(a*5+t*19)*roughness+Math.sin(a*9-t*11)*roughness*.45);
        positions.setXYZ(i,center.x+(positions.getX(i)-center.x)*amount,center.y+(positions.getY(i)-center.y)*amount,center.z+(positions.getZ(i)-center.z)*amount);
        if(bark)uv.setXY(i,uv.getY(i)*.82,uv.getX(i)*2.4);
      }
      shape.computeVertexNormals();return shape;
    });
  }
  function binding(id,y,turns=6,radius=.036){
    const points=[];for(let i=0;i<=turns*18;i++){const a=i/18*TAU;points.push([Math.cos(a)*radius,y+i/18*.0095,Math.sin(a)*radius*.87]);}
    return tube(id,points,.0034,()=>1,{segments:turns*22,sides:5,roughness:.12});
  }
  function lashings(parent,prefix,y,turns=6,radius=.036){
    mesh(parent,binding(`${prefix}-binding`,y,turns,radius),cord);
    mesh(parent,tube(`${prefix}-binding-cross`,[[-radius,y,.021],[radius*.8,y+turns*.0105,.029],[radius,y+turns*.0105,-.027],[-radius*.8,y,-.026],[-radius,y,.021]],.0031,()=>1,{segments:40,sides:5,roughness:.06}),darkCord);
  }
  // Lenticular blades thicken at the haft and meet along a thin, irregular edge.
  function blade(id,outline,{thickness=.046,roughness=.004,rings=6,sides=48}={}){
    return geometry(id,()=>{
      const boundary=new THREE.CatmullRomCurve3(outline.map(([x,y])=>new THREE.Vector3(x,y,0)),true,'centripetal');
      const center=outline.reduce((sum,[x,y])=>sum.add(new THREE.Vector3(x,y,0)),new THREE.Vector3()).multiplyScalar(1/outline.length);
      const positions=[],uv=[],indices=[];
      for(const side of [-1,1]){
        const start=positions.length/3;positions.push(center.x,center.y,side*thickness);uv.push(center.x*3+.5,center.y*3+.5);
        for(let ring=1;ring<=rings;ring++)for(let j=0;j<sides;j++){
          const t=ring/rings,a=j/sides*TAU,edge=boundary.getPoint(j/sides),x=center.x+(edge.x-center.x)*t,y=center.y+(edge.y-center.y)*t;
          const ridge=Math.sin(a*7+ring*2.1)*roughness*(.3+Math.sin(t*Math.PI)*.7),depth=.0018+thickness*Math.pow(Math.max(0,1-t*t),.7)+ridge;
          positions.push(x,y,side*Math.max(.0012,depth));uv.push(x*3+.5,y*3+.5);
          const index=start+1+(ring-1)*sides+j,next=start+1+(ring-1)*sides+(j+1)%sides;
          if(ring===1){if(side>0)indices.push(start,next,index);else indices.push(start,index,next);}
          else{const previous=index-sides,previousNext=next-sides;if(side>0)indices.push(previous,next,index,previous,previousNext,next);else indices.push(previous,index,next,previous,next,previousNext);}
        }
      }
      const firstEdge=1+(rings-1)*sides,secondEdge=1+rings*sides+firstEdge;
      for(let j=0;j<sides;j++){const k=(j+1)%sides;indices.push(firstEdge+j,secondEdge+j,secondEdge+k,firstEdge+j,secondEdge+k,firstEdge+k);}
      const shape=new THREE.BufferGeometry();shape.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));shape.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));shape.setIndex(indices);shape.computeVertexNormals();return shape;
    });
  }
  const handle=tube('tool-haft',[[.006,-.34,.004],[-.013,-.19,.008],[-.008,-.025,-.003],[.008,.13,-.008],[.006,.315,0]],.028,t=>.85+Math.sin(t*Math.PI)*.17,{bark:true,roughness:.038});
  const axeOutline=[[-.058,-.049],[-.053,.052],[.055,.082],[.172,.133],[.296,.112],[.338,.035],[.302,-.099],[.173,-.116],[.061,-.061]];
  const spearOutline=[[-.027,-.052],[-.063,.028],[-.052,.124],[-.021,.233],[0,.285],[.024,.225],[.057,.105],[.058,.021],[.024,-.052]];
  const metalFinish=item=>item.id.startsWith('copper')?copper:item.id.startsWith('bronze')?bronze:item.id.startsWith('abyssal')?abyssal:item.id.startsWith('obsidian')?obsidian:item.tier>=2?iron:stone;
  function makeModel(item){
    const model=new THREE.Group();model.name=`Held ${item.name||item.id}`;const id=item.id,type=item.tool||(/pickaxe/.test(id)?'pickaxe':/axe/.test(id)?'axe':/bow/.test(id)?'bow':/knife/.test(id)?'knife':/spear/.test(id)?'spear':'hammer'),finish=metalFinish(item),primitive=(item.tier||0)<2;
    if(id==='torch'){
      mesh(model,handle,wood);
      const head=tube('torch-charred-head',[[.003,.25,0],[.007,.315,-.002],[.001,.375,.003]],.04,t=>.9+Math.sin(t*Math.PI)*.16,{segments:18,sides:13,roughness:.13,bark:true});mesh(model,head,char);
      lashings(model,'torch',.225,7,.039);
      for(let i=0;i<5;i++)mesh(model,tube(`torch-splinter-${i}`,[[Math.sin(i*2)*.016,.30,Math.cos(i*2)*.019],[Math.sin(i*2)*.025,.382+(i%2)*.014,Math.cos(i*2)*.029]],.006,t=>1-t*.75,{segments:5,sides:5,roughness:.15}),i%2?char:ember);
      const plane=geometry('torch-flame-plane',()=>new THREE.PlaneGeometry(.22,.35,6,10));
      for(let i=0;i<2;i++){
        const material=own(new THREE.ShaderMaterial({uniforms:{flameTime:clock,flameSeed:{value:i*2.7}},vertexShader:flameVertex,fragmentShader:flameFragment,transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,toneMapped:false}));
        const flame=mesh(model,plane,material,[0,.548,0],i?[.81,.92,1]:null,[0,i*Math.PI/2,0]);flame.name='Transparent rising torch flame';flame.castShadow=flame.receiveShadow=false;flame.renderOrder=3;
      }
    }else if(type==='axe'){
      mesh(model,handle,wood);mesh(model,blade(primitive?'flaked-axe':'forged-axe',axeOutline,{thickness:primitive?.045:.026,roughness:primitive?.006:.0015}),finish,[-.005,.26,0]);lashings(model,'axe',.17,10,.037);
      if(!primitive)mesh(model,geometry('axe-haft-socket',()=>new THREE.CylinderGeometry(.043,.044,.10,12,2)),finish,[.004,.268,0]);
    }else if(type==='pickaxe'){
      mesh(model,handle,wood);
      const pick=tube(primitive?'stone-pick-head':'forged-pick-head',[[-.278,-.112,0],[-.21,-.014,.003],[-.09,.042,.002],[.038,.041,0],[.19,-.019,-.006],[.305,-.171,-.018]],primitive?.037:.028,t=>.055+Math.pow(Math.sin(t*Math.PI),.55)*(primitive?1.08:1.0),{segments:48,sides:primitive?7:12,roughness:primitive?.075:.015});
      mesh(model,pick,finish,[.005,.30,0]);lashings(model,'pick',.20,8,.037);
    }else if(type==='bow'){
      const bow=tube('bow-stave',[[.005,-.386,.005],[-.085,-.315,-.025],[-.145,-.15,-.056],[-.15,.02,-.061],[-.11,.215,-.042],[-.026,.36,-.008],[.016,.407,.004]],.022,t=>.42+Math.sin(t*Math.PI)*.62,{segments:50,sides:10,bark:true,roughness:.023});mesh(model,bow,wood);
      mesh(model,tube('bow-string',[[.005,-.386,.005],[.011,-.008,.008],[.016,.407,.004]],.0019,()=>1,{segments:16,sides:5,roughness:0}),cord);
      const grip=mesh(model,binding('bow-grip',-.057,11,.026),darkCord,[-.15,0,-.061]);grip.rotation.z=-.02;
      if(item.tier>=4)for(const y of [-.25,.24])mesh(model,binding(`bow-reinforcement-${y}`,y,4,.025),cord,[-.09,0,-.035]);
      mesh(model,tube('nocked-arrow',[[.011,-.005,.13],[.011,-.005,-.43]],.0036,()=>1,{segments:8,sides:6,bark:true}),wood);
      mesh(model,blade('arrow-point',spearOutline,{thickness:.025,roughness:.004,rings:4,sides:26}),stone,[.011,-.005,-.433],[.30,.30,.30],[-Math.PI/2,0,0]);
    }else if(id==='fishing_rod'||type==='fishing'){
      mesh(model,tube('fishing-rod',[[-.005,-.34,.005],[.008,.03,0],[.038,.36,-.025],[.073,.66,-.066]],.022,t=>1-t*.76,{segments:40,sides:9,bark:true}),wood);mesh(model,binding('rod-grip',-.19,14,.023),darkCord);
      mesh(model,tube('hanging-fishing-line',[[.073,.66,-.066],[.092,.45,-.118],[.10,.13,-.20],[.108,-.18,-.248]],.001,()=>1,{segments:28,sides:4,roughness:0}),cord);
      mesh(model,tube('fishing-hook',[[.108,-.18,-.248],[.108,-.216,-.248],[.123,-.228,-.248],[.135,-.214,-.248],[.130,-.200,-.248]],.0024,t=>t>.8?1-(t-.8)*3.8:1,{segments:16,sides:6,roughness:0}),iron);
    }else if(type==='spear'||type==='knife'||/sword/.test(id)){
      const knife=type==='knife',sword=/sword/.test(id);
      if(knife)mesh(model,tube('knife-grip',[[0,-.18,0],[-.007,-.067,.004],[0,.032,0]],.025,t=>.91+Math.sin(t*Math.PI)*.16,{segments:20,sides:10,bark:true}),wood);
      else mesh(model,tube('spear-shaft',[[.009,-.54,.005],[-.012,-.17,.006],[.003,.17,-.003],[0,.39,0]],.019,t=>1-t*.12,{segments:40,sides:9,bark:true}),wood);
      mesh(model,blade(primitive?'knapped-leaf-point':id.startsWith('obsidian')?'obsidian-leaf-point':'forged-leaf-point',spearOutline,{thickness:primitive?.023:.015,roughness:primitive?.004:.001,rings:6,sides:40}),finish,[0,knife?.048:.402,0],[knife?.81:1,sword?1.8:knife?.93:1,1]);lashings(model,knife?'knife':'spear',knife?-.034:.304,7,knife?.028:.023);
    }else if(type==='club'){
      mesh(model,tube('hardwood-club',[[.008,-.33,0],[-.008,-.12,.01],[.002,.08,-.005],[.028,.23,0],[.017,.33,.008]],.032,t=>.8+Math.pow(t,1.5)*1.7,{segments:34,sides:13,bark:true,roughness:.065}),wood);mesh(model,binding('club-grip',-.23,13,.030),darkCord);
    }else{
      mesh(model,handle,wood);
      const mallet=geometry('stone-hammer-head',()=>{const shape=new THREE.IcosahedronGeometry(1,2),p=shape.attributes.position;for(let i=0;i<p.count;i++){const amount=1+Math.sin(p.getX(i)*13+p.getY(i)*7)*.055;p.setXYZ(i,p.getX(i)*amount*.132,p.getY(i)*amount*.077,p.getZ(i)*amount*.079);}shape.computeVertexNormals();return shape;});mesh(model,mallet,finish,[.009,.28,0]);lashings(model,'hammer',.18,9,.038);
    }
    return model;
  }
  function set(item){
    if(disposed)return;const next=item?.id||'';if(next===key)return;
    current?.removeFromParent();key=next;swingRemaining=0;light.intensity=0;current=null;
    if(!next){group.visible=false;return;}
    if(!models.has(next))models.set(next,makeModel(item));current=models.get(next);group.add(current);
  }
  function update(dt,moving,visible,locomotion={}){
    if(disposed)return;
    dt=Number.isFinite(dt)?clamp(dt,0,.1):0;
    // Pausing hides equipment without advancing a tool swing or torch flame.
    if(!visible){body.update(0,moving,false,locomotion,0,Boolean(key));group.visible=false;light.intensity=0;return;}
    elapsed+=dt;clock.value=elapsed;swingRemaining=Math.max(0,swingRemaining-dt);
    const phase=1-swingRemaining/.4,stroke=swingRemaining>0?Math.sin(phase*Math.PI):0;
    const water=body.update(dt,moving,true,locomotion,stroke,Boolean(key));
    // Stow tools while swimming. Equipment selection is retained.
    group.position.set(0,-water*.24,water*.08);group.rotation.set(water*.64,0,-.10);
    group.scale.setScalar(Math.max(.001,1-water));group.visible=Boolean(key&&water<.995);
    light.intensity=key==='torch'&&group.visible&&!locomotion.swimming?16+Math.sin(elapsed*17.3)*.7+Math.sin(elapsed*31.7+.8)*.13+Math.sin(elapsed*5.2)*.16:0;
    ember.emissiveIntensity=.66+Math.sin(elapsed*8.8)*.07;
  }
  update(0,false,false);
  return{set,setProfile:body.setProfile,swing(){if(!disposed)swingRemaining=.4;},update,getDiagnostics(){return{...body.getDiagnostics(),equipped:key||null,toolVisible:group.visible,torchIntensity:Number(light.intensity.toFixed(3))};},dispose(){
    if(disposed)return;disposed=true;group.removeFromParent();for(const model of models.values())model.clear();models.clear();group.clear();
    for(const resource of resources)resource.dispose();resources.clear();geometryCache.clear();light.dispose?.();body.dispose();
  }};
}

