# Sky and lighting source

Kloofendal 48d Partly Cloudy (Pure Sky), 2K HDR, by Greg Zaal (original) and Jarod Guest (sky edits), from Poly Haven.

Source: https://polyhaven.com/a/kloofendal_48d_partly_cloudy_puresky

License: CC0. See https://polyhaven.com/license and https://docs.polyhaven.com/en/faq.

The HDR is stored locally in `assets/sky/partly-cloudy-2k.hdr`. The game makes no requests to Poly Haven while playing. Asset metadata was obtained from the Poly Haven public API using the ScarsOfTheWildPrototype/0.2 User-Agent.
