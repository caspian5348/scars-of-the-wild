import * as THREE from './vendor/three.module.js';

const assetRoot = new URL('./assets/foliage/', import.meta.url);

function fernGeometry(description, binary, meshIndex) {
  const primitive = description.meshes[meshIndex].primitives[0];
  function attribute(index) {
    const accessor = description.accessors[index], view = description.bufferViews[accessor.bufferView];
    const components = {SCALAR:1,VEC2:2,VEC3:3,VEC4:4}[accessor.type];
    const Type = {5126:Float32Array,5123:Uint16Array,5125:Uint32Array}[accessor.componentType];
    if (!Type || view.byteStride) throw new Error('Unsupported fern geometry layout.');
    const values = new Type(binary, (view.byteOffset || 0) + (accessor.byteOffset || 0), accessor.count * components);
    return new THREE.BufferAttribute(values.slice(), components, accessor.normalized || false);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', attribute(primitive.attributes.POSITION));
  geometry.setAttribute('normal', attribute(primitive.attributes.NORMAL));
  geometry.setAttribute('uv', attribute(primitive.attributes.TEXCOORD_0));
  geometry.setIndex(attribute(primitive.indices));
  geometry.computeBoundingBox(); geometry.computeBoundingSphere();
  return geometry;
}

/** Bundled photographic scans, generated broadleaf texture, and real fern meshes. */
export async function loadRealFoliage() {
  const loader = new THREE.TextureLoader(), textures = [];
  async function texture(filename, color = false, flipY = true) {
    const value = await loader.loadAsync(new URL(filename, assetRoot).href);
    value.colorSpace = color ? THREE.SRGBColorSpace : THREE.NoColorSpace;
    value.anisotropy = 8; value.flipY = flipY;
    value.wrapS = value.wrapT = THREE.RepeatWrapping; textures.push(value); return value;
  }
  const files = [
    ['pine-twig_diff.jpg',true],['pine-twig_alpha.jpg'],['pine-twig_nor_gl.jpg'],['pine-twig_rough.jpg'],
    ['pine-bark_diff.jpg',true],['pine-bark_nor_gl.jpg'],['pine-bark_rough.jpg'],
    ['fern-Diffuse.jpg',true,false],['fern-Alpha.jpg',false,false],['fern-nor_gl.jpg',false,false],['fern-Rough.jpg',false,false],
    ['grass-Diffuse.jpg',true,false],['grass-Alpha.jpg',false,false],['grass-nor_gl.jpg',false,false],['grass-Rough.jpg',false,false],
    ['jungle-broadleaf-v1.png',true],
  ];
  const results = await Promise.allSettled(files.map(args => texture(...args)));
  const failure = results.find(value => value.status === 'rejected');
  if (failure) { textures.forEach(value => value.dispose()); throw new Error('Photographic foliage textures could not load.', {cause:failure.reason}); }
  const values = results.map(result => result.value);
  const pine = {map:values[0],alphaMap:values[1],normalMap:values[2],roughnessMap:values[3]};
  // Upper-left atlas island is a complete photographic pine shoot; exclude bark/needle islands.
  for (const value of Object.values(pine)) { value.repeat.set(.218, .407); value.offset.set(.024, .554); }
  const bark = {map:values[4],normalMap:values[5],roughnessMap:values[6]};
  for (const value of Object.values(bark)) value.repeat.set(1.6, 8);
  const fern = {map:values[7],alphaMap:values[8],normalMap:values[9],roughnessMap:values[10]};
  const grass = {map:values[11],alphaMap:values[12],normalMap:values[13],roughnessMap:values[14]};
  const broadleaf=values[15];broadleaf.wrapS=broadleaf.wrapT=THREE.ClampToEdgeWrapping;
  const [descriptorResponse, binaryResponse] = await Promise.all([fetch(new URL('fern.gltf', assetRoot)), fetch(new URL('fern.bin', assetRoot))]);
  if (!descriptorResponse.ok || !binaryResponse.ok) throw new Error('The fern meshes could not load.');
  const [description, binary] = await Promise.all([descriptorResponse.json(), binaryResponse.arrayBuffer()]);
  const [grassDescription,grassBinary]=await Promise.all([fetch(new URL('grass.gltf',assetRoot)).then(r=>{if(!r.ok)throw new Error('Grass geometry unavailable.');return r.json();}),fetch(new URL('grass.bin',assetRoot)).then(r=>{if(!r.ok)throw new Error('Grass geometry unavailable.');return r.arrayBuffer();})]);
  return {pine,bark,fern,grass,broadleaf,fernGeometries:[fernGeometry(description,binary,2),fernGeometry(description,binary,3)],grassGeometries:[fernGeometry(grassDescription,grassBinary,11),fernGeometry(grassDescription,grassBinary,14)],textures};
}
