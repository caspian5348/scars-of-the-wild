import * as THREE from './vendor/three.module.js';
import {riverBankDistanceAt} from './river-network.js';

const TAU=Math.PI*2;
function generator(seed){return()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};}

// Stems, leaf blades and cupped petals share their actual attachment vertices.
export function flowerGeometry(variant=0){
  const p=[],c=[],ix=[];
  const vertex=(x,y,z,color)=>{const id=p.length/3;p.push(x,y,z);c.push(...color);return id;};
  const stem=t=>new THREE.Vector3(Math.sin(t*1.8)*.10,t*(.65+variant*.16),Math.sin(t*2.3)*.07);
  for(let ring=0;ring<=5;ring++){const s=stem(ring/5);for(let i=0;i<5;i++){const a=i/5*TAU;vertex(s.x+Math.cos(a)*.011,s.y,s.z+Math.sin(a)*.011,[.18,.32,.10]);if(ring<5){const n=ring*5+i,next=ring*5+(i+1)%5;ix.push(n,next,n+5,next,next+5,n+5);}}}
  function blade(base,angle,length,width,color,petal=false){
    const start=p.length/3;
    for(let row=0;row<=5;row++){const t=row/5,w=Math.sin(t*Math.PI)*width;for(const side of [-1,0,1]){
      const rise=petal?(Math.sin(t*Math.PI)*.065+t*t*.07):Math.sin(t*Math.PI)*.09;
      vertex(base.x+Math.cos(angle)*t*length-Math.sin(angle)*w*side,base.y+rise+(petal?side*side*.018:-side*side*w*.22),base.z+Math.sin(angle)*t*length+Math.cos(angle)*w*side,color.map(n=>n*(1-side*side*.12+t*.08)));
    }if(row>0)for(let col=0;col<2;col++){const n=start+(row-1)*3+col;ix.push(n,n+1,n+3,n+1,n+4,n+3);}}
  }
  for(let i=0;i<4;i++)blade(stem(.17+i*.16),i*2.4,.26+variant*.04,.068,[.20,.39,.11]);
  const palette=[[.77,.22,.36],[.78,.56,.17],[.45,.35,.70]],top=stem(1);
  for(let i=0;i<5+variant;i++)blade(top,i/(5+variant)*TAU,.16+variant*.024,.073,palette[variant],true);
  for(let i=0;i<7;i++){const a=i/7*TAU;const v=vertex(top.x,top.y+.055,top.z,[.90,.62,.13]),b=vertex(top.x+Math.cos(a)*.025,top.y+.03,top.z+Math.sin(a)*.025,[.72,.40,.08]),d=vertex(top.x+Math.cos(a+.9)*.025,top.y+.03,top.z+Math.sin(a+.9)*.025,[.72,.40,.08]);ix.push(v,b,d);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('color',new THREE.Float32BufferAttribute(c,3));g.setIndex(ix);g.computeVertexNormals();g.computeBoundingSphere();return g;
}

export function createForestFlowers({root,heightAt,blendAt,center,spread,count=1200,seed=691,glowing=false}){
  const group=new THREE.Group();group.name=glowing?'Luminous woodland flowers':'Rainforest orchids and flowering brush';root.add(group);
  const rng=generator(seed),clock={value:0},points=[],clusters=[],dummy=new THREE.Object3D(),geometries=[0,1,2].map(flowerGeometry);
  const mat=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.77,side:THREE.DoubleSide,emissive:glowing?'#84ffe4':'#000000',emissiveIntensity:glowing?.46:0});
  mat.onBeforeCompile=s=>{s.uniforms.flowerTime=clock;s.vertexShader='uniform float flowerTime;\n'+s.vertexShader;s.vertexShader=s.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
    float phase=instanceMatrix[3].x*.11+instanceMatrix[3].z*.08;
    transformed.x+=sin(flowerTime*.8+phase)*position.y*position.y*.055;
    transformed.z+=cos(flowerTime*.63+phase)*position.y*position.y*.024;
  `);if(glowing)s.fragmentShader=s.fragmentShader.replace('#include <emissivemap_fragment>','#include <emissivemap_fragment>\n totalEmissiveRadiance*=mix(vec3(.12),vColor.rgb,.88);');};mat.customProgramCacheKey=()=>`woodland-flowers-${glowing}-colored-petals`;
  for(let i=0;i<90;i++)clusters.push({x:center.x+(rng()*2-1)*spread.x,z:center.z+(rng()*2-1)*spread.z});
  for(let i=0;i<count*9&&points.length<count;i++){
    const cluster=clusters[i%clusters.length],a=rng()*TAU,r=Math.sqrt(rng())*14,x=cluster.x+Math.cos(a)*r,z=cluster.z+Math.sin(a)*r,h=heightAt(x,z);
    if(blendAt(x,z)<.50||h<3||riverBankDistanceAt(x,z)<.7||Math.hypot(heightAt(x+.4,z)-h,heightAt(x,z+.4)-h)>.5)continue;
    points.push({x,z,h,angle:rng()*TAU,scale:.7+rng()*.85,variant:i%3});
  }
  const batches=new Map();
  for(const point of points){const key=`${Math.floor(point.x/75)},${Math.floor(point.z/75)},${point.variant}`;if(!batches.has(key))batches.set(key,[]);batches.get(key).push(point);}
  const meshes=[];
  for(const list of batches.values()){
    const mesh=new THREE.InstancedMesh(geometries[list[0].variant],mat,list.length);
    list.forEach((v,i)=>{dummy.position.set(v.x,v.h-.01,v.z);dummy.rotation.set(0,v.angle,0);dummy.scale.setScalar(v.scale);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
    mesh.computeBoundingSphere();mesh.receiveShadow=true;group.add(mesh);meshes.push(mesh);
  }
  return{points,update(t,camera){clock.value=t;for(const mesh of meshes){const c=mesh.boundingSphere.center;mesh.visible=!camera||Math.hypot(camera.x-c.x,camera.z-c.z)<150+mesh.boundingSphere.radius;}},dispose(){root.remove(group);for(const mesh of meshes)mesh.dispose();for(const g of geometries)g.dispose();mat.dispose();}};
}
