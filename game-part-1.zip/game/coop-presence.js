import * as THREE from './vendor/three.module.js';
import {createCharacterModel} from './character-model.js';

export function createCoopPresence({scene,camera,selfId}){
  const views=new Map(),labels=document.createElement('div');labels.className='coop-player-labels';labels.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:22';document.body.append(labels);
  let roster=[],time=0,disposed=false;
  const targetPosition=new THREE.Vector3(),marker=new THREE.Vector3(),forward=new THREE.Vector3();
  function applySnapshot(snapshot){if(disposed)return;roster=(snapshot.players||[]).filter(p=>p.id!==selfId&&p.connected&&p.alive&&!['character','lobby','dead'].includes(p.mode)&&p.position&&[p.position.x,p.position.y,p.position.z,p.yaw].every(Number.isFinite));
    const ids=new Set(roster.map(p=>p.id));for(const [id,v] of views)if(!ids.has(id)){v.model.dispose();v.label.remove();views.delete(id);}
    for(const p of roster){const key=JSON.stringify(p.character);let v=views.get(p.id);if(v&&v.key!==key){v.model.dispose();v.label.remove();views.delete(p.id);v=null;}
      if(!v){const model=createCharacterModel(p.character);scene.add(model.root);model.root.position.set(p.position.x,p.position.y,p.position.z);model.root.rotation.y=p.yaw+Math.PI;
        const arms=['Left hand','Right hand'].map((name,index)=>{const arm=model.root.getObjectByName(name)?.parent;if(!arm)return null;const side=index===0?-1:1,pivot=new THREE.Vector3(side*.188,1.425,0);arm.position.copy(pivot);for(const child of arm.children)child.position.sub(pivot);return arm;});
        const label=document.createElement('span');label.style.cssText='position:absolute;left:0;top:0;color:#e6dcc0;background:#102720cf;border:1px solid #aaaf8466;padding:4px 8px;border-radius:3px;font:12px Segoe UI;white-space:nowrap';labels.append(label);v={model,label,key,arms};views.set(p.id,v);}v.target=p;v.label.textContent=p.name+(p.mode==='paused'?' · Paused':p.mode==='inventory'?' · Inventory':'');
    }
  }
  function update(dt){if(disposed)return;dt=Math.max(0,Math.min(.1,Number.isFinite(dt)?dt:0));time+=dt;camera.updateMatrixWorld();camera.getWorldDirection(forward);
    for(const v of views.values()){const p=v.target,root=v.model.root,blend=1-Math.exp(-dt*14);targetPosition.set(p.position.x,p.position.y,p.position.z);if(root.position.distanceToSquared(targetPosition)>400)root.position.copy(targetPosition);else root.position.lerp(targetPosition,blend);const yaw=p.yaw+Math.PI;root.rotation.y+=Math.atan2(Math.sin(yaw-root.rotation.y),Math.cos(yaw-root.rotation.y))*blend;v.model.update(dt);
      const moving=p.mode==='playing'&&['walking','running','swimming'].includes(p.motion),running=p.motion==='running',swimming=p.motion==='swimming',stride=Math.sin(time*(running?9:swimming?3.5:6.5));
      v.arms.forEach((arm,index)=>{if(arm)arm.rotation.x=moving?(swimming?-.8:0)+stride*(index?1:-1)*(running?.57:swimming?.55:.28):0;});
      marker.copy(root.position).add(new THREE.Vector3(0,2.06,0));const d=marker.distanceTo(camera.position),ahead=targetPosition.copy(marker).sub(camera.position).dot(forward)>0;marker.project(camera);v.label.hidden=!ahead||marker.z>1||marker.z< -1||Math.abs(marker.x)>1.1||Math.abs(marker.y)>1.1||d>100;v.label.style.transform=`translate(${(marker.x*.5+.5)*innerWidth}px,${(-marker.y*.5+.5)*innerHeight}px) translate(-50%,-100%)`;root.visible=d<160;
    }
  }
  return{applySnapshot,update,getDiagnostics:()=>({remotePlayers:views.size,ids:[...views.keys()]}),dispose(){if(disposed)return;disposed=true;for(const v of views.values())v.model.dispose();views.clear();labels.remove();}};
}
