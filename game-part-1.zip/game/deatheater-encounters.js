export const DEATHEATER_SPEED = 11;
export const DEATHEATER_DAMAGE = 100;
export const DEATHEATER_WARNING_SECONDS = 8;

const TAU = Math.PI * 2;
const finite = Number.isFinite;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const plain = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const vector = v => plain(v) && [v.x,v.y,v.z].every(finite) && Math.max(Math.abs(v.x),Math.abs(v.y),Math.abs(v.z)) < 100000;
const copyVector = v => ({x:v.x,y:v.y,z:v.z});
const stages = {circling:4,approaching:2.4,diving:3,recovering:4,retreating:5};
const angleOf = (dx,dz) => Math.atan2(-dx,-dz);
const wrapAngle = v => Math.atan2(Math.sin(v),Math.cos(v));

function randomAt(seed,index,purpose) {
  const text = JSON.stringify([String(seed),index,purpose]);
  let n = 2166136261;
  for (let i=0;i<text.length;i++) n = Math.imul(n ^ text.charCodeAt(i),16777619);
  n ^= n >>> 16; n = Math.imul(n,0x7feb352d);
  n ^= n >>> 15; n = Math.imul(n,0x846ca68b);
  return ((n ^ n >>> 16) >>> 0) / 4294967296;
}

function copyActive(a) {
  return {...a,position:copyVector(a.position),velocity:copyVector(a.velocity),goal:copyVector(a.goal),
    orbitCenter:{...a.orbitCenter},lockedTarget:a.lockedTarget ? copyVector(a.lockedTarget) : null};
}

/** Pure, tree-independent validation shared by the journey store and the controller. */
export function normalizeDeatheaterState(value) {
  if (value === undefined) return undefined;
  if (!plain(value) || value.version !== 1 || !((typeof value.seed === 'string' && value.seed.length > 0 && value.seed.length <= 512) || finite(value.seed))) return null;
  if (![value.clock,value.cooldown,value.warningRemaining,value.encounterIndex].every(finite) || value.clock < 0 || value.cooldown < 0 || value.cooldown > 75 || value.warningRemaining < 0 || value.warningRemaining > 8 || !Number.isSafeInteger(value.encounterIndex) || value.encounterIndex < 0 || typeof value.warningIssued !== 'boolean') return null;
  let active = null;
  if (value.active !== null) {
    const a = value.active;
    if (!plain(a) || typeof a.id !== 'string' || !a.id.length || a.id.length > 256 || !Object.hasOwn(stages,a.stage)) return null;
    if(a.health!==undefined&&(!finite(a.health)||a.health<=0||a.health>180))return null;
    if (![a.position,a.velocity,a.goal].every(vector) || a.lockedTarget !== null && !vector(a.lockedTarget)) return null;
    if (![a.remaining,a.heading,a.pitch,a.bank,a.huntRemaining,a.exitSeconds,a.swoopIndex,a.orbitAngle,a.orbitRadius,a.orbitAltitude].every(finite)) return null;
    if (a.remaining < 0 || a.remaining > stages[a.stage] + 1e-6 || a.huntRemaining < 0 || a.huntRemaining > 90 || a.exitSeconds < 0 || a.exitSeconds > 4.05 || !Number.isSafeInteger(a.swoopIndex) || a.swoopIndex < 0 || Math.abs(a.pitch) > Math.PI/2 + .001 || Math.abs(a.bank) > 1.3) return null;
    if (!plain(a.orbitCenter) || ![a.orbitCenter.x,a.orbitCenter.z].every(finite) || a.orbitRadius < 10 || a.orbitRadius > 40 || a.orbitAltitude < 8 || a.orbitAltitude > 45 || typeof a.struck !== 'boolean' || typeof a.passedTarget !== 'boolean') return null;
    if (a.stage === 'diving' && a.lockedTarget === null) return null;
    active = {
      id:a.id,stage:a.stage,remaining:a.remaining,position:copyVector(a.position),heading:a.heading,pitch:a.pitch,bank:a.bank,
      health:a.health??180,
      huntRemaining:a.huntRemaining,exitSeconds:a.exitSeconds,swoopIndex:a.swoopIndex,struck:a.struck,
      lockedTarget:a.lockedTarget ? copyVector(a.lockedTarget) : null,velocity:copyVector(a.velocity),orbitAngle:a.orbitAngle,
      orbitCenter:{x:a.orbitCenter.x,z:a.orbitCenter.z},orbitRadius:a.orbitRadius,orbitAltitude:a.orbitAltitude,
      goal:copyVector(a.goal),passedTarget:a.passedTarget,
    };
  }
  return {version:1,seed:String(value.seed),clock:value.clock,cooldown:value.cooldown,warningRemaining:value.warningRemaining,warningIssued:value.warningIssued,encounterIndex:value.encounterIndex,active};
}

/** Simulation time only: callers pause a hunt by withholding update(). No storage, DOM or renderer dependencies. */
export function createDeatheaterEncounters({heightAt,stormBlendAt = () => 0,isSafeAt = () => false,colliders = [],seed = 'deatheater',state,onDamage = () => {},onEvent = () => {},onChange = () => {},waterLevel = 2} = {}) {
  if (typeof heightAt !== 'function') throw new TypeError('Deatheater encounters need heightAt(x,z).');
  const restored = normalizeDeatheaterState(state);
  const runSeed = restored?.seed ?? String(seed);
  let clock = restored?.clock ?? 0, cooldown = restored?.cooldown ?? 0;
  let warningRemaining = restored?.warningRemaining ?? 8, warningIssued = restored?.warningIssued ?? false;
  let encounterIndex = restored?.encounterIndex ?? 0, active = restored?.active ? copyActive(restored.active) : null;
  const obstacles = colliders.filter(c => c && [c.x,c.z,c.radius].every(finite) && c.radius > 0).map(c => ({
    x:c.x,z:c.z,radius:c.radius,base:heightAt(c.x,c.z),top:finite(c.top) ? c.top : heightAt(c.x,c.z) + (finite(c.height) ? c.height : 4),
  }));

  function snapshot() { return {version:1,seed:runSeed,clock,cooldown,warningRemaining,warningIssued,encounterIndex,active:active ? copyActive(active) : null}; }
  function emit(type,details = {}) {
    const event = {type,id:active?.id ?? null,...details};
    onEvent(event);
    onChange(snapshot(),event);
  }
  function floor(x,z) { const h=heightAt(x,z); return finite(h) ? Math.max(h,waterLevel) : Infinity; }
  function head(player) { return {x:player.x,y:Math.max(player.y + 1.45,floor(player.x,player.z) + .95),z:player.z}; }
  function validPlayer(p) { return p && [p.x,p.y,p.z].every(finite); }
  function distance(a,b) { return Math.hypot(b.x-a.x,b.y-a.y,b.z-a.z); }

  // Swept clearance prevents large steps crossing a thin trunk, rock or a sudden ridge.
  function pathClear(from,to,margin = .72,checkGround = true) {
    const safeSamples=Math.max(1,Math.ceil(Math.hypot(to.x-from.x,to.z-from.z)/.4));
    for(let i=0;i<=safeSamples;i++){
      const t=i/safeSamples,x=from.x+(to.x-from.x)*t,z=from.z+(to.z-from.z)*t;
      if(isSafeAt(x,z))return false;
    }
    if (checkGround) for(let i=0;i<=4;i++) {
      const t=i/4,x=from.x+(to.x-from.x)*t,y=from.y+(to.y-from.y)*t,z=from.z+(to.z-from.z)*t;
      if(y < floor(x,z) + .9 - 1e-6)return false;
    }
    const dx=to.x-from.x,dz=to.z-from.z,len2=dx*dx+dz*dz;
    for(const c of obstacles) {
      if(Math.max(from.y,to.y) < c.base-.2 || Math.min(from.y,to.y) > c.top+margin)continue;
      const t=len2 > 1e-12 ? clamp(((c.x-from.x)*dx+(c.z-from.z)*dz)/len2,0,1) : 0;
      const x=from.x+dx*t,z=from.z+dz*t;
      if((x-c.x)**2+(z-c.z)**2 < (c.radius+margin)**2)return false;
    }
    return true;
  }

  function moveToward(goal,dt,speed = DEATHEATER_SPEED) {
    const a=active,from=copyVector(a.position),dx=goal.x-from.x,dy=goal.y-from.y,dz=goal.z-from.z;
    const length=Math.hypot(dx,dy,dz);
    if(length < .001){ a.velocity={x:0,y:0,z:0};return from; }
    const travel=Math.min(length,speed*dt),nx=dx/length,ny=dy/length,nz=dz/length;
    let next=null;
    for(const turn of [0,.52,-.52,1.05,-1.05,1.57,-1.57]) {
      const c=Math.cos(turn),s=Math.sin(turn),candidate={x:from.x+(nx*c-nz*s)*travel,y:from.y+ny*travel,z:from.z+(nx*s+nz*c)*travel};
      if(pathClear(from,candidate)){next=candidate;break;}
    }
    if(!next) {
      const up={x:from.x,y:from.y+travel,z:from.z};
      if(pathClear(from,up))next=up;
    }
    if(!next)next=from;
    const vx=(next.x-from.x)/dt,vy=(next.y-from.y)/dt,vz=(next.z-from.z)/dt,horizontal=Math.hypot(vx,vz);
    a.position=next;a.velocity={x:vx,y:vy,z:vz};
    if(horizontal > .001) {
      const heading=angleOf(vx,vz),turn=wrapAngle(heading-a.heading);
      a.bank += (clamp(-turn*1.6,-.7,.7)-a.bank)*Math.min(1,dt*5);
      a.heading=heading;
    }
    if(horizontal+Math.abs(vy) > .001)a.pitch=Math.atan2(vy,horizontal);
    return from;
  }

  function start(player) {
    if(active || !validPlayer(player)||isSafeAt(player.x,player.z))return false;
    const index=encounterIndex++,angle=randomAt(runSeed,index,'angle')*TAU;
    const radius=20+randomAt(runSeed,index,'radius')*6,altitude=18+randomAt(runSeed,index,'altitude')*5;
    // Choose a clear approach around the player without ever relocating an existing creature.
    let position=null,selectedAngle=angle;
    for(let i=0;i<16;i++) {
      const theta=angle+i*TAU/16,x=player.x+Math.cos(theta)*(radius+8),z=player.z+Math.sin(theta)*(radius+8);
      const candidate={x,y:Math.max(player.y+altitude+4,floor(x,z)+altitude),z};
      if(pathClear(candidate,candidate)){position=candidate;selectedAngle=theta;break;}
    }
    if(!position){encounterIndex--;return false;}
    active={id:`deatheater-${index}`,stage:'circling',remaining:4,position,heading:angleOf(player.x-position.x,player.z-position.z),pitch:0,bank:0,
      health:180,
      huntRemaining:60+randomAt(runSeed,index,'duration')*30,exitSeconds:0,swoopIndex:0,struck:false,lockedTarget:null,
      velocity:{x:0,y:0,z:0},orbitAngle:selectedAngle,orbitCenter:{x:player.x,z:player.z},orbitRadius:radius,orbitAltitude:altitude,
      goal:copyVector(position),passedTarget:false};
    warningIssued=false;warningRemaining=8;cooldown=0;emit('circling');return true;
  }

  function transition(stage,player,reason) {
    const a=active;
    a.stage=stage;a.remaining=stages[stage];
    if(stage==='approaching') {a.swoopIndex++;a.struck=false;a.passedTarget=false;a.lockedTarget=null;}
    if(stage==='diving') {a.lockedTarget ||= head(player);a.goal=copyVector(a.lockedTarget);}
    if(stage==='recovering' || stage==='retreating') {
      let dx=a.position.x-player.x,dz=a.position.z-player.z,l=Math.hypot(dx,dz);
      if(l<.5){dx=-Math.sin(a.heading);dz=-Math.cos(a.heading);l=1;}
      const reach=stage==='retreating'?65:20;
      const x=a.position.x+dx/l*reach,z=a.position.z+dz/l*reach;
      a.goal={x,y:Math.max(a.position.y+(stage==='retreating'?20:15),floor(x,z)+a.orbitAltitude),z};
    }
    if(stage==='circling') {
      a.orbitCenter={x:player.x,z:player.z};
      a.orbitAngle=Math.atan2(a.position.z-player.z,a.position.x-player.x);
    }
    emit(stage,reason ? {reason} : {});
  }

  function strikeIfContact(from,player) {
    const a=active;
    if(a.stage!=='diving' || a.struck||isSafeAt(player.x,player.z))return;
    const target=head(player),to=a.position,dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z;
    const len2=dx*dx+dy*dy+dz*dz,t=len2 > 1e-12 ? clamp(((target.x-from.x)*dx+(target.y-from.y)*dy+(target.z-from.z)*dz)/len2,0,1) : 0;
    const closest={x:from.x+dx*t,y:from.y+dy*t,z:from.z+dz*t};
    if(Math.hypot(closest.x-target.x,closest.z-target.z)>1.65 || Math.abs(closest.y-target.y)>1.15 || !pathClear(closest,target,.04,false))return;
    a.struck=true; // Persist this before callbacks: a fatal strike snapshot cannot strike twice after reload.
    emit('strike',{damage:DEATHEATER_DAMAGE});
    onDamage(DEATHEATER_DAMAGE,'Deatheater',copyActive(a));
  }

  function step(dt,player) {
    clock+=dt;
    const blend=stormBlendAt(player.x,player.z);
    if(!active) {
      cooldown=Math.max(0,cooldown-dt);
      if(isSafeAt(player.x,player.z)){
        if(warningIssued){warningIssued=false;warningRemaining=8;emit('warning-cancelled',{reason:'safe-zone'});}
        return;
      }
      if(cooldown>0)return;
      if(!warningIssued) {
        if(blend<=.55)return;
        warningIssued=true;warningRemaining=8;emit('warning');
      } else if(blend<.3) {
        warningIssued=false;warningRemaining=8;emit('warning-cancelled');return;
      }
      warningRemaining=Math.max(0,warningRemaining-dt);
      if(warningRemaining<=1e-8 && blend>.35)start(player);
      return;
    }
    const a=active;
    a.remaining=Math.max(0,a.remaining-dt);
    if(a.stage!=='retreating'&&(isSafeAt(player.x,player.z)||isSafeAt(a.position.x,a.position.z)))transition('retreating',player,'safe-zone');
    if(a.stage!=='retreating') {
      a.huntRemaining=Math.max(0,a.huntRemaining-dt);
      a.exitSeconds=blend<.12 ? Math.min(4,a.exitSeconds+dt) : 0;
      if(a.exitSeconds>=4-1e-8 || a.huntRemaining<=1e-8)transition('retreating',player,a.exitSeconds>=4-1e-8?'left-storm':'hunt-expired');
    }
    if(a.stage==='circling') {
      const follow=Math.min(1,dt*.8);
      a.orbitCenter.x+=(player.x-a.orbitCenter.x)*follow;a.orbitCenter.z+=(player.z-a.orbitCenter.z)*follow;
      a.orbitAngle+=dt*9/a.orbitRadius;
      const x=a.orbitCenter.x+Math.cos(a.orbitAngle)*a.orbitRadius,z=a.orbitCenter.z+Math.sin(a.orbitAngle)*a.orbitRadius;
      a.goal={x,y:Math.max(player.y+a.orbitAltitude,floor(x,z)+a.orbitAltitude),z};
      moveToward(a.goal,dt,10);
      if(a.remaining<=1e-8)transition('approaching',player);
    } else if(a.stage==='approaching') {
      if(a.remaining<=.65+1e-8 && !a.lockedTarget){a.lockedTarget=head(player);emit('target-locked');}
      const target=a.lockedTarget || head(player);
      a.goal={x:target.x,y:target.y+6.5,z:target.z};moveToward(a.goal,dt);
      if(a.remaining<=1e-8)transition('diving',player);
    } else if(a.stage==='diving') {
      if(!a.passedTarget && distance(a.position,a.lockedTarget)<.8) {
        a.passedTarget=true;
        a.goal={x:a.lockedTarget.x-Math.sin(a.heading)*10,y:a.lockedTarget.y+1.6,z:a.lockedTarget.z-Math.cos(a.heading)*10};
      }
      const from=moveToward(a.goal,dt);strikeIfContact(from,player);
      if(a.remaining<=1e-8 || a.passedTarget && distance(a.position,a.goal)<1)transition('recovering',player);
    } else if(a.stage==='recovering') {
      moveToward(a.goal,dt);
      if(a.remaining<=1e-8)transition('circling',player);
    } else {
      moveToward(a.goal,dt,12);
      if(a.remaining<=1e-8) {
        const id=a.id;
        active=null;cooldown=45+randomAt(runSeed,encounterIndex-1,'cooldown')*30;warningIssued=false;warningRemaining=8;
        emit('departed',{id});
      }
    }
  }

  function update(dt,player) {
    if(!finite(dt) || dt<=0 || !validPlayer(player))return;
    let remaining=Math.min(dt,.25);
    while(remaining>1e-9){const slice=Math.min(.05,remaining);step(slice,player);remaining-=slice;}
  }
  function updateMany(dt,players){
    const valid=Array.isArray(players)?players.filter(p=>validPlayer(p)&&p.alive!==false&&p.connected!==false):[];
    if(!finite(dt)||dt<=0||!valid.length)return;
    let remaining=Math.min(dt,.25);
    while(remaining>1e-9){
      const eligible=valid.filter(p=>!isSafeAt(p.x,p.z)&&stormBlendAt(p.x,p.z)>.35),pool=eligible.length?eligible:valid;
      const player=active?[...pool].sort((a,b)=>distance(active.position,a)-distance(active.position,b))[0]:pool[0];
      if(active)active.targetPlayerId=player.id;
      const slice=Math.min(.05,remaining);step(slice,player);if(active)active.targetPlayerId=player.id;remaining-=slice;
    }
  }
  return {update,updateMany,snapshot,getActive:() => active ? [copyActive(active)] : [],forceEncounter:start,
    damage(id,amount){if(!active||active.id!==id||!finite(amount)||amount<=0)return null;active.health=Math.max(0,(active.health??180)-amount);const health=active.health,killed=health<=0;
      if(killed){active=null;cooldown=75;warningIssued=false;warningRemaining=8;emit('killed',{id});}return{hit:true,killed,health,loot:killed?{raw_meat:4,bone:4,hide:2}:null};}};
}
