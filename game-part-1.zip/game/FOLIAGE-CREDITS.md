# Foliage assets

The foliage uses locally bundled Poly Haven assets, published under the [CC0 public-domain license](https://polyhaven.com/license).

- [Pine Tree 01](https://polyhaven.com/a/pine_tree_01): photography by Rob Tuytel; modeling by Rico Cilliers. The game uses the 2K photographic pine-shoot diffuse, alpha, OpenGL normal and roughness atlas, plus 2K bark diffuse, OpenGL normal and roughness maps. The original full-detail 3D tree is not bundled. The forest's instanced branch layout is authored for this prototype, with its UVs restricted to the photographed shoot in the source atlas.
- [Fern 02](https://polyhaven.com/a/fern_02): scanning by Rob Tuytel; modeling by Rico Cilliers. The game uses the original fern meshes (variants `fern_02_a` and `fern_02_d`, 784 and 816 triangles) and the 2K diffuse, alpha, OpenGL normal and roughness textures. Detailed fern instances are capped at 300; distant plants use lightweight frond geometry with the same photographic material.
- [Grass Medium 01](https://polyhaven.com/a/grass_medium_01): the game uses the original `grass_medium_01_tiny_c_LOD0` and `grass_medium_01_tiny_d_LOD0` blade meshes (40 and 32 triangles), with 1K diffuse, alpha, OpenGL normal and roughness textures. Instances form denser grass along both river banks.

Original metadata is retained in the workspace's `work/foliage-research/` directory. Texture source URLs and verified MD5 checksums are recorded in `assets/foliage/provenance.json`. Source atlases are unchanged; UV transforms select their relevant islands at render time.

The rainforest's separate `assets/foliage/jungle-broadleaf-v1.png` is AI-generated with the built-in image tool. Its original RGBA pixels are preserved; provenance, full prompt, geometry integration and preview controls are documented in `JUNGLE-ASSETS.md`. It is not a Poly Haven asset.

The scene is a real-time browser prototype using photographic materials and scanned fern geometry. It does not use the full 17-million-triangle pine model.
