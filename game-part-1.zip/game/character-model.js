import * as THREE from './vendor/three.module.js';
import {normalizeCharacterProfile,SKIN_TONES,CLOTHING_COLORS} from './character-profile.js';
import {createScannedHead} from './scanned-character-head.js';

// Three original 1K CC0 Rough Linen channels from Poly Haven. The finite,
// page-lifetime cache is shared across appearance edits; disposed characters
// release their own materials without invalidating another preview's maps.
let clothTexturePromise;
function loadClothingTextures(){
  if(typeof document==='undefined')return Promise.resolve(null);
  if(!clothTexturePromise){const loader=new THREE.TextureLoader();clothTexturePromise=Promise.allSettled([
    ['map','linen-albedo.jpg',true],['normalMap','linen-normal.jpg',false],['roughnessMap','linen-roughness.jpg',false]
  ].map(async([channel,file,color])=>{const texture=await loader.loadAsync(new URL(`./assets/character/${file}`,import.meta.url).href);texture.name=`Poly Haven Rough Linen ${channel}`;texture.colorSpace=color?THREE.SRGBColorSpace:THREE.NoColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(3.2,2.1);texture.anisotropy=4;return[channel,texture];})).then(results=>{const failed=results.find(r=>r.status==='rejected');if(failed){results.filter(r=>r.status==='fulfilled').forEach(r=>r.value[1].dispose());clothTexturePromise=null;console.warn('Clothing material unavailable',failed.reason);return null;}return Object.fromEntries(results.map(r=>r.value));});}
  return clothTexturePromise;
}

/** A clothed adult-scale survivor, in metres. +Z faces the camera. Facial
 * anatomy and skin detail come from a scan, not a primitive placeholder. */
export function createCharacterModel(value) {
  const profile=normalizeCharacterProfile(value),root=new THREE.Group();
  root.name='Survivor appearance';
  const geometries=new Set(),materials=new Set(),textures=new Set();
  const own=g=>(geometries.add(g),g);
  const surface=(color,roughness=.8,detail='')=>{
    const m=new THREE.MeshStandardMaterial({color,roughness,metalness:0,vertexColors:true});
    if(detail==='cloth')m.userData.clothingScan=true;
    if(detail&&detail!=='cloth'){
      const size=128,data=new Uint8Array(size*size*4);
      for(let y=0;y<size;y++)for(let x=0;x<size;x++){
        const i=(y*size+x)*4,hash=Math.sin(x*67.13+y*31.91)*43758.54;
        const noise=(hash-Math.floor(hash)-.5)*14;
        const weave=detail==='cloth'?((x%3===0?18:0)+(y%3===0?11:0)):detail==='leather'?noise*.7:noise;
        data[i]=128+weave*.22+noise*.45;data[i+1]=128-weave*.18+noise*.4;
        data[i+2]=251;data[i+3]=255;
      }
      const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);
      texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(detail==='cloth'?6:3,detail==='cloth'?8:3);
      texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.generateMipmaps=true;texture.anisotropy=4;
      texture.needsUpdate=true;texture.name=`Survivor ${detail} microdetail`;textures.add(texture);
      m.normalMap=texture;m.normalScale.setScalar(detail==='cloth'?.28:.16);
    }
    materials.add(m);return m;
  };
  const skin=surface(SKIN_TONES[profile.skinTone].color,.7,'skin');
  const shade=surface(new THREE.Color(skin.color).multiplyScalar(.77),.84);
  const shirt=surface(CLOTHING_COLORS[profile.topColor].color,.93,'cloth');
  const shirtDark=surface(new THREE.Color(shirt.color).multiplyScalar(.7),.96,'cloth');
  const seam=surface(new THREE.Color(shirt.color).multiplyScalar(1.12),.93);
  const pants=surface('#444638',.96,'cloth'),pantsSeam=surface('#515344',.95);
  const leather=surface('#43372b',.79,'leather'),sole=surface('#24251f',.95);
  const leatherSeam=surface('#594a37',.88,'leather'),thread=surface('#98866d',.98);
  const metal=surface('#666961',.60);metal.metalness=.68;
  const nail=surface(new THREE.Color(skin.color).lerp(new THREE.Color('#c9afa1'),.18),.47,'skin');
  const unitSphere=own(new THREE.SphereGeometry(1,24,16));
  const mesh=(geometry,material,parent=root)=>{if(!geometry.attributes.color){const c=new Float32Array(geometry.attributes.position.count*3).fill(1);geometry.setAttribute('color',new THREE.BufferAttribute(c,3));}const m=new THREE.Mesh(geometry,material);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;};
  const sphere=(parent,mat,pos,scale)=>{const m=mesh(unitSphere,mat,parent);m.position.set(...pos);m.scale.set(...scale);return m;};
  const tube=(parent,mat,points,radius=.005,segments=20)=>{
    if(parent===body&&(mat===seam||mat===shirtDark)&&points.every(p=>p[1]<1.42&&p[1]>.93))points=points.map(([x,y,z])=>[x,y,Math.sign(z||1)*(shirtSurface(x,y)+.003)]);
    const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));
    const m=mesh(own(new THREE.TubeGeometry(curve,segments,radius,6,false)),mat,parent);if(radius<.003){m.castShadow=false;m.receiveShadow=false;}return m;
  };
  // Interpolated anatomical rings and localized cloth drape keep shoulders,
  // elbows and knees continuous. Creases follow fabric tension at each joint.
  const loft=(parent,mat,input,sides=32)=>{
    const rings=[],positions=[],uv=[],colors=[],index=[];
    const cat=(a,b,c,d,t)=>.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
    for(let j=0;j<input.length-1;j++)for(let k=0;k<4;k++){const t=k/4,r=[];for(let v=0;v<5;v++){const a=input[Math.max(0,j-1)][v]||0,b=input[j][v]||0,c=input[j+1][v]||0,d=input[Math.min(input.length-1,j+2)][v]||0;r.push(v===0?b+(c-b)*t:cat(a,b,c,d,t));}rings.push(r);}rings.push(input.at(-1));
    rings.forEach(([y,rx,rz,cx=0,cz=0],row)=>{
      for(let i=0;i<=sides;i++){const a=i/sides*Math.PI*2;let fold=0;
        if(mat===shirt||mat===shirtDark){const joint=Math.exp(-Math.pow((y-1.14)/.045,2)),waist=Math.exp(-Math.pow((y-.98)/.06,2));fold=Math.sin(y*99+a*2.6)*.0032*joint+Math.sin(y*81-a*3.1)*.0035*waist+Math.sin(a*6+y*12)*.0012;}
        if(mat===pants){const knee=Math.exp(-Math.pow((y-.475)/.053,2)),cuff=Math.exp(-Math.pow((y-.18)/.039,2)),hip=Math.exp(-Math.pow((y-.745)/.055,2));fold=Math.sin(y*95+a*3)*.0041*knee+Math.sin(y*118-a*2)*.0032*cuff+Math.sin(y*62+a*3)*.0025*hip;}
        const tone=1-Math.max(0,-fold)*7;positions.push(cx+Math.cos(a)*(rx+fold),y,cz+Math.sin(a)*(rz+fold*.7));uv.push(i/sides,row/(rings.length-1));colors.push(tone,tone,tone);}
    });
    for(let j=0;j<rings.length-1;j++)for(let i=0;i<sides;i++){const a=j*(sides+1)+i,b=a+sides+1;index.push(a,b,a+1,b,b+1,a+1);}
    // Small end caps close sleeve shoulders, wrists and boots; the scan neck
    // enters the shirt independently, so no visible sphere joint is required.
    for(const row of [0,rings.length-1]){const r=rings[row],n=positions.length/3;positions.push(r[3]||0,r[0],r[4]||0);uv.push(.5,row===0?0:1);colors.push(1,1,1);for(let i=0;i<sides;i++){const a=row*(sides+1)+i;row===0?index.push(n,a,a+1):index.push(n,a+1,a);}}
    const geo=own(new THREE.BufferGeometry());geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.setIndex(index);geo.computeVertexNormals();
    return mesh(geo,mat,parent);
  };
  const fabricPatch=(parent,mat,{x,y,z,width,height,depth=.008})=>{
    const p=[],uv=[],ix=[],cols=8,rows=10;for(let j=0;j<=rows;j++)for(let i=0;i<=cols;i++){const u=i/cols,v=j/rows,edge=Math.sin(u*Math.PI)*Math.sin(v*Math.PI),px=x+(u-.5)*width,py=y+(v-.5)*height,pz=parent===body?shirtSurface(px,py)+.0025:z;p.push(px,py,pz+edge*(depth+Math.sin(u*9+v*7)*.0014));uv.push(u,v);}for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const n=j*(cols+1)+i;ix.push(n,n+1,n+cols+1,n+1,n+cols+2,n+cols+1);}const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();const m=mesh(g,mat,parent);m.castShadow=m.receiveShadow=false;return m;
  };
  const build={slender:{width:.89,depth:.94},balanced:{width:1,depth:1},broad:{width:1.13,depth:1.12}}[profile.bodyType];
  const body=new THREE.Group();root.add(body);body.name='Breathing torso';
  const torsoRings=[[.945,.145,.107],[.978,.153,.111],[1.035,.151,.104],[1.13,.147,.104],[1.24,.170,.118],[1.32,.190,.116],[1.39,.198,.098],[1.44,.147,.070],[1.468,.070,.052]].map(r=>[r[0],r[1]*build.width,r[2]*build.depth]);
  function shirtSurface(x,y){let j=0;while(j<torsoRings.length-2&&torsoRings[j+1][0]<y)j++;const b=torsoRings[j],c=torsoRings[j+1],a=torsoRings[Math.max(0,j-1)],d=torsoRings[Math.min(torsoRings.length-1,j+2)],t=Math.max(0,Math.min(1,(y-b[0])/(c[0]-b[0]))),cat=v=>.5*(2*b[v]+(-a[v]+c[v])*t+(2*a[v]-5*b[v]+4*c[v]-d[v])*t*t+(-a[v]+3*b[v]-3*c[v]+d[v])*t*t*t),rx=cat(1),rz=cat(2),angle=Math.acos(Math.max(-1,Math.min(1,x/rx))),joint=Math.exp(-Math.pow((y-1.14)/.045,2)),waist=Math.exp(-Math.pow((y-.98)/.06,2)),fold=Math.sin(y*99+angle*2.6)*.0032*joint+Math.sin(y*81-angle*3.1)*.0035*waist+Math.sin(angle*6+y*12)*.0012;return (rz+fold*.7)*Math.sqrt(Math.max(0,1-Math.pow(x/(rx+fold),2)));}
  loft(body,shirt,torsoRings,40);
  loft(body,shirtDark,[[.94,.145,.108],[.95,.147,.110],[.958,.149,.111]].map(r=>[r[0],r[1]*build.width,r[2]*build.depth]),40);
  // Open collar, a short placket and understated stitching give the shirt weight.
  for(const side of [-1,1]){
    const points=[side*.065,1.45,.052,side*.088,1.427,.078,side*.044,1.394,.11,side*.025,1.42,.088];
    const geometry=own(new THREE.BufferGeometry());geometry.setAttribute('position',new THREE.Float32BufferAttribute(points,3));geometry.setAttribute("uv",new THREE.Float32BufferAttribute([0,1,1,1,1,0,0,0],2));geometry.setIndex([0,1,2,0,2,3]);geometry.computeVertexNormals();
    const collar=mesh(geometry,shirtDark,body);collar.material.side=THREE.DoubleSide;
    tube(body,seam,[[side*.086,1.427,.08],[side*.044,1.397,.112],[side*.026,1.421,.091]],.0014,8);
  }
  tube(body,seam,[[0,1.391,.115],[0,1.30,.123],[0,1.22,.122]],.0018,10);
  for(const y of [1.35,1.30,1.25])sphere(body,shirtDark,[.003,y,.125],[.004,.004,.002]);
  for(const side of [-1,1]){
    const px=side*.107*build.width,pz=.108*build.depth;
    fabricPatch(body,shirt,{x:px,y:1.263,z:pz,width:.078,height:.095,depth:.014});
    fabricPatch(body,shirtDark,{x:px,y:1.303,z:pz+.004,width:.081,height:.026,depth:.014});
    tube(body,seam,[[px-.037,1.310,pz+.002],[px-.037,1.224,pz+.002],[px,1.216,pz+.007],[px+.037,1.224,pz+.002],[px+.037,1.310,pz+.002]],.0007,16);
  }
  fabricPatch(body,shirtDark,{x:.005,y:1.19,z:.113*build.depth,width:.023,height:.37,depth:.008});
  // Trousers and subtly bent legs use full adult proportions (roughly 7.7 heads high).
  createTrousers();
  loft(root,leather,[[.967,.150,.110],[.992,.148,.110]].map(r=>[r[0],r[1]*build.width,r[2]*build.depth]),40);
  const buckle=mesh(own(new THREE.BoxGeometry(.035,.027,.008)),pantsSeam);buckle.position.set(0,.991,.113);
  for(const side of [-1,1]){
    const lx=side*.083*build.width;
    createBoot(lx,side);
    tube(root,pantsSeam,[[lx+side*.059,.18,0],[lx+side*.069,.44,.005],[lx+side*.084,.75,0]],.0016,12);
    const pocket=new THREE.Group();pocket.position.set(lx+side*.078,.696,.002);pocket.rotation.y=side*Math.PI/2;root.add(pocket);
    fabricPatch(pocket,pants,{x:0,y:0,z:0,width:.101,height:.125,depth:.013});fabricPatch(pocket,pantsSeam,{x:0,y:.045,z:.004,width:.104,height:.034,depth:.008});
    tube(pocket,pantsSeam,[[-.047,.055,.002],[-.047,-.054,.002],[.047,-.054,.002],[.047,.055,.002]],.0007,16);
    tube(root,pantsSeam,[[side*.077*build.width,.955,.100*build.depth],[side*.113*build.width,.909,.086*build.depth],[side*.139*build.width,.886,.060*build.depth]],.0011,14);
  }
  function createTrousers(){
    // Each leg becomes one half of the hip surface. Welded vertices at the
    // crotch and front/back centre replace the old overlapping pelvis cup.
    const rings=[[.105,.052,.052],[.16,.054,.057],[.22,.057,.062],[.30,.062,.069],[.39,.063,.069],[.46,.064,.066],[.51,.064,.070],[.59,.073,.081],[.67,.079,.087],[.74,.082,.090],[.78,.081,.093],[.81,.080,.097],[.835,.080,.104],[.855,.080,.111],[.89,.080,.113],[.94,.08,.109],[.99,.075,.105]];
    const p=[],uv=[],indices=[],lookup=new Map(),sides=40;
    const vertex=(x,y,z,u,v)=>{const key=[x,y,z].map(n=>Math.round(n*1e6)).join(',');if(lookup.has(key))return lookup.get(key);const i=p.length/3;lookup.set(key,i);p.push(x,y,z);uv.push(u,v);return i;};
    for(const side of [-1,1]){const rows=[];for(let row=0;row<rings.length;row++){const[y,rx,rz]=rings[row],blend=Math.max(0,Math.min(1,(y-.78)/.075)),t=blend*blend*(3-2*blend),hipRX=(y>.89?.167-(y-.89)*.20:.167)*build.width,hipRZ=(y>.89?.116-(y-.89)*.08:.116)*build.depth,ids=[];
      for(let i=0;i<=sides;i++){const a=i/sides*Math.PI*2,c=Math.cos(a),s=Math.sin(a),legX=side*(.083*build.width+c*rx),hipX=side*Math.max(0,c)*hipRX;let x=legX+(hipX-legX)*t,z=s*rz+(s*hipRZ-s*rz)*t;const knee=Math.exp(-Math.pow((y-.475)/.052,2)),cuff=Math.exp(-Math.pow((y-.17)/.045,2)),fold=Math.sin(y*96+a*3)*.0033*knee+Math.sin(y*112-a*2)*.0026*cuff;x+=side*c*fold*(1-t);z+=s*fold*(1-t);ids.push(vertex(x,y,z,(side>0?.5:0)+Math.acos(Math.max(-1,Math.min(1,c)))/Math.PI*.5,(y-.105)/.885));}rows.push(ids);}
      for(let row=0;row<rings.length-1;row++)for(let i=0;i<sides;i++){if(rings[row][0]>=.855&&Math.cos((i+.5)/sides*Math.PI*2)<0)continue;const a=rows[row][i],b=rows[row+1][i],c=rows[row][i+1],d=rows[row+1][i+1];side===1?indices.push(a,b,c,b,d,c):indices.push(a,c,b,b,c,d);}
    }
    const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();mesh(g,pants);
  }
  function createBoot(lx,side){
    const steps=36,p=[],uv=[],ix=[],levels=[.013,.028,.045,.068,.094,.124,.154,.182];
    const outline=a=>({x:Math.cos(a)*(.059+.007*Math.sin(a)),z:-.041+(Math.sin(a)+1)*.126});
    for(let row=0;row<levels.length;row++)for(let i=0;i<=steps;i++){const a=i/steps*Math.PI*2,o=outline(a),front=Math.max(0,Math.min(1,(o.z-.008)/.15)),top=Math.max(0,(row-2)/5);p.push(lx+o.x*(1-top*.18)+Math.sin(a*8+row*1.8)*.0008,levels[row]-front*front*top*.105,o.z*(1-top*.55*front)-top*.027);uv.push(i/steps,row/(levels.length-1));}
    for(let row=0;row<levels.length-1;row++)for(let i=0;i<steps;i++){const n=row*(steps+1)+i;ix.push(n,n+steps+1,n+1,n+1,n+steps+1,n+steps+2);}const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();mesh(g,leather);
    const shape=new THREE.Shape();for(let i=0;i<=36;i++){const o=outline(i/36*Math.PI*2);i?shape.lineTo(o.x,o.z):shape.moveTo(o.x,o.z);}const sg=own(new THREE.ExtrudeGeometry(shape,{depth:.019,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:.002,bevelThickness:.002}));sg.rotateX(Math.PI/2);const so=mesh(sg,sole);so.position.set(lx,.023,0);
    const welt=[];for(let i=0;i<=36;i++){const o=outline(i/36*Math.PI*2);welt.push([lx+o.x*1.01,.030,o.z]);}tube(root,leatherSeam,welt,.002,36);
    const toe=[];for(let i=0;i<=12;i++){const a=i/12*Math.PI;toe.push([lx+Math.cos(a)*.06,.055+Math.sin(a)*.008,.135+Math.sin(a)*.024]);}tube(root,leatherSeam,toe,.0011,18);
    fabricPatch(root,leatherSeam,{x:lx,y:.108,z:.069,width:.052,height:.099,depth:.018});
    for(let j=0;j<5;j++){const y=.145-j*.014,z=.066+j*.014;for(const sx of [-1,1]){const eye=mesh(own(new THREE.CylinderGeometry(.0028,.0028,.002,8)),metal);eye.position.set(lx+sx*.023,y,z);eye.rotation.x=Math.PI/2;}
      tube(root,thread,[[lx-.023,y,z],[lx,y-.004,z+.008],[lx+.023,y-.011,z+.011]],.0012,5);tube(root,thread,[[lx+.023,y,z],[lx,y-.004,z+.009],[lx-.023,y-.011,z+.011]],.0012,5);}
    for(const x of [-.032,.032])for(let j=0;j<5;j++){const tread=mesh(own(new THREE.BoxGeometry(.027,.008,.018)),sole);tread.position.set(lx+x,.008,.002+j*.035);}
    tube(root,leatherSeam,[[lx+side*.051,.045,-.014],[lx+side*.05,.105,-.023],[lx+side*.044,.168,-.03]],.001,12);
  }
  // Arms hang naturally with a slight elbow bend rather than a rigid T-pose.
  const armGroups=[];
  for(const side of [-1,1]){
    const arm=new THREE.Group();body.add(arm);armGroups.push(arm);
    const sx=side*.188*build.width;
    const rings=[[1.456,.006,.016,sx-side*.083],[1.448,.024,.032,sx-side*.053],[1.429,.044,.047,sx-side*.015],[1.398,.060,.062,sx+side*.004],[1.35,.061,.065,sx+side*.015],[1.27,.056,.060,sx+side*.036],[1.18,.047,.051,sx+side*.057],[1.13,.045,.050,sx+side*.063]];
    if(profile.sleeve==='long')rings.push([1.065,.046,.05,sx+side*.068,.014],[.99,.039,.043,sx+side*.072,.031],[.942,.033,.035,sx+side*.075,.04],[.918,.030,.033,sx+side*.075,.043]);
    loft(arm,shirt,rings.reverse(),24);
    if(profile.sleeve==='rolled'){
      loft(arm,shirtDark,[[1.122,.05,.056,sx+side*.063],[1.155,.053,.058,sx+side*.062],[1.162,.05,.056,sx+side*.06]],24);
      loft(arm,skin,[[.926,.028,.03,sx+side*.076,.044],[.985,.035,.038,sx+side*.074,.035],[1.045,.044,.045,sx+side*.071,.024],[1.108,.042,.046,sx+side*.064,.005],[1.147,.037,.043,sx+side*.061]],24);
    }
    createRelaxedHand(arm,sx+side*.077,.912,.043,side);
  }
  function createRelaxedHand(parent,x,y,z,side){
    const hand=new THREE.Group();hand.name=side===1?'Right hand':'Left hand';hand.userData.anatomicalSide=side;hand.position.set(x,y,z);hand.rotation.z=side*.035;hand.rotation.y=side*.40;parent.add(hand);
    const inward=-side;
    // The broad metacarpal plane narrows into the matching forearm section.
    // +Z is the back of the hand; flexion and palm creases belong on -Z.
    const palm=loft(hand,skin,[[-.048,.038,.0185,inward*.002,-.002],[-.043,.038,.019,inward*.002,-.002],[-.021,.034,.021,inward*.002,-.002],[.002,.028,.025,0,-.001],[.023,.028,.030,0,0],[.029,.0275,.030,0,0]],32);palm.name='Continuous palm and wrist';
    const palmIndices=Array.from(palm.geometry.index.array),palmCapStart=palmIndices.length-32*6;palm.geometry.setIndex([...palmIndices.slice(0,palmCapStart),...palmIndices.slice(palmCapStart+32*3)]);
    const digitNames=['index','middle','ring','little'],lengths=[.073,.084,.078,.057],radii=[.008,.0085,.008,.0065],starts=[-.064,-.070,-.067,-.057];
    const fingerMeshes=[];
    for(let d=0;d<4;d++){
      const dx=side*(d-1.5)*.018,length=lengths[d],points=[new THREE.Vector3(dx,starts[d],-.002)];
      // Three phalanges flex progressively toward the palm. The little finger
      // rests slightly more curled than the index finger, without a clenched fist.
      const angles=[.12,.35+d*.025,.56+d*.035],fractions=[.43,.32,.25];
      for(let k=0;k<3;k++){const previous=points.at(-1);points.push(previous.clone().add(new THREE.Vector3(side*(d-1.5)*.00055,-Math.cos(angles[k])*length*fractions[k],-Math.sin(angles[k])*length*fractions[k])));}
      fingerMeshes.push(makeDigit(hand,digitNames[d],points,radii[d],false));
    }
    joinPalmAndFingers(hand,palm,fingerMeshes);
    // An opposed thumb begins inside the thenar pad and points medially. The
    // old rotation sign directed its tip back across the palm; explicit mirrored
    // anatomical landmarks make that impossible for either hand.
    makeDigit(hand,'thumb',[[inward*.023,-.018,-.001],[inward*.041,-.035,-.005],[inward*.050,-.057,-.012],[inward*.047,-.080,-.023]].map(p=>new THREE.Vector3(...p)),.0125,true);
    for(const points of [
      [[inward*.025,-.018,-.021],[inward*.014,-.034,-.023],[inward*.011,-.055,-.019]],
      [[-.023,-.040,-.018],[-.003,-.051,-.021],[.022,-.044,-.019]]
    ])tube(hand,shade,points,.00023,12);
    hand.userData.handLengthMetres=.175;
    return hand;
  }
  function makeDigit(parent,name,points,baseRadius,isThumb){
    const curve=new THREE.CatmullRomCurve3(points,false,'centripetal'),rows=30,sides=18,p=[],uv=[],ix=[];
    function section(t){const center=curve.getPointAt(t),tangent=curve.getTangentAt(t).normalize(),width=new THREE.Vector3(1,0,0).addScaledVector(tangent,-tangent.x).normalize(),dorsal=new THREE.Vector3().crossVectors(tangent,width).normalize();if(dorsal.z<0){width.negate();dorsal.negate();}
      const tip=t>.87?Math.sqrt(Math.max(.006,1-Math.pow((t-.87)/.13,2))):1;
      const knuckles=Math.exp(-Math.pow((t-.42)/.065,2))*.065+Math.exp(-Math.pow((t-.72)/.065,2))*.045;
      const radius=baseRadius*(1-t*(isThumb?.32:.24)+knuckles)*tip;return{center,tangent,width,dorsal,radius};}
    for(let row=0;row<=rows;row++){const t=row/rows,s=section(t);for(let i=0;i<=sides;i++){const a=i/sides*Math.PI*2,v=s.center.clone().addScaledVector(s.width,Math.cos(a)*s.radius).addScaledVector(s.dorsal,Math.sin(a)*s.radius*.88);p.push(v.x,v.y,v.z);uv.push(i/sides,t);}}
    for(let row=0;row<rows;row++)for(let i=0;i<sides;i++){const a=row*(sides+1)+i,b=a+sides+1;ix.push(a,a+1,b,b,a+1,b+1);}
    for(const row of isThumb?[0,rows]:[rows]){const c=section(row/rows).center,n=p.length/3;p.push(c.x,c.y,c.z);uv.push(.5,row/rows);for(let i=0;i<sides;i++){const a=row*(sides+1)+i;row===0?ix.push(n,a+1,a):ix.push(n,a,a+1);}}
    const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();const digit=mesh(g,skin,parent);digit.name=`${name} finger`;digit.userData.base=points[0].toArray();digit.userData.tip=points.at(-1).toArray();digit.userData.anatomicalLength=curve.getLength();
    // A nail follows the actual distal phalanx, including its bend and curved
    // dorsal surface. It never uses a fixed-depth rectangular tile.
    const np=[],nuv=[],ni=[],nrows=10,ncols=8;
    for(let row=0;row<=nrows;row++){const v=row/nrows,t=.74+v*.19,s=section(t),round=Math.pow(Math.max(0,Math.sin(v*Math.PI)),.18);for(let col=0;col<=ncols;col++){const u=col/ncols,w=(u-.5)*1.44*round,at=s.center.clone().addScaledVector(s.width,w*s.radius).addScaledVector(s.dorsal,Math.sqrt(Math.max(0,1-w*w))*s.radius*.88+.00018);np.push(at.x,at.y,at.z);nuv.push(u,v);}}
    for(let row=0;row<nrows;row++)for(let col=0;col<ncols;col++){const a=row*(ncols+1)+col,b=a+ncols+1;ni.push(a,b,a+1,b,b+1,a+1);}const ng=own(new THREE.BufferGeometry());ng.setAttribute('position',new THREE.Float32BufferAttribute(np,3));ng.setAttribute('uv',new THREE.Float32BufferAttribute(nuv,2));ng.setIndex(ni);ng.computeVertexNormals();const nm=mesh(ng,nail,parent);nm.name=`${name} nail`;nm.material.side=THREE.DoubleSide;nm.castShadow=false;
    for(const t of isThumb?[.61]:[.43,.73]){const s=section(t),line=[];for(let i=0;i<5;i++){const w=(i/4-.5)*1.32;line.push(s.center.clone().addScaledVector(s.width,w*s.radius).addScaledVector(s.dorsal,-Math.sqrt(1-w*w)*s.radius*.88-.0001).toArray());}tube(parent,shade,line,.00019,8);}
    return digit;
  }
  function joinPalmAndFingers(parent,palm,fingers){
    // Front and back skin patches terminate on the exact open root rings of
    // the four fingers. Raised web valleys join adjacent sockets; there is no
    // flat palm cap or intersecting finger cap beneath the knuckles.
    const ordered=[...fingers].sort((a,b)=>b.userData.base[0]-a.userData.base[0]),patches=[];
    const point=(g,i)=>new THREE.Vector3().fromBufferAttribute(g.attributes.position,i);
    for(const dorsal of [true,false]){
      const outline=[];
      if(dorsal)for(let i=16;i>=0;i--)outline.push(point(palm.geometry,i));
      else for(let i=16;i<=32;i++)outline.push(point(palm.geometry,i));
      for(let f=0;f<ordered.length;f++){
        const finger=ordered[f];if(dorsal)for(let i=0;i<=9;i++)outline.push(point(finger.geometry,i));else for(let i=18;i>=9;i--)outline.push(point(finger.geometry,i));
        if(f<ordered.length-1){const a=outline.at(-1),b=point(ordered[f+1].geometry,dorsal?0:18);outline.push(new THREE.Vector3((a.x+b.x)*.5,(a.y+b.y)*.5+.0007,(a.z+b.z)*.5));}
      }
      // Stitch the two ordered rims directly. A planar triangulator would
      // discard the palm arc as collinear in XY and flatten its outward bulge.
      // This strip uses every rim vertex, including its full 3D skin depth.
      const top=Array.from({length:17},(_,i)=>i),bottom=Array.from({length:outline.length-17},(_,i)=>outline.length-1-i),triangles=[];
      const progress=(list,i)=>(outline[list[i]].x-outline[list[0]].x)/(outline[list.at(-1)].x-outline[list[0]].x);let ti=0,bi=0;while(ti<top.length-1||bi<bottom.length-1){const tu=ti<top.length-1?progress(top,ti+1):Infinity,bu=bi<bottom.length-1?progress(bottom,bi+1):Infinity;
        if(tu<=bu){triangles.push([top[ti],top[ti+1],bottom[bi]]);ti++;}else{triangles.push([top[ti],bottom[bi+1],bottom[bi]]);bi++;}}
      const p=[],uv=[],index=[];for(const v of outline){p.push(v.x,v.y,v.z);uv.push((v.x+.05)*10,(v.y+.10)*10);}
      for(const [a,b,c] of triangles)dorsal?index.push(a,c,b):index.push(a,b,c);
      const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(index);patches.push(g);
    }
    // Weld the original shapes and connecting patches. Averaged normals cross
    // the shared finger rims, eliminating a separate material/shadow boundary.
    const positions=[],uv=[],indices=[],weld=new Map(),sources=[palm,...fingers];
    for(const source of [...sources.map(m=>m.geometry),...patches]){const p=source.attributes.position,t=source.attributes.uv,remap=[];for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),key=[x,y,z].map(v=>Math.round(v*1e7)).join(',');let n=weld.get(key);if(n===undefined){n=positions.length/3;weld.set(key,n);positions.push(x,y,z);uv.push(t.getX(i),t.getY(i));}remap.push(n);}for(let i=0;i<source.index.count;i+=3){const a=remap[source.index.getX(i)],b=remap[source.index.getX(i+1)],c=remap[source.index.getX(i+2)];if(a!==b&&b!==c&&a!==c)indices.push(a,b,c);}}
    // Front/back tessellation can meet on a zero-thickness web-tip triangle.
    // Remove that internal pair while preserving both surrounding skin sheets.
    const faces=new Map();for(let i=0;i<indices.length;i+=3){const tri=indices.slice(i,i+3),key=[...tri].sort((a,b)=>a-b).join(',');faces.set(key,faces.has(key)?null:tri);}const skinIndices=[...faces.values()].filter(Boolean).flat();
    // Round the metacarpal transition without altering the fingertip pose.
    // Shared edge midpoints keep the surface closed as its coarse bridge softens.
    const midpointCache=new Map(),refined=[];
    function midpoint(a,b){const key=a<b?`${a}:${b}`:`${b}:${a}`;if(midpointCache.has(key))return midpointCache.get(key);const id=positions.length/3;for(let k=0;k<3;k++)positions.push((positions[a*3+k]+positions[b*3+k])*.5);uv.push((uv[a*2]+uv[b*2])*.5,(uv[a*2+1]+uv[b*2+1])*.5);midpointCache.set(key,id);return id;}
    for(let i=0;i<skinIndices.length;i+=3){const a=skinIndices[i],b=skinIndices[i+1],c=skinIndices[i+2],ab=midpoint(a,b),bc=midpoint(b,c),ca=midpoint(c,a);refined.push(a,ab,ca,ab,b,bc,ca,bc,c,ab,bc,ca);}
    const neighbours=Array.from({length:positions.length/3},()=>new Set());
    for(let i=0;i<refined.length;i+=3){const a=refined[i],b=refined[i+1],c=refined[i+2];neighbours[a].add(b).add(c);neighbours[b].add(a).add(c);neighbours[c].add(a).add(b);}
    for(let pass=0;pass<3;pass++){
      const previous=positions.slice();
      for(let i=0;i<neighbours.length;i++){
        const y=previous[i*3+1],weight=.38*THREE.MathUtils.smoothstep(y,-.092,-.074)*(1-THREE.MathUtils.smoothstep(y,-.035,-.016));
        if(weight===0||!neighbours[i].size)continue;
        for(let k=0;k<3;k++){let sum=0;for(const j of neighbours[i])sum+=previous[j*3+k];positions[i*3+k]=THREE.MathUtils.lerp(previous[i*3+k],sum/neighbours[i].size,weight);}
      }
    }
    const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(refined);g.computeVertexNormals();const skinMesh=mesh(g,skin,parent);skinMesh.name='Welded palm, skin webbing and fingers';skinMesh.userData.webbedFingerCount=4;
    // Keep named anatomical source meshes available for inspection. Only the
    // welded mesh is rendered; all its finger positions are the original ones.
    for(const source of sources)source.visible=false;
  }
  // A photographic scan supplies face, ears and neck. No primitive head is
  // displayed while the real asset is loading.
  const scannedHead=createScannedHead(profile);
  scannedHead.root.position.set(0,1.43,0);scannedHead.root.name='Photographic scanned head';body.add(scannedHead.root);
  root.userData.characterProfile=profile;root.userData.modelHeight=1.76;
  let time=0,disposed=false;
  let clothingLoaded=false;
  const clothingReady=loadClothingTextures().then(channels=>{if(disposed||!channels)return false;for(const material of materials){if(!material.userData.clothingScan)continue;Object.assign(material,channels);material.normalScale.setScalar(.22);material.roughness=1;
      // Preserve selected dye colors: the original blue linen contributes only
      // a small neutral luminance variation, while its real normal/roughness
      // channels provide woven fibers and the photographed matte response.
      material.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`\n#ifdef USE_MAP\n vec4 linenSample=texture2D(map,vMapUv);\n float linenLight=dot(linenSample.rgb,vec3(0.2126,0.7152,0.0722));\n diffuseColor.rgb*=0.88+0.16*clamp(linenLight*2.4,0.0,1.0);\n#endif\n`);};material.customProgramCacheKey=()=> 'neutral-scanned-linen-v1';material.needsUpdate=true;}clothingLoaded=true;return true;});
  const ready=Promise.all([scannedHead.ready,clothingReady]).then(([head])=>head);
  return {root,profile,ready,update(dt=0){if(disposed)return;time+=Math.min(Math.max(Number(dt)||0,0),.1);body.position.y=Math.sin(time*1.25)*.0016;body.scale.z=1+Math.sin(time*1.25)*.004;armGroups.forEach((arm,index)=>arm.rotation.x=Math.sin(time*.8+index*.9)*.0022);scannedHead.update(dt);},
    dispose(){if(disposed)return;disposed=true;root.removeFromParent();scannedHead.dispose();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());},
    getDiagnostics(){return {profile,geometries:geometries.size,materials:materials.size,textures:textures.size+(clothingLoaded?3:0),height:1.76,head:"photographic scan",clothing:clothingLoaded?'Poly Haven Rough Linen scan':'loading'};}};
}
