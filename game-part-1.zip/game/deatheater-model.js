import * as THREE from './vendor/three.module.js';

const clamp = (n, low = 0, high = 1) => Math.max(low, Math.min(high, n));
const mix = (a, b, t) => a + (b - a) * t;
const hash = (x, y = 0) => { const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return n - Math.floor(n); };
const UP = new THREE.Vector3(0, 1, 0);

function noise(x, y) {
  const ix = Math.floor(x), iy = Math.floor(y), a = x - ix, b = y - iy;
  const u = a * a * (3 - 2 * a), v = b * b * (3 - 2 * b);
  return mix(mix(hash(ix, iy), hash(ix + 1, iy), u), mix(hash(ix, iy + 1), hash(ix + 1, iy + 1), u), v);
}

function organicTextures() {
  const size = 256, color = new Uint8Array(size * size * 4), relief = new Uint8Array(size * size * 4), roughness = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const index = (y * size + x) * 4, mottling = noise(x * .035, y * .035), grain = noise(x * .54, y * .61);
    const fibers = Math.pow(Math.max(0, Math.sin(x * .65 + noise(x * .06, y * .06) * 7 + y * .025)), 12);
    const creases = Math.pow(Math.max(0, Math.sin(y * .21 + noise(x * .05,y * .09) * 10)), 22);
    const scars = Math.pow(Math.max(0, Math.sin(x * .11 - y * .057 + noise(x * .018,y * .019) * 5)), 38);
    const pore = hash(x, y) > .94 ? .19 : 0, value = clamp(.66 + mottling * .20 + grain * .10 - fibers * .075 - pore - creases * .16 + scars * .07);
    color.set([Math.round(value * 252), Math.round(value * 245), Math.round(value * 232), 255], index);
    const bump = Math.round(clamp(.43 + grain * .25 - pore - fibers * .12 - creases * .18 + scars * .14) * 255);
    relief.set([bump, bump, bump, 255], index);
    const rough = Math.round(213 + mottling * 27 + grain * 12);
    roughness.set([rough, rough, rough, 255], index);
  }
  const make = (data, srgb = false) => {
    const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping; texture.repeat.set(2.7, 2.7);
    texture.magFilter = THREE.LinearFilter; texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.generateMipmaps = true; texture.anisotropy = 4;
    if (srgb) texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true; return texture;
  };
  return {map: make(color, true), bumpMap: make(relief), roughnessMap: make(roughness)};
}

function organicSphere(seed = 0, sides = 20, rows = 14) {
  const g = new THREE.SphereGeometry(1, sides, rows), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const r = 1 + Math.sin(x * 7.3 + z * 4.7 + seed) * .025 + Math.sin(y * 11.2 - z * 6.1 + seed * 2) * .012;
    p.setXYZ(i, x * r, y * r, z * r);
  }
  g.computeVertexNormals(); return g;
}

function merged(parts) {
  const positions = [], normals = [], uvs = [], colors = [];
  for (const {geometry, color = '#ffffff'} of parts) {
    const g = geometry.index ? geometry.toNonIndexed() : geometry;
    const p = g.attributes.position, n = g.attributes.normal, uv = g.attributes.uv, c = g.attributes.color, tint = new THREE.Color(color);
    for (let i = 0; i < p.count; i++) {
      positions.push(p.getX(i), p.getY(i), p.getZ(i)); normals.push(n.getX(i), n.getY(i), n.getZ(i));
      uvs.push(uv ? uv.getX(i) : 0, uv ? uv.getY(i) : 0);
      colors.push(tint.r * (c ? c.getX(i) : 1), tint.g * (c ? c.getY(i) : 1), tint.b * (c ? c.getZ(i) : 1));
    }
    if (g !== geometry) g.dispose(); geometry.dispose();
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3)); return g;
}

function ellipsoid(parts, center, scale, color, seed = 0) {
  const g = organicSphere(seed); g.scale(...scale); g.translate(...center); parts.push({geometry: g, color});
}

function tube(points, radius, radial = 7, steps = 14) {
  return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p))), steps, radius, radial, false);
}

function pointedCurve(points, radius, seed = 0, steps = 15, radial = 8) {
  const path = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  const g = new THREE.TubeGeometry(path, steps, radius, radial, false), p = g.attributes.position;
  for (let row = 0; row <= steps; row++) {
    const t = row / steps, center = path.getPointAt(t), taper = Math.pow(1 - t, .80) * (1 + .065 * Math.sin(t * 35 + seed));
    for (let i = 0; i <= radial; i++) {
      const index = row * (radial + 1) + i;
      p.setXYZ(index, center.x + (p.getX(index) - center.x) * taper, center.y + (p.getY(index) - center.y) * taper, center.z + (p.getZ(index) - center.z) * taper);
    }
  }
  g.computeVertexNormals(); return g;
}

// Thin, curved vanes have raised shafts and split tips instead of flat rectangular cards.
function vane(length, width, seed, rows = 14) {
  const p = [], uv = [], colors = [], indices = [], across = [-1, -.48, 0, .48, 1];
  for (let row = 0; row <= rows; row++) {
    const t = row / rows, envelope = Math.pow(Math.sin(Math.PI * Math.min(.995, t) * .93), .54) * (1 - t * .46);
    for (let column = 0; column < across.length; column++) {
      const u = across[column], notch = Math.abs(u) === 1 ? .47 + .45 * hash(row, seed) - (row % 4 === 3 ? .20 : 0) : 1;
      const tip = t > .88 ? (t - .88) / .12 : 0;
      p.push(u * width * envelope * notch, Math.sin(t * Math.PI) * length * .042 + (1 - Math.abs(u)) * width * .13, t * length - Math.abs(u) * tip * width * .42);
      uv.push((u + 1) * .5, t);
      const shade = .68 + .21 * t + (Math.abs(u) > .9 ? .11 : 0) + hash(row, seed) * .05;
      colors.push(shade, shade * .97, shade * .89);
      if (row < rows && column < 4) {
        // Missing vane sections expose the shaft; the gap is empty geometry, not an alpha card.
        const tornEdge = (column === 0 || column === 3) && row > 2 && hash(Math.floor(row / 2), seed + column * 9) > .54;
        const brokenTip = row > rows * (.72 + hash(seed, 19) * .23) && column !== 1;
        if (!tornEdge && !brokenTip) { const a = row * 5 + column; indices.push(a, a + 5, a + 1, a + 1, a + 5, a + 6); }
      }
    }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3)); g.setIndex(indices); g.computeVertexNormals(); return g;
}

const leadingProfile = [[.32, -.28], [.85, -.41], [1.4, -.55], [2.35, -.85], [3.1, -.78], [3.80, -.50], [4.2, -.18]];
const trailingProfile = [[.32, .79], [.9, 1.03], [1.40, 1.25], [1.93, 1.48], [2.22, 1.19], [2.59, 1.52], [2.88, 1.20], [3.20, 1.40], [3.48, .90], [3.80, .99], [4.03, .36], [4.2, -.08]];
function profile(points, x) {
  for (let i = 1; i < points.length; i++) if (x <= points[i][0]) return mix(points[i - 1][1], points[i][1], clamp((x - points[i - 1][0]) / (points[i][0] - points[i - 1][0])));
  return points.at(-1)[1];
}
function wingPoint(x, t, side) {
  const z = mix(profile(leadingProfile, x), profile(trailingProfile, x), t);
  return new THREE.Vector3(side * x, .26 - t * .21 + Math.sin(t * Math.PI) * .095 - clamp((x - 3.1) / 1.1) * .085, z);
}

const membraneWounds = [
  {x:.96,t:.48,rx:.22,rt:.22}, {x:1.63,t:.59,rx:.27,rt:.24},
  {x:2.24,t:.43,rx:.20,rt:.20}, {x:2.83,t:.46,rx:.29,rt:.25},
  {x:3.55,t:.47,rx:.24,rt:.29},
];
function wingWound(x,t,side) {
  for(let i=0;i<membraneWounds.length;i++) {
    const wound=membraneWounds[i],sx=wound.x+(side===1?.045*Math.sin(i*2.4):0),st=wound.t+(side===1?.045*Math.cos(i*1.7):0);
    const dx=(x-sx)/wound.rx,dt=(t-st)/wound.rt,a=Math.atan2(dt,dx);
    if(dx*dx+dt*dt < 1 + .15*Math.sin(a*7+i*2+side) + .08*Math.sin(a*13+i))return true;
  }
  // Deep tears open into the trailing edge between surviving bony fingers.
  for(const [cx,width,depth] of [[1.20,.13,.58],[2.10,.12,.50],[2.98,.14,.60],[3.66,.10,.57]]) {
    const dx=Math.abs(x-cx-(side===1?.045:0));
    if(t>depth && dx<width*(.38+(t-depth)*1.7) + .018*Math.sin(t*47+cx*9))return true;
  }
  return false;
}

function membraneGeometry() {
  const p = [], uv = [], colors = [], flex = [], indices = [], columns = 104, rows = 28;
  for (const side of [-1, 1]) {
    const offset = p.length / 3;
    for (let column = 0; column <= columns; column++) for (let row = 0; row <= rows; row++) {
      const x = mix(.32, 4.2, column / columns), t = row / rows, point = wingPoint(x, t, side);
      const wear = Math.sin(x * 37 + side * 2) * .032 + Math.sin(x * 73 + .4) * .019;
      point.z += wear * Math.pow(t, 9); point.y += Math.sin(x * 17 + t * 4) * .009 * Math.sin(t * Math.PI);
      p.push(point.x, point.y, point.z); uv.push(x * .54, t * 1.8);
      const mottling = noise(x * 4 + side * 3, t * 9), edge = Math.pow(t, 7), shade = .62 + mottling * .28 + edge * .10;
      const tint = new THREE.Color('#8c8578'); colors.push(tint.r * shade, tint.g * shade, tint.b * shade);
      flex.push(Math.pow(t, 4) * clamp(x - .65) * .030);
      if (column < columns && row < rows) {
        const a = offset + column * (rows + 1) + row, b = a + rows + 1;
        const centerX=mix(.32,4.2,(column+.5)/columns),centerT=(row+.5)/rows;
        if (wingWound(centerX,centerT,side)) continue;
        if (row >= rows-2 && hash(Math.floor(column/2),side+8)>.68) continue;
        if (side === 1) indices.push(a, a + 1, b, a + 1, b + 1, b);
        else indices.push(a, b, a + 1, a + 1, b, b + 1);
      }
    }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3)); g.setAttribute('wingFlex', new THREE.Float32BufferAttribute(flex, 1));
  g.setIndex(indices); g.computeVertexNormals(); return g;
}

function mouthFunnel() {
  const positions = [], uv = [], colors = [], indices = [], sides = 72, rings = 13;
  for (let row = 0; row <= rings; row++) for (let i = 0; i <= sides; i++) {
    const t = row / rings, a = i / sides * Math.PI * 2, folds = Math.cos(a * 15 + t * 4) * .016 * (1 - t);
    const r = mix(.423, .066, Math.pow(t, .76)) + folds, shade = 1 - t * .79;
    positions.push(Math.cos(a) * r, Math.sin(a) * r, t * .42);
    uv.push(i / sides * 2, t * 2); colors.push(.27 * shade, .15 * shade, .11 * shade);
    if (row < rings && i < sides) { const n = row * (sides + 1) + i; indices.push(n, n + 1, n + sides + 1, n + 1, n + sides + 2, n + sides + 1); }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3)); g.setIndex(indices); g.computeVertexNormals(); return g;
}

function skullVault() {
  // An open cranial shell surrounds the oral cavity; a solid ellipsoid would block the throat.
  const p = [], uv = [], indices = [], sides = 44, rows = 16;
  for (let row = 0; row <= rows; row++) for (let i = 0; i <= sides; i++) {
    const t = row / rows, a = i / sides * Math.PI * 2, taper = Math.sqrt(Math.max(.002, 1 - t * t));
    const irregular = (1 + Math.sin(a * 5 + t * 7) * .035 + Math.sin(a * 9) * .012) * (1 - Math.sin(t*Math.PI)*.17);
    p.push(Math.cos(a) * .455 * taper * irregular, .035 + Math.sin(a) * .418 * taper * irregular, -.378 + t * .80);
    uv.push(i / sides, t);
    if (row < rows && i < sides) { const n = row * (sides + 1) + i; indices.push(n, n + 1, n + sides + 1, n + 1, n + sides + 2, n + sides + 1); }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(indices); g.computeVertexNormals(); return g;
}

/** Broad-winged predator. Local -Z faces forward; the root is its flight center. */
export function createDeatheaterModel() {
  const group = new THREE.Group(); group.name = 'Deatheater';
  const resources = new Set(), batches = [], own = value => { resources.add(value); return value; };
  const textures = organicTextures(); Object.values(textures).forEach(own);
  const hide = own(new THREE.MeshStandardMaterial({...textures, color: '#bdb5a5', vertexColors: true, bumpScale: .032, roughness: .99, metalness: 0}));
  const membrane = own(new THREE.MeshStandardMaterial({...textures, color: '#c8bcaa', vertexColors: true, bumpScale: .018, roughness: .98, metalness: 0, side: THREE.DoubleSide}));
  const vanes = own(new THREE.MeshStandardMaterial({...textures, color: '#a49d8f', vertexColors: true, bumpScale: .014, roughness: .99, metalness: 0, side: THREE.DoubleSide}));
  const horn = own(new THREE.MeshStandardMaterial({...textures, color: '#e2d3b8', vertexColors: true, bumpScale: .006, roughness: .65, metalness: .005}));
  const teeth = own(new THREE.MeshStandardMaterial({...textures, color: '#e8dcc0', vertexColors: true, bumpScale: .0015, roughness: .48, metalness: 0}));
  const oral = own(new THREE.MeshPhysicalMaterial({...textures, color: '#ce9d88', vertexColors: true, bumpScale: .004, roughness: .59, clearcoat: .18, clearcoatRoughness: .38, side: THREE.DoubleSide}));
  const eye = own(new THREE.MeshPhysicalMaterial({color: '#241f14', roughness: .22, clearcoat: .35, clearcoatRoughness: .13}));
  const iris = own(new THREE.MeshStandardMaterial({color: '#a88a4d', roughness: .43, metalness: 0}));
  const black = own(new THREE.MeshStandardMaterial({color: '#060706', roughness: .89, side: THREE.DoubleSide}));
  const clock = {value: 0};
  membrane.onBeforeCompile = shader => {
    shader.uniforms.deatheaterTime = clock;
    shader.vertexShader = 'uniform float deatheaterTime;\nattribute float wingFlex;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\ntransformed.y += (sin(deatheaterTime * 11.0 + position.x * 13.0 + position.z * 4.0) + sin(deatheaterTime * 6.8 - position.x * 7.3)) * wingFlex;');
  };
  membrane.customProgramCacheKey = () => 'deatheater-withered-membrane-2';

  function meshFrom(parts, material, parent = group, name = '') {
    const mesh = new THREE.Mesh(own(merged(parts)), material); mesh.name = name; mesh.castShadow = mesh.receiveShadow = true; parent.add(mesh); return mesh;
  }
  function batch(name, geometry, material, count) {
    const mesh = new THREE.InstancedMesh(own(geometry), material, count); mesh.name = name;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); mesh.castShadow = mesh.receiveShadow = true; mesh.frustumCulled = false;
    group.add(mesh); batches.push(mesh); return mesh;
  }

  const body = new THREE.Group(); body.name = 'Emaciated ribcage'; group.add(body);
  const flesh = [];
  ellipsoid(flesh, [0, .015, .06], [.175, .19, .85], '#776f63', 2);
  ellipsoid(flesh, [0, -.07, -.31], [.20, .18, .38], '#958873', 3);
  ellipsoid(flesh, [0, .09, .37], [.13, .13, .56], '#726e63', 6);
  ellipsoid(flesh, [0, .08, -.57], [.14, .15, .26], '#89806e', 5);
  for (const side of [-1, 1]) ellipsoid(flesh, [side * .26, .12, -.28], [.10, .11, .34], '#8d816e', side + 8);
  meshFrom(flesh, hide, body, 'Shrunken hide over a hollow narrow torso');
  const ribcage=[];
  for(let i=0;i<8;i++) {
    const z=-.48+i*.135,width=.285-Math.max(0,i-4)*.023;
    for(const side of [-1,1]) ribcage.push({geometry:tube([[side*.026,.225,z],[side*width,.12,z+.012],[side*(width-.03),-.115,z+.037],[side*.055,-.23+i*.008,z+.055]],.018+(i%3)*.002,7,15),color:i%3?'#c5b79d':'#ddd0b4'});
    ellipsoid(ribcage,[0,.238,z],[.065,.048,.043],'#cabda4',i+70);
  }
  ribcage.push({geometry:tube([[0,-.22,-.45],[0,-.24,-.12],[0,-.16,.50]],.026,7,18),color:'#c3b298'});
  for(const side of [-1,1]) {
    ribcage.push({geometry:tube([[0,.22,-.50],[side*.22,.29,-.39],[side*.38,.21,-.28]],.034,8,16),color:'#d4c5a9'});
    ribcage.push({geometry:pointedCurve([[side*.10,.17,.50],[side*.24,.18,.64],[side*.25,.01,.79]],.035,side+8,12,7),color:'#b7a88e'});
    for(let i=0;i<4;i++)ribcage.push({geometry:tube([[side*.16,.035,-.37+i*.24],[side*.19,-.035,-.32+i*.24],[side*.13,-.13,-.27+i*.24]],.006,5,7),color:'#615447'});
  }
  meshFrom(ribcage,horn,body,'Exposed ribs vertebrae sternum and shoulder bones');
  const coat = [], shaftParts = [];
  for (let row = 0; row < 6; row++) for (let i = 0; i < 9; i++) {
    if(hash(row*9+i,91)<.72)continue;
    const a = i / 8 * Math.PI * 1.6 + Math.PI * .2, z = -.65 + row * .24, width = .28 * Math.sqrt(1 - Math.pow((z - .03) / 1.1, 2));
    const g = vane(.17 + hash(row, i) * .16, .036, row * 11 + i, 10);
    g.rotateZ(a - Math.PI / 2); g.rotateY((i / 8 - .5) * .24); g.translate(Math.cos(a) * width, Math.sin(a) * .26, z);
    coat.push({geometry: g, color: row % 2 ? '#949586' : '#adab94'});
  }
  for (let i = 0; i < 12; i++) {
    const z = -.63 + i * .123;
    shaftParts.push({geometry: pointedCurve([[0, .24, z], [.012, .35, z + .10], [0, .32, z + .26]], .027, i, 9, 6), color: '#b5ad93'});
  }
  meshFrom(coat, vanes, body, 'Sparse broken nape and body vanes'); meshFrom(shaftParts, horn, body, 'Exposed irregular dorsal ridge');

  const head = new THREE.Group(); head.name = 'Radial-mouthed skull'; head.position.set(0, .09, -.89); group.add(head);
  const skull = [{geometry: skullVault(), color: '#918574'}], brow = [], eyes = [], irises = [];
  for (const side of [-1, 1]) {
    ellipsoid(skull, [side * .395, .10, -.10], [.059, .19, .17], '#6b655b', side + 16);
    brow.push({geometry: tube([[side * .13, .34, -.35], [side * .30, .40, -.33], [side * .46, .25, -.20]], .038, 8, 17), color: '#bdb299'});
    brow.push({geometry: pointedCurve([[side * .31, .24, .02], [side * .37, .37, .19], [side * .30, .35, .43]], .060, side + 8), color: '#a99f86'});
    brow.push({geometry:tube([[side*.38,.24,-.29],[side*.45,.025,-.21],[side*.36,-.19,-.27]],.026,7,16),color:'#c9b99c'});
    for(let i=0;i<3;i++)skull.push({geometry:tube([[side*(.23+i*.045),.26-i*.07,-.31],[side*(.27+i*.04),.19-i*.07,-.27],[side*(.29+i*.027),.13-i*.06,-.19]],.007,5,8),color:'#4f463b'});
    const socket=organicSphere(side+41,16,10);socket.scale(.092,.074,.045);socket.translate(side*.337,.294,-.336);eyes.push({geometry:socket});
    const eyeGeo = organicSphere(side + 8, 16, 10); eyeGeo.scale(.067, .048, .063); eyeGeo.translate(side * .327, .292, -.344); eyes.push({geometry: eyeGeo});
    const irisGeo = new THREE.SphereGeometry(1, 14, 9); irisGeo.scale(.019, .026, .007); irisGeo.translate(side * .325, .293, -.402); irises.push({geometry: irisGeo});
  }
  meshFrom(skull, hide, head, 'Asymmetric skull and cheek folds'); meshFrom(brow, horn, head, 'Brow and swept cheek ridges');
  meshFrom(eyes, eye, head, 'Recessed non-emissive eyes'); meshFrom(irises, iris, head, 'Small amber irises');

  const mouth = new THREE.Group(); mouth.name = 'Circular tooth-filled mouth'; mouth.position.set(0, -.025, -.405); head.add(mouth);
  const lipParts = [], toothParts = [], oralParts = [{geometry: mouthFunnel()}];
  for (let ring = 0; ring < 3; ring++) {
    const g = new THREE.TorusGeometry(.433 + ring * .025, .021 + (ring === 1 ? .007 : 0), 8, 72), p = g.attributes.position;
    for (let i = 0; i < p.count; i++) { const a = Math.atan2(p.getY(i), p.getX(i)), r = 1 + Math.sin(a * 7 + ring) * .022 + Math.cos(a * 13) * .010;
      p.setXYZ(i, p.getX(i) * r, p.getY(i) * r, p.getZ(i) + ring * .018 + Math.sin(a * 15) * .007); }
    g.computeVertexNormals(); lipParts.push({geometry: g, color: ring === 1 ? '#a0866c' : '#736a58'});
  }
  for (let i = 0; i < 32; i++) {
    const a = i / 32 * Math.PI * 2, c = Math.cos(a), s = Math.sin(a), r = .469;
    lipParts.push({geometry: tube([[c * r, s * r, .047], [c * .444, s * .444, .016], [c * .414, s * .414, .049]], .010 + hash(i, 22) * .005, 5, 6), color: i % 3 ? '#95816a' : '#b3a085'});
  }
  for (let row = 0; row < 2; row++) {
    const count = row ? 23 : 29, radius = row ? .335 : .423;
    for (let i = 0; i < count; i++) {
      const a = (i + row * .46) / count * Math.PI * 2 + (hash(i, row + 52) - .5) * .027;
      const c = Math.cos(a), s = Math.sin(a), length = (row ? .083 : .12) + hash(i, row + 61) * (row ? .035 : .092), z = row ? .148 : -.006;
      const g = pointedCurve([[c * radius, s * radius, z], [c * (radius - length * .49), s * (radius - length * .49), z - .046], [Math.cos(a + .027) * (radius - length), Math.sin(a + .027) * (radius - length), z + .027]], row ? .020 : .028 + hash(i, 15) * .007, i + row * 40, 12, 7);
      const p = g.attributes.position, vertexColors = [];
      for (let j = 0; j < p.count; j++) { const t = Math.floor(j / 8) / 12, color = new THREE.Color('#8c7559').lerp(new THREE.Color(i % 7 === 0 ? '#bdac8b' : '#e8ddbd'), t); vertexColors.push(color.r, color.g, color.b); }
      g.setAttribute('color', new THREE.Float32BufferAttribute(vertexColors, 3)); toothParts.push({geometry: g});
    }
  }
  meshFrom(lipParts, hide, mouth, 'Weathered radial lip and annular folds');
  const oralMesh = meshFrom(oralParts, oral, mouth, 'Deep ridged oral funnel');
  const toothMesh = meshFrom(toothParts, teeth, mouth, 'Two irregular rings of recurved teeth');
  // The capture pose opens a real passage behind the teeth. Merely enlarging the
  // lip would leave the original narrow funnel crossing the swallowed figure.
  const expandedOral = oralMesh.geometry.clone(), expandedPosition = expandedOral.attributes.position;
  for (let i = 0; i < expandedPosition.count; i++) {
    const x = expandedPosition.getX(i), y = expandedPosition.getY(i), z = expandedPosition.getZ(i);
    const depth = clamp(z / .42), radial = Math.hypot(x, y);
    const stretch = 1 + .227 * Math.pow(depth, .76) / Math.max(.001, radial);
    expandedPosition.setXYZ(i, x * stretch, y * stretch, z * 4.3);
  }
  expandedOral.computeVertexNormals();
  oralMesh.geometry.morphAttributes.position = [expandedPosition.clone()];
  oralMesh.geometry.morphAttributes.normal = [expandedOral.attributes.normal.clone()];
  oralMesh.updateMorphTargets(); expandedOral.dispose();
  oralMesh.frustumCulled = false;
  let freeMouthRadius = Infinity;
  const toothPosition = toothMesh.geometry.attributes.position;
  for (let i = 0; i < toothPosition.count; i++) freeMouthRadius = Math.min(freeMouthRadius, Math.hypot(toothPosition.getX(i), toothPosition.getY(i)));
  const throat = new THREE.Mesh(own(new THREE.CircleGeometry(.082, 32)), black); throat.name = 'Dark recessed throat'; throat.position.z = .418; throat.rotation.y = Math.PI; mouth.add(throat);
  // Concentric folds remain attached to the skull as the aperture contracts.
  const sealGeometry = own(new THREE.RingGeometry(.425, .49, 72, 8)); sealGeometry.rotateY(Math.PI);
  const sealClosed = sealGeometry.clone(), sealPosition = sealClosed.attributes.position;
  for (let i = 0; i < sealPosition.count; i++) {
    const x = sealPosition.getX(i), y = sealPosition.getY(i), radial = Math.hypot(x, y);
    const t = clamp((radial - .425) / .065), angle = Math.atan2(y, x), radius = mix(.028, .49, t);
    sealPosition.setXYZ(i, x * radius / radial, y * radius / radial, -.012 - Math.sin(t * Math.PI) * (.014 + Math.cos(angle * 32) * .009));
  }
  sealClosed.computeVertexNormals();
  sealGeometry.morphAttributes.position = [sealPosition.clone()];
  sealGeometry.morphAttributes.normal = [sealClosed.attributes.normal.clone()]; sealClosed.dispose();
  const sealColors = new Float32Array(sealGeometry.attributes.position.count * 3), sealColor = new THREE.Color('#776754');
  for (let i = 0; i < sealGeometry.attributes.position.count; i++) sealColors.set([sealColor.r, sealColor.g, sealColor.b], i * 3);
  sealGeometry.setAttribute('color', new THREE.BufferAttribute(sealColors, 3));
  const mouthSeal = new THREE.Mesh(sealGeometry, hide); mouthSeal.name = 'Contracting radial mouth folds'; mouthSeal.position.copy(mouth.position);
  mouthSeal.castShadow = mouthSeal.receiveShadow = true; mouthSeal.frustumCulled = false; mouthSeal.visible = false; head.add(mouthSeal);

  const rootBone = new THREE.Bone(); rootBone.name = 'Flight skeleton'; group.add(rootBone);
  const bones = [rootBone], wingRig = [];
  for (const side of [-1, 1]) {
    const shoulder = new THREE.Bone(), elbow = new THREE.Bone(), wrist = new THREE.Bone();
    shoulder.name = side < 0 ? 'Left shoulder' : 'Right shoulder'; elbow.name = side < 0 ? 'Left elbow' : 'Right elbow'; wrist.name = side < 0 ? 'Left wrist' : 'Right wrist';
    shoulder.position.set(side * .38, .22, -.28); elbow.position.set(side * 1.02, .04, -.24); wrist.position.set(side * .95, .015, -.32);
    rootBone.add(shoulder); shoulder.add(elbow); elbow.add(wrist); bones.push(shoulder, elbow, wrist); wingRig.push({side, shoulder, elbow, wrist});
  }
  group.updateMatrixWorld(true); const skeleton = own(new THREE.Skeleton(bones));
  function skinned(geometry, material, name) {
    const p = geometry.attributes.position, indices = [], weights = [];
    for (let i = 0; i < p.count; i++) {
      const x = Math.abs(p.getX(i)), base = p.getX(i) < 0 ? 1 : 4;
      let first, second, blend;
      if (x < .58) { first = 0; second = base; blend = clamp((x - .27) / .31); }
      else if (x < 1.63) { first = base; second = base + 1; blend = clamp((x - 1.13) / .50); }
      else { first = base + 1; second = base + 2; blend = clamp((x - 2.08) / .52); }
      indices.push(first, second, 0, 0); weights.push(1 - blend, blend, 0, 0);
    }
    geometry.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(indices, 4)); geometry.setAttribute('skinWeight', new THREE.Float32BufferAttribute(weights, 4));
    const mesh = new THREE.SkinnedMesh(own(geometry), material); mesh.name = name; group.add(mesh); mesh.bind(skeleton); mesh.frustumCulled = false;
    mesh.castShadow = mesh.receiveShadow = true; return mesh;
  }
  skinned(membraneGeometry(), membrane, 'Perforated desiccated wing membranes');
  const wingBones = [], veins = [], flightVanes = [];
  const fingers = [
    [[2.35, .275, -.84], [3.16, .23, -.65], [4.2, .16, -.14]],
    [[2.35, .25, -.81], [3.10, .18, .03], [3.80, .06, .99]],
    [[2.34, .24, -.80], [2.80, .16, .33], [3.20, .05, 1.40]],
    [[2.33, .24, -.79], [2.43, .14, .55], [2.59, .05, 1.52]],
    [[1.40, .26, -.52], [1.68, .15, .33], [1.93, .05, 1.48]]
  ];
  for (const side of [-1, 1]) {
    const mirrored = list => list.map(([x, y, z]) => [side * x, y, z]);
    wingBones.push({geometry: tube(mirrored([[.34, .21, -.28], [.84, .27, -.39], [1.40, .26, -.52]]), .052, 10, 22), color: '#cbbb9f'});
    wingBones.push({geometry: tube(mirrored([[1.40, .26, -.52], [1.84, .28, -.70], [2.35, .275, -.84]]), .041, 9, 20), color: '#c8b99c'});
    wingBones.push({geometry: tube(mirrored([[1.41, .23, -.43], [1.88, .22, -.61], [2.32, .25, -.79]]), .025, 7, 16), color: '#b5a287'});
    ellipsoid(wingBones, [side * 1.4, .26, -.52], [.106, .096, .13], '#b1a289', side + 9);
    ellipsoid(wingBones, [side * 2.35, .275, -.84], [.098, .078, .12], '#b0a18a', side + 15);
    fingers.forEach((points, i) => wingBones.push({geometry: pointedCurve(mirrored(points), .038 - i * .0024, i, 23, 7), color: i % 2 ? '#c2b397' : '#d9caae'}));
    wingBones.push({geometry: pointedCurve(mirrored([[2.33, .29, -.85], [2.48, .36, -1.02], [2.62, .30, -1.10]]), .044, side + 8), color: '#c6baa0'});
    for (let i = 0; i < 31; i++) {
      const x = .54 + i * .111, t = .18 + hash(i, side + 8) * .24, endT = .84 + hash(i, 83) * .10;
      const a = wingPoint(x, t, side), b = wingPoint(x + .08, mix(t, endT, .45), side), c = wingPoint(x + .04, endT, side);
      a.y += .012; b.y += .012; c.y += .009;
      veins.push({geometry: tube([a.toArray(), b.toArray(), c.toArray()], .004 + hash(i, 22) * .003, 4, 9), color: '#7c715e'});
      if (i % 3 === 0) { const d = wingPoint(x + .16, .77, side); d.y += .012; veins.push({geometry: tube([b.toArray(), d.toArray()], .003, 4, 5), color: '#8d7d68'}); }
    }
    for(let i=0;i<membraneWounds.length;i++) {
      const wound=membraneWounds[i],centerX=wound.x+(side===1?.045*Math.sin(i*2.4):0),centerT=wound.t+(side===1?.045*Math.cos(i*1.7):0);
      const edge=[];
      for(let j=0;j<=30;j++) {
        const a=j/30*Math.PI*2,r=Math.sqrt(1+.15*Math.sin(a*7+i*2+side)+.08*Math.sin(a*13+i));
        const p=wingPoint(centerX+Math.cos(a)*wound.rx*r,centerT+Math.sin(a)*wound.rt*r,side);p.y+=.014;edge.push(p.toArray());
      }
      veins.push({geometry:tube(edge,.009,5,46),color:'#554d40'});
      for(let j=0;j<5;j++) {
        const index=(j*6+i*3)%30,a=new THREE.Vector3(...edge[index]);
        const b=a.clone().add(new THREE.Vector3(side*(.022+hash(i,j)*.025),-.038-hash(j,i)*.055,.018));
        const c=b.clone().add(new THREE.Vector3(-side*.018,-.018,.025));
        veins.push({geometry:pointedCurve([a.toArray(),b.toArray(),c.toArray()],.010,i+j,7,5),color:'#8a7860'});
      }
    }
    for(let i=0;i<20;i++) {
      const x=.65+i*.162,p=wingPoint(x,.97,side);
      if(wingWound(x,.97,side))continue;
      veins.push({geometry:pointedCurve([p.toArray(),[p.x+side*.018,p.y-.08-hash(i,side)*.10,p.z+.06],[p.x-side*.013,p.y-.17-hash(i,33)*.12,p.z+.14]],.015,i,9,5),color:'#81715b'});
    }
    for (let row = 0; row < 2; row++) for (let i = 0; i < 23; i++) {
      const x = .56 + i * .155, t = row ? .74 : .89, p = wingPoint(x, t, side), length = (row ? .19 : .29) + hash(i, row + 55) * .21;
      if(wingWound(x,t,side))continue;
      wingBones.push({geometry:pointedCurve([p.toArray(),[p.x+side*.025,p.y+.018,p.z+length*.48],[p.x+side*.055,p.y-.05,p.z+length*(.58+hash(i,row+side)*.32)]],.007,i,9,5),color:'#a79578'});
      if(hash(i+side*5,row+103)<.48)continue;
      const g = vane(length, .039 + hash(i, 54) * .021, i + row * 23 + (side + 1) * 29, 12);
      g.rotateY(side * (-.22 + x * .12)); g.rotateZ(side * .035); g.translate(p.x, p.y + .025 + row * .017, p.z - .06);
      flightVanes.push({geometry: g, color: row ? '#8d8473' : '#686b60'});
    }
  }
  skinned(merged(wingBones), horn, 'Bare wing bones fingers and snapped quills');
  skinned(merged(veins), hide, 'Torn scar margins hanging sinew and membrane vessels'); skinned(merged(flightVanes), vanes, 'Sparse shredded flight vanes');

  const legGeometry = new THREE.CylinderGeometry(.68, 1, 1, 10, 5), lp = legGeometry.attributes.position;
  for (let i = 0; i < lp.count; i++) { const t = lp.getY(i) + .5, folds = 1 + Math.cos(t * Math.PI * 11) * .052; lp.setX(i, lp.getX(i) * folds); lp.setZ(i, lp.getZ(i) * folds); }
  legGeometry.computeVertexNormals();
  const limbs = batch('Articulated hindlimbs and toes', legGeometry, hide, 14);
  const joints = batch('Organic hock and ankle joints', organicSphere(31, 14, 10), hide, 6);
  const talons = batch('Eight recurved grasping talons', pointedCurve([[0, 0, 0], [0, -.075, -.075], [0, -.12, -.13], [0, -.17, -.094]], .031, 23, 14, 8), horn, 8);
  const limbColor = new THREE.Color('#96846d'), jointColor = new THREE.Color('#b6a88d'), talonColor = new THREE.Color('#c9b999');
  for (let i = 0; i < limbs.count; i++) limbs.setColorAt(i, limbColor); for (let i = 0; i < joints.count; i++) joints.setColorAt(i, jointColor); for (let i = 0; i < talons.count; i++) talons.setColorAt(i, talonColor);

  const tail = new THREE.Group(); tail.name = 'Ragged balancing tail'; tail.position.set(0, .055, .74); group.add(tail);
  const tailSkin = [], tailVanes = [];
  ellipsoid(tailSkin, [0, -.02, .25], [.064, .049, .43], '#6d6557', 18);
  for(let i=0;i<8;i++)ellipsoid(tailSkin,[0,.025,.035+i*.075],[.047-i*.003,.035,.025],'#c5b79a',i+88);
  meshFrom(tailSkin, horn, tail, 'Wasted tail with exposed caudal vertebrae');
  for (let i = 0; i < 9; i++) {
    if([1,3,6,7].includes(i))continue;
    const x = (i - 4) / 4, g = vane(.63 + (1 - Math.abs(x)) * .37 + hash(i, 73) * .12, .075, i + 71, 16);
    g.rotateY(x * .43); g.rotateX(x * x * .12); g.translate(x * .063, .033 + (1 - Math.abs(x)) * .025, .15);
    tailVanes.push({geometry: g, color: i % 2 ? '#9d9d88' : '#818d80'});
  }
  meshFrom(tailVanes, vanes, tail, 'Split and frayed tail vanes');

  const dummy = new THREE.Object3D(), direction = new THREE.Vector3(), a = new THREE.Vector3(), b = new THREE.Vector3(), knee = new THREE.Vector3(), ankle = new THREE.Vector3();
  let disposed = false, lastTime = null, phase = 0, diveAmount = 0, attackAmount = 0, glideAmount = 0;
  function pose(mesh, index, position, scale, rotation = null) {
    dummy.position.copy(position); dummy.scale.set(...scale); if (rotation) dummy.quaternion.copy(rotation); else dummy.quaternion.identity();
    dummy.updateMatrix(); mesh.setMatrixAt(index, dummy.matrix);
  }
  function connect(mesh, index, start, end, radius) {
    direction.subVectors(end, start); const length = Math.max(.0001, direction.length());
    dummy.position.copy(start).add(end).multiplyScalar(.5); dummy.quaternion.setFromUnitVectors(UP, direction.divideScalar(length)); dummy.scale.set(radius, length, radius);
    dummy.updateMatrix(); mesh.setMatrixAt(index, dummy.matrix);
  }
  /** capture holds the mouth open; swallowing advances the throat contraction.
   * Keep capture at one until the whole body has crossed the mouth plane, then
   * fade it to zero with swallowing at one to close the circular lips. */
  function animate({time = 0, speed = 14, stage = 'flying', attacking = false, capture = 0, swallowing = 0} = {}) {
    if (disposed) return;
    time = Number.isFinite(time) ? time : 0; speed = Number.isFinite(speed) ? Math.abs(speed) : 14;
    capture = Number.isFinite(capture) ? clamp(capture) : 0;
    swallowing = Number.isFinite(swallowing) ? clamp(swallowing) : 0;
    const dt = lastTime === null ? 1 / 60 : clamp(time - lastTime, 0, .12); lastTime = time; clock.value = time;
    const state = typeof stage === 'string' ? stage.toLowerCase() : 'flying', pace = clamp(speed / 28);
    const dive = /div|swoop/.test(state) ? 1 : 0, glide = /glid|circl|soar|orbit/.test(state) ? 1 : 0;
    const attack = typeof attacking === 'number' && Number.isFinite(attacking) ? clamp(attacking) : attacking ? 1 : /^(attack|strik|bit)/.test(state) ? .8 : 0;
    const smooth = 1 - Math.exp(-dt * 6.5); diveAmount = mix(diveAmount, dive, smooth); attackAmount = mix(attackAmount, attack, smooth); glideAmount = mix(glideAmount, glide, smooth);
    phase += dt * (4.8 + pace * 4.2); const flap = Math.sin(phase) + Math.sin(phase * 2 - .35) * .16;
    const amplitude = (.40 + pace * .10) * (1 - glideAmount * .83) * (1 - diveAmount * .78) * (1 - attackAmount * .48);
    for (const {side, shoulder, elbow, wrist} of wingRig) {
      shoulder.rotation.set(.035 * Math.sin(phase - .8), -side * (.025 + diveAmount * .43), side * (.10 + attackAmount * .12 + flap * amplitude - diveAmount * .05));
      elbow.rotation.set(0, -side * (.045 + diveAmount * .43 + Math.max(0, Math.sin(phase - .6)) * .10), side * (-.025 + Math.sin(phase - .65) * amplitude * .37));
      wrist.rotation.set(0, -side * (.035 + diveAmount * .24), side * (Math.sin(phase - 1.05) * amplitude * .24 - .03));
    }
    const swallowPulse = Math.sin(swallowing * Math.PI) * (1 + Math.sin(swallowing * Math.PI * 6) * .15);
    const contraction = clamp((swallowing - .88) / .12) * (1 - capture);
    body.rotation.x = -.10 * diveAmount + Math.sin(phase) * .014;
    body.scale.set(1 + capture * .72 + swallowPulse * .56, 1 + Math.sin(time * 2.3) * .011 + capture * .62 + swallowPulse * .43, 1 + swallowPulse * .045);
    head.rotation.set(-diveAmount * .095 - attackAmount * .035, Math.sin(time * .71) * .036 * (1 - attackAmount), Math.sin(time * .88) * .018);
    const skullGape = 1 + capture * .68 + swallowPulse * .045;
    head.scale.set(skullGape, skullGape, 1 + swallowPulse * .035);
    const gape = .94 + attackAmount * .29 + Math.sin(time * 2.1) * .012;
    const openGape = mix(mix(gape, 1.16, capture), .11, contraction);
    mouth.scale.set(openGape, openGape * (1 + attackAmount * .035 * (1 - capture)), mix(1 - attackAmount * .09, 1, capture));
    oralMesh.morphTargetInfluences[0] = capture;
    throat.position.z = .418 * (1 + capture * 3.3);
    const throatGape = 1 + capture * (.227 / .082);
    throat.scale.set(throatGape, throatGape, 1);
    mouthSeal.visible = contraction > .001;
    mouthSeal.morphTargetInfluences[0] = contraction;
    const sealGape = mix(gape, 1.16, capture); mouthSeal.scale.set(sealGape, sealGape, 1);
    tail.rotation.set(.075 + diveAmount * .15 + Math.sin(phase - .65) * .04, Math.sin(time * 1.1) * .085, Math.sin(phase - 1.1) * .04);
    for (const side of [-1, 1]) {
      const index = side < 0 ? 0 : 1, reach = attackAmount, tuck = diveAmount * (1 - reach);
      a.set(side * .255, -.20, .45); knee.set(side * (.32 + reach * .045), -.34 - reach * .09 + tuck * .055, .76 - reach * .47);
      ankle.set(side * (.27 + reach * .11), -.37 - reach * .43 + tuck * .09, .97 - reach * 1.14);
      connect(limbs, index * 3, a, knee, .052); connect(limbs, index * 3 + 1, knee, ankle, .033);
      b.copy(ankle).add(direction.set(0, -.07 - reach * .07, .085 - reach * .13)); connect(limbs, index * 3 + 2, ankle, b, .043);
      pose(joints, index * 3, a, [.073, .073, .10]); pose(joints, index * 3 + 1, knee, [.068, .065, .09]); pose(joints, index * 3 + 2, ankle, [.06, .051, .075]);
      for (let toe = 0; toe < 4; toe++) {
        const spread = toe === 3 ? -.048 : (toe - 1) * (.049 + reach * .023), backward = toe === 3;
        a.copy(b).add(direction.set(spread, -.012, backward ? .035 : -.013));
        const tip = new THREE.Vector3(a.x + spread * .30, a.y - .018 - reach * .022, a.z + (backward ? .14 : -.13 - reach * .045));
        connect(limbs, 6 + index * 4 + toe, a, tip, .021 - (backward ? .004 : 0));
        dummy.quaternion.setFromAxisAngle(UP, backward ? Math.PI : side * spread * 1.3);
        const orientation = dummy.quaternion.clone(); pose(talons, index * 4 + toe, tip, [1, 1, 1], orientation);
      }
    }
    for (const mesh of batches) { mesh.instanceMatrix.needsUpdate = true; mesh.boundingBox = mesh.boundingSphere = null; }
  }
  /** World-space mouth plane; radius measures free clearance inside the teeth. */
  function getMouthPose() {
    mouth.updateWorldMatrix(true, false);
    const center = new THREE.Vector3().setFromMatrixPosition(mouth.matrixWorld);
    const inward = new THREE.Vector3(0, 0, 1).transformDirection(mouth.matrixWorld);
    const scale = new THREE.Vector3().setFromMatrixScale(mouth.matrixWorld);
    const position = {x: center.x, y: center.y, z: center.z}, axis = {x: inward.x, y: inward.y, z: inward.z};
    return {center: position, inward: axis, direction: {...axis}, outward: {x: -inward.x, y: -inward.y, z: -inward.z}, radius: freeMouthRadius * Math.min(Math.abs(scale.x), Math.abs(scale.y))};
  }
  animate();
  return {
    group,
    animate,
    getMouthPose,
    dispose() {
      if (disposed) return; disposed = true; group.removeFromParent();
      for (const mesh of batches) mesh.dispose(); for (const resource of resources) resource.dispose(); resources.clear(); group.clear();
    }
  };
}
