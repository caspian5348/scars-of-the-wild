import * as THREE from './vendor/three.module.js';
import {embeddedTreeHeight} from './terrain-surface.js';
import {createTreeInstanceRegistry} from './tree-instances.js';
import { STORM_CENTER,STORM_PREVIEW_SPAWN } from './biomes.js';
import {riverBankDistanceAt} from './river-network.js';

const TAU=Math.PI*2;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
function random(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};}
const hash=(x,z)=>{const n=Math.sin(x*127.1+z*311.7)*43758.5453;return n-Math.floor(n);};
const clearAt=(x,z,margin=0)=>Math.hypot(x-STORM_PREVIEW_SPAWN.x,z-STORM_PREVIEW_SPAWN.z)>7+margin&&riverBankDistanceAt(x,z)>3+margin;

function builder(){
  const positions=[],uvs=[],colors=[],exposed=[],flex=[],indices=[];
  const color=new THREE.Color();
  function vertex(p,u,v,tint,bare=0,bend=0){const n=positions.length/3;p.toArray(positions,positions.length);uvs.push(u,v);color.set(tint).toArray(colors,colors.length);exposed.push(bare);flex.push(bend);return n;}
  function tube(points,radii,sides=6,{tint='#aab0a7',broken=false,bend=0}={}){
    const start=positions.length/3;
    for(let j=0;j<points.length;j++){
      const p=new THREE.Vector3(...points[j]),before=new THREE.Vector3(...points[Math.max(0,j-1)]),after=new THREE.Vector3(...points[Math.min(points.length-1,j+1)]);
      const direction=after.sub(before).normalize(),rotation=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),direction);
      for(let i=0;i<=sides;i++){
        const a=i/sides*TAU,last=broken&&j===points.length-1;
        const chip=last?(Math.sin(a*3+.71)*.34+Math.sin(a*7+2)*.21)*Math.max(.32,radii[j]*1.9):0;
        const offset=new THREE.Vector3(Math.cos(a)*radii[j],chip,Math.sin(a)*radii[j]).applyQuaternion(rotation);
        vertex(p.clone().add(offset),i/sides,j*.8,tint,last?.85:0,bend*j/(points.length-1));
        if(j<points.length-1&&i<sides){const n=start+j*(sides+1)+i;indices.push(n,n+sides+1,n+1,n+1,n+sides+1,n+sides+2);}
      }
      if(j===points.length-1&&broken){
        const center=vertex(p.clone().addScaledVector(direction,-radii[j]*.85),.5,.5,'#d2c8b4',1,bend);
        const ring=start+j*(sides+1);for(let i=0;i<sides;i++)indices.push(center,ring+i+1,ring+i);
      }
    }
  }
  function shard(points,tint='#aea188'){
    const center=new THREE.Vector3(...points[0]),tip=new THREE.Vector3(...points[1]),r=points[2]||.06;
    const direction=tip.clone().sub(center).normalize(),rotation=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),direction);
    const ids=[];for(let i=0;i<3;i++){const a=i/3*TAU;ids.push(vertex(center.clone().add(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r).applyQuaternion(rotation)),i/2,0,tint,1,0));}
    const top=vertex(tip,.5,1,tint,1,.15);for(let i=0;i<3;i++)indices.push(ids[i],top,ids[(i+1)%3]);
  }
  return{tube,shard,finish(){const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.setAttribute('stormExposure',new THREE.Float32BufferAttribute(exposed,1));geometry.setAttribute('stormFlex',new THREE.Float32BufferAttribute(flex,1));geometry.setIndex(indices);geometry.computeVertexNormals();geometry.computeBoundingSphere();return geometry;}};
}

function deadTree(variant){
  const build=builder(),rng=random(5173+variant*937),height=[17,11.5,21][variant];
  const points=[],radii=[];
  for(let j=0;j<=7;j++){const t=j/7;points.push([Math.sin(t*2.7+variant)*t*.85,t*height,Math.sin(t*3.4)*t*.63]);radii.push(.63*(1-t*.73));}
  build.tube(points,radii,10,{broken:true});
  for(let root=0;root<5;root++){const a=root/5*TAU+.2;build.tube([[0,.75,0],[Math.cos(a)*.8,.24,Math.sin(a)*.8],[Math.cos(a)*1.7,-.16,Math.sin(a)*1.7]],[.18,.12,.025],5,{tint:'#818c81'});}
  for(let branch=0;branch<9;branch++){
    const a=branch*2.399+variant*.6,y=3.8+branch*(height-5.2)/9,reach=1.6+rng()*3.3;
    const end=[Math.cos(a)*reach,y+1.4+rng()*1.5,Math.sin(a)*reach];
    build.tube([[Math.sin(y/height*2.7+variant)*y/height*.85,y,0],[Math.cos(a)*reach*.55,y+.35,Math.sin(a)*reach*.55],end],[.14,.10,.04],5,{broken:true,bend:.18});
    if(branch%2===variant%2){const b=a+.55;build.tube([[end[0]*.61,y+.63,end[2]*.61],[Math.cos(b)*reach*.83,y+2.8,Math.sin(b)*reach*.83]],[.065,.013],4,{broken:true,bend:.6});}
  }
  for(let spike=0;spike<5;spike++){const a=spike/5*TAU;build.shard([[points[7][0]+Math.cos(a)*.12,height-.1,points[7][2]+Math.sin(a)*.12],[points[7][0]+Math.cos(a)*.22,height+.35+rng()*.9,points[7][2]+Math.sin(a)*.22],.055]);}
  return build.finish();
}

function uprootedTree(variant){
  const build=builder(),rng=random(90482+variant*819);
  build.tube([[0,.85,0],[3,.57,.10],[7,.44,.25],[12,.16,.38],[15,.06,.44]],[.66,.48,.35,.22,.14],9,{broken:true});
  // A lifted root fan, torn laterals and dangling fine roots show the uprooting.
  for(let root=0;root<11;root++){
    const a=-.22+root/11*Math.PI*1.38,r=1.6+rng()*1.4;
    const end=[-.65-rng()*.6,.72+Math.sin(a)*r,Math.cos(a)*r];
    build.tube([[0,.8,0],[-.42,.8+Math.sin(a)*r*.55,Math.cos(a)*r*.55],end],[.14,.075,.019],5,{broken:true,tint:'#93978b',bend:.25});
    if(root%2===0)build.tube([end,[end[0]-.25,end[1]-.5,end[2]+.20]],[.018,.006],3,{bend:.75});
  }
  for(let branch=0;branch<7;branch++){
    const x=2+branch*1.6,side=branch%2?1:-1;
    build.tube([[x,.45,0],[x+.8,.72,side*1.25],[x+1.7,.30+variant*.32,side*(1.9+rng())]],[.12,.07,.019],5,{broken:true,bend:.25});
  }
  return build.finish();
}

function dryBrush(){
  const build=builder(),rng=random(209671);
  for(let stem=0;stem<8;stem++){
    const a=rng()*TAU,r=rng()*.20,h=.35+rng()*.72;
    const end=[Math.cos(a)*r+.32,h,Math.sin(a)*r+.22];
    build.tube([[Math.cos(a)*r,0,Math.sin(a)*r],[end[0]*.65,h*.55,end[2]*.65],end],[.014,.010,.003],3,{tint:stem%3?'#968d72':'#777e6f',bend:1});
    if(stem%2===0)build.tube([[end[0]*.6,h*.6,end[2]*.6],[end[0]+.2,h*.77,end[2]-.12]],[.008,.002],3,{tint:'#a49b7e',bend:1});
  }
  return build.finish();
}

function weatheredWood(foliage,time,own){
  const maps={};for(const key of['map','normalMap','roughnessMap']){const texture=own(foliage.bark[key].clone());texture.repeat.set(1.2,1.2);texture.offset.set(0,0);texture.needsUpdate=true;maps[key]=texture;}
  function configure(material,shade){
    material.onBeforeCompile=shader=>{
      shader.uniforms.uStormTime=time;shader.vertexShader='attribute float stormExposure;attribute float stormFlex;uniform float uStormTime;varying float vStormExposure;varying vec3 vStormPoint;varying vec2 vStormUv;\n'+shader.vertexShader;
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
        vStormExposure=stormExposure;vStormPoint=position;vStormUv=uv;
        vec3 stormAnchor=vec3(0.0);
        #ifdef USE_INSTANCING
          stormAnchor=instanceMatrix[3].xyz;
        #endif
        float stormPhase=stormAnchor.x*.037+stormAnchor.z*.028;
        float stormGust=sin(uStormTime*1.7+stormPhase)+.37*sin(uStormTime*3.8+stormPhase*.7);
        transformed.x+=stormGust*stormFlex*.14;
        transformed.z+=cos(uStormTime*1.3+stormPhase)*stormFlex*.075;
      `);
      if(shade){shader.fragmentShader='uniform float uStormTime;varying float vStormExposure;varying vec3 vStormPoint;varying vec2 vStormUv;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
        float stormFiber=.79+.21*sin(vStormPoint.y*18.0+vStormPoint.x*41.0+vStormPoint.z*13.0);
        diffuseColor.rgb*=vec3(.70,.78,.80);
        diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.29,.25,.18)*stormFiber,vStormExposure*.82);
      `);shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
        float scarY=vStormPoint.y;
        float scarStep=floor(scarY*2.3),scarT=fract(scarY*2.3);
        float scarZig=mix(sin(scarStep*2.71),sin((scarStep+1.)*2.71),scarT)*.031;
        float scarPath=.34+sin(scarY*.62)*.04+scarZig;
        float scarDistance=abs(vStormUv.x-scarPath);
        scarDistance=min(scarDistance,1.-scarDistance);
        float scarHeight=smoothstep(.45,1.35,scarY)*(1.-smoothstep(12.5,17.,scarY));
        float scarBranch=abs(vStormUv.x-(scarPath+.10*(scarY-5.4)));
        float fork=(1.-smoothstep(.006,.016,scarBranch))*smoothstep(5.3,5.6,scarY)*(1.-smoothstep(6.8,7.2,scarY));
        float scar=((1.-smoothstep(.006,.019,scarDistance))+fork)*scarHeight*(1.-vStormExposure);
        float scarGlow=.70+.08*sin(uStormTime*.8+scarY*.38);
        totalEmissiveRadiance+=vec3(.34,.008,.82)*scar*scarGlow;
      `);}
    };
    material.customProgramCacheKey=()=>`storm-deadwood-purple-scars-v2-${shade}`;
  }
  const material=own(new THREE.MeshStandardMaterial({...maps,vertexColors:true,side:THREE.DoubleSide,roughness:.90,normalScale:new THREE.Vector2(.95,.95)}));configure(material,true);
  const depth=own(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking,side:THREE.DoubleSide}));configure(depth,false);
  return{material,depth};
}

/** Storm scenery only. Weather and flying creatures are controlled elsewhere. */
export function createStormBiome({group,heightAt,placementHeightAt=heightAt,stormBlendAt,foliage,rockMaps}){
  const root=new THREE.Group();root.name='Stormlands: shattered trees and exposed slate';group.add(root);
  const resources=[],own=value=>{resources.push(value);return value;},rng=random(193077),clock={value:0},colliders=[],registry=createTreeInstanceRegistry();
  const wood=weatheredWood(foliage,clock,own),dummy=new THREE.Object3D();let triangleCount=0,drawBatches=0;
  const slopeAt=(x,z)=>Math.hypot(placementHeightAt(x+1,z)-placementHeightAt(x-1,z),placementHeightAt(x,z+1)-placementHeightAt(x,z-1))/2;
  function instances(geometry,material,points,name,transform,shadow=false){
    const mesh=own(new THREE.InstancedMesh(geometry,material,points.length));mesh.name=name;
    points.forEach((p,i)=>{transform(p,dummy);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);registry.register(p.id,mesh,i,dummy.matrix);});mesh.computeBoundingSphere();mesh.receiveShadow=true;mesh.castShadow=shadow;if(material===wood.material)mesh.customDepthMaterial=wood.depth;root.add(mesh);triangleCount+=(geometry.index?geometry.index.count:geometry.attributes.position.count)/3*points.length;drawBatches++;return mesh;
  }
  const snags=[];
  for(let attempt=0;attempt<14000&&snags.length<185;attempt++){
    const x=STORM_CENTER.x-242+rng()*484,z=STORM_CENTER.z-210+rng()*420,h=placementHeightAt(x,z),scale=.72+rng()*.95;
    if(stormBlendAt(x,z)<.25+rng()*.30||h<4||slopeAt(x,z)>.86||!clearAt(x,z,scale*1.85)||snags.some(p=>Math.hypot(p.x-x,p.z-z)<6.5))continue;
    const id=`storm-tree-${String(snags.length).padStart(3,'0')}`,anchor=embeddedTreeHeight(x,z,1.8*scale);snags.push({id,x,z,h:anchor,y:anchor,radius:.65*scale,kind:'deadwood',felled:false,scale,angle:rng()*TAU,lean:(rng()-.5)*.085});colliders.push({x,z,radius:.65*scale,treeId:id});
  }
  for(let variant=0;variant<3;variant++){
    const geometry=own(deadTree(variant));geometry.computeBoundingBox();
    for(let i=variant;i<snags.length;i+=3)colliders[i].height=geometry.boundingBox.max.y*snags[i].scale;
    instances(geometry,wood.material,snags.filter((p,i)=>i%3===variant),`Splintered standing trunks ${variant+1}`,(p,o)=>{o.position.set(p.x,p.h-.10,p.z);o.rotation.set(0,p.angle,p.lean);o.scale.setScalar(p.scale);},true);
  }
  const fallen=[];
  for(let attempt=0;attempt<2200&&fallen.length<27;attempt++){
    const x=STORM_CENTER.x-213+rng()*426,z=STORM_CENTER.z-187+rng()*374,scale=.70+rng()*.48,angle=-.5+rng()*1.0+(rng()<.25?Math.PI:0),length=15*scale;
    const endX=x+Math.cos(angle)*length,endZ=z-Math.sin(angle)*length,h=heightAt(x,z),endH=heightAt(endX,endZ);
    if(stormBlendAt(x,z)<.5||stormBlendAt(endX,endZ)<.3||Math.abs(endH-h)/length>.32||!clearAt(x,z,3)||!clearAt(endX,endZ,2))continue;
    let clear=true;for(let along=0;along<=length;along+=.75)if(!clearAt(x+Math.cos(angle)*along,z-Math.sin(angle)*along,1.2)){clear=false;break;}if(!clear)continue;
    fallen.push({x,z,h,scale,angle,pitch:Math.atan2(endH-h,length)});
    colliders.push({x,z,radius:1.18*scale,height:3.5*scale});
    for(let along=.7;along<length;along+=.80)colliders.push({x:x+Math.cos(angle)*along,z:z-Math.sin(angle)*along,radius:scale*(.62-.36*along/length),height:1.1*scale});
  }
  for(let variant=0;variant<2;variant++)instances(own(uprootedTree(variant)),wood.material,fallen.filter((p,i)=>i%2===variant),`Uprooted tree falls ${variant+1}`,(p,o)=>{o.position.set(p.x,p.h-.12,p.z);o.rotation.set(0,p.angle,p.pitch,'YXZ');o.scale.setScalar(p.scale);},true);
  const slate=own(new THREE.IcosahedronGeometry(1,1)),vertices=slate.attributes.position;
  for(let i=0;i<vertices.count;i++){const x=vertices.getX(i),y=vertices.getY(i),z=vertices.getZ(i),r=.76+hash(x*3+11,z*5+y)*.31;vertices.setXYZ(i,x*r,y*.28*(.85+hash(x*7,z*9)*.3),z*r);}slate.computeVertexNormals();
  const rockCopies={};for(const key of['map','normalMap','roughnessMap']){const texture=own(rockMaps[key].clone());texture.repeat.set(1.15,1.15);texture.needsUpdate=true;rockCopies[key]=texture;}
  const stoneMaterial=own(new THREE.MeshStandardMaterial({...rockCopies,color:'#859296',roughness:.82,normalScale:new THREE.Vector2(.9,.9)})),stones=[];
  for(let attempt=0;attempt<3300&&stones.length<640;attempt++){
    const x=STORM_CENTER.x-242+rng()*484,z=STORM_CENTER.z-210+rng()*420,h=heightAt(x,z),scale=.15+Math.pow(rng(),2)*1.45;
    if(stormBlendAt(x,z)<.35||h<4||!clearAt(x,z,scale+.45))continue;
    stones.push({x,z,h,scale,angle:rng()*TAU,tilt:rng()*.34});if(scale>1.12)colliders.push({x,z,radius:scale*.78,height:.7*scale});
  }
  instances(slate,stoneMaterial,stones,'Broken slate and exposed gravel',(p,o)=>{o.position.set(p.x,p.h+.055,p.z);o.rotation.set(p.tilt,p.angle,p.tilt*.5);o.scale.set(p.scale,p.scale,p.scale*(.72+hash(p.x,p.z)*.44));},true);
  const brush=[];
  for(let attempt=0;attempt<4500&&brush.length<1250;attempt++){
    const x=STORM_CENTER.x-242+rng()*484,z=STORM_CENTER.z-210+rng()*420,h=heightAt(x,z);
    if(stormBlendAt(x,z)<.27||h<4||slopeAt(x,z)>.95||!clearAt(x,z,.65))continue;
    brush.push({x,z,h,scale:.35+rng()*.85,angle:-.6+rng()*.40});
  }
  instances(own(dryBrush()),wood.material,brush,'Wind-flattened withered brush',(p,o)=>{o.position.set(p.x,p.h+.01,p.z);o.rotation.set(0,p.angle,0);o.scale.setScalar(p.scale);});
  const splinter=builder();for(let i=0;i<3;i++)splinter.shard([[i*.08,.015,0],[i*.08+.10,.06,.6-i*.14],.025],'#b3aa92');
  const shards=[];for(let i=0;snags.length&&i<730;i++){const base=snags[i%snags.length],a=rng()*TAU,r=1.2+rng()*6,x=base.x+Math.cos(a)*r,z=base.z+Math.sin(a)*r;if(!clearAt(x,z,.3))continue;shards.push({x,z,h:heightAt(x,z),angle:rng()*TAU,scale:.65+rng()*1.45});}
  instances(own(splinter.finish()),wood.material,shards,'Torn bark and scattered splinters',(p,o)=>{o.position.set(p.x,p.h+.018,p.z);o.rotation.set(0,p.angle,0);o.scale.setScalar(p.scale);});
  root.userData.triangleCount=triangleCount;root.userData.drawBatches=drawBatches;
  const trees=snags.map((tree,i)=>({...tree,height:colliders[i].height}));
  return{colliders,trees,setTreeFelled(id,value){const changed=registry.setTreeFelled(id,value);if(changed)trees.find(tree=>tree.id===id).felled=!!value;return changed;},update(time,camera){clock.value=time;root.visible=!camera||Math.hypot(camera.x-STORM_CENTER.x,camera.z-STORM_CENTER.z)<1120;},dispose(){group.remove(root);for(const resource of resources)resource.dispose();}};
}
