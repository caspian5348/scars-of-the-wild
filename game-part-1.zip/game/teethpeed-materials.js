import * as THREE from './vendor/three.module.js';

const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const mix=(a,b,t)=>a+(b-a)*t;
function hash(x,y,seed=0) {
  let n=Math.imul(x+seed*31,374761393)+Math.imul(y+seed*17,668265263);
  n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967296;
}
function tileNoise(u,v,cells,seed) {
  const x=u*cells,y=v*cells,ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy;
  const sx=fx*fx*(3-2*fx),sy=fy*fy*(3-2*fy),h=(a,b)=>hash((a%cells+cells)%cells,(b%cells+cells)%cells,seed);
  return mix(mix(h(ix,iy),h(ix+1,iy),sx),mix(h(ix,iy+1),h(ix+1,iy+1),sx),sy);
}

function cuticleRoughness(dry=false) {
  const size=256,data=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++) {
    const u=x/size,v=y/size,patch=tileNoise(u,v,6,11),grain=tileNoise(u,v,49,23);
    const cellX=Math.floor(u*38),cellY=Math.floor(v*38),localX=u*38-cellX,localY=v*38-cellY;
    const poreX=.2+hash(cellX,cellY,37)*.6,poreY=.2+hash(cellX,cellY,39)*.6;
    const pore=Math.exp(-((localX-poreX)**2+(localY-poreY)**2)*170)*(hash(cellX,cellY,41)>.48?1:0);
    // Small dry pores interrupt the oily patches; no metallic flakes or directional wood grain.
    const value=dry ? .87+patch*.09+grain*.025+pore*.035 : .80+patch*.16+grain*.025+pore*.06;
    const byte=Math.round(clamp(value)*255),i=(y*size+x)*4;data.set([byte,byte,byte,255],i);
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);
  texture.name=dry?'Teethpeed joint micro-roughness':'Teethpeed cuticle micro-roughness';
  texture.colorSpace=THREE.NoColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
  texture.repeat.set(2.3,2.3);texture.generateMipmaps=true;texture.minFilter=THREE.LinearMipmapLinearFilter;
  texture.magFilter=THREE.LinearFilter;texture.anisotropy=4;texture.needsUpdate=true;return texture;
}

/** The albedo belongs to the caller. This factory owns only its generated textures and materials. */
export function createTeethpeedMaterials({surfaceTexture}={}) {
  const map=surfaceTexture||null,roughnessMap=cuticleRoughness(),jointRoughness=cuticleRoughness(true);
  const common={metalness:0,vertexColors:true};
  const materials={
    shell:new THREE.MeshPhysicalMaterial({
      ...common,name:'Teethpeed biological cuticle',color:map?'#bfc4b9':'#443a32',map,
      bumpMap:map,bumpScale:.0022,roughness:.63,roughnessMap,
      clearcoat:.045,clearcoatRoughness:.53,ior:1.48,specularIntensity:.60,
    }),
    edge:new THREE.MeshPhysicalMaterial({
      ...common,name:'Teethpeed softly abraded plate margins',color:map?'#95978b':'#65584b',map,
      bumpMap:map,bumpScale:.0012,roughness:.66,roughnessMap:jointRoughness,
      clearcoat:.025,clearcoatRoughness:.54,ior:1.47,specularIntensity:.57,
    }),
    membrane:new THREE.MeshStandardMaterial({
      ...common,name:'Teethpeed flexible dark intersegment membrane',color:'#392b29',
      bumpMap:map,bumpScale:.0007,roughness:.86,roughnessMap:jointRoughness,
    }),
    limb:new THREE.MeshPhysicalMaterial({
      ...common,name:'Teethpeed chestnut legs and dry joints',color:map?'#ded0b0':'#75604b',map,
      bumpMap:map,bumpScale:.0011,roughness:.65,roughnessMap:jointRoughness,
      clearcoat:.045,clearcoatRoughness:.51,ior:1.46,specularIntensity:.68,
    }),
    mandible:new THREE.MeshPhysicalMaterial({
      ...common,name:'Teethpeed hard dark chitin mandibles',color:map?'#c0ada0':'#513b31',map,
      bumpMap:map,bumpScale:.0010,roughness:.39,roughnessMap,
      clearcoat:.13,clearcoatRoughness:.34,ior:1.50,specularIntensity:.76,
    }),
    tooth:new THREE.MeshPhysicalMaterial({
      ...common,name:'Teethpeed worn amber chitin cutting edges',color:'#98755d',
      bumpMap:map,bumpScale:.00045,roughness:.49,roughnessMap:jointRoughness,
      clearcoat:.055,clearcoatRoughness:.42,ior:1.49,specularIntensity:.69,
    }),
    eye:new THREE.MeshPhysicalMaterial({
      ...common,name:'Teethpeed tiny black-brown ocelli',color:'#251a17',roughness:.18,
      clearcoat:.20,clearcoatRoughness:.14,ior:1.47,specularIntensity:.80,
    }),
    hair:new THREE.MeshStandardMaterial({
      ...common,name:'Teethpeed fine muted tactile bristles',color:'#685346',roughness:.88,
    }),
  };
  let disposed=false;
  return {materials,dispose(){
    if(disposed)return;disposed=true;
    for(const material of Object.values(materials))material.dispose();
    roughnessMap.dispose();jointRoughness.dispose();
  }};
}
