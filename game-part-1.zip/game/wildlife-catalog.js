/** Wildlife added in phase three. Teethpeed and Deatheater keep their own controllers. */
const species=(id,name,biomes,anatomy,habitat,temperament,values)=>Object.freeze({id,name,biomes:Object.freeze(biomes),anatomy,habitat,temperament,
  health:30,walkSpeed:1.2,runSpeed:5,vision:17,damage:8,biteInterval:2.1,radius:.4,height:.7,weight:1,...values,loot:Object.freeze(values?.loot||{raw_meat:1,bone:1})});

export const WILDLIFE_LIST=Object.freeze([
  species('mossback_deer','Mossback Deer',['forest'],'deer','ground','skittish',{health:65,height:1.65,radius:.65,runSpeed:8.3,walkSpeed:1.5,coat:'#796653',belly:'#b6a68b',antlers:true,loot:{raw_meat:4,hide:2,bone:2}}),
  species('fern_boar','Fern Boar',['forest'],'boar','ground','defensive',{health:80,height:.96,radius:.62,runSpeed:6.1,damage:13,vision:11,weight:.8,coat:'#4c4036',belly:'#756857',loot:{raw_meat:4,hide:2,bone:2}}),
  species('canopy_toucan','Canopy Toucan',['forest'],'toucan','air','skittish',{health:18,height:.44,radius:.24,walkSpeed:2.8,runSpeed:7.2,altitude:5.5,coat:'#232b29',belly:'#d5ceb2',loot:{raw_meat:1,feathers:3,bone:1}}),
  species('emerald_treefrog','Emerald Treefrog',['forest'],'frog','amphibious','skittish',{health:12,height:.18,radius:.15,walkSpeed:.42,runSpeed:2.2,vision:6,coat:'#546943',belly:'#b5b98b',loot:{raw_meat:1,venom:1}}),
  species('meadow_hare','Meadow Hare',['valley'],'hare','ground','skittish',{health:20,height:.43,radius:.24,walkSpeed:.72,runSpeed:7.8,vision:14,weight:1.5,coat:'#8c806a',belly:'#c6b99c',loot:{raw_meat:1,fur:1,bone:1}}),
  species('red_fox','Red Fox',['valley'],'fox','ground','skittish',{health:35,height:.69,radius:.36,walkSpeed:1.55,runSpeed:7.2,coat:'#95654b',belly:'#c0b299',loot:{raw_meat:2,fur:2,bone:1}}),
  species('ridge_goat','Ridge Goat',['valley'],'goat','ground','defensive',{health:65,height:1.27,radius:.49,walkSpeed:1.3,runSpeed:6.2,damage:10,vision:8,coat:'#938b78',belly:'#c9c1aa',loot:{raw_meat:3,hide:2,bone:2}}),
  species('wild_turkey','Wild Turkey',['valley'],'turkey','ground','skittish',{health:24,height:.74,radius:.32,walkSpeed:1.1,runSpeed:4.8,coat:'#544c41',belly:'#897963',loot:{raw_meat:2,feathers:4,bone:1}}),
  species('storm_wolf','Storm Wolf',['storm'],'wolf','ground','predator',{health:85,height:1.15,radius:.56,walkSpeed:1.7,runSpeed:6.7,damage:21,vision:31,weight:.75,coat:'#696c6b',belly:'#a1a6a0',loot:{raw_meat:3,fur:3,bone:2}}),
  species('ash_raven','Ash Raven',['storm'],'raven','air','skittish',{health:22,height:.43,radius:.28,walkSpeed:3,runSpeed:8.5,altitude:6.5,weight:1.6,coat:'#292f30',belly:'#535b5d',loot:{raw_meat:1,feathers:4,bone:1}}),
  species('bolt_mantis','Bolt Mantis',['storm'],'mantis','ground','predator',{health:55,height:1.02,radius:.44,walkSpeed:.9,runSpeed:4.8,damage:15,vision:19,weight:.65,coat:'#596568',belly:'#83908b',loot:{raw_meat:1,chitin:3,venom:1}}),
  species('cave_bat','Cave Bat',['cave'],'bat','air','skittish',{health:15,height:.21,radius:.2,walkSpeed:2.5,runSpeed:5.8,altitude:3.2,coat:'#554e48',belly:'#857669',loot:{raw_meat:1,hide:1,bone:1}}),
  species('blind_salamander','Blind Salamander',['cave'],'salamander','ground','skittish',{health:20,height:.22,radius:.25,walkSpeed:.55,runSpeed:2.1,vision:4,coat:'#b0a297',belly:'#d2c2aa',loot:{raw_meat:1,venom:1}}),
  species('crystal_spider','Crystal Spider',['cave'],'spider','ground','predator',{health:55,height:.51,radius:.51,walkSpeed:.95,runSpeed:4.8,damage:13,vision:14,weight:.55,coat:'#5a5955',belly:'#918781',loot:{chitin:3,venom:2,crystal_shard:1}}),
  species('tunnel_mole','Tunnel Mole',['cave'],'mole','ground','skittish',{health:24,height:.3,radius:.25,walkSpeed:.7,runSpeed:2.8,vision:5,coat:'#5b5750',belly:'#948575',loot:{raw_meat:1,fur:1,bone:1}}),
  species('cave_bear','Cave Bear',['cave'],'bear','ground','predator',{health:260,height:1.72,radius:.80,walkSpeed:1.25,runSpeed:6.5,damage:32,biteInterval:2.25,vision:20,eventOnly:true,weight:0,coat:'#524538',belly:'#817360',loot:{raw_meat:7,fur:4,hide:4,bone:4}}),
  species('ember_monitor','Ember Monitor',['lava'],'monitor','ground','predator',{health:90,height:.52,radius:.57,walkSpeed:1.05,runSpeed:5.7,damage:17,vision:17,weight:.55,coat:'#63554a',belly:'#b18a64',loot:{raw_meat:3,hide:2,ember_gland:1}}),
  species('basalt_tortoise','Basalt Tortoise',['lava'],'tortoise','ground','neutral',{health:120,height:.7,radius:.65,walkSpeed:.36,runSpeed:.75,vision:8,coat:'#656259',belly:'#948777',loot:{raw_meat:2,shell:3,bone:2}}),
  species('cinder_scorpion','Cinder Scorpion',['lava'],'scorpion','ground','predator',{health:42,height:.52,radius:.39,walkSpeed:.7,runSpeed:3.5,damage:12,vision:11,weight:.65,coat:'#716451',belly:'#a98760',loot:{chitin:3,venom:2,ember_gland:1}}),
  species('snow_fox','Snow Fox',['ice'],'snowfox','ground','skittish',{health:40,height:.58,radius:.35,walkSpeed:1.45,runSpeed:7.1,coat:'#c1c0b2',belly:'#e0dccb',loot:{raw_meat:2,fur:3,bone:1}}),
  species('glacier_ox','Glacier Ox',['ice'],'ox','ground','defensive',{health:180,height:1.7,radius:.86,walkSpeed:1.0,runSpeed:5.6,damage:24,vision:10,weight:.55,coat:'#716d62',belly:'#a19a87',loot:{raw_meat:6,fur:4,hide:2,bone:3}}),
  species('frost_owl','Frost Owl',['ice'],'owl','air','skittish',{health:24,height:.47,radius:.3,walkSpeed:2.8,runSpeed:6.4,altitude:4.8,coat:'#c6c3b4',belly:'#e0d8c0',loot:{raw_meat:1,feathers:4,bone:1}}),
  species('tide_crab','Tide Crab',['beach'],'crab','shore','defensive',{health:25,height:.21,radius:.32,walkSpeed:.65,runSpeed:2.3,damage:5,vision:4,weight:1.4,coat:'#9c8061',belly:'#ceb993',loot:{raw_meat:1,shell:2,chitin:1}}),
  species('leatherback_turtle','Leatherback Turtle',['beach','ocean'],'seaturtle','amphibious','neutral',{health:95,height:.48,radius:.67,walkSpeed:.5,runSpeed:1.8,depth:1.2,weight:.55,coat:'#697676',belly:'#b0b5a5',loot:{raw_meat:3,shell:3,bone:2}}),
  species('shore_gull','Shore Gull',['beach'],'gull','air','skittish',{health:20,height:.35,radius:.23,walkSpeed:3.1,runSpeed:7.8,altitude:4,coat:'#aab2b0',belly:'#dedfce',loot:{raw_meat:1,feathers:3,bone:1}}),
  species('reef_fish','Reef Fish',['ocean'],'reeffish','water','skittish',{health:12,height:.24,radius:.2,walkSpeed:1.15,runSpeed:3.9,depth:1.6,weight:2.2,coat:'#6e9a93',belly:'#d0b98b',loot:{raw_fish:1,bone:1}}),
  species('silver_tuna','Silver Tuna',['ocean'],'tuna','water','skittish',{health:35,height:.44,radius:.38,walkSpeed:2.8,runSpeed:7,depth:2.2,weight:1.25,coat:'#607c87',belly:'#c0c6be',loot:{raw_fish:3,bone:1}}),
  species('reef_shark','Reef Shark',['ocean'],'shark','water','predator',{health:130,height:.72,radius:.68,walkSpeed:2.0,runSpeed:6.4,damage:24,vision:22,depth:1.7,weight:.36,coat:'#758487',belly:'#bac0b2',loot:{raw_fish:5,hide:2,bone:3}}),
  species('manta_ray','Manta Ray',['ocean'],'manta','water','neutral',{health:100,height:.29,radius:.82,walkSpeed:1.5,runSpeed:4.2,depth:2.6,weight:.50,coat:'#4c6469',belly:'#b4bcb0',loot:{raw_fish:4,hide:2,bone:2}}),
  species('glow_deer','Glow Deer',['glow'],'deer','ground','skittish',{health:70,height:2.1,radius:.66,walkSpeed:1.05,runSpeed:7.5,vision:14,weight:1.0,coat:'#405a50',belly:'#9ca99b',bioluminescent:true,loot:{raw_meat:4,hide:2,bone:2}}),
  species('glow_jellyfish','Floating Glow Jellyfish',['glow'],'jellyfish','air','neutral',{health:18,height:1.1,radius:.40,walkSpeed:.42,runSpeed:.8,altitude:2.6,vision:6,weight:1.7,coat:'#648f92',belly:'#b7dace',bioluminescent:true,loot:{fiber:1}}),
  species('glow_butterfly','Glow Butterfly',['glow'],'butterfly','air','skittish',{health:6,height:.22,radius:.18,walkSpeed:.6,runSpeed:1.7,altitude:1.2,vision:3,weight:2.4,coat:'#549caf',belly:'#c2e6bb',bioluminescent:true,loot:{fiber:1}}),
  species('ocean_deatheater','Ocean Deatheater',['ocean'],'ocean_deatheater','water','predator',{health:380,height:1.9,radius:1.58,walkSpeed:3.2,runSpeed:15,damage:44,biteInterval:1.8,vision:36,depth:3.0,weight:.22,coat:'#3c5158',belly:'#859892',loot:{raw_fish:10,hide:4,bone:5}}),
  species('dillo_suare','Dillo-suare',['storm'],'dinosaur','ground','predator',{health:420,height:3.35,radius:1.12,walkSpeed:1.8,runSpeed:8.7,damage:38,biteInterval:1.65,vision:38,eventOnly:true,unique:true,weight:0,coat:'#4c4e50',belly:'#8a807e',loot:{raw_meat:10,hide:6,bone:6}}),
]);

export const WILDLIFE_SPECIES=Object.freeze(Object.assign(Object.create(null),Object.fromEntries(WILDLIFE_LIST.map(value=>[value.id,value]))));
export const WILDLIFE_BIOMES=Object.freeze(['forest','valley','storm','cave','lava','ice','beach','ocean','glow']);
export const WILDLIFE_LIMITS=Object.freeze({actors:36,views:24,savedActors:128,remains:2048,respawnSeconds:1800,corpseSeconds:900});

const finite=Number.isFinite,plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
const point=value=>plain(value)&&[value.x,value.y,value.z].every(finite)&&Math.max(Math.abs(value.x),Math.abs(value.y),Math.abs(value.z))<10000;
const id=value=>typeof value==='string'&&value.length>0&&value.length<=160;
const time=value=>finite(value)&&value>=0&&value<1e10;
/** Pure persistence validation; does not create models or use random numbers. */
export function normalizeWildlifeState(value){
  if(value===undefined)return undefined;
  if(!plain(value)||value.version!==1||!id(value.seed)||!time(value.clock)||!Array.isArray(value.actors)||value.actors.length>WILDLIFE_LIMITS.savedActors||!Array.isArray(value.remains)||value.remains.length>WILDLIFE_LIMITS.remains)return null;
  if(value.concealEpisode!==undefined&&(!Number.isInteger(value.concealEpisode)||value.concealEpisode<0)||value.wasConcealed!==undefined&&typeof value.wasConcealed!=='boolean')return null;
  const seen=new Set(),uniqueSeen=new Set(),actors=[],remains=[];
  for(const r of value.actors){
    const s=WILDLIFE_SPECIES[r?.species];
    if(!plain(r)||!id(r.id)||seen.has(r.id)||!s||!point(r.position)||!point(r.home)||!finite(r.heading)||!finite(r.health)||r.health<=0||r.health>s.health||!['roam','flee','chase','hunt'].includes(r.state))return null;
    if(![r.age,r.stateTime,r.cooldown,r.roamIndex,r.hidingEpisode,r.savedAt].every(time)||!Number.isInteger(r.roamIndex)||!Number.isInteger(r.hidingEpisode)||typeof r.concealFound!=='boolean')return null;
    if(r.memory!=null&&!point(r.memory)||r.target!=null&&!point(r.target))return null;
    if(s.unique&&uniqueSeen.has(s.id))return null;
    if(s.unique)uniqueSeen.add(s.id);
    actors.push({id:r.id,species:r.species,position:{...r.position},home:{...r.home},heading:r.heading,health:r.health,state:r.state,age:r.age,stateTime:r.stateTime,cooldown:r.cooldown,roamIndex:r.roamIndex,hidingEpisode:r.hidingEpisode,concealFound:r.concealFound,savedAt:r.savedAt,memory:r.memory?{...r.memory}:null,target:r.target?{...r.target}:null});seen.add(r.id);
  }
  const deadSeen=new Set();
  for(const r of value.remains){
    if(!plain(r)||!id(r.id)||deadSeen.has(r.id)||!WILDLIFE_SPECIES[r.species]||!point(r.position)||!finite(r.heading)||!time(r.deathTime)||!time(r.respawnAt)||r.respawnAt<r.deathTime||typeof r.harvested!=='boolean')return null;
    remains.push({id:r.id,species:r.species,position:{...r.position},heading:r.heading,deathTime:r.deathTime,respawnAt:r.respawnAt,harvested:r.harvested});deadSeen.add(r.id);
  }
  if(actors.some(r=>deadSeen.has(r.id)))return null;
  return {version:1,seed:value.seed,clock:value.clock,concealEpisode:value.concealEpisode??0,wasConcealed:value.wasConcealed??false,actors,remains};
}
