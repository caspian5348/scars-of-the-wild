import * as THREE from './vendor/three.module.js';

// A narrow edge skirt overlaps the terrain outside the player's bounds; rising
// scenery remains beyond radius 410. This never supplies player collision heights.
const TAU = Math.PI * 2;
const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));
const mix = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, v) => { const t = clamp((v - a) / (b - a)); return t * t * (3 - 2 * t); };
const hash = (x, z) => { const v = Math.sin(x * 127.1 + z * 311.7) * 43758.5453; return v - Math.floor(v); };
function noise(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
  const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
  return mix(mix(hash(ix, iz), hash(ix + 1, iz), u), mix(hash(ix, iz + 1), hash(ix + 1, iz + 1), u), v);
}
const fbm = (x, z) => noise(x, z) * .55 + noise(x * 2.04 + 9.1, z * 2.04 - 6.8) * .28 + noise(x * 4.09, z * 4.09) * .17;
const ridgeNoise = (x, z) => 1 - Math.abs(noise(x, z) * 2 - 1);
const angularDistance = (a, b) => Math.atan2(Math.sin(a - b), Math.cos(a - b));
const peak = (a, center, width) => Math.exp(-Math.pow(angularDistance(a, center) / width, 2));

function seededRandom(seed) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

function innerRadius(a) {
  // Half a metre of overlap seals the square terrain edge without a visible gap.
  return 399.5 / Math.max(Math.abs(Math.cos(a)), Math.abs(Math.sin(a)));
}

function makeHeightFunctions(heightAt) {
  function nearHeight(x, z) {
    const a = Math.atan2(z, x), r = Math.hypot(x, z), edge = Math.max(410, innerRadius(a));
    const inward = smooth(edge + 6, edge + 176, r);
    const angular = fbm(Math.cos(a) * 3.2 + 16, Math.sin(a) * 3.2 + 7);
    const teeth = ridgeNoise(Math.cos(a) * 19 + 3, Math.sin(a) * 19 - 8);
    const hero = peak(a, -.39, .20) * 126 + peak(a, .32, .17) * 92 + peak(a, -1.06, .24) * 58;
    const summit = 115 + angular * 134 + teeth * 42 + hero;
    const spine = 737 + (angular - .5) * 108 + Math.sin(a * 5.7 + .8) * 24;
    const width = r < spine ? 169 : 210;
    const main = Math.exp(-Math.pow(Math.abs((r - spine) / width), 1.12));
    // Domain-warped drainage cuts create crags and buttresses, not smooth cones.
    const warp = noise(x * .004 + 28, z * .004 - 17) * 54;
    const ribs = ridgeNoise((x + warp) * .017, (z - warp * .55) * .017);
    const fine = ridgeNoise(x * .043 + 11, z * .043) * 13 + (noise(x * .105, z * .105) - .5) * 7;
    const ledges = Math.sin((x * .15 + z * .042) + noise(x * .018, z * .018) * 5) * 7;
    const erosion = (ribs - .48) * 52 + fine + ledges * main;
    const foothills = 20 + fbm(x * .008, z * .008) * 43;
    const mountain = foothills + summit * main + erosion * (.32 + main * .68);
    return mix(heightAt(x, z) - .32, mountain, inward);
  }
  function farHeight(x, z) {
    const a = Math.atan2(z, x), r = Math.hypot(x, z);
    const angular = fbm(Math.cos(a) * 4.7 - 30, Math.sin(a) * 4.7 + 16);
    const crest = ridgeNoise(Math.cos(a) * 28 + 2, Math.sin(a) * 28 + 6);
    const hero = peak(a, -.23, .14) * 176 + peak(a, .48, .20) * 150 + peak(a, -1.4, .19) * 92;
    const spine = 1250 + (angular - .5) * 125;
    const profile = Math.exp(-Math.pow(Math.abs((r - spine) / 182), 1.05));
    const gullies = ridgeNoise(x * .018 + noise(x * .006, z * .006) * 2, z * .018);
    const crags = (gullies - .42) * 76 + (ridgeNoise(x * .065, z * .065) - .5) * 19;
    return 55 + (290 + angular * 165 + crest * 64 + hero) * profile + crags * smooth(925, 1050, r);
  }
  return { nearHeight, farHeight };
}

function createRangeGeometry(height, far) {
  const segments = far ? 576 : 640, rows = far ? 30 : 46;
  const positions = [], colors = [], uv = [], snow = [], indices = [];
  const forest = new THREE.Color('#38523f'), rock = new THREE.Color('#87938a');
  const color = new THREE.Color();
  for (let row = 0; row <= rows; row++) for (let i = 0; i <= segments; i++) {
    const a = i / segments * TAU, start = far ? 935 : innerRadius(a);
    const radius = mix(start, far ? 1500 : 1050, Math.pow(row / rows, far ? 1 : 1.13));
    const x = Math.cos(a) * radius, z = Math.sin(a) * radius, h = height(x, z);
    const dx = (height(x + 1.7, z) - height(x - 1.7, z)) / 3.4;
    const dz = (height(x, z + 1.7) - height(x, z - 1.7)) / 3.4;
    const slope = Math.hypot(dx, dz);
    const concavity = (height(x + 6, z) + height(x - 6, z) + height(x, z + 6) + height(x, z - 6) - h * 4) / 18;
    // Tree cover continues up the lower slopes; slope alone must not turn the
    // entire foothill into a pale quarry wall.
    const bareRock = Math.max(smooth(174, 304, h), smooth(.84, 1.85, slope) * smooth(128, 240, h));
    color.copy(forest).lerp(rock, bareRock);
    const sediment = .89 + Math.sin(h * .135 + x * .013 - z * .009 + noise(x * .01, z * .01) * 2) * .105;
    const warp = noise(x * .004 + 28, z * .004 - 17) * 54;
    const ribs = ridgeNoise((x + warp) * .017, (z - warp * .55) * .017);
    const drainage = .67 + ribs * .31 - clamp(concavity) * .20;
    color.multiplyScalar(sediment * drainage * (.88 + noise(x * .013, z * .013) * .22));
    color.toArray(colors, colors.length);
    const elevation = smooth(far ? 459 : 320, far ? 583 : 414, h + noise(x * .016, z * .016) * 28);
    const holding = 1 - smooth(.34, 1.55, slope);
    const snowCatchment = clamp(.48 + concavity * .26 + (noise(x * .026 + 13, z * .026) - .5) * .74);
    snow.push(elevation * holding * snowCatchment);
    positions.push(x, h, z); uv.push(x / 13, z / 13);
    if (row < rows && i < segments) {
      const n = row * (segments + 1) + i;
      // Alternating diagonals stop long parallel mesh seams on the cliff faces.
      if ((row + i) % 2) indices.push(n, n + 1, n + segments + 1, n + 1, n + segments + 2, n + segments + 1);
      else indices.push(n, n + segments + 2, n + segments + 1, n, n + 1, n + segments + 2);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(new Float32Array(positions.length), 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geometry.setAttribute('alpineSnow', new THREE.Float32BufferAttribute(snow, 1));
  geometry.setIndex(indices); geometry.computeVertexNormals(); geometry.computeBoundingSphere();
  return geometry;
}

function createRockMaterial(rockMaps, own) {
  const maps = {};
  for (const key of ['map', 'normalMap', 'roughnessMap']) {
    const texture = own(rockMaps[key].clone());
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 1); texture.offset.set(0, 0); texture.needsUpdate = true;
    maps[key] = texture;
  }
  const material = own(new THREE.MeshStandardMaterial({ ...maps, vertexColors: true, roughness: 1, normalScale: new THREE.Vector2(.58, .58), side: THREE.FrontSide }));
  material.onBeforeCompile = shader => {
    shader.vertexShader = `attribute float alpineSnow;
      varying float vAlpineSnow;
      varying vec3 vAlpinePosition;
      varying vec3 vAlpineNormal;
    ` + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      vAlpineSnow = alpineSnow;
      vAlpinePosition = (modelMatrix * vec4(position, 1.0)).xyz;
      vAlpineNormal = normalize(mat3(modelMatrix) * normal);
    `);
    shader.fragmentShader = `varying float vAlpineSnow;
      varying vec3 vAlpinePosition;
      varying vec3 vAlpineNormal;
      float alpineHash(vec2 p) { return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
      float alpineNoise(vec2 p) {
        vec2 cell=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
        return mix(mix(alpineHash(cell),alpineHash(cell+vec2(1,0)),f.x),mix(alpineHash(cell+vec2(0,1)),alpineHash(cell+vec2(1,1)),f.x),f.y);
      }
      vec4 alpineTriplanar(sampler2D tex, vec3 p, vec3 weights) {
        return texture2D(tex,p.zy)*weights.x + texture2D(tex,p.xz)*weights.y + texture2D(tex,p.xy)*weights.z;
      }
    ` + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>', `
      vec3 alpineWeights = pow(abs(normalize(vAlpineNormal)), vec3(4.0));
      alpineWeights /= max(dot(alpineWeights,vec3(1.0)),0.0001);
      vec3 alpineUv = vAlpinePosition * .079;
      vec4 alpineRock = alpineTriplanar(map,alpineUv,alpineWeights);
      vec4 alpineMacro = alpineTriplanar(map,alpineUv*.183+vec3(7.1),alpineWeights);
      diffuseColor *= mix(alpineRock,alpineMacro,.27);
      float alpineSnowMask = smoothstep(.25,.69,vAlpineSnow+(alpineNoise(vAlpinePosition.xz*.19)-.5)*.17);
    `);
    shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
      float alpineStrata = .925 + .075*sin(vAlpinePosition.y*.51+vAlpinePosition.x*.016-vAlpinePosition.z*.023);
      diffuseColor.rgb *= alpineStrata;
      diffuseColor.rgb = mix(diffuseColor.rgb,vec3(.65,.73,.76),alpineSnowMask);
    `);
    shader.fragmentShader = shader.fragmentShader.replace('#include <roughnessmap_fragment>', `
      float roughnessFactor = roughness * alpineTriplanar(roughnessMap,alpineUv,alpineWeights).g;
      roughnessFactor = mix(max(.76,roughnessFactor),.97,alpineSnowMask);
    `);
    shader.fragmentShader = shader.fragmentShader.replace('#include <normal_fragment_maps>', `
      vec3 alpineNx=texture2D(normalMap,alpineUv.zy).xyz*2.0-1.0;
      vec3 alpineNy=texture2D(normalMap,alpineUv.xz).xyz*2.0-1.0;
      vec3 alpineNz=texture2D(normalMap,alpineUv.xy).xyz*2.0-1.0;
      vec3 alpineWorldNormal=inverseTransformDirection(normal,viewMatrix);
      vec3 alpineDetail=vec3(0,alpineNx.y,alpineNx.x)*alpineWeights.x
        +vec3(alpineNy.x,0,alpineNy.y)*alpineWeights.y
        +vec3(alpineNz.x,alpineNz.y,0)*alpineWeights.z;
      alpineDetail-=alpineWorldNormal*dot(alpineWorldNormal,alpineDetail);
      alpineWorldNormal=normalize(alpineWorldNormal+alpineDetail*.58*(1.0-alpineSnowMask*.86));
      normal=normalize((viewMatrix*vec4(alpineWorldNormal,0.0)).xyz);
    `);
    // Clear upper air leaves crags readable while mist stays in the lower valley.
    shader.fragmentShader = shader.fragmentShader.replace('#include <fog_fragment>', `
      #ifdef USE_FOG
        #ifdef FOG_EXP2
          float alpineAir=mix(.62,.48,smoothstep(100.0,360.0,vAlpinePosition.y));
          float fogFactor=1.0-exp(-fogDensity*fogDensity*vFogDepth*vFogDepth*alpineAir*alpineAir);
        #else
          float fogFactor=smoothstep(fogNear,fogFar,vFogDepth);
        #endif
        gl_FragColor.rgb=mix(gl_FragColor.rgb,fogColor,fogFactor);
      #endif
    `);
  };
  material.customProgramCacheKey = () => 'alpine-rock-snow-triplanar-v2';
  return material;
}

function createDistantPineGeometry() {
  const positions = [], colors = [], indices = [];
  const segments = 6;
  // A narrow, staggered evergreen silhouette: the irregular ring edges form
  // boughs at this distance without alpha cards or large overdraw costs.
  const rings = [[0,.14],[2.1,.23],[2.7,1.50],[4.1,.76],[4.35,1.14],[6,.48],[6.2,.70],[8,.04]];
  for (let ring = 0; ring < rings.length; ring++) for (let i = 0; i < segments; i++) {
    const a = i / segments * TAU + (ring % 2) * .11;
    const [height, radius] = rings[ring], irregular = .83 + hash(i + 8, ring + 3) * .34;
    positions.push(Math.cos(a)*radius*irregular,height+(ring>1?Math.sin(a*2.0+ring)*.13:0),Math.sin(a)*radius*irregular);
    const tint = ring < 2 ? new THREE.Color('#554c3d') : new THREE.Color('#3f5942');
    tint.multiplyScalar(.82+hash(i,ring)*.29); tint.toArray(colors,colors.length);
    if (ring < rings.length-1) { const n=ring*segments+i,next=ring*segments+(i+1)%segments;indices.push(n,n+segments,next,next,n+segments,next+segments); }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
  geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}

/** Creates scenery only. rockMaps is the {map,normalMap,roughnessMap} scan set. */
export function createAlpineBackdrop({ group, heightAt, rockMaps }) {
  const backdrop = new THREE.Group(); backdrop.name = 'Alpine ridges and forested foothills'; group.add(backdrop);
  const resources = [], own = value => { resources.push(value); return value; };
  const { nearHeight, farHeight } = makeHeightFunctions(heightAt);
  const material = createRockMaterial(rockMaps, own);
  for (const [name, height, far] of [['Weathered nearer range',nearHeight,false],['High broken skyline',farHeight,true]]) {
    const mesh = new THREE.Mesh(own(createRangeGeometry(height,far)),material);
    mesh.name=name;mesh.receiveShadow=true;backdrop.add(mesh);
  }
  const pineGeometry=own(createDistantPineGeometry());
  const pineMaterial=own(new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,emissive:'#253429',emissiveIntensity:.055}));
  const rng=seededRandom(749127),treePoints=[];
  for(let attempt=0;attempt<13000&&treePoints.length<1050;attempt++) {
    const a=rng()*TAU,start=innerRadius(a),r=start+12+rng()*194;
    const x=Math.cos(a)*r,z=Math.sin(a)*r,h=nearHeight(x,z);
    const slope=Math.hypot(nearHeight(x+2,z)-nearHeight(x-2,z),nearHeight(x,z+2)-nearHeight(x,z-2))/4;
    if(h>188||slope>1.04||noise(x*.043,z*.043)<.24)continue;
    treePoints.push({x,z,h,scale:.88+rng()*.83,angle:rng()*TAU});
  }
  const pines=own(new THREE.InstancedMesh(pineGeometry,pineMaterial,treePoints.length)),dummy=new THREE.Object3D();
  treePoints.forEach((p,i)=>{dummy.position.set(p.x,p.h-.12,p.z);dummy.rotation.set(0,p.angle,0);dummy.scale.set(p.scale,p.scale*(.88+rng()*.28),p.scale);dummy.updateMatrix();pines.setMatrixAt(i,dummy.matrix);pines.setColorAt(i,new THREE.Color().setScalar(.85+rng()*.22));});
  pines.name='Distant evergreen slopes';pines.computeBoundingSphere();backdrop.add(pines);
  return {dispose(){group.remove(backdrop);for(const resource of resources)resource.dispose();}};
}
