import * as THREE from './vendor/three.module.js';

const TAU=Math.PI*2,clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const hash=(x,y=0,s=0)=>{const n=Math.sin(x*127.1+y*311.7+s*74.7)*43758.5453;return n-Math.floor(n);};
const noise=(x,y)=>{const ix=Math.floor(x),iy=Math.floor(y),u=x-ix,v=y-iy,a=u*u*(3-2*u),b=v*v*(3-2*v);return THREE.MathUtils.lerp(THREE.MathUtils.lerp(hash(ix,iy),hash(ix+1,iy),a),THREE.MathUtils.lerp(hash(ix,iy+1),hash(ix+1,iy+1),a),b);};

/** Close-range camp models. Static pieces are merged by material and cached;
 * multiple copies of a wall or furnace share all geometry and textures. */
export function createCampVisuals({root}){
  const owned=new Set(),templates=new Map(),cache=new Map(),resourceCache=new Map();
  const clock={value:0};let disposed=false;
  const own=v=>(owned.add(v),v);
  const geo=(key,make)=>{if(!cache.has(key))cache.set(key,own(make()));return cache.get(key);};
  const mat=(name,options)=>{const m=own(new THREE.MeshStandardMaterial({roughness:.94,vertexColors:true,...options}));m.name=name;return m;};
  function scan(path,color){if(typeof document==='undefined')return null;const t=own(new THREE.TextureLoader().load(new URL(path,import.meta.url).href,loaded=>{if(disposed)loaded.dispose();},undefined,()=>{}));t.colorSpace=color?THREE.SRGBColorSpace:THREE.NoColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=4;return t;}
  function texture(width,height,fn,color=false){const bytes=new Uint8Array(width*height*4);for(let y=0;y<height;y++)for(let x=0;x<width;x++){const rgb=fn(x/width,y/height,x,y),i=(y*width+x)*4;bytes[i]=Math.round(clamp(rgb[0])*255);bytes[i+1]=Math.round(clamp(rgb[1])*255);bytes[i+2]=Math.round(clamp(rgb[2])*255);bytes[i+3]=255;}const t=own(new THREE.DataTexture(bytes,width,height,THREE.RGBAFormat));t.colorSpace=color?THREE.SRGBColorSpace:THREE.NoColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.magFilter=THREE.LinearFilter;t.minFilter=THREE.LinearMipmapLinearFilter;t.generateMipmaps=true;t.anisotropy=4;t.needsUpdate=true;return t;}
  // Fibers follow board length (V), with knots, split grain and saw/axe marks.
  const grain=(u,v)=>{const warp=noise(u*4,v*3)*.14+Math.sin(v*15)*.008;let x=u+warp;for(const [a,b] of [[.24,.31],[.73,.78]]){const dy=(v-b)*2.5,dx=(u-a)*1.2,r=Math.sqrt(dx*dx+dy*dy);x+=Math.exp(-r*18)*Math.sin(Math.atan2(dy,dx))* .09;}const lines=Math.pow(.5+.5*Math.sin(x*420+noise(u*32,v*2)*9),13);const split=Math.pow(noise(u*72,v*3),14)*1.1;return clamp(.53+noise(u*12,v*2)*.27+noise(u*110,v*260)*.08-lines*.13-split*.35);};
  const woodMap=texture(256,512,(u,v)=>{const n=grain(u,v);return[n*.91,n*.77,n*.59];},true);
  const woodBump=texture(256,512,(u,v)=>{const n=grain(u,v);return[n,n,n];});
  const barkMap=scan('./assets/foliage/pine-bark_diff.jpg',true),barkNormal=scan('./assets/foliage/pine-bark_nor_gl.jpg',false);
  const rockMap=scan('./assets/materials/rock-albedo.jpg',true),rockNormal=scan('./assets/materials/rock-normal.jpg',false),rockRough=scan('./assets/materials/rock-roughness.jpg',false);
  const hideMap=texture(128,128,(u,v)=>{const n=.7+noise(u*80,v*110)*.15+noise(u*7,v*8)*.15;return[n*.67,n*.52,n*.36];},true);
  const leafMap=texture(128,256,(u,v)=>{const edge=Math.abs(u-.5)*2,vein=Math.exp(-Math.abs(u-.5)*160),rib=Math.pow(.5+.5*Math.sin(v*85+edge*24),24),n=.69+noise(u*22,v*31)*.21;return[(.33+vein*.12+rib*.06)*n,(.35+vein*.10+rib*.035)*n,(.16+vein*.025)*n];},true);
  const wood=mat('Weathered split timber',{map:woodMap,bumpMap:woodBump,bumpScale:.023,color:0xe1d6bd});
  const paleWood=mat('Freshly exposed wood',{map:woodMap,bumpMap:woodBump,bumpScale:.014,color:0xffe7b5});
  const bark=mat('Bark covered poles',{map:barkMap,normalMap:barkNormal,normalScale:new THREE.Vector2(.5,.5),color:0x9a8c75});
  const stone=mat('Weathered fieldstone',{map:rockMap,normalMap:rockNormal,roughnessMap:rockRough,normalScale:new THREE.Vector2(.7,.7),color:0xa9aaa0,flatShading:true});
  const clay=mat('Dried earth mortar',{map:rockMap,bumpMap:woodBump,bumpScale:.017,color:0x706452});
  const cord=mat('Twisted plant cord',{map:woodMap,bumpMap:woodBump,bumpScale:.006,color:0xc1b396});
  const iron=mat('Forged iron',{normalMap:rockNormal,normalScale:new THREE.Vector2(.05,.05),color:0x687172,roughness:.59,metalness:.81});
  const dark=mat('Charred timber and soot',{map:barkMap,normalMap:barkNormal,normalScale:new THREE.Vector2(.36,.36),color:0x282421});
  const hide=mat('Cured and worn hide',{map:hideMap,bumpMap:woodBump,bumpScale:.007,color:0xf0d9b4,side:THREE.DoubleSide});
  const thatch=mat('Layered weathered palm leaves',{map:leafMap,bumpMap:leafMap,bumpScale:.013,color:0xd1c49a,side:THREE.DoubleSide});
  const ember=mat('Live embers',{map:rockMap,color:0x493022,emissive:0x9b2304,emissiveIntensity:.9});
  const flame=own(new THREE.ShaderMaterial({uniforms:{time:clock},vertexShader:`varying vec2 vUv;uniform float time;void main(){vUv=uv;vec3 p=position;p.x+=sin(uv.y*10.-time*5.+position.z*3.)*.08*uv.y*uv.y;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,fragmentShader:`varying vec2 vUv;uniform float time;float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+1.),f.x),f.y);}void main(){float y=vUv.y,t=n(vec2(vUv.x*5.,y*7.-time*3.));float x=abs(vUv.x-.5-sin(y*7.-time*4.)*.07*y);float w=.34*pow(1.-y,.77)*(t*.6+.63);float a=(1.-smoothstep(w*.65,w+.02,x))*(1.-smoothstep(.65,1.,y+(1.-t)*.17))*smoothstep(0.,.07,y);if(a<.02)discard;float heat=clamp((1.-y)*1.15-x*1.8+t*.15,0.,1.);vec3 c=mix(vec3(.8,.08,.008),vec3(1.,.52,.055),heat);c=mix(c,vec3(1.,.86,.44),smoothstep(.6,1.,heat));gl_FragColor=vec4(c,a*.82);\n#include <tonemapping_fragment>\n#include <colorspace_fragment>}`,transparent:true,side:THREE.DoubleSide,depthWrite:false}));

  function colored(g,color=0xffffff){if(g.getAttribute('color'))return g;const c=new THREE.Color(color),values=[];for(let i=0;i<g.getAttribute('position').count;i++)values.push(c.r,c.g,c.b);g.setAttribute('color',new THREE.Float32BufferAttribute(values,3));return g;}
  function boardGeometry(){const g=new THREE.BoxGeometry(1,1,1,4,4,4),p=g.attributes.position;for(let i=0;i<p.count;i++){const a=new THREE.Vector3(p.getX(i),p.getY(i),p.getZ(i));for(const k of ['x','y','z'])if(Math.abs(a[k])===.25)a[k]=Math.sign(a[k])*.474;const inner=a.clone().clampScalar(-.474,.474),d=a.clone().sub(inner);if(d.length())a.copy(inner).add(d.normalize().multiplyScalar(.026));p.setXYZ(i,a.x,a.y,a.z);}g.computeVertexNormals();return colored(g);}
  const board=geo('beveled-board',boardGeometry),unitBox=geo('unit-box',()=>colored(new THREE.BoxGeometry(1,1,1)));
  const pole=geo('irregular-bark-pole',()=>{const g=new THREE.CylinderGeometry(.91,1,1,10,5),p=g.attributes.position,uv=g.attributes.uv;for(let i=0;i<p.count;i++){const y=p.getY(i),a=Math.atan2(p.getZ(i),p.getX(i)),r=1+Math.sin(a*3+y*12)*.03+Math.sin(a*7-y*8)*.019;p.setXYZ(i,p.getX(i)*r,y,p.getZ(i)*r);uv.setXY(i,uv.getX(i),uv.getY(i)*2);}g.computeVertexNormals();return colored(g);});
  const roughStone=geo('fieldstone',()=>{const g=new THREE.IcosahedronGeometry(1,2),p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),r=.90+noise(x*4+z,y*3)*.18+Math.sin(x*8+y*7+z*5)*.035;p.setXYZ(i,x*r,y*r,z*r);}g.computeVertexNormals();return colored(g);});
  const nail=geo('forged-nail',()=>colored(new THREE.CylinderGeometry(1,.75,1,6)));
  function mesh(parent,geometry,material,p=[0,0,0],s=[1,1,1],rot=[0,0,0]){const m=new THREE.Mesh(geometry,material);m.position.set(...p);m.scale.set(...s);m.rotation.set(...rot);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
  function plank(parent,p,s,rotation=[0,0,0],material=wood){
    // Unit board is long along Y: rotate its grain with the timber, not the world.
    const g=new THREE.Group();g.position.set(...p);g.rotation.set(...(rotation.length?rotation:[0,0,0]));parent.add(g);const axis=s.indexOf(Math.max(...s));const part=mesh(g,board,material,[0,0,0],axis===0?[s[1],s[0],s[2]]:axis===2?[s[0],s[2],s[1]]:s);if(axis===0)part.rotation.z=Math.PI/2;else if(axis===2)part.rotation.x=Math.PI/2;return part;
  }
  function beam(parent,a,b,r=.065,material=bark){const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b),m=mesh(parent,pole,material,av.clone().add(bv).multiplyScalar(.5).toArray(),[r,av.distanceTo(bv),r]);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),bv.sub(av).normalize());return m;}
  function binding(parent,p,r=.085,axis='y'){
    const key=`binding-${r}`;const g=geo(key,()=>{const points=[];for(let i=0;i<=72;i++){const t=i/72,a=t*TAU*3.25;points.push(new THREE.Vector3(Math.cos(a)*r,(t-.5)*.105,Math.sin(a)*r));}return colored(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),72,.008,4,false));});
    return mesh(parent,g,cord,p,[1,1,1],axis==='x'?[0,0,Math.PI/2]:axis==='z'?[Math.PI/2,0,0]:[0,0,0]);
  }
  function rock(parent,p,s,seed=0,material=stone){return mesh(parent,roughStone,material,p,s,[Math.sin(seed*.57)*.09,seed*1.7,Math.sin(seed*.36)*.09]);}
  function pin(parent,x,y,z,front=true){return mesh(parent,nail,iron,[x,y,z],[.016,.013,.016],front?[Math.PI/2,0,0]:[0,0,0]);}
  function ropeLine(parent,a,b,r=.009){return beam(parent,a,b,r,cord);}
  function merge(parent){
    parent.updateWorldMatrix(true,true);const inverse=new THREE.Matrix4().copy(parent.matrixWorld).invert(),groups=new Map();parent.traverse(n=>{if(!n.isMesh)return;const list=groups.get(n.material)||[];list.push(n);groups.set(n.material,list);});
    const result=[];for(const [material,list] of groups){const p=[],normal=[],uv=[],color=[];for(const n of list){const g=n.geometry.index?n.geometry.toNonIndexed():n.geometry.clone();g.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inverse,n.matrixWorld));const a=g.attributes;for(let i=0;i<a.position.count;i++){p.push(a.position.getX(i),a.position.getY(i),a.position.getZ(i));normal.push(a.normal.getX(i),a.normal.getY(i),a.normal.getZ(i));uv.push(a.uv?a.uv.getX(i):0,a.uv?a.uv.getY(i):0);color.push(a.color?a.color.getX(i):1,a.color?a.color.getY(i):1,a.color?a.color.getZ(i):1);}g.dispose();}const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(normal,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('color',new THREE.Float32BufferAttribute(color,3));g.computeBoundingSphere();const m=new THREE.Mesh(g,material);m.castShadow=m.receiveShadow=true;result.push(m);}parent.clear();for(const m of result)parent.add(m);return parent;
  }
  function leafGeometry(){const p=[],uv=[],indices=[];for(let j=0;j<=8;j++){const t=j/8,w=Math.sin(Math.PI*t)*(.14+.012*Math.sin(j*9));for(const side of [-1,0,1]){p.push(w*side,t,Math.sin(t*Math.PI)*.045-Math.abs(side)*w*.27);uv.push((side+1)/2,t);}}for(let j=0;j<8;j++)for(let i=0;i<2;i++){const n=j*3+i;indices.push(n,n+3,n+1,n+1,n+3,n+4);}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return colored(g);}
  const leaf=geo('curved-palm-leaf',leafGeometry);
  function addFire(container,position=[0,.24,0],scale=1){const g=new THREE.Group();g.name='camp-fire';g.position.set(...position);g.scale.setScalar(scale);container.add(g);for(let i=0;i<5;i++){const p=mesh(g,geo('fire-sheet',()=>new THREE.PlaneGeometry(.77,1.0,1,8)),flame,[Math.sin(i*7)*.18,.48,Math.cos(i*7)*.18],[1,1-(i%2)*.23,1],[0,i*2.4,0]);p.castShadow=p.receiveShadow=false;}for(let i=0;i<9;i++)rock(g,[Math.sin(i*7)*.3,-.08,Math.cos(i*7)*.3],[.07,.045,.09],i,ember);const light=new THREE.PointLight(0xffa05a,0,11,2);light.name='camp-fire-light';light.position.set(position[0],position[1]+.65,position[2]);container.add(light);merge(g);g.traverse(n=>{if(n.isMesh)n.castShadow=false;});return g;}

  function buildTemplate(type){
    const g=new THREE.Group(),s=new THREE.Group();g.add(s);
    if(type==='foundation'||type==='floor'){
      for(let i=0;i<12;i++)plank(s,[(i-5.5)*.248,.082+hash(i)*.01,0],[.24,.165,2.99],[0,0,(hash(i,3)-.5)*.004],i%5===0?paleWood:wood);
      for(const x of [-1.25,1.25]){beam(s,[x,-.16,-1.45],[x,-.16,1.45],.115);for(const z of [-1.3,0,1.3])pin(s,x,.173,z,false);}
      for(const z of [-1.23,1.23]){plank(s,[0,-.24,z],[2.86,.23,.18]);if(type==='foundation')for(const x of [-1.26,1.26]){beam(s,[x,-.72,z],[x,-.05,z],.115);rock(s,[x,-.55,z],[.24,.22,.24],x+z);}}
    }else if(type==='wall'||type==='doorframe'||type==='door'){
      for(const x of [-1.4,1.4]){beam(s,[x,0,0],[x,2.49,0],.09);for(const y of [.35,2.28])binding(s,[x,y,0],.098);}
      for(const y of [.17,2.39])plank(s,[0,y,.052],[2.83,.15,.17]);
      const doorway=type!=='wall';
      for(let i=0;i<12;i++){const x=(i-5.5)*.241;if(doorway&&Math.abs(x)<.58)continue;plank(s,[x,1.28,.004],[.234,2.31,.095],[0,0,(hash(i)-.5)*.008],i%4===1?paleWood:wood);for(const y of [.23,2.32])pin(s,x,y,-.057);}
      if(!doorway){plank(s,[0,1.20,.10],[2.5,.09,.085],[0,0,.61]);for(const x of [-1.12,1.12])pin(s,x,1.2+x*.7,.148);}
      else {for(const x of [-.59,.59])plank(s,[x,1.15,-.002],[.105,2.28,.165]);plank(s,[0,2.28,0],[1.3,.14,.17]);
        if(type==='door'){const d=new THREE.Group();d.name='camp-door';d.position.x=-.53;g.add(d);const ds=new THREE.Group();d.add(ds);for(let i=0;i<5;i++)plank(ds,[.105+i*.21,1.1,-.025],[.202,2.18,.087],[],i===2?paleWood:wood);for(const y of [.34,1.89]){plank(ds,[.52,y,.042],[1.02,.13,.085]);for(const x of [.095,.94])pin(ds,x,y,-.074);}plank(ds,[.52,1.13,.083],[1.62,.095,.062],[0,0,1.01]);for(const y of [.32,1.94])binding(ds,[.01,y,0],.07);const handle=geo('door-loop',()=>colored(new THREE.TorusGeometry(.075,.012,5,16,Math.PI*1.6)));mesh(ds,handle,cord,[.88,1.18,-.10]);merge(ds);}
      }
    }else if(type==='palisade'){
      for(let i=0;i<10;i++){const x=(i-4.5)*.295,h=2.40+hash(i,1)*.16;beam(s,[x,-.08,0],[x,h-.22,0],.153);mesh(s,geo('palisade-point',()=>colored(new THREE.ConeGeometry(1,1,8))),paleWood,[x,h-.065,0],[.142,.40,.142],[0,hash(i)*TAU,0]);for(const y of [.65,1.7])binding(s,[x,y,0],.16);}
      for(const y of [.65,1.7])beam(s,[-1.45,y,.16],[1.45,y,.16],.07);
    }else if(type==='roof'){
      for(const z of [-1.45,0,1.45]){beam(s,[-1.6,2.43,z],[0,3.18,z],.058);beam(s,[0,3.18,z],[1.6,2.43,z],.058);beam(s,[-1.47,2.44,z],[1.47,2.44,z],.062);binding(s,[0,3.18,z],.08,'z');}
      beam(s,[0,3.18,-1.65],[0,3.18,1.65],.07);
      for(const side of [-1,1]){
        for(let row=0;row<6;row++){const x=side*(.14+row*.276),y=3.155-Math.abs(x)*.47;beam(s,[x,y-.047,-1.65],[x,y-.047,1.65],.024);
          for(let col=0;col<15;col++){const z=(col-7)*.225+(row%2)*.05,seed=row*17+col+side*71;const l=mesh(s,leaf,thatch,[x,y+.025+hash(seed)*.016,z],[1.03,.69+hash(seed,1)*.12,1.7],[0,0,0]);const lengthAxis=new THREE.Vector3(side,-.47,0).normalize(),widthAxis=new THREE.Vector3(0,0,side),normalAxis=new THREE.Vector3().crossVectors(widthAxis,lengthAxis);l.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(widthAxis,lengthAxis,normalAxis));l.rotateY((hash(seed,3)-.5)*.20);}}
      }
      for(let i=0;i<12;i++)binding(s,[0,3.20,(i-5.5)*.28],.085,'z');
    }else if(type==='campfire'){
      for(let i=0;i<13;i++){const a=i/13*TAU;rock(s,[Math.sin(a)*.60,.14,Math.cos(a)*.60],[.19,.15+hash(i)*.05,.17],i);}
      rock(s,[0,.012,0],[.60,.05,.60],0,dark);for(let i=0;i<5;i++){const a=i*2.39;beam(s,[Math.sin(a)*-.45,.09,Math.cos(a)*-.45],[Math.sin(a)*.45,.19,Math.cos(a)*.45],.073,dark);}
      addFire(g);
    }else if(type==='furnace'){
      // Mortar and individual fieldstones form a hollow firebox and chimney.
      for(let row=0;row<6;row++)for(let i=0;i<13;i++){const a=i/13*TAU+(row%2)*.23;if(row<3&&Math.cos(a)<-.82)continue;const r=.63-row*.025;rock(s,[Math.sin(a)*r,.14+row*.245,Math.cos(a)*r],[.19,.16,.17],i+row*3);}
      for(let i=0;i<8;i++){const a=Math.PI+i/7*Math.PI;rock(s,[Math.cos(a)*.30,.48-Math.sin(a)*.31,-.62],[.14,.16,.18],i+43);}
      for(let row=0;row<4;row++)for(let i=0;i<8;i++){const a=i/8*TAU;rock(s,[Math.sin(a)*.23,1.48+row*.20,.17+Math.cos(a)*.23],[.135,.135,.14],i+row);}
      rock(s,[0,.07,0],[.58,.07,.58],5,dark);rock(s,[0,.68,.4],[.45,.67,.20],4,clay);addFire(g,[0,.10,-.17],.60);
    }else if(type==='storage_chest'||type==='chest'){
      for(const z of [-.355,.355])for(let i=0;i<4;i++)plank(s,[0,.14+i*.16,z],[1.17,.15,.07]);for(const x of [-.59,.59])for(let i=0;i<4;i++)plank(s,[x,.14+i*.16,0],[.07,.15,.69]);
      for(let i=0;i<6;i++)plank(s,[(i-2.5)*.20,.073,0],[.19,.08,.72]);
      for(const x of [-.46,.46]){for(const z of [-.4,.4])plank(s,[x,.385,z],[.046,.67,.025],[],cord);plank(s,[x,.032,0],[.046,.026,.79],[],cord);}
      const lid=new THREE.Group();lid.name='camp-chest-lid';lid.position.set(0,.725,.385);g.add(lid);const ls=new THREE.Group();lid.add(ls);for(let i=0;i<6;i++){const x=(i-2.5)*.208;plank(ls,[x,.025,-.385],[.202,.077,.82],[],i===2?paleWood:wood);}for(const x of [-.46,.46]){plank(ls,[x,.069,-.385],[.045,.022,.82],[],cord);binding(ls,[x,-.003,-.02],.055,'x');}merge(ls);plank(s,[0,.59,-.415],[.12,.17,.025],[],wood);binding(s,[0,.56,-.433],.042,'z');
      for(const x of [-.625,.625])mesh(s,geo('chest-handle',()=>colored(new THREE.TorusGeometry(.10,.012,5,18,Math.PI))),cord,[x,.39,0],[1,1,1],[0,Math.PI/2,Math.PI]);
    }else if(type==='bedroll'){
      // A soft hide drapes over a leaf mattress; it is not a rigid wooden bed.
      const bed=geo('draped-fur-bedroll',()=>{const g=new THREE.PlaneGeometry(1.22,2.0,12,20);g.rotateX(-Math.PI/2);const p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i),edge=Math.min(1-Math.abs(x)/.61,1-Math.abs(z));p.setY(i,.09+Math.min(.12,edge*.42)+Math.sin(z*16+x*12)*.018+Math.sin(x*35-z*5)*.008);}g.computeVertexNormals();return colored(g);});mesh(s,bed,hide);
      const roll=geo('fur-pillow-roll',()=>{const g=new THREE.CylinderGeometry(.115,.115,1.1,14,4);g.rotateZ(Math.PI/2);return colored(g);});mesh(s,roll,hide,[0,.19,-.79]);
      for(let i=0;i<38;i++){const z=(i-18.5)*.049,x=i%2?-.62:.62;const strand=mesh(s,leaf,thatch,[x,.062,z],[.40,.25,1],[0,0,i%2?Math.PI/2:-Math.PI/2]);strand.rotateX(-.3);}
      for(const x of [-.44,.44])binding(s,[x,.19,-.79],.122,'x');
    }else if(type==='tanning_rack'||type==='drying_rack'){
      for(const x of [-.70,.70]){beam(s,[x,-.06,-.28],[x,2.08,0],.048);beam(s,[x,-.06,.45],[x,1.9,0],.038);binding(s,[x,1.9,0],.063);}
      beam(s,[-.83,1.95,0],[.83,1.95,0],.052);beam(s,[-.76,.25,0],[.76,.25,0],.038);
      if(type==='tanning_rack'){
        const h=geo('stretched-hide',()=>{const shape=new THREE.Shape();shape.moveTo(-.37,.64);shape.bezierCurveTo(-.59,.75,-.57,.42,-.48,.23);shape.bezierCurveTo(-.42,.02,-.51,-.31,-.50,-.59);shape.quadraticCurveTo(-.21,-.47,0,-.61);shape.quadraticCurveTo(.27,-.48,.50,-.58);shape.bezierCurveTo(.40,-.19,.46,.02,.49,.26);shape.bezierCurveTo(.64,.51,.52,.72,.32,.60);shape.quadraticCurveTo(0,.71,-.37,.64);const g=new THREE.ShapeGeometry(shape,12),p=g.attributes.position;for(let i=0;i<p.count;i++)p.setZ(i,Math.sin(p.getX(i)*7+p.getY(i)*5)*.021);g.computeVertexNormals();return colored(g);});mesh(s,h,hide,[0,1.1,-.045]);
        for(const side of [-1,1])for(let i=0;i<6;i++){const y=.53+i*.23;ropeLine(s,[side*.49,y,-.045],[side*.70,y+.045,0],.006);}for(const x of [-.3,0,.3])ropeLine(s,[x,1.76,-.04],[x,1.95,0],.006);
      }else for(let row=0;row<4;row++){const y=.44+row*.37;for(let i=0;i<8;i++)beam(s,[-.7,y,(i-3.5)*.082],[.7,y,(i-3.5)*.082],.016);for(const x of [-.68,.68])beam(s,[x,y,-.34],[x,y,.34],.029);}
    }else if(type==='fish_trap'){
      const r=.39;for(let i=0;i<26;i++){const a=i/26*TAU;const points=[];for(let j=0;j<=8;j++){const t=j/8,rr=r*(.88+Math.sin(t*Math.PI)*.12);points.push(new THREE.Vector3(Math.cos(a)*rr,.045+t*.67,Math.sin(a)*rr));}const tube=geo(`trap-rib-${i}`,()=>colored(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),10,.009,4)));mesh(s,tube,wood);}
      for(let row=0;row<11;row++){const t=row/10,rr=r*(.88+Math.sin(t*Math.PI)*.12);const ring=geo(`trap-weave-${row}`,()=>colored(new THREE.TorusGeometry(rr,.008,4,28)));mesh(s,ring,cord,[0,.045+t*.67,0],[1,1,1],[Math.PI/2,0,0]);}
      for(let i=0;i<20;i++){const a=i/20*TAU;beam(s,[Math.cos(a)*r*.87,.70,Math.sin(a)*r*.87],[Math.cos(a)*.09,.37,Math.sin(a)*.09],.007,wood);beam(s,[Math.cos(a)*r*.86,.045,Math.sin(a)*r*.86],[0,.045,0],.008,wood);}
    }else if(type==='anvil'){
      for(let i=0;i<6;i++){const a=i/6*TAU;rock(s,[Math.sin(a)*.24,.17,Math.cos(a)*.24],[.30,.24,.31],i);}plank(s,[0,.50,0],[.55,.24,.49],[],paleWood);
      for(const x of [-.16,.16])plank(s,[x,.66,0],[.12,.18,.36],[],iron);plank(s,[0,.79,0],[.84,.18,.33],[],iron);plank(s,[0,.625,0],[.50,.08,.41],[],iron);
      const horn=geo('anvil-horn',()=>{const g=new THREE.ConeGeometry(.165,.40,12,1);g.rotateZ(-Math.PI/2);g.scale(1,.55,1);return colored(g);});mesh(s,horn,iron,[.58,.785,0]);for(const x of [-.20,.20])for(const z of [-.19,.19])pin(s,x,.56,z,false);
    }else{
      for(let i=0;i<4;i++)plank(s,[0,.96,(i-1.5)*.215],[1.80,.15,.205],[],i===1?paleWood:wood);
      for(const x of [-.69,.69])for(const z of [-.30,.30]){beam(s,[x*.94,-.01,z*1.16],[x,.94,z],.076);binding(s,[x,.79,z],.081);}
      for(const x of [-.69,.69]){plank(s,[x,.78,0],[.14,.15,.85]);beam(s,[x,.19,-.31],[x,.19,.31],.037);}
      beam(s,[-.70,.27,0],[.70,.27,0],.037);plank(s,[0,.30,.15],[1.40,.08,.25]);
      // Worn chopping block, bound maul, chips and a cord coil on the bench.
      mesh(s,geo('chopping-block',()=>colored(new THREE.CylinderGeometry(.25,.27,.07,12))),paleWood,[.46,1.071,0]);beam(s,[-.5,1.065,-.20],[-.08,1.065,.13],.025,paleWood);rock(s,[-.1,1.105,.13],[.10,.065,.085],4);binding(s,[-.12,1.078,.105],.035,'x');
      for(let i=0;i<4;i++)plank(s,[-.20+hash(i)*.4,1.052,-.27+hash(i,2)*.2],[.055,.009,.12],[0,hash(i,1)*TAU,0],paleWood);
    }
    merge(s);return g;
  }

  function createBuilding(b,preview=false){
    if(typeof preview==='object')preview=!!preview.preview;
    if(!templates.has(b.type))templates.set(b.type,buildTemplate(b.type));
    const g=templates.get(b.type).clone(true);g.name=`Handcrafted ${b.type}`;g.position.set(b.x,b.y,b.z);g.rotation.y=b.rotation;
    g.userData.door=g.getObjectByName('camp-door')||undefined;if(g.userData.door)g.userData.door.rotation.y=b.open?Math.PI/2:0;
    g.userData.lid=g.getObjectByName('camp-chest-lid')||undefined;
    g.userData.fire=g.getObjectByName('camp-fire')||undefined;g.userData.light=g.getObjectByName('camp-fire-light')||undefined;
    if(g.userData.fire)g.userData.fire.visible=b.fuel>0;
    if(preview){const m=new THREE.MeshBasicMaterial({color:0x98b99c,transparent:true,opacity:.35,depthWrite:false,side:THREE.DoubleSide});g.traverse(n=>{if(n.isMesh)n.material=m;if(n.isLight)n.visible=false;});g.userData.previewMaterial=m;}
    root.add(g);return g;
  }

  // All pickup pieces share one material per item and merge into one instanced
  // draw call. Mineral seams are small inclusions in a rock matrix, not crystals
  // floating above the ground or uniformly colored glowing boulders.
  function resourceVisual(id){
    if(['fiber','leaf','berries','herb'].includes(id))return null;
    if(resourceCache.has(id))return resourceCache.get(id);
    const g=new THREE.Group();let material;
    const oreColors={coal:0x272b2d,copper_ore:0x8b6c48,tin_ore:0xaaa99a,iron_ore:0x6d4735,gold_ore:0xb7a465,cave_ore:0x647c7d,obsidian:0x262a2e,frost_crystal:0x9bafb0};
    const colorize=(source,color)=>{const result=source.clone();result.deleteAttribute('color');colored(result,color);return own(result);};
    if(Object.hasOwn(oreColors,id)||['stone','flint'].includes(id)){
      material=mat(`Natural ${id} rock`,{map:rockMap,normalMap:rockNormal,roughnessMap:rockRough,normalScale:new THREE.Vector2(.72,.72),roughness:id==='obsidian'?.33:.91,metalness:id==='gold_ore'?.26:0,color:0xcacbc0,flatShading:true});
      const base=geo(`resource-rock-${id}`,()=>{const source=new THREE.IcosahedronGeometry(1,2),p=source.attributes.position,c=[];for(let i=0;i<p.count;i++){let x=p.getX(i),y=p.getY(i),z=p.getZ(i);const n=.86+noise(x*5+z*2,y*4)*.24;x*=n;y*=n;z*=n;p.setXYZ(i,x,y*.70,z*.81);let tone=.58+noise(x*3,y*3+z)*.30;if(id==='coal')tone*=.55;if(id==='flint')tone*=.58;const co=new THREE.Color(id==='obsidian'?0x394143:0xc1bbb0).multiplyScalar(tone);c.push(co.r,co.g,co.b);}source.setAttribute('color',new THREE.Float32BufferAttribute(c,3));source.computeVertexNormals();return source;});mesh(g,base,material);
      for(let i=0;i<3;i++)mesh(g,base,material,[Math.sin(i*7)*.70,-.38,Math.cos(i*7)*.60],[.32,.35,.31],[i*.3,i*2.1,0]);
      if(Object.hasOwn(oreColors,id)){
        // Surface fragments follow actual matrix triangles so every vein is
        // attached; narrower dark fractures make the ore readable close up.
        const p=base.attributes.position,ns=base.attributes.normal,positions=[],normals=[],uv=[],colors=[];const color=new THREE.Color(oreColors[id]);
        for(let i=0;i<p.count;i+=3){const av=new THREE.Vector3().fromBufferAttribute(p,i),bv=new THREE.Vector3().fromBufferAttribute(p,i+1),cv=new THREE.Vector3().fromBufferAttribute(p,i+2),center=av.clone().add(bv).add(cv).multiplyScalar(1/3);if(center.y<-.2)continue;const seam=Math.sin(center.x*6+center.z*4+Math.sin(center.y*5)*1.5);if(Math.abs(seam)>.48&&hash(i,3)>.08)continue;const vertices=[av,bv,cv];const shrink=.22+hash(i,1)*.44;for(let j=0;j<3;j++){const normal=new THREE.Vector3().fromBufferAttribute(ns,i+j),v=vertices[j].clone().sub(center).multiplyScalar(shrink).add(center).addScaledVector(normal,.017);positions.push(v.x,v.y,v.z);normals.push(normal.x,normal.y,normal.z);uv.push(v.x*.5+.5,v.z*.5+.5);const tone=.76+hash(i,j)*.24;colors.push(color.r*tone,color.g*tone,color.b*tone);}}
        const seamGeo=own(new THREE.BufferGeometry());seamGeo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));seamGeo.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));seamGeo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));seamGeo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));mesh(g,seamGeo,material);
        if(id==='frost_crystal'||id==='cave_ore')for(let i=0;i<5;i++){const crystal=geo('small-mineral-prism',()=>{const g=new THREE.CylinderGeometry(.105,.13,.36,6,1);return colored(g);});mesh(g,colorize(crystal,oreColors[id]),material,[(hash(i,2)-.5)*.70,.42,(hash(i,4)-.5)*.5],[1,.7+hash(i),1],[.2,hash(i)*TAU,(hash(i,3)-.5)*.5]);}
      }
    }else if(id==='branch'){
      material=mat('Fallen branch bark',{map:barkMap,normalMap:barkNormal,normalScale:new THREE.Vector2(.5,.5),color:0x958671});beam(g,[0,-.49,0],[.045,.51,.025],.053,material);beam(g,[.026,.16,.005],[.24,.42,.03],.023,material);beam(g,[.014,-.13,0],[-.17,.08,.075],.017,material);
    }else if(id==='mushroom'){
      material=mat('Mushroom skin',{map:hideMap,bumpMap:woodBump,bumpScale:.004,color:0xe0d4b7});
      const cap=geo('mushroom-cap',()=>{const g=new THREE.SphereGeometry(1,16,8,0,TAU,0,Math.PI*.55);g.scale(1,.34,1);return colored(g,0xc7ae89);});const stem=colorize(pole,0xe5d8bd);
      for(let i=0;i<4;i++){const a=i*2.4,r=i===0?0:.48,h=.54+hash(i)*.22;mesh(g,stem,material,[Math.sin(a)*r,h*.35-.37,Math.cos(a)*r],[.065,h*.7,.065],[.07,0,(hash(i)-.5)*.18]);mesh(g,cap,material,[Math.sin(a)*r,h*.7-.34,Math.cos(a)*r],[.31+.09*hash(i),1,.30]);}
    }else if(id==='shell'){
      material=mat('Weathered shell',{map:rockMap,normalMap:rockNormal,normalScale:new THREE.Vector2(.15,.15),color:0xd7c9a9,roughness:.72});
      const shell=geo('scalloped-shell',()=>{const p=[],uv=[],ix=[];for(let row=0;row<=12;row++)for(let col=0;col<=18;col++){const t=row/12,a=(col/18-.5)*Math.PI*1.35,r=t*(.83+.04*Math.cos(col*2.5)),x=Math.sin(a)*r,z=Math.cos(a)*r;p.push(x,-.37+Math.sin(t*Math.PI)*.16+.045*Math.cos(col*2.5)*t,z-.2);uv.push(col/18,t);}for(let row=0;row<12;row++)for(let col=0;col<18;col++){const i=row*19+col;ix.push(i,i+19,i+1,i+1,i+19,i+20);}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();return colored(g);});material.side=THREE.DoubleSide;mesh(g,shell,material);
    }else if(id==='vine'){
      material=mat('Coiled fallen vine',{map:barkMap,color:0x6e7254});for(let j=0;j<3;j++){const coil=geo(`fallen-vine-${j}`,()=>{const points=[];for(let i=0;i<=45;i++){const t=i/45,a=t*TAU*1.23,r=.45+t*.15;points.push(new THREE.Vector3(Math.cos(a)*r,-.44+j*.06+Math.sin(a*3)*.05,Math.sin(a)*r));}return colored(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),45,.025,5));});mesh(g,coil,material);}
    }else if(id==='roots'){
      material=mat('Earth coated roots',{map:rockMap,bumpMap:woodBump,bumpScale:.025,color:0x87745b});for(let i=0;i<4;i++){const a=i*2.4;mesh(g,pole,material,[Math.sin(a)*.33,-.34,Math.cos(a)*.32],[.085,.85,.10],[1.35,a,.2]);}
    }else if(id==='nuts'){
      material=mat('Wild nuts',{map:woodMap,bumpMap:woodBump,bumpScale:.018,color:0x99764d});for(let i=0;i<7;i++)mesh(g,roughStone,material,[Math.sin(i*7)*.44,-.40,Math.cos(i*7)*.40],[.15,.17,.13],[i,0,0]);
    }else if(['clay','sand','salt','resin'].includes(id)){
      const color={clay:0x8e7155,sand:0xbbb19a,salt:0xc9c4b5,resin:0x957149}[id];material=mat(`Natural ${id}`,{map:rockMap,normalMap:rockNormal,normalScale:new THREE.Vector2(.22,.22),color,roughness:id==='resin'?.46:.98});for(let i=0;i<5;i++)mesh(g,roughStone,material,[Math.sin(i*7)*.43,-.38+hash(i)*.05,Math.cos(i*7)*.36],[.4,.12+hash(i)*.08,.35],[i,.4,0]);
    }else return null;
    merge(g);const view=g.children[0];if(id!=='branch'){view.geometry.computeBoundingBox();view.geometry.translate(0,-.60-view.geometry.boundingBox.min.y,0);view.geometry.computeBoundingSphere();}const result={geometry:view.geometry,material:view.material};resourceCache.set(id,result);return result;
  }
  function updateBuilding(b,timeSeconds){clock.value=timeSeconds;const view=b.view||b;if(view.userData.fire){view.userData.fire.visible=b.fuel>0;const scale=b.type==='furnace'?.60:1;view.userData.fire.scale.y=scale*(.94+Math.sin(timeSeconds*9.3)*.055);if(view.userData.light)view.userData.light.intensity=b.fuel>0?(b.type==='furnace'?1.1:2.2)+Math.sin(timeSeconds*17.1)*.25:0;}if(view.userData.door)view.userData.door.rotation.y=b.open?Math.PI/2:0;}
  function dispose(){if(disposed)return;disposed=true;for(const resource of owned)resource.dispose?.();owned.clear();cache.clear();templates.clear();resourceCache.clear();}
  return {createBuilding,resourceVisual,updateBuilding,dispose};
}
