import * as THREE from './vendor/three.module.js';
import { createWorld, heightAt, riverX, surfaceAt, landmarks, spawn, WORLD_SIZE, WATER_LEVEL } from './world.js';
import { createMap } from './map.js';
import { createCrashSequence, CRASH_TIMING } from './crash.js';
import { createSoundscape } from './audio.js';
import { HDRLoader } from './vendor/HDRLoader.js';
import { createJourneyStore, SAVE_KEY, DEATH_KEY } from './journey-store.js';
import { forestBlendAt, stormBlendAt, glowBlendAt, isGlowSafeAt, biomeAt, FOREST_PREVIEW_SPAWN, STORM_PREVIEW_SPAWN, GLOW_PREVIEW_SPAWN, STORM_CENTER, GLOW_CENTER } from './biomes.js';
import {createWorldShadows} from './world-shadows.js';
import { createTeethpeedEncounters } from './teethpeed-encounters.js';
import { createTeethpeedModel } from './teethpeed-model.js';
import { createBurrowpeedModel } from './burrowpeed-model.js';
import { createDeatheaterEncounters } from './deatheater-encounters.js';
import { createDeatheaterModel } from './deatheater-model.js';
import { createStormWeather } from './storm-weather.js';
import { SWIM_DEPTH, getWaterState, canTraverseGround, stepPlayerVertical, getPlayerLocomotion } from './player-motion.js';
import { createTripRisk, getTripChasers } from './trip-risk.js';
import { createTripCutscene } from './trip-cutscene.js';
import { createPhase3 } from './phase3-runtime.js';
import { hasTeethpeedLineOfSight } from './teethpeed-senses.js';
import {ITEMS} from './survival-catalog.js';
import {createCharacterEditor} from './character-editor.js';
import {normalizeCharacterProfile} from './character-profile.js';
import {isInsideCave,caveWalkableAt,CAVE_BOUNDS,CAVE_ZONES,CAVE_SEGMENTS,MAZE_REWARD_POSITION} from './cave-maze.js';
import {rareOreAt} from './cave-progression.js';
import {createMultiplayerClient,readMultiplayerSession} from '../multiplayer/client.js';
import {createCoopPhase3} from './coop-phase3.js';
import {createCoopPresence} from './coop-presence.js';

const $ = id => document.getElementById(id);
const PREF_KEY = 'scars-of-the-wild.world.preferences.v1';
const coopMode=false;
let coopClient=null,coopSnapshot=null,coopPresence=null,coopCreatures=null,coopConnected=false,coopMoveTime=0,coopMovePending=false,coopBar=null;
let coopEventId=null,coopNeedsPositionSync=true;
// Explicit QA routes let visible checks run without touching the player's save.
const checkMode=new URLSearchParams(location.search).get('check');
const fallCheck=checkMode==='fatal-fall';
const teethpeedCheck=checkMode==='teethpeed';
const stormCheck=checkMode==='storm';
const foliageCheck=checkMode==='foliage';
const crashCheck=checkMode==='crash';
const swimmingCheck=checkMode==='swimming';
const tripCheck=checkMode==='trip';
const ecologyCheck=checkMode==='ecology';
const biomesCheck=checkMode==='biomes';
const burrowpeedCheck=checkMode==='burrowpeed';
let biomeCreaturesPaused=false;
const phase3Check=checkMode==='phase3'||ecologyCheck||biomesCheck||burrowpeedCheck;
const characterCheck=checkMode==='character';
const isolatedCheck=characterCheck||phase3Check||fallCheck||checkMode==='landscape'||teethpeedCheck||stormCheck||foliageCheck||crashCheck||swimmingCheck||tripCheck;
const savePrefix=burrowpeedCheck?'scars-of-the-wild.burrowpeed-check.':biomesCheck?(new URLSearchParams(location.search).get('qa')==='agent'?'scars-of-the-wild.biomes-agent-check.':'scars-of-the-wild.biomes-check.'):ecologyCheck?'scars-of-the-wild.ecology-check.':characterCheck?'scars-of-the-wild.character-check.':phase3Check?(new URLSearchParams(location.search).get('qa')==='agent'?'scars-of-the-wild.phase3-agent-check.':'scars-of-the-wild.phase3-check.'):tripCheck?'scars-of-the-wild.trip-check.':swimmingCheck?'scars-of-the-wild.swimming-check.':crashCheck?'scars-of-the-wild.crash-check.':foliageCheck?'scars-of-the-wild.foliage-check.':stormCheck?'scars-of-the-wild.storm-check.':teethpeedCheck?'scars-of-the-wild.teethpeed-check.':isolatedCheck?'scars-of-the-wild.check.':'';
const journeyStore = createJourneyStore({
  getItem:key=>localStorage.getItem(savePrefix+key),
  setItem:(key,value)=>localStorage.setItem(savePrefix+key,value),
  removeItem:key=>localStorage.removeItem(savePrefix+key)
});
if(isolatedCheck) {
  const badge=document.createElement('div');badge.textContent=`ISOLATED ${tripCheck?'TRIP':swimmingCheck?'SWIMMING':crashCheck?'CRASH':fallCheck?'FALL':teethpeedCheck?'TEETHPEED':stormCheck?'STORM':foliageCheck?'FOLIAGE':'WORLD'} TEST · Your journey save is untouched`;
  badge.style.cssText='position:fixed;top:0;left:50%;transform:translateX(-50%);z-index:1000;padding:6px 15px;background:#6b2924;color:white;font:11px Segoe UI,sans-serif;pointer-events:none';
  document.body.append(badge);
}
const canvas = $('world-canvas');
const keys = new Set();
let mode = 'loading', renderer, scene, camera, world, chart, crash, directionalSun, worldShadows;
let waypoint = null, footY = 0, verticalSpeed = 0, stamina = 100, grounded = true;
let swimming=false,lastSwimStroke=0,swimTime=0,swimPreviewRoute=null,swimPreviewCrossing=false,swimPreviewStatus=null,swimCrossButton=null,swimPreviewStages=[];
let dragLook = false, lastMouse = null, pointerSupported = true, lastTime = 0;
let elapsed = 0, hudTime = 0, saveTime = 0, notificationTimer, storageWorks = true;
let lastBoundaryNote = -100, lastRegion = '';
let sensitivity = 1, motionEffects = !matchMedia('(prefers-reduced-motion: reduce)').matches;
let discovered = new Set();
const player = {x:spawn.x,z:spawn.z,yaw:spawn.yaw,pitch:-.035};
const collisionGrid = new Map();
const cellSize = 16;
const eyeHeight = 1.72;
let stepDistance = 0, lastStep = 0, visibleMovement = false;
let journeyStarted=false;
let continuing = false;
let journey = null, health = 100, survivedSeconds = 0, continuationUnavailable = false;
let restoredMotion=null;
let runPersisted=false;
let soundEnabled=false,soundVolume=.35;
let encounters=null, encounterViews=new Map(), creatureTime=0, encounterPreviewTree=null;
let phase3=null,phase3InventorySection='inventory';
let characterProfile=normalizeCharacterProfile(),characterEditor=null;
let locomotionVisual={sprinting:false,speed:0};
let caveTestRoute=null;
const phase3Direction=new THREE.Vector3();
let tripRisk=null,tripCutscene=null,tripDeath=null,tripPreviewStatus=null,tripPreviewSlow=false;
const tripEvents=[];
let previewStatus=null, previewButton=null, previewSenseStatus=null, damageFlashTime=0;
let encounterFrozen=foliageCheck||teethpeedCheck||tripCheck;
let teethpeedSurfaceTexture=null;
let prewarmedBurrowpeedView=null;
let teethpeedSpecimen=null,teethpeedInspection=null,teethpeedSpecimenTime=0,teethpeedSpecimenPaused=false,teethpeedFreezeButton=null;
let teethpeedLandingTrack=false,teethpeedLandingSlow=false;
const teethpeedLandingFrames=[];
let deatheater=null,deatheaterView=null,stormWeather=null,stormStatus=null,stormTrigger=null,stormFrozen=foliageCheck||tripCheck,stormTrack=false;
let deatheaterTime=0,stormInspect=false,stormInspectionPose='mouth';
let foliageWindFrozen=false,foliageWindTime=0,foliageStatus=null,foliageCameraOverride=null;
let previewFrames=0,previewFrameTime=0,previewRenderTime=0;
let teethpeedAudioSources=[],audioPreviewStatus=null,audioPreviewButton=null,audioMeterTime=0;
const crashEvents=[];
const audioDirection=new THREE.Vector3();
const valleyFog=new THREE.Color('#9eaeb1'), forestFog=new THREE.Color('#506555'), stormFog=new THREE.Color('#393442'),glowFog=new THREE.Color('#365c60'),lightningFog=new THREE.Color('#8c55be');
try {
  const introPrefs=JSON.parse(localStorage.getItem('scars-of-the-wild.intro.preferences.v1')||'null');
  soundEnabled=introPrefs?.ambient===true;
  if(Number.isFinite(introPrefs?.volume))soundVolume=THREE.MathUtils.clamp(introPrefs.volume/100,0,1);
} catch {}
const sound=createSoundscape({enabled:soundEnabled,volume:soundVolume,onUnavailable:()=>{
  soundEnabled=false;$('world-sound').checked=false;notify('Sound is unavailable in this browser.');
}});
$('world-sound').checked=soundEnabled;
$('startup-sound').checked=soundEnabled;
function changeSoundPreference(event) {
  soundEnabled=event.target.checked;sound.setEnabled(soundEnabled);
  $('world-sound').checked=soundEnabled;$('startup-sound').checked=soundEnabled;
  if(audioPreviewButton)audioPreviewButton.textContent=soundEnabled?'Mute preview sound':'Enable preview sound';
  if(isolatedCheck)return;
  try {
    const pref=JSON.parse(localStorage.getItem('scars-of-the-wild.intro.preferences.v1')||'{}');
    localStorage.setItem('scars-of-the-wild.intro.preferences.v1',JSON.stringify({...pref,ambient:soundEnabled}));
  } catch {}
}
$('world-sound').addEventListener('change',changeSoundPreference);
$('startup-sound').addEventListener('change',changeSoundPreference);

function notify(message) {
  clearTimeout(notificationTimer);
  $('notification').textContent = message;
  $('notification').hidden = false;
  notificationTimer = setTimeout(() => { $('notification').hidden = true; }, 4200);
}

function loadSavedWorld() {
  if(coopMode)return;
  if (!new URLSearchParams(location.search).has('continue')) return;
  try {
    const saved = journeyStore.read();
    if (!saved) { continuationUnavailable = true; return; }
    const p = saved.player;
    if (![p.x,p.z,p.yaw,p.pitch].every(Number.isFinite) || Math.abs(p.x)>WORLD_SIZE/2-12 || Math.abs(p.z)>WORLD_SIZE/2-12) return;
    Object.assign(player,{x:p.x,z:p.z,yaw:p.yaw,pitch:THREE.MathUtils.clamp(p.pitch,-1.25,1.25)});
    discovered = new Set((Array.isArray(saved.discovered)?saved.discovered:[]).filter(id=>landmarks.some(l=>l.id===id)));
    if (saved.waypoint && [saved.waypoint.x,saved.waypoint.z].every(Number.isFinite) && Math.abs(saved.waypoint.x)<=WORLD_SIZE/2 && Math.abs(saved.waypoint.z)<=WORLD_SIZE/2) waypoint=saved.waypoint;
    journey=saved;health=saved.health;survivedSeconds=saved.survivedSeconds;restoredMotion=saved.motion||null;runPersisted=true;
    characterProfile=normalizeCharacterProfile(saved.character);
    continuing = true;
  } catch { storageWorks=false; }
}

function correctCoopPosition(snapshot=coopSnapshot){
  const position=snapshot?.self?.position||snapshot?.players?.find(p=>p.id===snapshot.selfId)?.position;
  if(!world||!phase3||!position||![position.x,position.y,position.z].every(Number.isFinite))return false;
  player.x=position.x;player.z=position.z;footY=position.y;verticalSpeed=0;
  const floor=phase3.groundHeight(player.x,player.z),water=getWaterState({floor,footY,waterLevel:WATER_LEVEL});
  swimming=water.swimming;grounded=!swimming&&footY<=floor+.15;visibleMovement=false;locomotionVisual={sprinting:false,speed:0};
  camera.position.set(player.x,footY+eyeHeight,player.z);document.body.classList.toggle('swimming',swimming);
  return true;
}
function receiveCoopStatus(status){
  coopConnected=status.state==='connected';
  // EventSource emits "connected" for every snapshot. Only an interruption
  // requires the next authoritative pose to replace local prediction.
  if(!coopConnected)coopNeedsPositionSync=true;
  if(!coopConnected||!journeyStarted){if(coopBar)coopBar.textContent=status.message;}
  if(!coopConnected)$('save-status').textContent='Co-op disconnected · waiting to reconnect';
}
async function sendCoopFrame(frame){
  if(coopNeedsPositionSync)throw new Error('Waiting for your position from the co-op server.');
  try{
    const response=await coopClient.move(frame),snapshot=response.snapshot,position=snapshot?.self?.position;
    // Compare the acknowledgement with the submitted pose, not the player's
    // newer predicted pose, so normal network latency never snaps movement.
    if(position&&(!coopSnapshot||snapshot.serverTime>=coopSnapshot.serverTime)&&Math.hypot(position.x-frame.position.x,position.y-frame.position.y,position.z-frame.position.z)>.05)correctCoopPosition(snapshot);
    return response;
  }catch(error){
    if(['blocked_movement','movement_too_fast','position','invalid_position'].includes(error.code)){
      correctCoopPosition(coopClient.snapshot()||coopSnapshot);keys.clear();coopNeedsPositionSync=true;
    }
    throw error;
  }
}
function receiveCoopSnapshot(snapshot){
  coopSnapshot=snapshot;if(!world||!phase3)return;
  const self=snapshot.players.find(p=>p.id===snapshot.selfId);if(!self)return;
  health=snapshot.self.health;survivedSeconds=snapshot.self.survivedSeconds||0;
  phase3.applySnapshot(snapshot);coopCreatures?.applySnapshot(snapshot.world?.creatures);coopPresence?.applySnapshot(snapshot);
  if(coopNeedsPositionSync||self.position&&Math.hypot(self.position.x-player.x,self.position.z-player.z)>4.5){if(correctCoopPosition(snapshot))coopNeedsPositionSync=false;}
  if(snapshot.self.alive===false&&mode!=='dead')showEndedLife(snapshot.self.deathCause||'This survivor died in the shared wilderness.');
  const creatureState=snapshot.world?.creatures;
  if(coopEventId!==null)for(const event of creatureState?.events||[]){if(event.eventId<=coopEventId||!event.position||Math.hypot(event.position.x-player.x,event.position.z-player.z)>60)continue;if(event.kind==='burrowpeed')sound.burrowEvent(event.type,event.position);else if(event.kind==='teethpeed'&&event.type==='bite')sound.creatureEvent('bite',event.position);}
  coopEventId=creatureState?.eventId??coopEventId;
  const infection=snapshot.world?.creatures?.infection;
  const savingFailed=snapshot.saveHealthy===false;
  if(coopBar)coopBar.textContent=savingFailed?'CO-OP · SERVER SAVE FAILED · Recent progress may not survive a server restart.':`CO-OP · ${snapshot.code} · ${snapshot.players.filter(p=>p.connected).length}/4 survivors${infection?` · Infection: ${infection.stage==='cleared'?'vanquished':infection.nodes.length+' spread nodes'}`:''}`;
  canvas.dataset.coop=JSON.stringify({code:snapshot.code,selfId:snapshot.selfId,players:snapshot.players.map(p=>({id:p.id,name:p.name,position:p.position,alive:p.alive,connected:p.connected,mode:p.mode})),self:snapshot.self,worldRevision:snapshot.world?.revision,remotePlayers:coopPresence?.getDiagnostics(),infection:infection?{cycle:infection.cycle,stage:infection.stage,nodes:infection.nodes.length}:null});
  $('save-status').textContent=savingFailed?'Co-op server cannot save · recent progress is at risk':'Co-op world autosaves on server';
}
function sendCoopMovement(){
  if(!coopMode||!coopClient||!world||!journeyStarted||!coopConnected||coopNeedsPositionSync||coopMovePending||health<=0)return;
  coopMovePending=true;const serverMode=mode==='playing'?'playing':mode==='character'||mode==='ready'?'character':mode==='inventory'||mode==='map'?'inventory':'paused';
  sendCoopFrame({position:{x:player.x,y:footY,z:player.z},yaw:player.yaw,pitch:player.pitch,mode:serverMode,motion:swimming?'swimming':visibleMovement?(locomotionVisual.sprinting?'running':'walking'):'idle'}).catch(error=>{if(coopBar&&coopSnapshot?.saveHealthy!==false)coopBar.textContent=error.message;}).finally(()=>{coopMovePending=false;});
}

function saveWorld(manual=false) {
  if(coopMode){const savingFailed=coopSnapshot?.saveHealthy===false;if(manual)notify(!coopConnected?'Reconnect to the co-op server to save your position.':savingFailed?'The co-op server cannot save right now. Recent progress may not survive a server restart.':'The server automatically saves your co-op inventory and world.');sendCoopMovement();return coopConnected&&!savingFailed;}
  if (!world || !journeyStarted || !journey || health<=0 || ['dead','loading','error','cinematic'].includes(mode)) return false;
  try {
    const saved=journeyStore.save(journeyData());
    if(!saved) { checkJourneyState();if(manual&&mode!=='dead')notify('This life could not be saved in this browser.');return false; }
    journey=saved;health=saved.health;survivedSeconds=saved.survivedSeconds;
    runPersisted=true;
    storageWorks=true;
    $('save-status').textContent='Journey saved locally';
    if (manual) notify('Your position and discoveries have been saved.');
    return true;
  } catch {
    storageWorks=false;
    $('save-status').textContent='Saving unavailable in this browser';
    if (manual) notify('This browser could not save your journey. You can keep exploring this visit.');
    return false;
  }
}

function journeyData() {
  return {...journey,character:{...characterProfile},player:{...player},discovered:[...discovered],waypoint,health,survivedSeconds,motion:{footY,verticalSpeed,grounded},encounters:encounters?.snapshot(),deatheater:deatheater?.snapshot(),trips:tripRisk?.snapshot(),phase3:phase3?.snapshot()||journey?.phase3};
}

function durationText(seconds) {
  const total=Math.max(0,Math.floor(seconds));
  const hours=Math.floor(total/3600),minutes=Math.floor(total/60)%60,rest=total%60;
  return `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2,'0')}:${rest.toString().padStart(2,'0')}`;
}

function beginLife() {
  if(coopMode){journey={runId:`coop-${coopSnapshot.code}`,status:'alive'};journeyStarted=true;continuing=true;health=coopSnapshot.self.health;setupPhase3();return;}
  health=100;survivedSeconds=0;
  const result=journeyStore.begin({character:{...characterProfile},player:{...player},discovered:[...discovered],waypoint,health,survivedSeconds,motion:{footY,verticalSpeed,grounded}});
  journey=result.record;journeyStarted=true;storageWorks=result.persisted;runPersisted=result.persisted;
  setupPhase3();
  if(!result.persisted) {$('save-status').textContent='This life is not saved';notify('Saving is unavailable. This life can only last for this visit.');}
}

function openSurvival(section='inventory') {
  if(!phase3||!['playing','inventory'].includes(mode))return;
  if(section===null){phase3.close();resume();return;}
  phase3InventorySection=section;setMode('inventory');phase3.open(section);saveWorld();
}
function setupPhase3(){
  phase3?.dispose();
  if(coopMode){phase3=createCoopPhase3({scene,world,client:{...coopClient,move:sendCoopFrame},initial:coopSnapshot,notify,onInventory:openSurvival,onRefreshCollision:indexColliders,creatures:coopCreatures,getMovement:()=>({position:{x:player.x,y:footY,z:player.z},yaw:player.yaw,pitch:player.pitch,mode:mode==='inventory'?'inventory':'playing',motion:swimming?'swimming':visibleMovement?(locomotionVisual.sprinting?'running':'walking'):'idle'})});indexColliders();return;}
  const prewarmedView=prewarmedBurrowpeedView;prewarmedBurrowpeedView=null;
  phase3=createPhase3({scene,camera,world,state:journey?.phase3,seed:journey?.runId||'wilderness',character:characterProfile,notify,onSave:()=>saveWorld(),onDamage:takeDamage,isPlaying:()=>mode==='playing',surfaceTexture:teethpeedSurfaceTexture,prewarmedView,
    onBurrowEvent:event=>{sound.burrowEvent(event.type,event.position);if(event.type==='emerge')notify('The teeth in the soil are moving.');},
    onHeal:amount=>{if(health>0&&mode!=='dead'&&mode!=='tripped')health=Math.min(100,health+amount);},onInventory:openSurvival,
    onRefreshCollision:()=>{saveWorld();indexColliders();setupEncounters();},
    onLegacyAttack:({origin,direction,range,damage})=>{
      const targets=[...(encounters?.getActive()||[]).map(r=>({...r,kind:'teethpeed',id:r.treeId})),...(deatheater?.getActive()||[]).map(r=>({...r,kind:'deatheater'}))];
      let closest=null;
      for(const r of targets){const target={...r.position,y:r.position.y+(r.kind==='teethpeed'?.3:0)},delta=new THREE.Vector3(target.x-origin.x,target.y-origin.y,target.z-origin.z),along=delta.dot(direction);if(along<0||along>range)continue;const off=delta.addScaledVector(direction,-along).length();if(off>(r.kind==='teethpeed'?1:1.6)||!hasTeethpeedLineOfSight({position:origin,player:target,heightAt:world.groundHeight,colliders:world.colliders,originEyeHeight:0,playerEyeHeight:0}))continue;if(!closest||along<closest.along)closest={...r,along};}
      if(!closest)return {hit:false};return closest.kind==='teethpeed'?encounters.damage(closest.id,damage):deatheater.damage(closest.id,damage);
    }});
  camera.getWorldDirection(phase3Direction);phase3.update(0,{...player,y:footY},phase3Direction,{active:false});
  indexColliders();setupEncounters();
}
function isPlayerChased(){if(isGlowSafeAt(player.x,player.z))return false;if(coopMode)return !!coopSnapshot?.self?.chased;return getTripChasers({teethpeeds:encounterFrozen?[]:encounters?.getActive(),deatheaters:stormFrozen?[]:deatheater?.getActive(),player}).length>0||!!phase3?.getChasers({...player,y:footY})?.length;}

function buildCharacterPreviewControls(){
  if(!characterCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check character-test-controls';panel.setAttribute('aria-label','Character editor test controls');
  const title=document.createElement('strong');title.textContent='CHARACTER EDITOR TEST';
  const description=document.createElement('p');description.textContent='Separate test life. Appearance is saved without changing survival progress.';panel.append(title,description);
  function button(label,action){const b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',()=>{if(!phase3||!['playing','paused'].includes(mode))return;action();});panel.append(b);}
  button('Edit character',openCharacterEditor);
  button('Save and reload appearance',()=>{if(saveWorld())location.href='./index.html?continue=1&check=character';});
  document.body.append(panel);
}
function playerContext(){return {...player,y:footY,...phase3?.getConcealment()};}

function showEndedLife(cause, persisted=true) {
  clearTimeout(notificationTimer);$('notification').hidden=true;
  $('death-cause').textContent=cause;
  $('death-survived').textContent=durationText(survivedSeconds);
  $('death-save-note').textContent=persisted?'This life has ended. There is no respawn or checkpoint reload.':'This life has ended, but the browser could not record it. Persistent saving is unavailable.';
  setMode('dead');
}

function takeDamage(amount,cause,context={}) {
  if(coopMode)return;
  if(context.creature&&isGlowSafeAt(player.x,player.z))return;
  if(!['playing','inventory'].includes(mode)||!journeyStarted||health<=0||!Number.isFinite(amount)||amount<=0)return;
  cause=typeof cause==='string'?cause:'An injury overwhelmed you.';
  if(context?.creature||/Teethpeed|Deatheater/i.test(cause)){
    const garment=phase3?.survival.getEquipment('body'),armor=garment?.item?.armor||0;
    if(garment?.durability>0&&armor>0){
      const incoming=amount;amount*=1-THREE.MathUtils.clamp(armor,0,.8);
      // Ordinary bites wear the garment before the resulting life is saved.
      // Committed fatal trips and swallowing sequences bypass this function.
      phase3.survival.damageEquipment(Math.max(1,Math.ceil(incoming*.2)),'body');
    }
  }
  health=Math.max(0,health-amount);
  if(health<=0) {
    const result=journeyStore.end(journeyData(),cause);
    journey=result.record;showEndedLife(cause,result.persisted);
  } else { saveWorld();if(amount>=1)notify(`${cause.includes('Teethpeed')?'A Teethpeed bit you.':cause.includes('Deatheater')?'The Deatheater struck you.':cause} Health: ${Math.ceil(health)}.`); }
  damageFlashTime=.4;document.body.classList.add('injured');
  updateHUD();
}

function finishFatalTrip() {
  if(mode!=='tripped'||!tripDeath)return;
  tripCutscene.finish();
  showEndedLife(tripDeath.record.cause,tripDeath.persisted);
}

function beginFatalTrip(chaser,{entry='trip'}={}) {
  if(mode!=='playing'||health<=0||!journey||!tripCutscene)return;
  const kind=chaser.kind==='deatheater'?'deatheater':'teethpeed';
  const name=kind==='teethpeed'?'Teethpeed':'Deatheater';
  const diving=kind==='deatheater'&&entry==='dive';
  const cause=diving?'The Deatheater caught you in its dive and swallowed you whole.':kind==='deatheater'?'You tripped while fleeing. The Deatheater swallowed you whole.':`You tripped while fleeing. The ${name} killed you in one strike.`;
  // A fatal attack commits before presentation, so quitting mid-scene cannot
  // restore a living save. Normal combat and input stop during the sequence.
  tripDeath=journeyStore.end(journeyData(),cause);journey=tripDeath.record;health=0;
  clearTimeout(notificationTimer);$('notification').hidden=true;
  stopSwimCrossing();keys.clear();tripEvents.length=0;teethpeedAudioSources=[];
  for(const view of encounterViews.values())view.group.visible=false;
  if(deatheaterView?.anchor)deatheaterView.anchor.visible=false;
  if(teethpeedSpecimen)teethpeedSpecimen.group.visible=false;
  $('trip-creature').textContent=name.toUpperCase();
  $('trip-caption').textContent=diving?'Its mouth closes around you.':'Your footing gives way.';
  $('trip-fade').style.opacity='0';
  setMode('tripped');updateHUD();
  try {tripCutscene.start({kind,entry:diving?'dive':'trip',player:{x:player.x,y:footY,z:player.z,yaw:player.yaw},creature:chaser});}
  catch(error){console.error('Trip cinematic could not start.',error);finishFatalTrip();}
}

function checkTripRisk() {
  if(coopMode)return;
  if(biomeCreaturesPaused)return;
  if(isGlowSafeAt(player.x,player.z))return;
  if(mode!=='playing'||!tripRisk)return;
  const chasers=getTripChasers({teethpeeds:encounterFrozen?[]:encounters?.getActive(),deatheaters:stormFrozen?[]:deatheater?.getActive(),player});
  const fatal=tripRisk.update({moving:visibleMovement,grounded,swimming,chasers});
  if(isolatedCheck)canvas.dataset.tripRisk=JSON.stringify({chasers:chasers.map(c=>({kind:c.kind,id:c.id})),resolved:tripRisk.snapshot().resolved.length,moving:visibleMovement,grounded,swimming});
  if(fatal)beginFatalTrip(fatal);
}

function buildTripPreviewControls() {
  if(!tripCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check';panel.setAttribute('aria-label','Isolated fatal trip test controls');
  const title=document.createElement('strong');title.textContent='FATAL TRIP PREVIEW';
  tripPreviewStatus=document.createElement('output');tripPreviewStatus.textContent='10% during a chase · one roll per creature encounter\nThese buttons force a fatal trip in this separate test life.';
  const slowLabel=document.createElement('label'),slow=document.createElement('input');slow.type='checkbox';slow.addEventListener('change',()=>{tripPreviewSlow=slow.checked;});slowLabel.append(slow,' Slow motion inspection');panel.append(slowLabel);
  for(const [kind,label] of [['teethpeed','Teethpeed fatal trip'],['deatheater','Deatheater fatal trip']]) {
    const button=document.createElement('button');button.textContent=label;
    button.addEventListener('click',()=>{if(mode==='playing')beginFatalTrip({kind,id:'isolated-trip-preview'});});panel.append(button);
  }
  panel.prepend(title,tripPreviewStatus);document.body.append(panel);
}

function buildPhase3PreviewControls(){
  if(!phase3Check)return;
  const panel=document.createElement('aside');panel.className='phase3-test-panel';panel.setAttribute('aria-label','Phase 3 test controls');
  const details=document.createElement('details');details.open=true;const summary=document.createElement('summary');summary.textContent='PHASE 3 · Test controls';details.append(summary);
  const copy=document.createElement('p');copy.textContent='Separate test life. Test supplies and travel shortcuts only exist here.';details.append(copy);
  const buttons=document.createElement('div');buttons.className='test-buttons';details.append(buttons);panel.append(details);document.body.append(panel);
  const button=(name,fn)=>{const b=document.createElement('button');b.textContent=name;b.onclick=()=>{if(!phase3||!['playing','inventory'].includes(mode))return;fn();};buttons.append(b);return b;};
  function travel(x,z,yaw=0){phase3.cancelBuild();if(mode==='inventory')phase3.close();let chosen=null;for(let r=0;r<=12&&!chosen;r+=2)for(let a=0;a<8;a++){const px=x+Math.sin(a*Math.PI/4)*r,pz=z+Math.cos(a*Math.PI/4)*r;if(canStand(px,pz,px,pz)&&!world.hazardAt?.(px,pz)){chosen={x:px,z:pz};break;}}if(!chosen){notify('No clear ground near that point.');return;}Object.assign(player,chosen,{yaw,pitch:-.15});footY=Math.max(phase3.groundHeight(player.x,player.z),WATER_LEVEL-SWIM_DEPTH);verticalSpeed=0;grounded=true;swimming=false;camera.position.set(player.x,footY+eyeHeight,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');resume();camera.getWorldDirection(phase3Direction);phase3.update(0,{...player,y:footY},phase3Direction,{active:true});saveWorld();}
  button('Find loose stone',()=>{const node=phase3.camp.nearby({...player,y:footY},120).find(n=>n.item==='stone'&&!n.mineable&&n.kind==='resource');if(!node){notify('No uncollected loose stones on this patch. Try dry ground.');return;}travel(node.x,node.z+1.7,0);player.pitch=Math.atan2(node.y+.2-footY-eyeHeight,1.7);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');camera.getWorldDirection(phase3Direction);phase3.update(0,{...player,y:footY},phase3Direction,{active:true});notify('Loose stone · E picks it up with empty hands.');});
  if(burrowpeedCheck){
    let testDen=null,testAngle=0;
    const approach=distance=>{if(!testDen)return;travel(testDen.denPosition.x+Math.sin(testAngle)*distance,testDen.denPosition.z+Math.cos(testAngle)*distance,testAngle);player.pitch=-.13;camera.rotation.set(player.pitch,player.yaw,0,'YXZ');};
    button('Inspect buried den from 12 metres',()=>{
      for(const den of phase3.burrowers.getDens().filter(d=>d.stage==='buried'))for(let i=0;i<16;i++){
        const a=i*Math.PI/8,p=den.denPosition;
        if(![9,12,17].every(d=>canStand(p.x+Math.sin(a)*d,p.z+Math.cos(a)*d,p.x+Math.sin(a)*d,p.z+Math.cos(a)*d)&&biomeAt(p.x+Math.sin(a)*d,p.z+Math.cos(a)*d).id===den.biome))continue;
        const eye={x:p.x+Math.sin(a)*9,z:p.z+Math.cos(a)*9};eye.y=world.groundHeight(eye.x,eye.z);
        if(!hasTeethpeedLineOfSight({position:p,player:eye,heightAt:world.groundHeight,colliders:world.colliders,originEyeHeight:.22,playerEyeHeight:1.2}))continue;
        testDen=den;testAngle=a;approach(12);notify('Outside the 10m detection radius. Only tooth tips should show.');return;
      }
    });
    button('Enter the 10 metre detection radius',()=>approach(9));
    button('Move outside the den rearm radius',()=>approach(17));
    const status=document.createElement('output');status.id='burrowpeed-test-status';details.insertBefore(status,buttons);
  }
  button('Open inventory',()=>openSurvival('inventory'));button('Open crafting',()=>openSurvival('craft'));button('Open building',()=>openSurvival('build'));
  button('Add basic test supplies',()=>{const s=phase3.survival;for(const [id,count] of Object.entries({branch:8,stone:12,flint:5,fiber:40,wood:18,resin:6,berries:6,raw_meat:2}))s.add(id,count);saveWorld();notify('Basic test supplies added within pack capacity.');});
  button('Add construction test supplies',()=>{const s=phase3.survival;for(const [id,count] of Object.entries({plank:20,rope:8,leaf:30,wood:10,resin:5}))s.add(id,count);saveWorld();notify('Construction test supplies added within pack capacity.');});
  button('Visit nearby loose supplies',()=>{const nodes=phase3.camp.nearby({...player,y:footY},120).filter(n=>n.kind==='resource');const node=nodes.find(n=>['branch','stone','fiber','flint'].includes(n.item))||nodes[0];if(node)travel(node.x,node.z+1.5,0);});
  button('Visit nearby harvestable tree',()=>{const tree=world.gatherTrees.filter(t=>!t.felled&&Math.hypot(t.x-player.x,t.z-player.z)<120).sort((a,b)=>Math.hypot(a.x-player.x,a.z-player.z)-Math.hypot(b.x-player.x,b.z-player.z))[0];if(tree)travel(tree.x,tree.z+tree.radius+1.3,0);});
  button('Interact / place (E)',()=>phase3.interact());button('Attack (F)',()=>phase3.attack());button('Rotate building (R)',()=>phase3.rotate());
  button('Cancel building preview',()=>phase3.cancelBuild());button('Step right beside camp',()=>travel(player.x+3,player.z,player.yaw));button('Step forward toward camp',()=>travel(player.x-Math.sin(player.yaw)*2,player.z-Math.cos(player.yaw)*2,player.yaw));
  button('Add hunting test gear',()=>{const s=phase3.survival;s.add('hunting_bow',1);s.add('arrow',10);s.equip('hunting_bow');saveWorld();notify('Test bow and arrows added. Aim carefully; F fires.');});
  function approachTestAnimal(fire=false){const target=phase3.wildlife.getNearbyTargets({origin:{...player,y:footY},range:90}).find(t=>!t.dead&&t.health<=35);if(!target){notify('No nearby small animal to inspect.');return;}travel(target.position.x,target.position.z+3,0);player.yaw=Math.atan2(player.x-target.position.x,player.z-target.position.z);player.pitch=Math.atan2(target.position.y+.4-footY-eyeHeight,Math.hypot(player.x-target.position.x,player.z-target.position.z));camera.rotation.set(player.pitch,player.yaw,0,'YXZ');camera.getWorldDirection(phase3Direction);phase3.update(0,{...player,y:footY},phase3Direction,{active:true});if(fire)phase3.attack();else notify(`Combat test: ${target.name}. F fires; E harvests after a kill.`);}
  button('Approach wildlife for combat test',()=>approachTestAnimal());button('Aim and fire test shot',()=>approachTestAnimal(true));
  for(const [label,x,z,yaw] of [['Valley',135,85,0],['Rainforest',-190,-25,.8],['Stormlands',STORM_CENTER.x,STORM_CENTER.z,0],['Glowhaven',GLOW_CENTER.x,GLOW_CENTER.z,-.65],['Cave entrance',-493,-60,Math.PI/2],['Inside cavern',-542,-60,Math.PI/2],['Lava shore',610,-270,0],['Ice highlands',-545,-570,0],['Beach',250,535,Math.PI],['Ocean',60,780,0]])button(`Visit ${label}`,()=>travel(x,z,yaw));
  if(biomesCheck){
    const creaturePauseButton=button('Pause creatures for scenery review',()=>{biomeCreaturesPaused=!biomeCreaturesPaused;encounterFrozen=stormFrozen=biomeCreaturesPaused;creaturePauseButton.textContent=biomeCreaturesPaused?'Resume creatures after scenery review':'Pause creatures for scenery review';notify(biomeCreaturesPaused?'Creature simulation paused for this visual test.':'Creature simulation resumed.');});
    button('View distant northern hurricane',()=>travel(180,-377,0));
    button('Visit west river confluence',()=>travel(riverX(-80)+18,-80,Math.PI/2));
    button('Visit east river confluence',()=>travel(riverX(220)-18,220,-Math.PI/2));
    button('Visit river delta',()=>travel(riverX(520)+34,520,Math.PI));
    button('View wildlife nearby',()=>{const targets=phase3.wildlife.getNearbyTargets({origin:{...player,y:footY},range:100}).filter(t=>!t.dead);const target=targets[0];if(!target){notify('Wildlife is moving nearby. Try again in a moment.');return;}const p=target.position;travel(p.x,p.z+7,0);player.pitch=Math.atan2(p.y+.7-footY-eyeHeight,7);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');notify(target.name);});
  }
  if(ecologyCheck){
    button('Add mining test equipment',()=>{phase3.survival.add('iron_pickaxe',1);phase3.survival.add('torch',1);phase3.survival.equip('iron_pickaxe');saveWorld();});
    function findRock(rare){let nodes=phase3.camp.getResourceNodes().filter(n=>n.mineable&&(!rare||rareOreAt(journey.runId,n.id)));if(!nodes.length){travel(135,85);nodes=phase3.camp.getResourceNodes().filter(n=>n.mineable&&(!rare||rareOreAt(journey.runId,n.id)));}const rock=nodes[0];if(rock)travel(rock.x,rock.z+2.3,0);else notify('No matching unmined rock nearby. Explore another area.');}
    button('Visit mineable stone',()=>findRock(false));button('Find naturally rare test rock',()=>findRock(true));
    button('Equip torch',()=>{phase3.survival.equip('torch');saveWorld();});
    button('Walk maze route to reward (test)',()=>{
      travel(-493,-60,Math.PI/2);phase3.survival.equip('torch');
      const routes=new Map([['entrance',[CAVE_SEGMENTS[0].a]]]),queue=['entrance'];
      while(queue.length&&!routes.has('5:0')){const id=queue.shift();for(const edge of CAVE_SEGMENTS){const next=edge.a.id===id?edge.b:edge.b.id===id?edge.a:null;if(next&&!routes.has(next.id)){routes.set(next.id,[...routes.get(id),next]);queue.push(next.id);}}}
      caveTestRoute={points:routes.get('5:0')?.slice(1)||[],blocked:0};notify('Following the physical maze route for testing. Movement keys take control.');
    });
    button('Stop maze walkthrough',()=>{caveTestRoute=null;keys.clear();});
    button('Inspect cave reward chamber',()=>travel(MAZE_REWARD_POSITION.x,MAZE_REWARD_POSITION.z+2.5,0));
    button('Show cave bear (forced test)',()=>{const zone=CAVE_ZONES.find(z=>z.id==='0:2');travel(zone.x,zone.z+4,0);phase3.wildlife.spawnCaveBear({position:{x:zone.x,y:world.groundHeight(zone.x,zone.z),z:zone.z-3},encounterId:`forced-visual-${Date.now()}`});saveWorld();notify('Forced visual test only. Normal entries retain the 1% chance.');});
    button('Show building models (test)',()=>{
      const examples=[['foundation',135,80],['wall',135,78.52],['roof',135,80],['workbench',131,82],['storage_chest',139,82],['campfire',143,82],['furnace',147,80],['tanning_rack',127,80]];
      for(const [type,x,z] of examples)phase3.camp.placeBuilding({type,x,z,y:['wall','roof'].includes(type)?world.groundHeight(135,80)+.17:world.groundHeight(x,z),rotation:0,valid:true});
      for(const b of phase3.camp.getBuildings())if(['campfire','furnace'].includes(b.type))b.fuel=600;
      indexColliders();setupEncounters();travel(135,89,0);saveWorld();
    });
  }
  button('Save and reload test life',()=>{saveWorld();location.href='./index.html?continue=1&check='+checkMode+(new URLSearchParams(location.search).get('qa')==='agent'?'&qa=agent':'');});
}

function checkJourneyState() {
  if(coopMode)return;
  if(!journeyStarted||!journey||mode==='dead'||mode==='tripped')return;
  try {
    if(journeyStore.isDead(journey.runId)) {
      health=0;showEndedLife('This life has already ended.');return;
    }
    const current=journeyStore.read();
    if(runPersisted&&current&&current.runId!==journey.runId) {
      showEndedLife('A new journey has replaced this life.');return;
    }
    if(current?.runId===journey.runId){health=Math.min(health,current.health);survivedSeconds=Math.max(survivedSeconds,current.survivedSeconds);}
  } catch {storageWorks=false;}
}
window.addEventListener('storage',event=>{if(event.key===savePrefix+SAVE_KEY||event.key===savePrefix+DEATH_KEY)checkJourneyState();});

function savePreferences() {
  try { localStorage.setItem(PREF_KEY,JSON.stringify({sensitivity,motionEffects})); } catch {}
}
try {
  const pref=JSON.parse(localStorage.getItem(PREF_KEY)||'null');
  if (pref && Number.isFinite(pref.sensitivity)) sensitivity=THREE.MathUtils.clamp(pref.sensitivity,.3,2);
  if (pref && typeof pref.motionEffects==='boolean') motionEffects=pref.motionEffects;
} catch {}
$('look-sensitivity').value=sensitivity;
$('motion-effects').checked=motionEffects;
$('look-sensitivity').addEventListener('input',event=>{sensitivity=Number(event.target.value);savePreferences();});
$('motion-effects').addEventListener('change',event=>{motionEffects=event.target.checked;savePreferences();});

function releasePointer() {
  dragLook=false;
  lastMouse=null;
  if (document.pointerLockElement===canvas) document.exitPointerLock();
}

function setMode(next) {
  if(mode==='dead'&&next!=='dead')return;
  if(mode==='tripped'&&next!=='dead'&&next!=='tripped')return;
  mode=next;
  if(coopMode)sendCoopMovement();
  if(mode!=='character')characterEditor?.close();
  if(mode!=='playing')caveTestRoute=null;
  if(mode!=='inventory')phase3?.close();
  keys.clear();
  document.body.dataset.mode=mode;
  $('startup').hidden=mode!=='ready';
  $('map-panel').hidden=mode!=='map';
  $('pause-panel').hidden=mode!=='paused';
  $('hud').hidden=mode==='loading'||mode==='error'||mode==='ready'||mode==='character';
  $('crosshair').hidden=mode!=='playing'||(teethpeedCheck&&!!teethpeedInspection);
  $('cinematic').hidden=mode!=='cinematic';
  $('trip-cinematic').hidden=mode!=='tripped';
  $('death-panel').hidden=mode!=='dead';
  if(mode!=='playing')$('creature-warning').hidden=true;
  if(mode==='dead'||mode==='tripped')$('hud').hidden=true;
  if(mode!=='playing'&&phase3){camera.getWorldDirection(phase3Direction);phase3.update(0,{...player,y:footY},phase3Direction,{active:false});}
  sound.activate(mode==='playing'||mode==='cinematic'||mode==='tripped');
  if(isolatedCheck)canvas.dataset.audio=JSON.stringify(sound.getState());
  if (mode!=='playing') releasePointer();
  if (mode==='map') { updateMap(); $('close-map').focus(); }
  else if (mode==='paused') { saveWorld(); $('resume-game').focus(); }
  else if (mode==='ready') $('enter-world').focus();
  else if (mode==='playing') canvas.focus({preventScroll:true});
  else if (mode==='dead') $('death-new-journey').focus();
  else if (mode==='tripped') $('skip-trip').focus();
}

async function requestLook() {
  if(teethpeedCheck&&teethpeedInspection)return;
  if (!canvas.requestPointerLock || !pointerSupported) return;
  try {
    await canvas.requestPointerLock();
  } catch {
    $('controls-hint').textContent='WASD move · Drag / arrows look · Shift sprint · E gather · F attack · I inventory · B build · M map';
  }
}

function setupEncounters() {
  if(coopMode)return;
  tripRisk=createTripRisk({seed:journey?.runId,state:journey?.trips,onChange:()=>saveWorld()});
  for(const view of encounterViews.values())view.dispose();
  encounterViews.clear();
  encounters=createTeethpeedEncounters({
    trees:world.encounterTrees,heightAt:world.groundHeight,colliders:world.colliders,forestBlendAt,isSafeAt:isGlowSafeAt,
    state:journey?.encounters,seed:journey?.runId,
    onDamage:amount=>takeDamage(amount,'Killed by a Teethpeed.'),
    onEvent:event=>{
      if(event.type==='descent')notify('Something is crawling down the tree.');
      else if(event.type==='retreat')notify('The Teethpeed is retreating into the forest.');
      else if(event.type==='bite')sound.creatureEvent('bite',event.position);
    },
    onChange:()=>saveWorld()
  });
  deatheaterView?.anchor?.removeFromParent();deatheaterView?.dispose();deatheaterView=null;
  deatheater=createDeatheaterEncounters({heightAt:world.groundHeight,colliders:world.colliders,stormBlendAt,isSafeAt:isGlowSafeAt,
    seed:journey?.runId,state:journey?.deatheater,
    onDamage:(amount,cause,record)=>{
      if(isGlowSafeAt(player.x,player.z))return;
      const anchor=deatheaterView?.anchor,p=anchor?.position||record.position,q=anchor?.quaternion;
      beginFatalTrip({kind:'deatheater',id:record.id,position:{x:p.x,y:p.y,z:p.z},
        heading:record.heading,pitch:record.pitch,bank:record.bank,
        orientation:q?{x:q.x,y:q.y,z:q.z,w:q.w}:null,animationTime:deatheaterTime},{entry:'dive'});
    },
    onEvent:event=>{
      if(event.type==='warning')notify('Something is hunting in the storm above you.');
      if(event.type==='retreating')notify('The Deatheater is disappearing into the storm.');
    },onChange:()=>saveWorld()
  });
}

function rainforestTrunkRadiusAt(tree,y) {
  const ring=THREE.MathUtils.clamp((y-tree.h+.08)/tree.height,0,1)*10,lower=Math.floor(ring),upper=Math.min(10,lower+1);
  const sample=j=>(1-.945*Math.pow(j/10,.76))*(1+Math.sin(j*1.7)*.035);
  return THREE.MathUtils.lerp(sample(lower),sample(upper),ring-lower)*tree.radius;
}

function rainforestTrunkAt(tree,y) {
  const ring=THREE.MathUtils.clamp((y-tree.h+.08)/tree.height,0,1)*10,lower=Math.floor(ring),upper=Math.min(10,lower+1),blend=ring-lower;
  const variant=Number.isFinite(tree.variant)?tree.variant:(parseInt(tree.id.split('-').at(-1),10)||0)%2;
  const sample=j=>{const t=j/10;return {x:Math.sin(t*2.6+variant)*t*.55,z:Math.sin(t*3.9)*t*.46};};
  const a=sample(lower),b=sample(upper),localX=THREE.MathUtils.lerp(a.x,b.x,blend)*tree.radius,localZ=THREE.MathUtils.lerp(a.z,b.z,blend)*tree.radius;
  return {x:tree.x+Math.cos(tree.angle)*localX+Math.sin(tree.angle)*localZ,z:tree.z-Math.sin(tree.angle)*localX+Math.cos(tree.angle)*localZ,radius:rainforestTrunkRadiusAt(tree,y)};
}

function teethpeedClimbingQuaternion(outwardX,outwardZ,velocity) {
  return teethpeedSurfaceQuaternion(new THREE.Vector3(outwardX,0,outwardZ).normalize(),velocity);
}

function teethpeedSurfaceQuaternion(normal,velocity) {
  const forward=velocity.clone();
  forward.addScaledVector(normal,-forward.dot(normal));
  if(forward.lengthSq()<.0000001){
    forward.set(0,Math.abs(normal.y)<.8?-1:0,Math.abs(normal.y)<.8?0:-1);
    forward.addScaledVector(normal,-forward.dot(normal));
  }
  forward.normalize();
  const back=forward.negate(),right=new THREE.Vector3().crossVectors(normal,back).normalize();
  return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,normal,back));
}

function drawEncounters(dt) {
  teethpeedAudioSources=[];
  if(!encounters)return;
  creatureTime+=dt;
  const active=encounters.getActive(),ids=new Set(active.map(record=>record.treeId));
  for(const [id,view] of encounterViews)if(!ids.has(id)){view.dispose();encounterViews.delete(id);}
  for(const record of active) {
    let view=encounterViews.get(record.treeId);
    if(!view){view=createTeethpeedModel({surfaceTexture:teethpeedSurfaceTexture});scene.add(view.group);encounterViews.set(record.treeId,view);}
    view.group.visible=!(teethpeedCheck&&teethpeedInspection);
    const travelled=view.lastPosition?Math.hypot(record.position.x-view.lastPosition.x,record.position.y-view.lastPosition.y,record.position.z-view.lastPosition.z):0;
    const crawlSpeed=dt>0?Math.min(8,travelled/dt):0;
    teethpeedAudioSources.push({id:record.treeId,position:{...record.position},stage:record.stage,speed:crawlSpeed});
    const firstPose=!view.lastPosition;
    const velocity=record.descentPose?.velocity?new THREE.Vector3(record.descentPose.velocity.x,record.descentPose.velocity.y,record.descentPose.velocity.z):view.lastPosition?new THREE.Vector3(record.position.x-view.lastPosition.x,record.position.y-view.lastPosition.y,record.position.z-view.lastPosition.z):new THREE.Vector3(0,-1,0);
    view.group.position.set(record.position.x,record.position.y,record.position.z);
    const climbing=!!record.descentPose;
    const groundBlend=climbing?record.descentPose?.groundBlend||0:1;
    const normal=new THREE.Vector3(Math.cos(record.descentPose?.angle??record.descent.angle),0,Math.sin(record.descentPose?.angle??record.descent.angle)).lerp(new THREE.Vector3(0,1,0),groundBlend).normalize();
    const turn=climbing?teethpeedSurfaceQuaternion(normal,velocity):new THREE.Quaternion().setFromEuler(new THREE.Euler(0,record.heading||0,0,'YXZ'));
    const previousTurn=view.group.quaternion.clone();
    if(firstPose)view.group.quaternion.copy(turn);else view.group.quaternion.slerp(turn,1-Math.exp(-dt*12));
    view.lastPosition={...record.position};
    const bitePose=record.stage==='attacking'?Math.max(.08,Math.min(1,(record.biteCooldown-1.35)/.45)):0;
    const groundSample=new THREE.Vector3();
    const groundAt=(x,z)=>{
      groundSample.set(x,0,z).applyQuaternion(view.group.quaternion).add(view.group.position);
      return world.groundHeight(groundSample.x,groundSample.z)-view.group.position.y;
    };
    // A close player can stop the head before the tail clears the bark.
    // Keep its support tree until the model confirms every segment is on land.
    if(climbing||firstPose){
      const sourceTree=world.encounterTrees.find(tree=>tree.id===record.treeId);
      if(sourceTree&&(climbing||Math.hypot(record.position.x-sourceTree.x,record.position.z-sourceTree.z)<sourceTree.radius+5.5))view.supportTree=sourceTree;
    }
    if(!climbing&&!firstPose&&view.getDiagnostics?.().trunkSupportedSegments===0)view.supportTree=null;
    const climbTree=view.supportTree||null;
    const climbRadius=Math.max(.28,climbTree?rainforestTrunkRadiusAt(climbTree,view.group.position.y):(record.descent?.surfaceRadius||1.8)-.08);
    const climbTaper=climbTree?(rainforestTrunkRadiusAt(climbTree,view.group.position.y)-rainforestTrunkRadiusAt(climbTree,view.group.position.y+3.35))/3.35:.035;
    view.animate({time:creatureTime,speed:crawlSpeed,climbing,climbBlend:1-groundBlend,climbTree,climbRadius,climbTaper,attacking:bitePose,groundAt,groundHeightAt:world.groundHeight});
    if(teethpeedCheck&&dt>0&&(creatureTime-(view.lastLandingSample??-1)>=.04||view.lastSampledStage!==record.stage)){
      view.lastLandingSample=creatureTime;view.lastSampledStage=record.stage;
      teethpeedLandingFrames.push({treeId:record.treeId,stage:record.stage,progress:record.descentPose?.progress??1,groundBlend,speed:crawlSpeed,
        turnDegrees:firstPose?0:previousTurn.angleTo(view.group.quaternion)*180/Math.PI,position:{...record.position},diagnostics:view.getDiagnostics?.()});
      if(teethpeedLandingFrames.length>240)teethpeedLandingFrames.shift();
      canvas.dataset.teethpeedLanding=JSON.stringify(teethpeedLandingFrames);
    }
  }
  const attacking=active.some(record=>record.stage==='attacking'),hunting=active.some(record=>record.stage==='hunting'),descending=active.some(record=>record.stage==='descending');
  const warning=$('creature-warning');warning.hidden=mode!=='playing'||(!attacking&&!hunting&&!descending);
  if(teethpeedCheck&&teethpeedInspection)warning.hidden=true;
  warning.dataset.stage=attacking?'attacking':hunting?'hunting':'descending';
  warning.textContent=attacking?'Teethpeed — it sees you. Keep moving.':hunting?'Teethpeed — hunting your last known position. Stay out of sight.':'Movement above — watch the tree trunks.';
  canvas.dataset.biome=biomeAt(player.x,player.z).id;
  canvas.dataset.encounters=active.map(record=>`${record.treeId}:${record.stage}:${Math.ceil(record.remaining||0)}`).join(',');
  if(isolatedCheck)canvas.dataset.teethpeedDescents=JSON.stringify(active.filter(record=>record.stage==='descending').map(record=>({treeId:record.treeId,position:record.position,heading:record.heading,descentPose:record.descentPose||null})));
  if(teethpeedCheck)canvas.dataset.teethpeedSenses=JSON.stringify(active.map(record=>({treeId:record.treeId,stage:record.stage,senses:record.senses||null,lastKnownPlayer:record.lastKnownPlayer||null,remaining:record.remaining})));
  if(previewStatus) {
    if(!teethpeedInspection)previewStatus.textContent=active.length?active.map(record=>{
      const senses=record.senses,distance=Number.isFinite(senses?.distance)?senses.distance:Math.hypot(record.position.x-player.x,record.position.z-player.z);
      const stage=record.stage==='attacking'?'Chasing':record.stage==='hunting'?'Hunting':record.stage;
      const sight=typeof senses?.lineOfSight==='boolean'?(senses.lineOfSight?'Clear sight':'Sight blocked'):'Senses waiting for update';
      const detection=typeof senses?.withinDetection==='boolean'?`10 m detection · ${senses.withinDetection?'inside':'outside'}`:'10 m initial detection';
      return `${stage} · ${Math.ceil(record.remaining||0)}s\n${distance.toFixed(1)} m · ${sight}\n${detection}`;
    }).join('\n\n'):'No active Teethpeed\n10 m initial detection · 15% per tree';
    previewButton.disabled=mode!=='playing'||(!teethpeedInspection&&active.length>0);
  }
  if(previewSenseStatus)previewSenseStatus.textContent=active.length?active.map(record=>{
    const seen=record.lastKnownPlayer;
    const lastSeen=seen&&[seen.x,seen.y,seen.z].every(Number.isFinite)?`${seen.x.toFixed(1)}, ${seen.y.toFixed(1)}, ${seen.z.toFixed(1)}`:'none';
    return `${record.treeId} · ${record.stage}\nLine of sight: ${typeof record.senses?.lineOfSight==='boolean'?(record.senses.lineOfSight?'clear':'blocked'):'waiting'}\nInside 10 m: ${typeof record.senses?.withinDetection==='boolean'?(record.senses.withinDetection?'yes':'no'):'waiting'}\nLast known position: ${lastSeen}`;
  }).join('\n\n'):'The safe specimen has no AI senses. Trigger a nearby tree encounter to inspect detection and hunting.';
}

function drawDeatheater(dt) {
  if(!deatheater)return;
  deatheaterTime+=dt;
  const record=deatheater.getActive()[0];
  if(!record){deatheaterView?.anchor?.removeFromParent();deatheaterView?.dispose();deatheaterView=null;}
  else {
    if(!deatheaterView){deatheaterView=createDeatheaterModel();deatheaterView.anchor=new THREE.Group();deatheaterView.anchor.add(deatheaterView.group);deatheaterView.group.position.set(0,-.065,1.295);scene.add(deatheaterView.anchor);}
    const inspecting=stormCheck&&stormInspect;
    const inspectionDistance=stormInspectionPose==='wings'?6.8:4.8;
    const p=inspecting?{x:player.x-Math.sin(player.yaw)*inspectionDistance,y:footY+eyeHeight+.1,z:player.z-Math.cos(player.yaw)*inspectionDistance}:record.position;
    // Flight and contact use the mouth, keeping its teeth above the ground during steep dives.
    deatheaterView.anchor.position.set(p.x,p.y,p.z);
    const flightPose=new THREE.Quaternion().setFromEuler(new THREE.Euler(inspecting?(stormInspectionPose==='wings'?-.48:0):record.pitch||0,inspecting?player.yaw+Math.PI+(stormInspectionPose==='wings'?.6:0):record.heading||0,inspecting?0:record.bank||0,'YXZ'));
    if(!deatheaterView.hasPose||inspecting)deatheaterView.anchor.quaternion.copy(flightPose);else deatheaterView.anchor.quaternion.slerp(flightPose,1-Math.exp(-dt*10));
    deatheaterView.hasPose=true;
    deatheaterView.animate({time:deatheaterTime,speed:inspecting?0:Math.hypot(record.velocity?.x||0,record.velocity?.y||0,record.velocity?.z||0),stage:inspecting?'circling':record.stage,attacking:inspecting||record.stage==='diving'?1:0});
    if(inspecting){player.pitch=0;camera.rotation.set(0,player.yaw,0,'YXZ');}
    else if(stormCheck&&stormTrack&&mode==='playing') {
      player.yaw=Math.atan2(player.x-p.x,player.z-p.z);
      player.pitch=THREE.MathUtils.clamp(Math.atan2(p.y-footY-eyeHeight,Math.hypot(player.x-p.x,player.z-p.z)),-1.25,1.25);
      camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
    }
  }
  const state=deatheater.snapshot(),warning=$('creature-warning');
  if(mode==='playing'&&(record&&record.stage!=='retreating'||state.warningIssued&&state.warningRemaining>0)) {
    warning.hidden=false;warning.dataset.stage=record?.stage==='diving'?'attacking':'circling';
    warning.textContent=record?.stage==='diving'?'DEATHEATER — Dive incoming. Dodge sideways!':record?.stage==='recovering'?'DEATHEATER — Move while it climbs.':'DEATHEATER — Watch the sky. Keep room to dodge.';
  }
  canvas.dataset.deatheater=record?`${record.stage}:${Math.ceil(record.huntRemaining||0)}`:'none';
  if(stormStatus){stormStatus.textContent=stormInspect?`${stormInspectionPose==='wings'?'Withered wings and exposed bones':'Circular mouth inspection'}\nFlight paused · Inspection view`:record?`${record.stage} · ${Math.ceil(record.huntRemaining)}s\n${Math.hypot(record.position.x-player.x,record.position.z-player.z).toFixed(1)} m away`:`No active Deatheater\n${state.warningIssued?'A shape is approaching…':'Enter the storm to attract it.'}`;stormTrigger.disabled=mode!=='playing'||!!record;}
}

function buildStormPreviewControls() {
  if(!stormCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check';panel.setAttribute('aria-label','Isolated storm test controls');
  panel.style.maxHeight='calc(100vh - 140px)';panel.style.overflowY='auto';
  const title=document.createElement('strong');title.textContent='STORMLANDS PREVIEW';
  stormStatus=document.createElement('output');stormStatus.textContent='Enter the storm preview.';
  stormTrigger=document.createElement('button');stormTrigger.textContent='Summon Deatheater';stormTrigger.disabled=true;
  stormTrigger.addEventListener('click',()=>{if(mode==='playing'&&deatheater){deatheater.forceEncounter({...player,y:footY});saveWorld();canvas.focus();}});
  const track=document.createElement('button');track.textContent='Follow creature with camera';
  track.addEventListener('click',()=>{stormTrack=!stormTrack;track.textContent=stormTrack?'Release camera':'Follow creature with camera';canvas.focus();});
  const freeze=document.createElement('button');freeze.textContent='Freeze flight for inspection';
  freeze.addEventListener('click',()=>{stormFrozen=!stormFrozen;if(!stormFrozen){stormInspect=false;inspect.textContent='Inspect circular mouth';}freeze.textContent=stormFrozen?'Resume flight':'Freeze flight for inspection';canvas.focus();});
  const inspect=document.createElement('button');inspect.textContent='Inspect circular mouth';
  function inspectModel(pose){
    const record=deatheater?.getActive()[0];if(!record||mode!=='playing')return;
    stormInspect=true;stormInspectionPose=pose;stormFrozen=true;keys.clear();freeze.textContent='Resume flight';
    // The isolated viewer repositions only the rendered model. The saved hunt pose stays intact.
    if(stormInspect){stormTrack=false;track.textContent='Follow creature with camera';player.pitch=0;for(let i=0;i<12;i++)deatheaterView?.animate({time:deatheaterTime+=.1,speed:0,stage:'circling',attacking:1});}
    drawDeatheater(0);canvas.focus();
  }
  inspect.addEventListener('click',()=>inspectModel('mouth'));
  const withered=document.createElement('button');withered.textContent='Inspect withered wings';withered.addEventListener('click',()=>inspectModel('wings'));
  const devour=document.createElement('button');devour.textContent='Preview swallowing dive';devour.addEventListener('click',()=>{
    if(mode==='playing')beginFatalTrip({kind:'deatheater',id:'isolated-devour-preview'},{entry:'dive'});
  });
  const slowLabel=document.createElement('label'),slow=document.createElement('input');slow.type='checkbox';slow.addEventListener('change',()=>{tripPreviewSlow=slow.checked;});slowLabel.append(slow,' Slow motion inspection');
  const restart=document.createElement('button');restart.textContent='Restart isolated storm test';restart.addEventListener('click',()=>{location.href='./index.html?new=1&check=storm';});
  panel.append(title,stormStatus,stormTrigger,track,inspect,withered,freeze,devour,slowLabel,restart);document.body.append(panel);
}

function inspectFoliage(biome='valley') {
  clearFoliageCamera();
  const forest=biome==='forest',origin=forest?FOREST_PREVIEW_SPAWN:{x:60,z:85};
  const candidates=[...(forest?world.encounterTrees:world.valleyTrees||[])].sort((a,b)=>Math.hypot(a.x-origin.x,a.z-origin.z)-Math.hypot(b.x-origin.x,b.z-origin.z));
  for(const tree of candidates) {
    const height=forest?tree.height:16*tree.scale,distance=forest?height*.64:Math.max(10,height*.83);
    for(let i=0;i<16;i++) {
      const angle=3.95+i*Math.PI/8,x=tree.x+Math.sin(angle)*distance,z=tree.z+Math.cos(angle)*distance;
      if(Math.abs(x)>380||Math.abs(z)>380||!canStand(x,z,x,z))continue;
      Object.assign(player,{x,z,yaw:angle});footY=world.groundHeight(x,z);verticalSpeed=0;grounded=true;keys.clear();
      player.pitch=THREE.MathUtils.clamp(Math.atan2(tree.h+height*.51-footY-eyeHeight,distance),-.9,1.1);
      camera.position.set(x,footY+eyeHeight,z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
      if(foliageStatus)foliageStatus.textContent=`${forest?'Rainforest branches and vines':'Valley conifer branches'}\nCreature encounters paused for inspection`;
      updateHUD();canvas.focus();return;
    }
  }
}

function clearFoliageCamera() {
  foliageCameraOverride=null;
  if(!foliageCheck||!camera)return;
  camera.position.set(player.x,footY+eyeHeight,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
  canvas.dataset.foliageInspection='ground';
}

function inspectJungleBark() {
  if(!foliageCheck||mode!=='playing')return null;
  clearFoliageCamera();
  const candidates=[...world.encounterTrees].sort((a,b)=>Math.hypot(a.x-FOREST_PREVIEW_SPAWN.x,a.z-FOREST_PREVIEW_SPAWN.z)-Math.hypot(b.x-FOREST_PREVIEW_SPAWN.x,b.z-FOREST_PREVIEW_SPAWN.z));
  for(const tree of candidates) {
    const distance=Math.max(4.4,tree.radius+3.2);
    for(let i=0;i<16;i++) {
      const angle=3.95+i*Math.PI/8,x=tree.x+Math.sin(angle)*distance,z=tree.z+Math.cos(angle)*distance;
      if(!canStand(x,z,x,z)||Math.abs(world.groundHeight(x,z)-tree.h)>2.3)continue;
      Object.assign(player,{x,z,yaw:angle});footY=world.groundHeight(x,z);verticalSpeed=0;grounded=true;keys.clear();
      player.pitch=Math.atan2(tree.h+2.5-footY-eyeHeight,distance);
      camera.position.set(x,footY+eyeHeight,z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
      canvas.dataset.foliageInspection='bark';
      foliageStatus.textContent='Jungle bark · rough plates, fissures and moss\nCreature encounters paused for inspection';
      updateHUD();canvas.focus();return tree;
    }
  }
  foliageStatus.textContent='No clear standing point found beside a jungle trunk.';
  return null;
}

function inspectJungleCanopy() {
  if(!foliageCheck||mode!=='playing')return;
  // First choose an ordinary safe ground position. Only the rendering camera
  // rises into the canopy; neither player height nor saved fall state changes.
  const tree=inspectJungleBark();if(!tree)return;
  const treeIndex=world.encounterTrees.indexOf(tree),variant=treeIndex%2;
  const crowns=scene.getObjectByName(`Layered broadleaf crowns ${variant+1}`);
  const position=crowns?.geometry.getAttribute('position'),indices=crowns?.geometry.index;
  const outward=new THREE.Vector3(Math.sin(3.95),0,Math.cos(3.95));
  let target=new THREE.Vector3(tree.x+outward.x*tree.radius*5,tree.h+tree.height*.73,tree.z+outward.z*tree.radius*5);
  if(position&&indices) {
    scene.updateMatrixWorld(true);
    const transform=new THREE.Matrix4();crowns.getMatrixAt(Math.floor(treeIndex/2),transform);transform.premultiply(crowns.matrixWorld);
    const center=new THREE.Vector3(),vertex=new THREE.Vector3();let best=-Infinity;
    // Triangle centers work for both the original fan leaves and the curved,
    // textured leaf grids. This aims at a real outer leaf, not an empty crown.
    for(let i=0;i<indices.count;i+=3) {
      center.set(0,0,0);
      for(let j=0;j<3;j++)center.add(vertex.fromBufferAttribute(position,indices.getX(i+j)).applyMatrix4(transform));
      center.multiplyScalar(1/3);
      const relativeY=center.y-tree.h;
      if(relativeY<tree.height*.60||relativeY>tree.height*.86)continue;
      const projection=(center.x-tree.x)*outward.x+(center.z-tree.z)*outward.z;
      const score=projection-Math.abs(relativeY-tree.height*.73)*.18;
      if(score>best){best=score;target.copy(center);}
    }
  }
  foliageCameraOverride={position:target.clone().addScaledVector(outward,3.3).add(new THREE.Vector3(0,2.1,0)),target};
  camera.position.copy(foliageCameraOverride.position);camera.lookAt(target);
  canvas.dataset.foliageInspection='canopy';
  foliageStatus.textContent='Jungle canopy · curved leaves and fine veins\nCamera raised · player stays safely on the ground';
  keys.clear();canvas.focus();
}

function buildFoliagePreviewControls() {
  if(!foliageCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check';panel.setAttribute('aria-label','Isolated foliage test controls');
  const title=document.createElement('strong');title.textContent='TREE DETAIL PREVIEW';
  foliageStatus=document.createElement('output');foliageStatus.textContent='Inspect the real trees and their moving branches.';
  const valley=document.createElement('button');valley.textContent='Inspect valley trees';valley.addEventListener('click',()=>{if(mode==='playing')inspectFoliage('valley');});
  const forest=document.createElement('button');forest.textContent='Inspect rainforest trees';forest.addEventListener('click',()=>{if(mode==='playing')inspectFoliage('forest');});
  const bark=document.createElement('button');bark.textContent='Inspect jungle bark';bark.addEventListener('click',inspectJungleBark);
  const canopy=document.createElement('button');canopy.textContent='Inspect jungle canopy';canopy.addEventListener('click',inspectJungleCanopy);
  const ground=document.createElement('button');ground.textContent='Return to ground';ground.addEventListener('click',()=>{if(mode!=='playing')return;clearFoliageCamera();keys.clear();foliageStatus.textContent='Ground view · creature encounters paused for inspection';canvas.focus();});
  const wind=document.createElement('button');wind.textContent='Freeze wind';wind.addEventListener('click',()=>{foliageWindFrozen=!foliageWindFrozen;wind.textContent=foliageWindFrozen?'Resume wind':'Freeze wind';canvas.focus();});
  panel.append(title,foliageStatus,valley,forest,bark,canopy,ground,wind);document.body.append(panel);
}

function prepareEncounterPreview() {
  Object.assign(player,FOREST_PREVIEW_SPAWN);
  // Choose a clear viewing point in front of a real tree, using the ordinary collision rules.
  const candidates=[...world.encounterTrees].sort((a,b)=>Math.hypot(a.x-player.x,a.z-player.z)-Math.hypot(b.x-player.x,b.z-player.z));
  for(const tree of candidates) {
    for(let i=0;i<12;i++) {
      const angle=i*Math.PI/6,x=tree.x+Math.sin(angle)*9,z=tree.z+Math.cos(angle)*9;
      if(forestBlendAt(x,z)>.48&&canStand(x,z,x,z)) {
        encounterPreviewTree=tree;Object.assign(player,{x,z,yaw:angle,pitch:.42});
        footY=world.groundHeight(x,z);verticalSpeed=0;grounded=true;return;
      }
    }
  }
}

function findTeethpeedInspectionPatch() {
  // Inspect the real model on ordinary terrain, with room for its full body and legs.
  const origin={x:player.x,z:player.z};
  let best={...origin,score:Infinity};
  for(const radius of [0,3,6,9,12])for(let i=0;i<(radius?16:1);i++) {
    const angle=i*Math.PI/8,x=origin.x+Math.cos(angle)*radius,z=origin.z+Math.sin(angle)*radius;
    if(forestBlendAt(x,z)<.4)continue;
    const heights=[];let clear=true;
    for(const [dx,dz] of [[0,0],[-1.2,0],[1.2,0],[-1.2,1.7],[1.2,1.7],[0,3.6],[-2.9,-.9]]) {
      if(!canStand(x+dx,z+dz,x+dx,z+dz)){clear=false;break;}
      heights.push(world.groundHeight(x+dx,z+dz));
    }
    if(!clear)continue;
    const variation=Math.max(...heights)-Math.min(...heights),score=variation+radius*.015;
    if(score<best.score)best={x,z,score};
  }
  return best;
}

function inspectTeethpeed(pose='body') {
  if(!teethpeedCheck||!scene||!world)return;
  if(!teethpeedSpecimen) {
    const patch=findTeethpeedInspectionPatch();
    teethpeedSpecimen=createTeethpeedModel({surfaceTexture:teethpeedSurfaceTexture});
    teethpeedSpecimen.group.name='isolated-teethpeed-specimen';
    teethpeedSpecimen.group.position.set(patch.x,world.groundHeight(patch.x,patch.z),patch.z);
    teethpeedSpecimen.previewPatch=teethpeedSpecimen.group.position.clone();
    scene.add(teethpeedSpecimen.group);
    const metrics={meshes:0,triangles:0};
    teethpeedSpecimen.group.traverse(node=>{
      if(!node.isMesh)return;metrics.meshes++;
      metrics.triangles+=(node.geometry.index?.count||node.geometry.attributes.position?.count||0)/3*(node.isInstancedMesh?node.count:1);
    });
    teethpeedSpecimen.previewMetrics=metrics;
  }
  teethpeedInspection=pose;teethpeedSpecimenPaused=false;encounterFrozen=true;keys.clear();
  teethpeedSpecimen.group.visible=true;
  teethpeedSpecimen.group.position.copy(teethpeedSpecimen.previewPatch);
  teethpeedSpecimen.group.quaternion.identity();
  if(pose==='tree') {
    const patch=teethpeedSpecimen.previewPatch;
    const tree=[...world.encounterTrees].sort((a,b)=>Math.hypot(a.x-patch.x,a.z-patch.z)-Math.hypot(b.x-patch.x,b.z-patch.z))[0];
    if(!tree){teethpeedInspection='body';return;}
    const y=tree.h+13,center=rainforestTrunkAt(tree,y),radius=center.radius;
    const angle=Math.atan2(patch.z-center.z,patch.x-center.x),dx=Math.cos(angle),dz=Math.sin(angle);
    const taper=(radius-rainforestTrunkRadiusAt(tree,y+3.35))/3.35;
    const target=rainforestTrunkAt(tree,tree.h+9);
    teethpeedSpecimen.previewTree={id:tree.id,tree,radius,taper,dx,dz,initialAngle:angle,angle,progress:0,turnCount:2,startedAt:teethpeedSpecimenTime,
      camera:{x:target.x+dx*8-dz*3,y:tree.h+10,z:target.z+dz*8+dx*3},target:{x:target.x,y:tree.h+9,z:target.z}};
    teethpeedSpecimen.group.position.set(center.x+dx*(radius+.08),y,center.z+dz*(radius+.08));
    teethpeedSpecimen.group.quaternion.copy(teethpeedClimbingQuaternion(dx,dz,new THREE.Vector3(-dz*(radius+.08)*Math.PI*4/14,-7.5/14,dx*(radius+.08)*Math.PI*4/14)));
  }
  // Keep the saved player grounded; only the review camera leaves eye height.
  Object.assign(player,{x:teethpeedSpecimen.previewPatch.x,z:teethpeedSpecimen.previewPatch.z,yaw:0,pitch:-.08});
  footY=world.groundHeight(player.x,player.z);verticalSpeed=0;grounded=true;
  if(teethpeedFreezeButton)teethpeedFreezeButton.textContent='Freeze specimen';
  releasePointer();drawTeethpeedInspection(0);updateHUD();
  if(mode==='playing')canvas.focus({preventScroll:true});
}

function clearTeethpeedInspection() {
  teethpeedInspection=null;
  if(teethpeedSpecimen)teethpeedSpecimen.group.visible=false;
  keys.clear();
  canvas.dataset.teethpeedInspection=JSON.stringify({active:false,encountersFrozen:encounterFrozen});
  if(teethpeedFreezeButton)teethpeedFreezeButton.textContent=encounterFrozen?'Resume encounter':'Freeze encounter for inspection';
  camera.position.set(player.x,footY+eyeHeight,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
}

function drawTeethpeedLandingCamera() {
  if(!teethpeedCheck||!teethpeedLandingTrack||teethpeedInspection||mode!=='playing')return;
  const record=encounters?.getActive()[0],view=record&&encounterViews.get(record.treeId);
  if(!record||!view)return;
  const p=view.group.position,a=record.descent.angle,dx=Math.cos(a),dz=Math.sin(a);
  const x=p.x+dx*6-dz*4,z=p.z+dz*6+dx*4;
  camera.position.set(x,Math.max(p.y+2.6,world.groundHeight(x,z)+1.2),z);
  const target=new THREE.Vector3(0,.2,1.1).applyQuaternion(view.group.quaternion).add(p);
  camera.lookAt(target);$('crosshair').hidden=true;$('movement-state').textContent='Trunk-to-ground inspection';
}

function drawTeethpeedInspection(dt) {
  if(!teethpeedCheck||!teethpeedInspection||!teethpeedSpecimen)return;
  const p=teethpeedSpecimen.group.position;
  const climbing=teethpeedInspection==='tree';
  const moving=(teethpeedInspection==='crawl'||climbing)&&!teethpeedSpecimenPaused&&motionEffects;
  let speed=moving?(climbing?.65:.8):0;
  if(!teethpeedSpecimenPaused&&motionEffects)teethpeedSpecimenTime+=dt;
  if(climbing&&!teethpeedSpecimenPaused){
    const review=teethpeedSpecimen.previewTree,tree=review.tree,progress=((teethpeedSpecimenTime-review.startedAt)%14)/14;
    const angle=review.initialAngle+progress*Math.PI*4,y=tree.h+13-progress*7.5,trunk=rainforestTrunkAt(tree,y),dx=Math.cos(angle),dz=Math.sin(angle);
    const previous=p.clone(),wrapped=progress<review.progress;
    p.set(trunk.x+dx*(trunk.radius+.08),y,trunk.z+dz*(trunk.radius+.08));
    const velocity=dt>0&&!wrapped&&moving?p.clone().sub(previous).divideScalar(dt):new THREE.Vector3(-dz*(trunk.radius+.08)*Math.PI*4/14,-7.5/14,dx*(trunk.radius+.08)*Math.PI*4/14);
    if(moving)speed=velocity.length()||.65;
    teethpeedSpecimen.group.quaternion.copy(teethpeedClimbingQuaternion(dx,dz,velocity));
    Object.assign(review,{radius:trunk.radius,taper:(trunk.radius-rainforestTrunkRadiusAt(tree,y+3.35))/3.35,dx,dz,angle,progress});
  }
  if(!teethpeedSpecimenPaused)teethpeedSpecimen.animate({time:teethpeedSpecimenTime,speed,climbing,climbTree:climbing?teethpeedSpecimen.previewTree?.tree:null,climbRadius:Math.max(.28,teethpeedSpecimen.previewTree?.radius||1.8),climbTaper:teethpeedSpecimen.previewTree?.taper??.035,attacking:teethpeedInspection==='jaws'?.15:0,
    groundAt:(x,z)=>world.groundHeight(p.x+x,p.z+z)-p.y});
  const jaws=teethpeedInspection==='jaws';
  if(climbing){
    const review=teethpeedSpecimen.previewTree;
    camera.position.set(review.camera.x,review.camera.y,review.camera.z);
    camera.lookAt(review.target.x,review.target.y,review.target.z);
  } else {
    camera.position.set(p.x+(jaws?-.82:-2.9),p.y+(jaws?.72:1.4),p.z+(jaws?-1.15:-.9));
    camera.lookAt(p.x,p.y+.30,p.z+(jaws?-.1:1.35));
  }
  $('crosshair').hidden=true;
  $('movement-state').textContent=climbing?'Spiral descent inspection':jaws?'Jaw inspection':moving?'Crawl inspection':'Creature inspection';
  if(moving)teethpeedAudioSources.push({id:'isolated-specimen',position:{x:p.x,y:p.y,z:p.z},stage:climbing?'descending':'attacking',speed});
  const diagnostics=teethpeedSpecimen.getDiagnostics?.()||teethpeedSpecimen.diagnostics||teethpeedSpecimen.group.userData.diagnostics||null;
  canvas.dataset.teethpeedInspection=JSON.stringify({active:true,pose:teethpeedInspection,animated:!teethpeedSpecimenPaused&&motionEffects,time:teethpeedSpecimenTime,
    speed,climbing,tree:climbing?teethpeedSpecimen.previewTree:null,position:{x:p.x,y:p.y,z:p.z},camera:{x:camera.position.x,y:camera.position.y,z:camera.position.z},
    grounded,encountersFrozen:encounterFrozen,...teethpeedSpecimen.previewMetrics,diagnostics});
  if(previewStatus)previewStatus.textContent=`${climbing?`Two turns down the trunk · ${Math.floor(teethpeedSpecimen.previewTree.progress*14)} / 14s`:jaws?'Jagged mandibles':moving?'Coordinated crawling in place':'Body, chitin, and joint detail'}\n${teethpeedSpecimenPaused?'Specimen paused':!motionEffects?'Motion effects disabled':'Safe specimen · encounters paused'}\n${Math.round(teethpeedSpecimen.previewMetrics.triangles).toLocaleString()} model triangles`;
}

function buildEncounterPreviewControls() {
  if(!teethpeedCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check';panel.setAttribute('aria-label','Isolated Teethpeed test controls');
  panel.style.maxHeight='calc(100vh - 140px)';panel.style.overflowY='auto';
  const title=document.createElement('strong');title.textContent='TEETHPEED PREVIEW';
  previewStatus=document.createElement('output');previewStatus.textContent='Start the preview to inspect the creature safely.';
  previewButton=document.createElement('button');previewButton.textContent='Trigger nearby tree encounter';previewButton.disabled=true;
  previewButton.addEventListener('click',()=>{
    if(mode!=='playing'||!encounters)return;
    clearTeethpeedInspection();encounterFrozen=false;
    if(teethpeedFreezeButton)teethpeedFreezeButton.textContent='Freeze encounter for inspection';
    if(encounters.getActive().length){notify('The live tree encounter has resumed. Sprint to keep your distance.');canvas.focus();return;}
    const spent=new Set(encounters.snapshot().spent||[]);
    const tree=[...world.encounterTrees].filter(t=>!spent.has(t.id)).sort((a,b)=>Math.hypot(a.x-player.x,a.z-player.z)-Math.hypot(b.x-player.x,b.z-player.z))[0];
    if(tree&&Math.hypot(tree.x-player.x,tree.z-player.z)<25){
      player.yaw=Math.atan2(player.x-tree.x,player.z-tree.z);player.pitch=.42;
      encounters.forceEncounter(tree.id);saveWorld();canvas.focus();
    }
    else notify('Walk near another unspent rainforest tree to test its descent.');
  });
  const freeze=document.createElement('button');teethpeedFreezeButton=freeze;freeze.textContent='Freeze specimen';
  freeze.addEventListener('click',()=>{
    if(mode!=='playing')return;
    if(teethpeedInspection){teethpeedSpecimenPaused=!teethpeedSpecimenPaused;freeze.textContent=teethpeedSpecimenPaused?'Resume specimen':'Freeze specimen';}
    else {encounterFrozen=!encounterFrozen;freeze.textContent=encounterFrozen?'Resume encounter':'Freeze encounter for inspection';}
    canvas.focus();
  });
  const inspect=document.createElement('button');inspect.textContent='Inspect creature close-up';
  inspect.addEventListener('click',()=>{
    if(mode!=='playing')return;
    inspectTeethpeed('body');
  });
  const jaws=document.createElement('button');jaws.textContent='Inspect jaws';jaws.addEventListener('click',()=>{if(mode==='playing')inspectTeethpeed('jaws');});
  const crawl=document.createElement('button');crawl.textContent='Watch crawling';crawl.addEventListener('click',()=>{if(mode==='playing')inspectTeethpeed('crawl');});
  const tree=document.createElement('button');tree.textContent='Watch spiral descent';tree.addEventListener('click',()=>{if(mode==='playing')inspectTeethpeed('tree');});
  const followLabel=document.createElement('label');followLabel.style.cssText='display:flex;gap:8px;align-items:center;margin:8px 0;font:12px Segoe UI,sans-serif';
  const follow=document.createElement('input');follow.type='checkbox';follow.addEventListener('change',()=>{teethpeedLandingTrack=follow.checked;if(!follow.checked&&!teethpeedInspection)$('crosshair').hidden=false;});
  followLabel.append(follow,document.createTextNode(' Follow trunk-to-ground transition'));
  const slowLabel=document.createElement('label');slowLabel.style.cssText=followLabel.style.cssText;
  const slow=document.createElement('input');slow.type='checkbox';slow.addEventListener('change',()=>{teethpeedLandingSlow=slow.checked;});
  slowLabel.append(slow,document.createTextNode(' Slow motion encounter'));
  const senses=document.createElement('button');senses.textContent='Show senses';senses.setAttribute('aria-expanded','false');
  previewSenseStatus=document.createElement('output');previewSenseStatus.id='teethpeed-senses-preview';previewSenseStatus.hidden=true;
  previewSenseStatus.textContent='Trigger a nearby tree encounter to inspect detection and hunting.';senses.setAttribute('aria-controls',previewSenseStatus.id);
  senses.addEventListener('click',()=>{previewSenseStatus.hidden=!previewSenseStatus.hidden;senses.textContent=previewSenseStatus.hidden?'Show senses':'Hide senses';senses.setAttribute('aria-expanded',String(!previewSenseStatus.hidden));});
  const ground=document.createElement('button');ground.textContent='Return to ground view';ground.addEventListener('click',()=>{if(mode!=='playing')return;clearTeethpeedInspection();$('crosshair').hidden=false;notify('Ground view. Trigger a nearby tree encounter to watch a live Teethpeed.');canvas.focus();});
  const restart=document.createElement('button');restart.textContent='Restart isolated forest test';restart.addEventListener('click',()=>{location.href='./index.html?new=1&check=teethpeed';});
  panel.append(title,previewStatus,inspect,jaws,crawl,tree,freeze,ground,followLabel,slowLabel,previewButton,senses,previewSenseStatus,restart);document.body.append(panel);
  inspectTeethpeed('body');
}

function resume() {
  checkJourneyState();if(mode==='dead')return;
  setMode('playing');
  if(!phase3Check&&!characterCheck)requestLook();
}

function buildAudioPreviewControls() {
  if(!isolatedCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check audio-check';panel.setAttribute('aria-label','Live sound preview');
  const title=document.createElement('strong');title.textContent=crashCheck?'CRASH & SOUND PREVIEW':'LIVE SOUND';
  audioPreviewStatus=document.createElement('output');audioPreviewStatus.textContent='Waiting for the preview to begin.';
  audioPreviewButton=document.createElement('button');audioPreviewButton.textContent=soundEnabled?'Mute preview sound':'Enable preview sound';
  audioPreviewButton.addEventListener('click',()=>{
    soundEnabled=!soundEnabled;sound.setEnabled(soundEnabled);sound.activate(mode==='playing'||mode==='cinematic');
    $('world-sound').checked=soundEnabled;$('startup-sound').checked=soundEnabled;audioPreviewButton.textContent=soundEnabled?'Mute preview sound':'Enable preview sound';
  });
  panel.append(title,audioPreviewStatus,audioPreviewButton);
  if(crashCheck){
    const replay=document.createElement('button');replay.textContent='Replay opening';replay.addEventListener('click',()=>{location.href='./index.html?new=1&check=crash';});panel.append(replay);
  }
  document.body.append(panel);
}

function updateWorldAudio(dt) {
  const flight=crash.getState();
  const plane=mode==='cinematic'?{...flight,distance:camera.position.distanceTo(new THREE.Vector3(flight.position.x,flight.position.y,flight.position.z))}:null;
  camera.getWorldDirection(audioDirection);
  sound.update(dt,{listener:{x:camera.position.x,y:camera.position.y,z:camera.position.z,yaw:Math.atan2(-audioDirection.x,-audioDirection.z)},
    biome:biomeAt(camera.position.x,camera.position.z).id,trees:world.soundTrees,
    teethpeeds:mode==='playing'?[...teethpeedAudioSources,...(coopMode?coopSnapshot?.world?.creatures?.burrowers?.dens||[]:phase3?.burrowers?.getActive()||[]).filter(r=>['emerging','chasing','burrowing'].includes(r.stage)).map(r=>({id:r.id,position:r.position,stage:r.stage,speed:r.stage==='chasing'?4.65:1.2}))]:[],plane});
  if(!isolatedCheck)return;
  audioMeterTime+=dt;if(audioMeterTime<.2)return;audioMeterTime=0;
  const audio=sound.getState();
  canvas.dataset.audio=JSON.stringify(audio);canvas.dataset.crash=JSON.stringify({...flight,events:crashEvents});
  if(audioPreviewStatus){
    const meter=Number(audio.rms??audio.outputRms??0);
    audioPreviewStatus.textContent=`${crashCheck?`${flight.stage} · ${flight.time.toFixed(1)} / ${CRASH_TIMING.duration}s\n`:''}${soundEnabled?'Sound enabled':'Sound muted'} · ${audio.contextState||audio.context||'waiting'}\nOutput ${meter.toFixed(4)} · Voices ${audio.activeVoices??audio.voices??0}${crashCheck?`\nCrash events: ${crashEvents.join(' → ')||'waiting'}`:''}`;
  }
}

function finishCrash() {
  crash.finish();sound.plane(false);Object.assign(player,crash.survivor);
  footY=world.groundHeight(player.x,player.z);verticalSpeed=0;grounded=true;
  if(fallCheck){footY+=24;grounded=false;}
  camera.position.set(player.x,footY+eyeHeight,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
  beginLife();resume();updateHUD();saveWorld();if(storageWorks)notify('You survived the crash. Your only objective: stay alive.');
}
async function enterJourney(){
  if(coopMode){if(!coopConnected){notify('Reconnect to the co-op server before entering.');return;}journeyStarted=true;continuing=true;try{await coopClient.profile({name:characterProfile.name,character:characterProfile});resume();sendCoopMovement();}catch(error){notify(error.message);}return;}
  if(continuing||journeyStarted){journeyStarted=true;resume();saveWorld();}
  else if(teethpeedCheck||stormCheck||foliageCheck||swimmingCheck||tripCheck||phase3Check||characterCheck){crash.finish();beginLife();resume();updateHUD();saveWorld();}
  else {setMode('cinematic');crashEvents.length=0;crash.start();sound.plane(true);$('skip-crash').focus();}
}
function openCharacterEditor(){
  if(!['ready','paused','playing'].includes(mode)||health<=0)return;
  saveWorld();
  if(!characterEditor)characterEditor=createCharacterEditor({
    onConfirm:profile=>{characterProfile=normalizeCharacterProfile(profile);phase3?.setCharacter(characterProfile);tripCutscene?.setProfile(characterProfile);enterJourney();},
    onCancel:()=>setMode(journeyStarted?'paused':'ready')
  });
  setMode('character');characterEditor.open(characterProfile,{continuing:continuing||journeyStarted});
}
$('enter-world').addEventListener('click',()=>{if(continuing||(isolatedCheck&&!characterCheck))enterJourney();else openCharacterEditor();});
$('edit-character').addEventListener('click',openCharacterEditor);
$('skip-crash').addEventListener('click',finishCrash);
$('skip-trip').addEventListener('click',finishFatalTrip);
$('resume-game').addEventListener('click',resume);
$('pause-game').addEventListener('click',()=>setMode('paused'));
$('open-map').addEventListener('click',()=>setMode('map'));
$('close-map').addEventListener('click',resume);
$('save-game').addEventListener('click',()=>saveWorld(true));
$('return-menu').addEventListener('click',()=>{
  if(coopMode){sendCoopMovement();releasePointer();location.href='../multiplayer/';return;}
  saveWorld();releasePointer();location.href='../scars-of-the-wild-intro.html#menu';
});
$('death-new-journey').addEventListener('click',()=>{location.href=coopMode?'../multiplayer/':'./index.html?new=1'+(isolatedCheck?'&check='+checkMode:'');});
$('death-menu').addEventListener('click',()=>{location.href=coopMode?'../multiplayer/':'../scars-of-the-wild-intro.html#menu';});
$('clear-waypoint').addEventListener('click',()=>{waypoint=null;updateMap();saveWorld();});

document.addEventListener('pointerlockchange',()=>{
  const locked=document.pointerLockElement===canvas;
  document.body.classList.toggle('pointer-locked',locked);
  if (!locked && mode==='playing' && !dragLook && !(teethpeedCheck&&teethpeedInspection)) setMode('paused');
  if (locked) $('controls-hint').textContent='WASD move · Mouse look · Shift sprint · E gather · Click attack · I inventory · B build · M map · Esc pause';
});
document.addEventListener('pointerlockerror',()=>{
  $('controls-hint').textContent='WASD move · Drag / arrows look · Shift sprint · E gather · F attack · I inventory · B build · M map';
});

function look(dx,dy) {
  player.yaw-=dx*.0020*sensitivity;
  player.pitch=THREE.MathUtils.clamp(player.pitch-dy*.0018*sensitivity,-1.25,1.25);
}
canvas.addEventListener('pointerdown',event=>{
  if (mode!=='playing' || event.button!==0) return;
  if(teethpeedCheck&&teethpeedInspection)return;
  if(document.pointerLockElement===canvas)phase3?.attack();
  canvas.focus();dragLook=true;lastMouse={x:event.clientX,y:event.clientY};requestLook();
});
document.addEventListener('pointermove',event=>{
  if (mode!=='playing') return;
  if(teethpeedCheck&&teethpeedInspection)return;
  if (document.pointerLockElement===canvas) look(event.movementX,event.movementY);
  else if (dragLook && lastMouse) {
    look(event.clientX-lastMouse.x,event.clientY-lastMouse.y);
    lastMouse={x:event.clientX,y:event.clientY};
  }
});
document.addEventListener('pointerup',()=>{dragLook=false;lastMouse=null;});
document.addEventListener('pointercancel',()=>{dragLook=false;lastMouse=null;keys.clear();});

const movementKeys=['KeyW','KeyA','KeyS','KeyD','ShiftLeft','ShiftRight','Space','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'];
document.addEventListener('keydown',event=>{
  if (event.altKey||event.ctrlKey||event.metaKey) return;
  if (event.code==='Tab' && ['ready','paused','map','cinematic','tripped','dead','inventory'].includes(mode)) {
    const panel=mode==='inventory'?$('survival-panel'):mode==='ready'?$('startup'):mode==='map'?$('map-panel'):mode==='cinematic'?$('cinematic'):mode==='tripped'?$('trip-cinematic'):mode==='dead'?$('death-panel'):$('pause-panel');
    const focusable=[...panel.querySelectorAll('button,input,a[href]')].filter(e=>!e.disabled);
    if (focusable.length) {
      const i=focusable.indexOf(document.activeElement);
      if (event.shiftKey && i<=0) {event.preventDefault();focusable.at(-1).focus();}
      else if (!event.shiftKey && (i===focusable.length-1||i<0)) {event.preventDefault();focusable[0].focus();}
    }
    return;
  }
  if (event.code==='Escape' && !event.repeat) {
    if(mode==='inventory'){event.preventDefault();openSurvival(null);return;}
    if (mode==='playing') { if (document.pointerLockElement!==canvas) setMode('paused'); }
    else if (mode==='map'||mode==='paused') resume();
    return;
  }
  if (event.code==='KeyM' && !event.repeat && ['map','playing'].includes(mode)) {
    event.preventDefault();mode==='map'?resume():setMode('map');return;
  }
  if(event.code==='KeyI'&&!event.repeat&&['playing','inventory'].includes(mode)){event.preventDefault();openSurvival(mode==='inventory'?null:'inventory');return;}
  if(event.code==='KeyB'&&!event.repeat&&mode==='playing'){event.preventDefault();phase3?.cancelBuild();openSurvival('build');return;}
  if (mode!=='playing') return;
  if(!event.repeat&&['KeyE','KeyF','KeyR'].includes(event.code)){event.preventDefault();if(event.code==='KeyE')phase3?.interact();else if(event.code==='KeyF')phase3?.attack();else phase3?.rotate();return;}
  if(!event.repeat&&/^Digit[1-6]$/.test(event.code)){phase3?.quickEquip(Number(event.code.at(-1))-1);return;}
  if (movementKeys.includes(event.code)) {
    if (event.target instanceof Element && event.target.closest('button,input,a,select,textarea')) return;
    if((foliageCheck&&foliageCameraOverride)||(teethpeedCheck&&teethpeedInspection)){event.preventDefault();return;}
    event.preventDefault();keys.add(event.code);
    if (event.code==='Space'&&!event.repeat&&grounded&&!swimming) { verticalSpeed=5.8;grounded=false; }
  }
});
document.addEventListener('keyup',event=>keys.delete(event.code));
window.addEventListener('blur',()=>{keys.clear();dragLook=false;if(mode==='playing')setMode('paused');});
document.addEventListener('visibilitychange',()=>{lastTime=0;if(document.hidden&&mode==='playing')setMode('paused');sound.activate(!document.hidden&&(mode==='playing'||mode==='cinematic'||mode==='tripped'));});
window.addEventListener('pagehide',()=>saveWorld());

function indexColliders() {
  collisionGrid.clear();
  for (const c of world.colliders) {
    const reach=c.radius+.4;
    for(let x=Math.floor((c.x-reach)/cellSize);x<=Math.floor((c.x+reach)/cellSize);x++) {
      for(let z=Math.floor((c.z-reach)/cellSize);z<=Math.floor((c.z+reach)/cellSize);z++) {
        const key=`${x},${z}`;
        if(!collisionGrid.has(key))collisionGrid.set(key,[]);
        collisionGrid.get(key).push(c);
      }
    }
  }
}

function canStand(x,z,fromX,fromZ) {
  if(x<CAVE_BOUNDS.maxX&&x>CAVE_BOUNDS.minX&&z>CAVE_BOUNDS.minZ&&z<CAVE_BOUNDS.maxZ&&isInsideCave(fromX,fromZ,footY)&&!caveWalkableAt(x,z,.34))return false;
  const floor=phase3?phase3.groundHeight(x,z):world.groundHeight(x,z);
  const fromFloor=phase3?phase3.groundHeight(fromX,fromZ):world.groundHeight(fromX,fromZ);
  if(phase3?.blocking(x,z))return false;
  if(!canTraverseGround({floor,fromFloor,footY,x,z,fromX,fromZ,waterLevel:WATER_LEVEL}))return false;
  const near=collisionGrid.get(`${Math.floor(x/cellSize)},${Math.floor(z/cellSize)}`)||[];
  for(const c of near) if(Math.hypot(x-c.x,z-c.z)<c.radius+.34)return false;
  return true;
}

function stopSwimCrossing() {
  swimPreviewCrossing=false;
  if(swimCrossButton)swimCrossButton.textContent='Cross the river';
}

function prepareSwimmingPreview() {
  // Find a continuous, walkable shore-to-shore route in the actual scenery.
  for(let z=80;z<=245;z+=3) {
    const center=riverX(z),westX=center-24,eastX=center+24;
    let clear=true,previousX=westX,previousFloor=world.groundHeight(westX,z);
    for(let x=westX;x<=eastX;x+=.4) {
      const floor=world.groundHeight(x,z);
      if(!canTraverseGround({floor,fromFloor:previousFloor,footY:Math.max(previousFloor,WATER_LEVEL-SWIM_DEPTH),x,z,fromX:previousX,fromZ:z,waterLevel:WATER_LEVEL})||world.colliders.some(c=>Math.hypot(x-c.x,z-c.z)<c.radius+.5)){clear=false;break;}
      previousX=x;previousFloor=floor;
    }
    if(clear){swimPreviewRoute={z,center,westX,eastX};break;}
  }
  if(!swimPreviewRoute){const z=80,center=riverX(z);swimPreviewRoute={z,center,westX:center-24,eastX:center+24};}
  if(!continuing)Object.assign(player,{x:swimPreviewRoute.westX,z:swimPreviewRoute.z,yaw:-Math.PI/2,pitch:-.07});
}

function placeSwimmingPreview(deep=false) {
  if(mode!=='playing')return;
  stopSwimCrossing();keys.clear();
  Object.assign(player,{x:deep?swimPreviewRoute.center:swimPreviewRoute.westX,z:swimPreviewRoute.z,yaw:-Math.PI/2,pitch:-.07});
  const floor=world.groundHeight(player.x,player.z);
  footY=Math.max(floor,WATER_LEVEL-SWIM_DEPTH);verticalSpeed=0;
  swimming=getWaterState({floor,footY,waterLevel:WATER_LEVEL}).swimming;grounded=!swimming;
  if(swimming)sound.swim({entering:true});lastSwimStroke=stepDistance;
  camera.position.set(player.x,footY+eyeHeight,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
  saveWorld();updateHUD();canvas.focus();
}

function buildSwimmingPreviewControls() {
  if(!swimmingCheck)return;
  const panel=document.createElement('aside');panel.className='encounter-check';panel.setAttribute('aria-label','Isolated swimming test controls');
  const title=document.createElement('strong');title.textContent='RIVER SWIMMING';
  swimPreviewStatus=document.createElement('output');swimPreviewStatus.textContent='WASD to swim · Shift to swim faster\nSwimming starts automatically in deep water.';
  const bank=document.createElement('button');bank.textContent='Return to riverbank';bank.addEventListener('click',()=>placeSwimmingPreview(false));
  const deep=document.createElement('button');deep.textContent='Start in deep water';deep.addEventListener('click',()=>placeSwimmingPreview(true));
  swimCrossButton=document.createElement('button');swimCrossButton.textContent='Cross the river';swimCrossButton.addEventListener('click',()=>{
    if(mode!=='playing')return;
    if(swimPreviewCrossing){stopSwimCrossing();return;}
    placeSwimmingPreview(false);swimPreviewStages=[];swimPreviewCrossing=true;swimCrossButton.textContent='Stop crossing';canvas.focus();
  });
  const reload=document.createElement('button');reload.textContent='Save and reload here';reload.addEventListener('click',()=>{
    if(mode==='playing'&&saveWorld())location.href='./index.html?continue=1&check=swimming';
  });
  panel.append(title,swimPreviewStatus,bank,deep,swimCrossButton,reload);document.body.append(panel);
}

function movePlayer(dt) {
  if(keys.has('ArrowLeft')) player.yaw+=dt*1.15*sensitivity;
  if(keys.has('ArrowRight')) player.yaw-=dt*1.15*sensitivity;
  if(keys.has('ArrowUp')) player.pitch=THREE.MathUtils.clamp(player.pitch+dt*.8*sensitivity,-1.25,1.25);
  if(keys.has('ArrowDown')) player.pitch=THREE.MathUtils.clamp(player.pitch-dt*.8*sensitivity,-1.25,1.25);
  if(swimPreviewCrossing&&['KeyW','KeyA','KeyS','KeyD'].some(key=>keys.has(key)))stopSwimCrossing();
  if(swimPreviewCrossing)player.yaw=-Math.PI/2;
  if(caveTestRoute&&['KeyW','KeyA','KeyS','KeyD'].some(key=>keys.has(key)))caveTestRoute=null;
  if(caveTestRoute){
    while(caveTestRoute.points.length&&Math.hypot(player.x-caveTestRoute.points[0].x,player.z-caveTestRoute.points[0].z)<.45)caveTestRoute.points.shift();
    if(!caveTestRoute.points.length){caveTestRoute=null;notify('Maze route completed. E collects the mineral cache.');}
    else{const target=caveTestRoute.points[0];player.yaw=Math.atan2(player.x-target.x,player.z-target.z);player.pitch=-.04;}
  }
  const automatic=swimPreviewCrossing||!!caveTestRoute;
  const f=automatic?1:Number(keys.has('KeyW'))-Number(keys.has('KeyS'));
  const s=automatic?0:Number(keys.has('KeyD'))-Number(keys.has('KeyA'));
  const moving=f!==0||s!==0;
  const waterBefore=getWaterState({floor:world.groundHeight(player.x,player.z),footY,waterLevel:WATER_LEVEL});
  const locomotion=getPlayerLocomotion({...waterBefore,moving,fastRequested:!!caveTestRoute||keys.has('ShiftLeft')||keys.has('ShiftRight'),chased:isPlayerChased(),stamina,dt});
  stamina=locomotion.stamina;
  const speed=locomotion.speed,sprint=locomotion.fast;
  let travelled=0;
  if(moving) {
    const norm=Math.hypot(f,s),sin=Math.sin(player.yaw),cos=Math.cos(player.yaw);
    const dx=(-sin*f+cos*s)/norm*speed*dt,dz=(-cos*f-sin*s)/norm*speed*dt;
    const oldX=player.x,oldZ=player.z,limit=WORLD_SIZE/2-12;
    const nx=THREE.MathUtils.clamp(oldX+dx,-limit,limit),nz=THREE.MathUtils.clamp(oldZ+dz,-limit,limit);
    if ((nx!==oldX+dx||nz!==oldZ+dz)&&elapsed-lastBoundaryNote>8) {notify('The mountain boundary marks the edge of this first map.');lastBoundaryNote=elapsed;}
    if(canStand(nx,nz,oldX,oldZ)){player.x=nx;player.z=nz;}
    else {
      if(canStand(nx,oldZ,oldX,oldZ))player.x=nx;
      if(canStand(player.x,nz,player.x,oldZ))player.z=nz;
    }
    travelled=Math.hypot(player.x-oldX,player.z-oldZ);
    stepDistance+=travelled;
    if(grounded&&!waterBefore.swimming&&stepDistance-lastStep>1.85){sound.step(surfaceAt(player.x,player.z));lastStep=stepDistance;}
  }
  visibleMovement=travelled>.001;
  if(caveTestRoute){caveTestRoute.blocked=visibleMovement?0:caveTestRoute.blocked+dt;if(caveTestRoute.blocked>1.5){caveTestRoute=null;notify('Maze test stopped at a physical obstacle.');}}
  locomotionVisual={sprinting:visibleMovement&&sprint,speed:dt>0?travelled/dt:0};
  const floor=phase3?phase3.groundHeight(player.x,player.z):world.groundHeight(player.x,player.z);
  const wasGrounded=grounded,wasSwimming=swimming;
  const motion=stepPlayerVertical({footY,verticalSpeed,grounded,floor,dt,waterLevel:WATER_LEVEL});
  footY=motion.footY;verticalSpeed=motion.verticalSpeed;grounded=motion.grounded;swimming=motion.swimming;
  if(swimPreviewCrossing){const stage=swimming?'Swim':motion.wading?'Wade':'Walk';if(swimPreviewStages.at(-1)!==stage)swimPreviewStages.push(stage);}
  if(!wasGrounded&&motion.impactSpeed>10)takeDamage((motion.impactSpeed-10)*8,'A fatal fall.');
  if(swimming&&!wasSwimming){sound.swim({entering:true});lastSwimStroke=stepDistance;}
  if(swimming&&visibleMovement&&stepDistance-lastSwimStroke>1.5){sound.swim({fast:sprint});lastSwimStroke=stepDistance;}
  if(swimming)swimTime+=dt;
  document.body.classList.toggle('swimming',swimming);
  if(swimPreviewCrossing&&(player.x>=swimPreviewRoute.eastX||travelled<.00001)) {
    stopSwimCrossing();notify(player.x>=swimPreviewRoute.eastX?'River crossed. You are back on your feet.':'Crossing stopped at an obstacle. WASD takes control.');
  }
  if(mode==='dead')return;
  // No idle camera movement; walking bob is deliberately small and optional.
  const bob=motionEffects?(swimming?Math.sin(swimTime*(visibleMovement?3.4:1.7))*(visibleMovement?.035:.018):visibleMovement&&grounded?Math.sin(stepDistance*3.8)*.025:0):0;
  camera.position.set(player.x,footY+eyeHeight+bob,player.z);
  camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
  $('movement-state').textContent=swimming?(visibleMovement?(sprint?'Swimming fast':'Swimming'):'Treading water'):!grounded?'Jumping':motion.wading?'Wading':visibleMovement?(sprint?'Sprinting':'Walking'):'Exploring';
  if(isolatedCheck)canvas.dataset.swimming=JSON.stringify({swimming,wading:motion.wading,grounded,footY,verticalSpeed,depth:WATER_LEVEL-floor,waterLevel:WATER_LEVEL,cameraY:camera.position.y,speed:visibleMovement?speed:0,stamina,health,crossing:swimPreviewCrossing});
  if(swimPreviewStatus)swimPreviewStatus.textContent=`${$('movement-state').textContent}\nWater depth: ${Math.max(0,WATER_LEVEL-floor).toFixed(2)} m\nSpeed: ${visibleMovement?speed.toFixed(1):'0.0'} m/s · Stamina: ${Math.round(stamina)}%\nTeethpeed: runs on land; cannot swim${swimPreviewStages.length?'\nCrossing: '+swimPreviewStages.join(' → '):''}`;
  for(const place of landmarks) {
    if(!discovered.has(place.id)&&Math.hypot(player.x-place.x,player.z-place.z)<(place.radius||15)) {
      discovered.add(place.id);notify(`Discovered ${place.name}`);saveWorld();
    }
  }
}

function coordinateText() {return `${Math.abs(Math.round(player.x))} ${player.x<0?'W':'E'} · ${Math.abs(Math.round(player.z))} ${player.z<0?'N':'S'}`;}
function updateHUD() {
  $('health-fill').style.width=`${health}%`;
  $('health-fill').parentElement.setAttribute('aria-valuenow',Math.ceil(health));
  $('survived-time').textContent=durationText(survivedSeconds);
  const heading=((-player.yaw*180/Math.PI)%360+360)%360;
  const points=['N','NE','E','SE','S','SW','W','NW'];
  $('compass-heading').textContent=`${points[Math.round(heading/45)%8]}  ${Math.round(heading).toString().padStart(3,'0')}°`;
  $('coordinates').textContent=coordinateText();
  $('stamina-fill').style.width=`${stamina}%`;
  $('stamina-fill').parentElement.setAttribute('aria-valuenow',Math.round(stamina));
  const closest=[...landmarks].sort((a,b)=>Math.hypot(a.x-player.x,a.z-player.z)-Math.hypot(b.x-player.x,b.z-player.z))[0];
  const biome=biomeAt(player.x,player.z);
  $('biome-name').textContent=isGlowSafeAt(player.x,player.z)?'GLOWHAVEN · SANCTUARY':biome.name.toUpperCase()+' BIOME';
  const region=closest&&Math.hypot(closest.x-player.x,closest.z-player.z)<55?closest.name:biome.name;
  if(region!==lastRegion){$('location-name').textContent=region;lastRegion=region;}
  if(waypoint) {
    const distance=Math.round(Math.hypot(player.x-waypoint.x,player.z-waypoint.z));
    $('coordinates').textContent+=` · Waypoint ${distance} m`;
    if(distance<5){waypoint=null;notify('Waypoint reached.');saveWorld();}
  }
  canvas.dataset.position=`${player.x.toFixed(2)},${footY.toFixed(2)},${player.z.toFixed(2)}`;
  canvas.dataset.heading=heading.toFixed(1);
}

function updateMap() {
  if(!chart)return;
  const focusedLandmark=document.activeElement?.dataset.landmark;
  chart.draw(player,waypoint,discovered);
  $('map-coordinates').textContent=coordinateText();
  $('waypoint-status').textContent=waypoint?`${Math.round(Math.hypot(player.x-waypoint.x,player.z-waypoint.z))} m to waypoint`:'Click the map to place a waypoint';
  $('clear-waypoint').disabled=!waypoint;
  $('landmark-list').replaceChildren(...landmarks.map(place=>{
    const item=document.createElement('button');item.type='button';item.className='landmark-item';item.dataset.landmark=place.id;
    const name=document.createElement('span');name.textContent=place.name;
    const detail=document.createElement('small');detail.textContent=`${discovered.has(place.id)?'Discovered':'Unexplored'} · ${Math.round(Math.hypot(player.x-place.x,player.z-place.z))} m`;
    item.append(name,detail);
    item.addEventListener('click',()=>{waypoint={x:place.x,z:place.z};updateMap();saveWorld();});
    return item;
  }));
  if(focusedLandmark) $('landmark-list').querySelector(`[data-landmark="${focusedLandmark}"]`)?.focus();
}

function resize() {
  if(!renderer)return;
  const w=innerWidth,h=innerHeight;
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5,Math.sqrt(1600000/(w*h))));
  renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
  if(mode==='map')updateMap();
  if(mode!=='loading'&&mode!=='error')renderer.render(scene,camera);
}
window.addEventListener('resize',resize,{passive:true});

function makeSky() {
  const geometry=new THREE.SphereGeometry(1300,32,20);
  const material=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,toneMapped:false,uniforms:{top:{value:new THREE.Color('#4c7f9d')},horizon:{value:new THREE.Color('#cbd0c5')}},vertexShader:'varying vec3 vPosition;void main(){vPosition=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`
    uniform vec3 top;uniform vec3 horizon;varying vec3 vPosition;
    float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
    float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
    void main(){
      vec3 direction=normalize(vPosition);float h=direction.y;
      vec3 color=mix(horizon,top,pow(max(h,0.),.58));
      vec2 sky=direction.xz/max(.14,h+.23)*2.4;
      float cloud=noise(sky)*.62+noise(sky*2.1)*.26+noise(sky*4.3)*.12;
      float veil=smoothstep(.48,.77,cloud)*smoothstep(.02,.22,h)*.60;
      color=mix(color,vec3(.88,.89,.85),veil);
      gl_FragColor=vec4(color,1.);
      #include <colorspace_fragment>
    }`,fog:false});
  scene.add(new THREE.Mesh(geometry,material));
  const sunDisk=new THREE.Mesh(new THREE.SphereGeometry(13,20,12),new THREE.MeshBasicMaterial({color:'#fff3cf',fog:false}));
  sunDisk.position.set(-490,380,-590);scene.add(sunDisk);
}

function tick(now) {
  requestAnimationFrame(tick);
  if(document.hidden||!renderer||mode==='loading'||mode==='error') {lastTime=0;return;}
  const wallDt=lastTime?Math.max(0,(now-lastTime)/1000):0;
  const dt=Math.min(wallDt,.05);lastTime=now;
  if(coopMode){coopMoveTime+=wallDt;if(coopMoveTime>=.1){coopMoveTime=0;sendCoopMovement();}coopPresence?.update(dt);if(!coopConnected||coopNeedsPositionSync)keys.clear();}
  if(mode==='character'){characterEditor?.update(dt);return;}
  if(isolatedCheck&&(mode==='playing'||mode==='cinematic'||mode==='tripped')){previewFrames++;previewFrameTime+=wallDt;if(previewFrameTime>=1){canvas.dataset.previewFps=(previewFrames/previewFrameTime).toFixed(1);previewFrames=0;previewFrameTime=0;}}
    if(mode==='playing'||mode==='ready'||mode==='cinematic'||mode==='tripped') {
    elapsed+=Math.min(wallDt,.25);
    if(mode==='playing') {
      if(!coopMode)survivedSeconds+=wallDt;
      let simulationTime=Math.min(wallDt,.25);
      while(simulationTime>0&&mode==='playing') {
        if((foliageCheck&&foliageCameraOverride)||(teethpeedCheck&&teethpeedInspection))keys.clear();
        const step=Math.min(.05,simulationTime);movePlayer(step);
        if(mode==='playing'&&!encounterFrozen)encounters?.update(step*(teethpeedCheck&&teethpeedLandingSlow ? .35 : 1),playerContext());
        if(mode==='playing'&&!stormFrozen)deatheater?.update(step,playerContext());
        if(mode==='playing')checkTripRisk();
        simulationTime-=step;
      }
      if(mode==='playing'){drawEncounters(encounterFrozen?0:Math.min(wallDt,.25)*(teethpeedCheck&&teethpeedLandingSlow ? .35 : 1));drawDeatheater(stormFrozen?0:Math.min(wallDt,.25));}
      if(mode==='playing'&&phase3){camera.getWorldDirection(phase3Direction);phase3.update(biomeCreaturesPaused?0:Math.min(wallDt,.25),{...player,y:footY},phase3Direction,{moving:visibleMovement,active:true,swimming,...locomotionVisual,motionEffects});if(isolatedCheck){const diagnostics=phase3.getDiagnostics();canvas.dataset.phase3=JSON.stringify(diagnostics);canvas.dataset.character=JSON.stringify(characterProfile);if(burrowpeedCheck){const status=$('burrowpeed-test-status'),b=diagnostics.burrowers;if(status&&b)status.textContent=`${b.total} dens · ${b.tipsVisible} buried\n${b.records.map(r=>`${r.stage} · ${r.remaining.toFixed(1)}s · ${r.health} health`).join('\n')||'All dens quiet.'}`;}}}
      hudTime+=wallDt;saveTime+=wallDt;
      damageFlashTime=Math.max(0,damageFlashTime-wallDt);if(damageFlashTime===0)document.body.classList.remove('injured');
      if(hudTime>.12){updateHUD();hudTime=0;}
      if(saveTime>12){saveWorld();saveTime=0;}
    }
    if(mode==='cinematic') {
      const finished=crash.update(Math.min(wallDt,.25));
      const time=crash.getState().time;
      $('cinematic-caption').textContent=time<CRASH_TIMING.engineFailure?'Far below, a river cuts through the wilderness.':time<CRASH_TIMING.airframeStress?'The engine is failing.':time<CRASH_TIMING.contact?'Losing altitude. Hold on.':time<CRASH_TIMING.settled?'Brace for impact.':'The wilderness is all that remains.';
      if(finished) finishCrash();
    } else crash.update(dt);
    if(mode==='tripped') {
      const finished=tripCutscene.update(Math.min(wallDt,.25)*((tripCheck||stormCheck) && tripPreviewSlow ? .35 : 1));
      const state=tripCutscene.getState();
      $('trip-fade').style.opacity=String(state.fade||0);
      $('trip-caption').textContent=state.swallowProgress>=1?'Swallowed whole.':state.stage==='swallowing'?'Caught in its jaws.':state.captured?'There is no escape from its mouth.':state.stage==='trip'?'Your footing gives way.':state.stage==='falling'?'You cannot get back up.':state.stage==='strike'?'One strike. One life.':'It is closing in.';
      if(isolatedCheck)canvas.dataset.tripCutscene=JSON.stringify({...state,events:tripEvents,health,deathCommitted:!!tripDeath});
      if(finished)finishFatalTrip();
    }
    if(foliageCheck&&foliageCameraOverride&&mode==='playing') {
      camera.position.copy(foliageCameraOverride.position);camera.lookAt(foliageCameraOverride.target);
      $('movement-state').textContent='Canopy inspection';
    }
    if(teethpeedCheck&&teethpeedInspection)drawTeethpeedInspection(mode==='playing'?Math.min(wallDt,.25):0);
    drawTeethpeedLandingCamera();
    if(directionalSun && (mode==='playing'||mode==='tripped')) {
      worldShadows.update(player,footY);
    }
    if(!foliageWindFrozen)foliageWindTime=elapsed;
    world.update(foliageCheck?foliageWindTime:elapsed,dt,camera.position);
    const forest=forestBlendAt(camera.position.x,camera.position.z);
    const storm=stormBlendAt(camera.position.x,camera.position.z);
    const glow=glowBlendAt(camera.position.x,camera.position.z);
    const underground=isInsideCave(player.x,player.z,footY);
    const flash=stormWeather?.update(elapsed,Math.min(wallDt,.25),camera.position,storm,{reducedMotion:!motionEffects,viewHeading:player.yaw})||0;
    scene.fog.color.copy(valleyFog).lerp(forestFog,forest*.88).lerp(glowFog,glow*.9).lerp(stormFog,storm).lerp(lightningFog,Math.min(.58,flash*storm*.65));
    scene.fog.density=THREE.MathUtils.lerp(THREE.MathUtils.lerp(THREE.MathUtils.lerp(.0014,.0048,forest),.006,glow),.0085,storm);
    scene.environmentIntensity=THREE.MathUtils.lerp(THREE.MathUtils.lerp(THREE.MathUtils.lerp(.68,.56,forest),.32,glow),.25,storm)+flash*.24;
    scene.backgroundIntensity=THREE.MathUtils.lerp(THREE.MathUtils.lerp(.65,.28,glow),.16,storm);
    if(directionalSun){directionalSun.intensity=THREE.MathUtils.lerp(THREE.MathUtils.lerp(1.85,.55,glow),.28,storm)+flash*1.9;directionalSun.color.set('#f5eddd').lerp(lightningFog,Math.min(.7,flash*storm));}
    if(underground){scene.environmentIntensity=.075;scene.fog.color.set('#252923');scene.fog.density=.014;if(directionalSun)directionalSun.intensity=.045;}
    sound.storm(storm);
    if(isolatedCheck)canvas.dataset.biomes=JSON.stringify({region:biomeAt(player.x,player.z).id,safe:isGlowSafeAt(player.x,player.z),glow:world.glowDiagnostics,shadows:worldShadows.diagnostics()});
    if(mode==='playing'||mode==='cinematic'||mode==='tripped')updateWorldAudio(Math.min(wallDt,.25));
    canvas.dataset.storm=storm.toFixed(2);
    if(isolatedCheck&&stormWeather)canvas.dataset.lightning=JSON.stringify(stormWeather.lightningState());
    renderer.render(scene,camera);
    if(isolatedCheck){
      previewRenderTime+=wallDt;
      if(previewRenderTime>=.5){
        previewRenderTime=0;
        const fps=Number(canvas.dataset.previewFps)||null;
        canvas.dataset.renderStats=JSON.stringify({calls:renderer.info.render.calls,triangles:renderer.info.render.triangles,fps,frameMs:fps?1000/fps:null});
      }
    }
  }
}

async function initialize() {
  try {
    if(coopMode){
      const session=readMultiplayerSession();if(!session){location.replace('../multiplayer/');return;}
      coopBar=document.createElement('output');coopBar.setAttribute('aria-live','polite');coopBar.style.cssText='position:fixed;top:10px;left:50%;transform:translateX(-50%);z-index:40;background:#112920e6;color:#e6dfbd;padding:8px 16px;border:1px solid #92986a88;font:12px Segoe UI;border-radius:4px;max-width:50vw;text-align:center';document.body.append(coopBar);
      coopClient=createMultiplayerClient({baseUrl:session.baseUrl,token:session.token,onSnapshot:receiveCoopSnapshot,onStatus:receiveCoopStatus});
      await coopClient.connect();if(coopSnapshot.status!=='playing'){location.replace('../multiplayer/');return;}
      document.body.dataset.coop='true';
      if(coopSnapshot.self.alive)await coopClient.move({position:coopSnapshot.self.position,yaw:coopSnapshot.self.yaw,pitch:coopSnapshot.self.pitch,mode:'character',motion:'idle'});
    }
    $('loading-status').textContent='Preparing the alpine valley…';
    renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
    renderer.localClippingEnabled=true;
    renderer.outputColorSpace=THREE.SRGBColorSpace;
    renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.02;
    renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    scene=new THREE.Scene();scene.background=new THREE.Color('#b6c7ca');scene.fog=new THREE.FogExp2('#9eaeb1',.0014);
    camera=new THREE.PerspectiveCamera(68,innerWidth/innerHeight,.09,2000);scene.add(camera);
    $('loading-status').textContent='Loading the sky and natural lighting…';
    const sky=await new HDRLoader().loadAsync('./assets/sky/partly-cloudy-2k.hdr');
    sky.mapping=THREE.EquirectangularReflectionMapping;
    scene.background=sky;scene.environment=sky;
    scene.backgroundIntensity=.65;scene.environmentIntensity=.68;
    scene.backgroundRotation.set(0,-1.3,0);scene.environmentRotation.set(0,-1.3,0);
    scene.add(new THREE.HemisphereLight('#d5e5ec','#454b37',.48));
    const sun=new THREE.DirectionalLight('#f5eddd',1.85);sun.position.set(-120,180,-130);directionalSun=sun;
    worldShadows=createWorldShadows({sun,renderer});worldShadows.update(spawn,0);
    scene.add(sun);scene.add(sun.target);
    // Yield once so the loading state paints before geometry generation.
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    $('loading-status').textContent='Loading forest materials and shaping the river valley…';
    world=await createWorld(scene);
    stormWeather=createStormWeather({scene,heightAt:world.groundHeight,onThunder:strength=>sound.thunder(strength)});
    teethpeedSurfaceTexture=await new THREE.TextureLoader().loadAsync('./assets/creatures/teethpeed-chitin-v2.png');
    teethpeedSurfaceTexture.colorSpace=THREE.SRGBColorSpace;
    teethpeedSurfaceTexture.wrapS=teethpeedSurfaceTexture.wrapT=THREE.RepeatWrapping;
    teethpeedSurfaceTexture.anisotropy=8;
    $('loading-status').textContent='Preparing creature movement…';
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    // Compile and upload the real clipped body, soil and shadow materials while
    // the loading overlay is visible. The same view is adopted by the runtime.
    prewarmedBurrowpeedView=createBurrowpeedModel({surfaceTexture:teethpeedSurfaceTexture});
    const warmPosition=camera.position.clone(),warmRotation=camera.quaternion.clone(),warmGround=world.groundHeight(spawn.x,spawn.z);
    prewarmedBurrowpeedView.group.position.set(spawn.x,warmGround,spawn.z);scene.add(prewarmedBurrowpeedView.group);
    prewarmedBurrowpeedView.animate({time:0,stage:'emerging',progress:.5,groundHeightAt:world.groundHeight});
    camera.position.set(spawn.x+6,warmGround+4,spawn.z+7);camera.lookAt(spawn.x,warmGround+.5,spawn.z+1);
    renderer.render(scene,camera);
    prewarmedBurrowpeedView.group.visible=false;prewarmedBurrowpeedView.group.removeFromParent();camera.position.copy(warmPosition);camera.quaternion.copy(warmRotation);
    tripCutscene=createTripCutscene({scene,camera,heightAt:world.groundHeight,surfaceTexture:teethpeedSurfaceTexture,reducedMotion:()=>!motionEffects,onEvent:event=>{
      tripEvents.push(event.type);sound.tripEvent(event.type,event.kind);sound.devourEvent(event.type);
      if(event.type==='strike'){$('trip-caption').textContent='One strike. One life.';}
    }});
    crash=createCrashSequence({scene,camera,riverX,heightAt,waterLevel:WATER_LEVEL,reducedMotion:()=>!motionEffects,onEvent:event=>{
      if(mode!=='cinematic')return;
      crashEvents.push(event.type);
      const p=event.position||crash.getState().position;
      sound.crashEvent(event.type,{...event,position:p,distance:Math.hypot(camera.position.x-p.x,camera.position.y-p.y,camera.position.z-p.z)});
    }});
    world.colliders.push(...crash.colliders);indexColliders();
    Object.assign(player,crash.survivor);loadSavedWorld();
    if(coopMode){
      const self=coopSnapshot.players.find(p=>p.id===coopSnapshot.selfId),position=self.position;
      Object.assign(player,{x:position.x,z:position.z,yaw:self.yaw||0,pitch:self.pitch||0});footY=position.y;health=coopSnapshot.self.health;survivedSeconds=coopSnapshot.self.survivedSeconds||0;
      characterProfile=normalizeCharacterProfile({...self.character,name:self.name});journey={runId:`coop-${coopSnapshot.code}`,status:coopSnapshot.self.alive?'alive':'dead'};continuing=true;journeyStarted=true;runPersisted=true;storageWorks=true;restoredMotion={footY,verticalSpeed:0,grounded:true};
      const {createCoopCreatureViews}=await import('./coop-creature-views.js');
      coopCreatures=createCoopCreatureViews({scene,world,surfaceTexture:teethpeedSurfaceTexture,prewarmedView:prewarmedBurrowpeedView});prewarmedBurrowpeedView=null;
      coopPresence=createCoopPresence({scene,camera,selfId:coopSnapshot.selfId});
      encounters={update(){},getActive:()=>coopSnapshot.world?.creatures?.teethpeeds||[],snapshot:()=>coopSnapshot.world?.creatures?.teethpeedState};
      deatheater={update(){},getActive:()=>coopSnapshot.world?.creatures?.deatheaters||[],snapshot:()=>coopSnapshot.world?.creatures?.deatheaterState||{warningIssued:false}};
      crash.finish();
    }
    if(teethpeedCheck&&!continuing){crash.finish();prepareEncounterPreview();}
    if(stormCheck&&!continuing){crash.finish();Object.assign(player,STORM_PREVIEW_SPAWN);}
    if(biomesCheck&&!continuing){crash.finish();Object.assign(player,GLOW_PREVIEW_SPAWN);}
    if(foliageCheck&&!continuing){crash.finish();inspectFoliage('valley');}
    if(swimmingCheck){crash.finish();prepareSwimmingPreview();}
    if(tripCheck&&!continuing){crash.finish();prepareEncounterPreview();player.pitch=-.03;}
    if(continuing)setupPhase3();
    if(continuing) {
      crash.finish();$('startup-title').textContent='The wilderness awaits.';
      $('enter-world').innerHTML='Continue your journey <span aria-hidden="true">→</span>';
      document.querySelector('.startup-copy').textContent='Continue this life where you left off. Stay alive. Death ends this journey permanently.';
    } else if(continuationUnavailable) {
      $('startup-title').textContent='A new life awaits.';
      document.querySelector('.startup-copy').textContent='Your previous life cannot be continued. Begin a new journey. Stay alive.';
    }
    if(teethpeedCheck&&!continuing){$('startup-title').textContent='Beneath the giants.';$('enter-world').textContent='Enter the forest preview';document.querySelector('.startup-copy').textContent='Inspect the Teethpeed’s body, jaws, and crawling motion safely. Trigger a live tree encounter when you are ready to test its attack. This preview uses a separate save.';}
    if(stormCheck&&!continuing){$('startup-title').textContent='Into the storm.';$('enter-world').textContent='Enter the storm preview';document.querySelector('.startup-copy').textContent='A separate test life in the withered Stormlands. Watch for the Deatheater overhead. Its dive is fast: dodge sideways when it commits.';}
    if(foliageCheck&&!continuing){$('startup-title').textContent='Roots to canopy.';$('enter-world').textContent='Inspect the trees';document.querySelector('.startup-copy').textContent='A separate scenery preview. Examine the valley and rainforest trees while their branches move in the wind.';}
    if(crashCheck&&!continuing){$('startup-title').textContent='The last flight.';$('enter-world').textContent='Play the crash opening';document.querySelector('.startup-copy').textContent='Follow the aircraft down the valley as its engine fails, then survive the river impact. This 26-second preview uses its own save.';}
    if(swimmingCheck&&!continuing){$('startup-title').textContent='Into the river.';$('enter-world').textContent='Enter the swimming preview';document.querySelector('.startup-copy').textContent='Wade in from the bank, then swim across the river. WASD moves you and Shift swims faster. Teethpeeds stay on land. This preview uses a separate save.';}
    if(tripCheck&&!continuing){$('startup-title').textContent='One wrong step.';$('enter-world').textContent='Enter the trip preview';document.querySelector('.startup-copy').textContent='See each creature’s fatal trip sequence in a separate test life. The preview buttons force the outcome; normal play uses a 10% chance while being chased.';}
    if(phase3Check&&!continuing){$('startup-title').textContent='Make a life here.';$('enter-world').textContent='Enter Phase 3 preview';document.querySelector('.startup-copy').textContent='Gather, craft, hunt and build across nine biomes. This preview uses a separate life and includes clearly marked test controls.';}
    if(!coopMode&&!canStand(player.x,player.z,player.x,player.z)) {
      Object.assign(player,{x:spawn.x,z:spawn.z,yaw:spawn.yaw,pitch:-.035});
      restoredMotion=null;
    }
    if(coopMode)correctCoopPosition(coopSnapshot);
    else footY=Math.max(world.groundHeight(player.x,player.z),WATER_LEVEL-SWIM_DEPTH);
    if(!coopMode&&continuing&&restoredMotion&&!restoredMotion.grounded&&restoredMotion.footY>footY) {
      footY=restoredMotion.footY;verticalSpeed=restoredMotion.verticalSpeed;grounded=false;
    }
    if(!coopMode)swimming=verticalSpeed<=0&&getWaterState({floor:world.groundHeight(player.x,player.z),footY,waterLevel:WATER_LEVEL}).swimming;
    if(swimming){grounded=false;verticalSpeed=0;}
    camera.position.set(player.x,footY+eyeHeight,player.z);camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
    chart=createMap({canvas:$('world-map'),landmarks,heightAt,riverX,WORLD_SIZE,waterLevel:WATER_LEVEL,onWaypoint:point=>{waypoint=point;updateMap();saveWorld();},getNetworkState:()=>coopMode?coopSnapshot:null});
    buildEncounterPreviewControls();buildStormPreviewControls();buildFoliagePreviewControls();buildSwimmingPreviewControls();buildTripPreviewControls();buildAudioPreviewControls();buildPhase3PreviewControls();resize();renderer.render(scene,camera);updateHUD();
    $('loading').hidden=true;canvas.dataset.renderer='webgl2';
    setMode('ready');buildCharacterPreviewControls();
    tripCutscene?.setProfile(characterProfile);
    if(coopMode){receiveCoopSnapshot(coopSnapshot);document.querySelector('.pause-copy')?.append(document.createTextNode(' Your friends and the shared world continue while you use menus.'));if(coopSnapshot.self.alive)openCharacterEditor();else showEndedLife(coopSnapshot.self.deathCause||'This co-op life has ended.');
      if(checkMode==='coop'){const {createCoopTestControls}=await import('./coop-test-controls.js');createCoopTestControls({lookDown:()=>{player.pitch=-.8;camera.rotation.set(player.pitch,player.yaw,0,'YXZ');},onWalk:()=>{keys.add('KeyW');setTimeout(()=>keys.delete('KeyW'),1200);},onTurn:amount=>{player.yaw+=amount;},onFaceResource:()=>{const n=phase3.camp.getResourceNodes().filter(n=>!n.mineable&&!n.reward).sort((a,b)=>Math.hypot(a.x-player.x,a.z-player.z)-Math.hypot(b.x-player.x,b.z-player.z))[0];if(n){player.yaw=Math.atan2(player.x-n.x,player.z-n.z);player.pitch=-.65;notify((ITEMS[n.item]?.name||n.item)+' · '+Math.round(Math.hypot(n.x-player.x,n.z-player.z))+' m');}},onInteract:()=>phase3.interact(),onAttack:()=>phase3.attack(),onInventory:()=>openSurvival('inventory'),isPlaying:()=>mode==='playing'});}}
    else if(!continuing&&(!isolatedCheck||characterCheck))openCharacterEditor();
    requestAnimationFrame(tick);
  } catch(error) {
    console.error('The wilderness could not start.',error);
    mode='error';$('loading').hidden=true;$('startup').hidden=true;$('error-panel').hidden=false;
    $('error-message').textContent=coopMode?`Co-op could not start: ${error.message}`:'The 3D world could not start in this browser. Try reopening it in a browser with hardware acceleration enabled.';
    canvas.dataset.renderer='unavailable';
  }
}
initialize();



