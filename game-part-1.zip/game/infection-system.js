import { biomeAt, isGlowSafeAt, lavaAt } from './biomes.js';
import { riverBankDistanceAt } from './river-network.js';

export const INFECTION_NODE_LIMIT = 128;
export const INFECTION_CLEAR_GRACE = 20;
export const INFECTION_INITIAL_NODES = 3;
export const INFECTION_INITIAL_RADIUS = 2.45;
const BOUND = 860, FLOOR = 2.6, CELL = 24;
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const copyPoint = p => ({ x:p.x, y:p.y, z:p.z });
const distance = (a,b) => Math.hypot(a.x-b.x,a.z-b.z);
const validPoint = p => p && [p.x,p.y,p.z].every(Number.isFinite) && Math.abs(p.x)<900 && Math.abs(p.z)<900 && Math.abs(p.y)<1000;
const uint = v => Number.isSafeInteger(v) && v>=0;
function seedValue(seed) { let n=2166136261; for(const c of String(seed)) n=Math.imul(n^c.charCodeAt(0),16777619); return n>>>0; }
function copyNode(node) { return {...node,position:copyPoint(node.position),path:(node.path||[]).map(copyPoint)}; }

export function normalizeInfectionState(state) {
  if(state===undefined)return undefined;
  if(!state||state.version!==1||typeof state.seed!=='string'||state.seed.length>512||!uint(state.randomState)||state.randomState>0xffffffff||!uint(state.cycle)||state.cycle<1||!uint(state.revision)||!uint(state.serial)||!uint(state.totalSpawned)||!Number.isFinite(state.clock)||state.clock<0||!['spreading','cleared'].includes(state.stage)||!validPoint(state.origin)||!Array.isArray(state.nodes)||state.nodes.length>INFECTION_NODE_LIMIT||!Array.isArray(state.destroyedIds)||state.destroyedIds.length>4096)return null;
  if(!Number.isFinite(state.clearRemaining)||state.clearRemaining<0||state.clearRemaining>INFECTION_CLEAR_GRACE||!Number.isFinite(state.spreadRemaining)||state.spreadRemaining<0||state.spreadRemaining>30||state.stage==='cleared'&&state.nodes.length||state.stage==='spreading'&&!state.nodes.length)return null;
  const ids=new Set(),nodes=[];
  for(const node of state.nodes){
    if(!node||typeof node.id!=='string'||!/^infection-\d+-\d+$/.test(node.id)||!node.id.startsWith(`infection-${state.cycle}-`)||Number(node.id.split('-')[2])>state.serial||ids.has(node.id)||!validPoint(node.position)||!Number.isFinite(node.radius)||node.radius<1||node.radius>4||!Number.isFinite(node.maxHealth)||node.maxHealth<1||node.maxHealth>500||!Number.isFinite(node.health)||node.health<=0||node.health>node.maxHealth||!Number.isFinite(node.resistance)||node.resistance<0||node.resistance>.6||!Number.isFinite(node.bornAt)||node.bornAt<0||node.bornAt>state.clock||node.parentId!==null&&typeof node.parentId!=='string')return null;
    const territoryRadius=node.territoryRadius??node.radius,path=node.path??[];
    if(!Number.isFinite(territoryRadius)||territoryRadius<node.radius||territoryRadius>16||!Array.isArray(path)||path.length>10||!path.every(validPoint))return null;
    ids.add(node.id);nodes.push(copyNode({...node,territoryRadius,path}));
  }
  const destroyedIds=[];
  for(const id of state.destroyedIds){if(typeof id!=='string'||!/^infection-\d+-\d+$/.test(id)||!id.startsWith(`infection-${state.cycle}-`)||Number(id.split('-')[2])>state.serial||ids.has(id)||destroyedIds.includes(id))return null;destroyedIds.push(id);}
  if(state.serial<state.totalSpawned||state.totalSpawned<nodes.length+destroyedIds.length)return null;
  return {version:1,seed:state.seed,randomState:state.randomState,cycle:state.cycle,clock:state.clock,revision:state.revision,serial:state.serial,totalSpawned:state.totalSpawned,stage:state.stage,origin:copyPoint(state.origin),clearRemaining:state.clearRemaining,spreadRemaining:state.spreadRemaining,nodes,destroyedIds};
}

/** The server supplies active simulation time. Rejoining or restarting never rolls a new outbreak. */
export function createInfectionSystem({heightAt,colliders=[],seed='cooperative-infection',state,onEvent=()=>{}}={}) {
  if(typeof heightAt!=='function')throw new TypeError('Infection requires terrain heights.');
  const restored=normalizeInfectionState(state);
  if(state!==undefined&&!restored)throw new TypeError('Invalid infection save state.');
  const runSeed=restored?.seed??String(seed);
  let randomState=restored?.randomState??seedValue(runSeed),cycle=restored?.cycle??0,clock=restored?.clock??0,revision=restored?.revision??0,serial=restored?.serial??0,totalSpawned=restored?.totalSpawned??0;
  let stage=restored?.stage??'spreading',origin=restored?.origin??null,clearRemaining=restored?.clearRemaining??0,spreadRemaining=restored?.spreadRemaining??25,disposed=false;
  const nodes=new Map((restored?.nodes||[]).map(n=>[n.id,copyNode(n)]));
  let destroyedIds=[...(restored?.destroyedIds||[])],grid=new Map();
  function rng(){randomState=(randomState+0x6d2b79f5)>>>0;let n=randomState;n=Math.imul(n^(n>>>15),n|1);n^=n+Math.imul(n^(n>>>7),n|61);return((n^(n>>>14))>>>0)/4294967296;}
  function refreshGrid(){
    // Growth is infrequent. Rebuild here so a felled tree replaced by a new
    // wall is detected even when the collider array keeps the same length.
    grid=new Map();
    for(const c of colliders){if(!c||![c.x,c.z,c.radius].every(Number.isFinite)||c.radius<=0)continue;const reach=c.radius+4.5;for(let x=Math.floor((c.x-reach)/CELL);x<=Math.floor((c.x+reach)/CELL);x++)for(let z=Math.floor((c.z-reach)/CELL);z<=Math.floor((c.z+reach)/CELL);z++){const key=`${x}:${z}`;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(c);}}
  }
  function usable(x,z,radius,{valley=false}={}){
    if(Math.abs(x)+radius>=BOUND||Math.abs(z)+radius>=BOUND||riverBankDistanceAt(x,z)<radius+.8)return null;
    const y=heightAt(x,z);if(!Number.isFinite(y)||y<FLOOR)return null;
    function pointOkay(px,pz){const h=heightAt(px,pz),biome=biomeAt(px,pz).id;return Number.isFinite(h)&&h>=FLOOR&&Math.abs(h-y)<=radius*.58+.2&&!isGlowSafeAt(px,pz)&&!lavaAt(px,pz)&&biome!=='ocean'&&biome!=='cave'&&(!valley||biome==='valley');}
    // Dense rings plus interior samples keep the entire initial footprint within the valley,
    // and keep all later roots clear of sanctuary edges, rivers and dangerous terrain.
    const extent=radius+.45;
    for(let dx=-extent;dx<=extent+.01;dx+=.8)for(let dz=-extent;dz<=extent+.01;dz+=.8)if(dx*dx+dz*dz<=extent*extent&&!pointOkay(x+dx,z+dz))return null;
    for(let i=0;i<32;i++){const a=i*Math.PI/16;if(!pointOkay(x+Math.cos(a)*extent,z+Math.sin(a)*extent))return null;}
    for(const c of grid.get(`${Math.floor(x/CELL)}:${Math.floor(z/CELL)}`)||[])if(Math.hypot(c.x-x,c.z-z)<c.radius+radius+.35)return null;
    return{x,y,z};
  }
  function difficulty(){const level=clamp(1+Math.floor(totalSpawned/8),1,5);return{level,maxHealth:48+(level-1)*24,resistance:(level-1)*.08,spreadInterval:Math.max(8,25-(level-1)*4),branches:level>=4?2:1,contactDamage:3+(level-1)*2};}
  function emit(type,extra={}){revision++;onEvent({type,cycle,clock,...extra});}
  function addNode(position,radius,parentId=null,territoryRadius=radius,path=[]){
    const d=difficulty(),node={id:`infection-${cycle}-${++serial}`,position:copyPoint(position),radius,territoryRadius,path:path.map(copyPoint),health:d.maxHealth,maxHealth:d.maxHealth,resistance:d.resistance,bornAt:clock,parentId};
    nodes.set(node.id,node);totalSpawned++;return node;
  }
  function beginPatch(){
    refreshGrid();const oldOrigin=origin;
    let found=null;
    for(let attempt=0;attempt<12000&&!found;attempt++){
      const x=-415+rng()*840,z=-420+rng()*855;
      if(oldOrigin&&distance({x,z},oldOrigin)<100||Math.hypot(x+65,z-95)<55)continue;
      const centre=usable(x,z,INFECTION_INITIAL_RADIUS,{valley:true});if(!centre)continue;
      const angle=rng()*Math.PI*2,positions=[centre];
      for(let branch=0;branch<2;branch++){
        const a=angle+branch*2.5,px=x+Math.cos(a)*3.45,pz=z+Math.sin(a)*3.45,p=usable(px,pz,2.15,{valley:true});
        if(!p)break;positions.push(p);
      }
      if(positions.length===INFECTION_INITIAL_NODES)found=positions;
    }
    if(!found)throw new Error('Could not place an infection patch entirely inside an unobstructed valley.');
    cycle++;serial=0;totalSpawned=0;destroyedIds=[];nodes.clear();origin=copyPoint(found[0]);stage='spreading';clearRemaining=0;spreadRemaining=25;
    const root=addNode(found[0],INFECTION_INITIAL_RADIUS);
    for(const p of found.slice(1))addNode(p,2.15,root.id,2.15,[root.position,p]);
    emit('infection-started',{origin:copyPoint(origin),count:nodes.size});
  }
  function spread(){
    refreshGrid();const d=difficulty(),newIds=[];
    for(let branch=0;branch<d.branches&&nodes.size<INFECTION_NODE_LIMIT;branch++){
      const parents=[...nodes.values()],mature=totalSpawned>=8;let added=false;
      for(let attempt=0;attempt<220&&!added;attempt++){
        // Frontier preference makes neglect expand across the landscape rather
        // than exhausting the bounded node budget in one dense clump.
        const ranked=mature?parents.map(n=>({n,score:distance(n.position,origin)+rng()*35})).sort((a,b)=>b.score-a.score):null;
        const parent=mature&&rng()<.78?ranked[Math.floor(rng()*Math.min(8,ranked.length))].n:parents[Math.floor(rng()*parents.length)];
        const radius=2.1+rng()*.65,outward=Math.atan2(parent.position.z-origin.z,parent.position.x-origin.x),a=mature&&rng()<.75?outward+(rng()-.5)*2.6:rng()*Math.PI*2,reach=mature?18+rng()*10:(parent.radius+radius)*(.82+rng()*.10);
        const x=parent.position.x+Math.cos(a)*reach,z=parent.position.z+Math.sin(a)*reach;
        if([...nodes.values()].some(n=>n.id!==parent.id&&distance({x,z},n.position)<(mature?12:(radius+n.radius)*.73)))continue;
        const p=usable(x,z,radius);if(!p)continue;
        const path=rootPath(parent.position,p);if(!path)continue;
        const node=addNode(p,radius,parent.id,mature?Math.min(14,reach*.5):radius,path);newIds.push(node.id);added=true;
      }
    }
    const next=difficulty();for(const node of nodes.values())node.resistance=next.resistance;
    spreadRemaining=next.spreadInterval;
    if(newIds.length)emit('infection-spread',{nodeIds:newIds,difficulty:next.level,count:nodes.size});
  }
  function pathPointSafe(x,z,previous){
    const y=heightAt(x,z);if(!Number.isFinite(y)||y<FLOOR||isGlowSafeAt(x,z)||lavaAt(x,z)||biomeAt(x,z).id==='cave'||riverBankDistanceAt(x,z)<.55)return false;
    if(previous&&Math.abs(y-previous.y)>distance({x,z},previous)*.9+.08)return false;
    for(const c of grid.get(`${Math.floor(x/CELL)}:${Math.floor(z/CELL)}`)||[])if(Math.hypot(x-c.x,z-c.z)<c.radius+.32)return false;
    return{x,y,z};
  }
  function rootPath(a,b){
    const dx=b.x-a.x,dz=b.z-a.z,length=distance(a,b),waypoints=[];
    for(const bend of [0,4,-4,7,-7]){
      const middle={x:(a.x+b.x)*.5-dz/length*bend,z:(a.z+b.z)*.5+dx/length*bend};
      middle.y=heightAt(middle.x,middle.z);const route=bend?[a,middle,b]:[a,b];let previous=a,valid=true;
      for(let leg=1;leg<route.length&&valid;leg++){
        const from=route[leg-1],to=route[leg],steps=Math.ceil(distance(from,to)/.65);
        for(let i=1;i<=steps;i++){const t=i/steps,p=pathPointSafe(from.x+(to.x-from.x)*t,from.z+(to.z-from.z)*t,previous);if(!p){valid=false;break;}previous=p;}
      }
      if(!valid)continue;
      waypoints.length=0;waypoints.push(copyPoint(a));
      for(let leg=1;leg<route.length;leg++){const from=route[leg-1],to=route[leg],steps=Math.max(1,Math.ceil(distance(from,to)/5));for(let i=1;i<=steps;i++){const t=i/steps,x=from.x+(to.x-from.x)*t,z=from.z+(to.z-from.z)*t;waypoints.push({x:Math.round(x*1000)/1000,y:Math.round(heightAt(x,z)*1000)/1000,z:Math.round(z*1000)/1000});}}
      if(waypoints.length<=10)return waypoints;
    }
    return null;
  }
  function exposureAt(position){
    if(disposed||!validPoint(position)||isGlowSafeAt(position.x,position.z)||lavaAt(position.x,position.z)||riverBankDistanceAt(position.x,position.z)<.1)return 0;
    const floor=heightAt(position.x,position.z);if(!Number.isFinite(floor)||floor<FLOOR||Math.abs(position.y-floor)>2.5)return 0;
    for(const n of nodes.values()){
      if(distance(position,n.position)<n.territoryRadius)return 1;
      for(let i=1;i<n.path.length;i++){const a=n.path[i-1],b=n.path[i],dx=b.x-a.x,dz=b.z-a.z,len=dx*dx+dz*dz,t=clamp(((position.x-a.x)*dx+(position.z-a.z)*dz)/(len||1),0,1);if(Math.hypot(position.x-a.x-dx*t,position.z-a.z-dz*t)<.42)return .65;}
    }
    return 0;
  }
  function snapshot(){return{version:1,seed:runSeed,randomState,cycle,clock,revision,serial,totalSpawned,stage,origin:copyPoint(origin),clearRemaining,spreadRemaining,difficulty:difficulty(),nodes:[...nodes.values()].map(n=>({...copyNode(n),age:clock-n.bornAt})),destroyedIds:[...destroyedIds]};}
  function update(dt){
    if(disposed||!Number.isFinite(dt)||dt<=0)return;
    let remaining=Math.min(dt,3600);
    while(remaining>1e-8){
      const timer=stage==='cleared'?clearRemaining:spreadRemaining,step=Math.min(remaining,Math.max(0,timer));
      clock+=step;remaining-=step;
      if(stage==='cleared'){clearRemaining=Math.max(0,clearRemaining-step);if(clearRemaining<=1e-8)beginPatch();}
      else{spreadRemaining=Math.max(0,spreadRemaining-step);if(spreadRemaining<=1e-8)spread();}
    }
  }
  function damage(id,amount){
    const node=nodes.get(id);if(disposed||!node||!Number.isFinite(amount)||amount<=0)return{hit:false};
    const applied=Math.max(.1,Math.min(1000,amount)*(1-node.resistance));node.health=Math.max(0,node.health-applied);
    const killed=node.health===0;
    if(killed){nodes.delete(id);destroyedIds.push(id);if(destroyedIds.length>4096)destroyedIds.shift();emit('infection-destroyed',{id,position:copyPoint(node.position),remaining:nodes.size});}
    else emit('infection-damaged',{id,health:node.health});
    if(!nodes.size){stage='cleared';clearRemaining=INFECTION_CLEAR_GRACE;emit('infection-cleared',{origin:copyPoint(origin),nextOutbreakIn:INFECTION_CLEAR_GRACE});}
    return{hit:true,id,kind:'infection-node',name:'Infection heart',damage:applied,killed,health:node.health,remaining:nodes.size};
  }
  if(!restored)beginPatch();
  return{update,snapshot,damage,exposureAt,getTargets:()=>[...nodes.values()].map(n=>({...copyNode(n),kind:'infection-node',name:'Infection heart',age:clock-n.bornAt})),dispose(){disposed=true;nodes.clear();}};
}
