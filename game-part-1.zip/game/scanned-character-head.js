import * as THREE from './vendor/three.module.js';
import {normalizeCharacterProfile,SKIN_TONES,HAIR_COLORS} from './character-profile.js';

// Infinite, 3D Head Scan by Lee Perry-Smith / Infinite Realities, CC BY 3.0.
// See assets/character/LeePerrySmith_License.txt and asset-credits.md.
// This reader deliberately supports only the bundled, uncompressed static GLB.
const assetRoot=new URL('./assets/character/',import.meta.url);
let sourcePromise;
export function preloadScannedHead(){
  if(!sourcePromise)sourcePromise=loadSource().catch(error=>{sourcePromise=null;throw error;});
  return sourcePromise;
}
async function loadSource(){
  const loader=new THREE.TextureLoader();
  const [response,color,normal,specular]=await Promise.all([
    fetch(new URL('LeePerrySmith.glb',assetRoot)),
    loader.loadAsync(new URL('Map-COL.jpg',assetRoot).href),
    loader.loadAsync(new URL('Infinite-Level_02_Tangent_SmoothUV.jpg',assetRoot).href),
    loader.loadAsync(new URL('Map-SPEC.jpg',assetRoot).href)
  ]);
  if(!response.ok)throw new Error('The survivor scan could not be loaded.');
  const data=await response.arrayBuffer(),header=new DataView(data);
  if(header.getUint32(0,true)!==0x46546c67||header.getUint32(4,true)!==2)throw new Error('Invalid survivor scan.');
  let descriptor,binOffset;
  for(let offset=12;offset<data.byteLength;){
    const length=header.getUint32(offset,true),type=header.getUint32(offset+4,true);
    if(type===0x4e4f534a)descriptor=JSON.parse(new TextDecoder().decode(new Uint8Array(data,offset+8,length)));
    if(type===0x004e4942)binOffset=offset+8;
    offset+=8+length;
  }
  const primitive=descriptor.meshes[0].primitives[0];let geometry=new THREE.BufferGeometry();
  function attribute(id){
    const a=descriptor.accessors[id],v=descriptor.bufferViews[a.bufferView];
    if(v.byteStride||a.sparse)throw new Error('Unsupported survivor vertex layout.');
    const count={SCALAR:1,VEC2:2,VEC3:3}[a.type],Type={5123:Uint16Array,5126:Float32Array}[a.componentType];
    return new THREE.BufferAttribute(new Type(data,binOffset+(v.byteOffset||0)+(a.byteOffset||0),a.count*count).slice(),count);
  }
  geometry.setAttribute('position',attribute(primitive.attributes.POSITION));
  geometry.setAttribute('normal',attribute(primitive.attributes.NORMAL));
  geometry.setAttribute('uv',attribute(primitive.attributes.TEXCOORD_0));
  geometry.setIndex(attribute(primitive.indices));
  const p=geometry.attributes.position;
  for(let i=0;i<p.count;i++){
    const y=(p.getY(i)+2.92)*.045,neckBlend=1-THREE.MathUtils.smoothstep(y,.09,.165);
    const x=(p.getX(i)+.08)*.045,z=(p.getZ(i)-.15)*.045;
    // Remove the residual trapezius ridge below the nape, without changing the
    // jaw or skull. The original bust leans out behind a standing neck here.
    const softX=x/Math.pow(1+Math.pow(Math.abs(x)/.052,8),1/8);
    const softZ=z<0?z/Math.pow(1+Math.pow(-z/.049,8),1/8):z;
    p.setXYZ(i,THREE.MathUtils.lerp(x,softX,neckBlend),y,THREE.MathUtils.lerp(z,softZ,neckBlend));
  }
  const original=geometry;geometry=fitNeck(original);original.dispose();
  geometry.computeVertexNormals();geometry.computeBoundingBox();geometry.computeBoundingSphere();
  color.colorSpace=THREE.SRGBColorSpace;
  for(const texture of [color,normal,specular]){texture.anisotropy=4;texture.name='Bundled human scan';}
  return {geometry,color,normal,specular};
}

// Clip away the scan's shoulder bust, rather than squeezing those shoulder
// triangles into the neck. Extend its actual cut boundary into a smooth throat
// inside the shirt collar, so neither side contains folded-over skin or spikes.
function fitNeck(source){
  const plane=.081,p=source.attributes.position,uv=source.attributes.uv,srcIndex=source.index.array;
  const vertices=[],tex=[],indices=[],sourceMap=new Map(),edgeMap=new Map(),boundary=[];
  function original(i){if(sourceMap.has(i))return sourceMap.get(i);const id=vertices.length/3;vertices.push(p.getX(i),p.getY(i),p.getZ(i));tex.push(uv.getX(i),uv.getY(i));sourceMap.set(i,id);return id;}
  function crossing(a,b){
    const key=a<b?`${a}:${b}`:`${b}:${a}`;if(edgeMap.has(key))return edgeMap.get(key);
    const t=(plane-p.getY(a))/(p.getY(b)-p.getY(a)),id=vertices.length/3;
    vertices.push(THREE.MathUtils.lerp(p.getX(a),p.getX(b),t),plane,THREE.MathUtils.lerp(p.getZ(a),p.getZ(b),t));
    tex.push(THREE.MathUtils.lerp(uv.getX(a),uv.getX(b),t),THREE.MathUtils.lerp(uv.getY(a),uv.getY(b),t));edgeMap.set(key,id);return id;
  }
  for(let i=0;i<srcIndex.length;i+=3){
    const triangle=[srcIndex[i],srcIndex[i+1],srcIndex[i+2]],polygon=[],cut=[];
    for(let j=0;j<3;j++){
      const a=triangle[j],b=triangle[(j+1)%3],insideA=p.getY(a)>=plane,insideB=p.getY(b)>=plane;
      if(insideA)polygon.push(original(a));
      if(insideA!==insideB){const id=crossing(a,b);polygon.push(id);cut.push(id);}
    }
    for(let j=1;j+1<polygon.length;j++)indices.push(polygon[0],polygon[j],polygon[j+1]);
    if(cut.length===2){
      // The new neck must use the reverse edge winding of the retained surface.
      const a=polygon.indexOf(cut[0]),b=polygon.indexOf(cut[1]);
      boundary.push((a+1)%polygon.length===b?[cut[1],cut[0]]:[cut[0],cut[1]]);
    }
  }
  const rings=new Map();
  for(const top of new Set(boundary.flat())){
    const x=vertices[top*3],z=vertices[top*3+2],u=tex[top*2],v=tex[top*2+1],theta=Math.atan2((z+.018)/.058,x/.058),ring=[top];
    for(let j=1;j<=6;j++){
      const t=j/6,blend=t*t*(3-2*t),id=vertices.length/3;
      vertices.push(THREE.MathUtils.lerp(x,Math.cos(theta)*.047,blend),THREE.MathUtils.lerp(plane,-.016,t),THREE.MathUtils.lerp(z,-.006+Math.sin(theta)*.043,blend));
      tex.push(u,THREE.MathUtils.lerp(v,.18,t));ring.push(id);
    }
    rings.set(top,ring);
  }
  for(const [a,b] of boundary){const aa=rings.get(a),bb=rings.get(b);for(let j=0;j<6;j++)indices.push(aa[j],bb[j],aa[j+1],bb[j],bb[j+1],aa[j+1]);}
  const result=new THREE.BufferGeometry();result.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));result.setAttribute('uv',new THREE.Float32BufferAttribute(tex,2));result.setIndex(indices);result.computeVertexNormals();
  result.userData.sourceVertices=p.count;result.userData.sourceIndices=srcIndex.length;result.userData.neckBoundaryEdges=boundary.length;
  return result;
}

export function createScannedHead(value){
  const profile=normalizeCharacterProfile(value),root=new THREE.Group();root.name='Scanned survivor head';
  let disposed=false;const materials=[],geometries=[];
  const ready=preloadScannedHead().then(source=>{
    if(disposed)return false;
    const tint=new THREE.Color(SKIN_TONES[profile.skinTone].color),reference=new THREE.Color('#c7a18f');
    tint.setRGB(tint.r/reference.r,tint.g/reference.g,tint.b/reference.b);
    const skin=new THREE.MeshPhysicalMaterial({map:source.color,normalMap:source.normal,normalScale:new THREE.Vector2(.7,.7),
      color:tint,roughness:.65,metalness:0,specularIntensity:.32,clearcoat:.035,clearcoatRoughness:.55});
    materials.push(skin);
    const head=new THREE.Mesh(source.geometry,skin);head.name='Photographed skin and anatomical face';head.castShadow=true;head.receiveShadow=true;root.add(head);
    const hairColor=new THREE.Color(HAIR_COLORS[profile.hairColor].color);
    const hairGeo=source.geometry.clone(),p=hairGeo.attributes.position,n=hairGeo.attributes.normal;
    const shaved=profile.hairStyle==='shaved',swept=profile.hairStyle==='swept';
    for(let i=0;i<p.count;i++){
      const y=p.getY(i),rise=THREE.MathUtils.smoothstep(y,.19,.31);
      const thickness=shaved?.00012:(swept?.0005+rise*.004:.00035+rise*.0005);
      p.setXYZ(i,p.getX(i)+n.getX(i)*thickness+(swept?rise*.002:0),y+n.getY(i)*thickness,p.getZ(i)+n.getZ(i)*thickness);
    }
    geometries.push(hairGeo);
    const hair=new THREE.MeshStandardMaterial({color:hairColor,roughness:.88,metalness:0,transparent:shaved,opacity:shaved?.29:1});
    hair.onBeforeCompile=shader=>{
      shader.vertexShader='varying vec3 survivorScalp;\n'+shader.vertexShader;
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nsurvivorScalp=position;');
      shader.fragmentShader='varying vec3 survivorScalp;\n'+shader.fragmentShader;
      shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
        float front=smoothstep(-0.02,0.077,survivorScalp.z);
        float hairline=mix(0.144,0.254,front);
        hairline+=0.011*smoothstep(0.02,0.058,abs(survivorScalp.x))*front+0.00065*sin(survivorScalp.x*1900.0);
        if(abs(survivorScalp.x)>0.064)hairline=max(hairline,0.214);
        if(survivorScalp.y<hairline)discard;
        vec3 follicle=floor(survivorScalp*3600.0);
        float grain=fract(sin(dot(follicle,vec3(12.9898,78.233,39.425)))*43758.5453);
        float edge=smoothstep(hairline,hairline+0.0035,survivorScalp.y);
        if(grain>edge)discard;
        float strandCoord=survivorScalp.x*8500.0+survivorScalp.z*3500.0+sin(survivorScalp.y*110.0)*4.0;
        float strands=sin(strandCoord)*(1.0-smoothstep(0.4,2.5,fwidth(strandCoord)));
        diffuseColor.rgb*=0.68+0.3*grain+0.03*strands;
      `);
    };
    hair.customProgramCacheKey=()=>`survivor-scalp-${profile.hairStyle}`;
    materials.push(hair);const scalp=new THREE.Mesh(hairGeo,hair);scalp.name='Fine strand scalp';root.add(scalp);
    if(!shaved){
      const hp=hairGeo.attributes.position,hn=hairGeo.attributes.normal,indices=hairGeo.index.array;
      const strandPositions=[],strandColors=[],base=new THREE.Color(HAIR_COLORS[profile.hairColor].color);
      let randomSeed=48391;const random=()=>{randomSeed=(Math.imul(randomSeed,1664525)+1013904223)|0;return(randomSeed>>>0)/4294967296;};
      const a=new THREE.Vector3(),b=new THREE.Vector3(),c=new THREE.Vector3(),normal=new THREE.Vector3();
      let count=0;
      for(let attempt=0;attempt<65000&&count<2200;attempt++){
        const k=Math.floor(random()*indices.length/3)*3,ia=indices[k],ib=indices[k+1],ic=indices[k+2];
        a.fromBufferAttribute(hp,ia);b.fromBufferAttribute(hp,ib);c.fromBufferAttribute(hp,ic);
        const u=Math.sqrt(random()),v=random();const point=a.multiplyScalar(1-u).addScaledVector(b,u*(1-v)).addScaledVector(c,u*v);
        const front=THREE.MathUtils.smoothstep(point.z,-.02,.077);
        let line=THREE.MathUtils.lerp(.144,.254,front)+.011*THREE.MathUtils.smoothstep(Math.abs(point.x),.02,.058)*front;
        if(Math.abs(point.x)>.064)line=Math.max(line,.214);if(point.y<line+.001)continue;
        normal.fromBufferAttribute(hn,ia).normalize();
        const tangent=new THREE.Vector3(.12,-.24,-1).addScaledVector(normal,-normal.dot(new THREE.Vector3(.12,-.24,-1))).normalize();
        const length=(swept?.009:profile.hairStyle==='tied'?.007:.0018)*(0.5+random());
        const end=point.clone().addScaledVector(normal,swept?.0015:.00065).addScaledVector(tangent,length);
        strandPositions.push(...point.toArray(),...end.toArray());const shade=.55+random()*.55;
        strandColors.push(base.r*shade,base.g*shade,base.b*shade,base.r*(shade+.12),base.g*(shade+.12),base.b*(shade+.12));count++;
      }
      const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(strandPositions,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(strandColors,3));
      const mat=new THREE.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.65,depthWrite:false});geometries.push(geo);materials.push(mat);const strands=new THREE.LineSegments(geo,mat);strands.name='Individual short hair strands';root.add(strands);
    }
    if(profile.hairStyle==='tied'){
      // A compact plait follows the nape, with separate intertwined strands.
      for(let strand=0;strand<3;strand++){
        const points=[];
        for(let i=0;i<20;i++){const t=i/19,a=t*Math.PI*5+strand*Math.PI*2/3;points.push(new THREE.Vector3(Math.sin(a)*.005,.207-t*.12,-.087-Math.cos(a)*.005-t*.022));}
        const geo=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),40,.006,7,false);
        const mat=new THREE.MeshStandardMaterial({color:hairColor,roughness:.86});geometries.push(geo);materials.push(mat);root.add(new THREE.Mesh(geo,mat));
      }
    }
    if(profile.scar!=='none'){
      const ray=new THREE.Raycaster(),points=[];
      const path=profile.scar==='brow'?[[.036,.239],[.034,.226],[.031,.215]]:[[-.049,.18],[-.044,.168],[-.034,.157]];
      root.updateMatrixWorld(true);
      for(const [x,y] of path){ray.set(new THREE.Vector3(x,y,.2),new THREE.Vector3(0,0,-1));const hit=ray.intersectObject(head)[0];if(hit)points.push(hit.point.clone().addScaledVector(hit.face.normal,.0005));}
      if(points.length>1){const geo=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),18,.0007,5,false),mat=new THREE.MeshStandardMaterial({color:new THREE.Color(SKIN_TONES[profile.skinTone].color).lerp(new THREE.Color('#ad897b'),.25),roughness:.82});geometries.push(geo);materials.push(mat);root.add(new THREE.Mesh(geo,mat));}
    }
    root.userData.loaded=true;return true;
  }).catch(error=>{if(!disposed){root.userData.loadError=error.message;console.warn('Survivor scan unavailable',error);}return false;});
  return {root,ready,update(){},dispose(){if(disposed)return;disposed=true;root.removeFromParent();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());}};
}


