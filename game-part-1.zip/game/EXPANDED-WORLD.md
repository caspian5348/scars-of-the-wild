# Expanded wilderness

The playable chart is 1,800 × 1,800 metres, with bounds ±900m. Player movement stays inside ±888m. The central crash valley remains the starting area. The Stormlands have moved far north, Glowhaven occupies an eastern refuge, and three connected rivers drain to the ocean. The world has nine biomes and 37 creature species: 34 wildlife species plus the Teethpeed, Deatheater and Burrowpeed. Rendering uses procedural browser geometry and locally bundled material scans.

| Region | Reference position | Terrain and access |
|---|---|---|
| Rainforest | −190, −25 | Giant trees, denser brush, flowers and vines; stable `rainforest-000` IDs |
| River Valley | 135, 85 | Open valley, river and central wreck |
| Stormlands | 180, −655 | Northern hurricane, purple lightning and luminous trunk scars; one global Dillo-suare |
| Hollowroot Caverns | Entrance −510, −60 | Descending ramp to a branching underground maze; first chamber at −542, −60 |
| Ember Caldera | Lava centre 610, −350 | Basalt rim, animated molten lake and flames; lava surface at 29m |
| Frostbound Highlands | −545, −570 | Snow terrain, fractured ice and exposed stone; ore deposits are underground |
| Sundrift Coast | 250, 535 | Pale sand, palms and moving shoreline wash |
| Open Ocean | 60, 780 | Water surface at 2m; deeper offshore water supports the Ocean Deatheater |
| Glowhaven | 390, 185 | Protected luminous woodland with Glow Deer, floating Glow Jellyfish and Glow Butterflies |

## Glowhaven, Stormlands and ocean wildlife

`isGlowSafeAt(x,z)` and the visible `glow` biome share one boundary. Hostile wildlife cannot spawn inside it or retain attacks across it. The Teethpeed and flying Deatheater also disengage when the player enters the refuge. The three resident species are passive or neutral, with localized emissive markings, pulsing translucent bells and articulated butterfly wings. Nonhostile land or air fauna can roam into the refuge. Hunger, thirst and permadeath remain active. Peaceful music accompanies Glowhaven through the existing sound controls.

The northern hurricane is anchored to `STORM_CENTER`, with rotating cloud bands and purple lightning illumination above damaged vegetation. The Dillo-suare uses the canonical ID `unique:dillo_suare`, is excluded from ordinary weighted spawning, and is protected from dormant-actor pruning. Its live record persists across streaming and saves; duplicate live unique records fail normalization. Its death record blocks respawning for 1,800 seconds of survival time, after which the next suitable Stormlands visit can create one new individual.

The Ocean Deatheater is approximately seven metres long, with a shark body, fins, gills, a circular open throat and three tooth rings. It swims at 3.2 m/s while roaming and 15 m/s in pursuit, with 44 base bite damage before armor. Water-depth checks keep it submerged and off dry or shallow terrain. The player must be in the ocean for its pursuit and damage to remain eligible. Its combat and harvesting use the normal wildlife controller, independently of the flying Deatheater’s swallowing presentation.

`river-network.js` defines the main Wildwater River and the western Rainforest and eastern Glowwater tributaries. Both tributaries end on the main channel. Its southern channel widens through the coast into an ocean mouth. Terrain carving, water rendering and map paths share these curves.

## Rainforest and valley burrowers

The Burrowpeed is a ground-burrowing Teethpeed relative with 50 fixed den IDs, `burrowpeed-00` through `burrowpeed-49`. Twenty-five belong to each of the rainforest and valley habitats; every pair is at least 30.48 metres apart. Den placement excludes water, the Glowhaven refuge and obstructed or unsuitable ground. Tooth tips mark a buried animal. Entering its 10-metre detection radius triggers emergence, then a 10-second chase and a return underground. The animal must rearm after the survivor leaves before the den can trigger again.

Its dedicated controller saves under optional `phase3.burrowers`, separate from the 34 ordinary wildlife species. The version-1 state has a stable seed, simulation clock, revision and up to 50 canonical den records. Each record preserves its encounter cycle, stage, remaining time, progress, health and harvest status. Older journeys without the field remain valid. Stale-tab merging keeps deaths and harvests permanent, never increases animal health, and cannot restart an existing encounter timer; new cycles can legitimately receive a new chase duration. Burrowing does not regenerate health or create a replacement animal. Rearming requires the eight-second cooldown to end while the survivor is more than 14 metres from the den.

## Hollowroot Caverns

The entrance leads below a rocky hillside into 30 connected chambers, four misleading dead-end branches, a reward endpoint and a reconnecting loop. The shortest route from the outside approach to the cache is 581m with 16 turns. The floor descends from about 19m to about 8m above world datum, safely above the shared water surface. Deep chambers have more than 20m of overlying rock. Continuous side walls and enclosed, uneven ceilings prevent walking or looking through the maze. Calcite curtains, dripstone, entrance roots and a natural geode help distinguish chambers.

The cave uses the same rendered terrain triangles for its walking floor. A separate ceiling and hill cap enclose the excavated passages. The overburden is scenery above the playable cave; the player controller does not provide a second walkable layer on top of a passage. The main map marks the cave entrance without drawing the underground solution.

The last chamber contains a one-time natural mineral cache: **6 Abyssal Ore, 6 Frost Crystal and 4 Gold Ore per journey**. The cache stays available if all its contents cannot fit in the pack. Claiming it persists across saves. This is optional survival loot, not a victory destination.

Sixteen fixed, reachable seams distribute copper, tin, coal, iron, gold, obsidian, frost crystal and abyssal ore through the chambers. Each seam supplies eight units. Additional cave resources respect the same walkable-floor mask; outdoor biome resource pools contain no ore deposits.

Loose stones are still gathered by hand. A larger stone outcrop requires a working equipped pickaxe and three strikes. Each accepted strike gathers stone and costs durability. Depleting the outcrop performs a **10% rare-ore draw**, producing one gold ore, abyssal ore, obsidian or frost crystal when successful. The draw is deterministic for the journey seed and source ID, so reloading cannot reroll it. Strike counts and depletion are saved, and an inventory-capacity failure spends neither a strike nor tool wear.

Crossing the cave boundary from outside to inside performs a **1% Cave Bear roll**. Remaining inside or reloading an inside save performs no roll; leaving and reentering makes a new one. A bear is placed in a clear chamber, never in a wall, and is excluded from ordinary habitat spawning. At most one live cave bear is retained at a time. The bear is protected from ordinary dormant-actor eviction and remains in saved wildlife state when travelling away. Cave entry counts, the last successful roll and reward collection also persist.

## Integration contracts

- `terrain-surface.js` exports `WORLD_SIZE`, `WATER_LEVEL`, `heightAt`, `riverX`, and `hazardAt`. `heightAt` interpolates the exact Float32 triangles rendered by the world. `world.js` re-exports these public terrain functions.
- `biomeAt(x,z)` returns `{id,name,x,z,color}`. The nine IDs are `forest`, `valley`, `storm`, `cave`, `lava`, `ice`, `beach`, `ocean`, and `glow`. Use `isInsideCave(x,z,y)` when vertical occupancy matters.
- `biomes.js` exports `STORM_CENTER`, `GLOW_CENTER`, `glowBlendAt` and `isGlowSafeAt`. Use the shared sanctuary predicate for creature eligibility rather than a separate radius.
- `river-network.js` exports sampled paths and nearest-channel queries for the connected watershed.
- `cave-maze.js` owns `CAVE_ID`, `CAVE_ENTRANCE`, `CAVE_BOUNDS`, `CAVE_SEGMENTS`, `CAVE_ZONES`, `CAVE_DEPOSITS` and `MAZE_REWARD_POSITION`. The cache is at x −682, z −116. `caveWalkableAt(x,z,margin)` accepts a clearance margin for the actor's radius. `caveFloorAt` is a reference height inside the opening and returns `null` outside; final ground placement uses the triangulated `heightAt`.
- `cave-mesh.js` builds the shared maze outline into walls, overlapping wall colliders, ceilings and overburden. Intersections are the union of open passages, with no overlapping tube end walls.
- `cave-progression.js` exports `createCaveProgress`, `normalizeCaveProgress`, `rareOreAt`, the `.10` rare-ore chance, the `.01` cave-bear chance and reward contents. `visit(inside)` emits only boundary changes. `claim()` succeeds once. Cave progress has its own revision for persistence.
- `createWorld()` provides `gatherTrees`, `bushZones`, `resourceNodes`, `setTreeFelled(id,boolean)`, and `hazardAt`.
- Gather trees have stable `{id,x,z,y,h,radius,kind,felled}` fields. `y`/`h` describe their embedded rendering anchor. Kinds are `pine`, `rainforest`, `deadwood`, and `palm`.
- `setTreeFelled` returns `true` only when state changes. It removes or restores every bark, canopy and vine instance and mutates `colliders` and `encounterTrees` in place. The caller rebuilds its collision index and cached encounter anchors after a successful cut. Canopy shade refreshes on the next world update.
- Lava returns `{kind:'lava',damagePerSecond:42,surfaceY:29,cause:'Burned in the lava.'}`; safe terrain returns `null`. Apply damage when the player's feet are near or below the molten surface.

## Materials and performance

The heightfield retains 3⅓m vertex spacing and is split into 81 indexed terrain tiles sharing vertex attributes. Pine wood and canopy instances are grouped into 160m spatial cells. Rainforest, storm and outer scenery groups are culled by distance. Tree bases embed across their actual triangulated root footprint.

Sun shadows use a player-following, texel-aligned orthographic region with 260m half-extent and up to a 4096px shadow map, respecting the renderer’s supported texture limit. This extends detailed coverage while limiting shimmering; distant canopy shading supplements it.

Maze walls follow the signed passage outline, with physically continuous colliders. Shared ceiling vertices produce smooth arches. The opaque hill cap overlaps unexcavated terrain beyond the passage boundaries. Basalt, ice, cave rubble, roots, dripstone and palms use batched geometry. The cave has three small local lights; a carried torch helps exploration. Lava and ocean animation need no network requests.

Construction uses split-grain timber, beveled planks, bark poles, cord bindings, layered leaf roofing, draped hide and irregular masonry. Repeated structures share cached geometry and materials. Ore and gathered materials have shaped, textured surfaces. Wildlife has revised anatomical proportions and species-appropriate fur, feather or scale grain; models still use a small number of merged material batches. These visual improvements remain procedural and do not establish photographic realism.

The first-person view renders no player hands or arms on land or in water. Equipped tools still animate and stow while swimming; character appearance remains saved for the editor and character scenes.

## Verification

`game/phase3-check.html` exposes 41 manual browser checks covering terrain, the real maze geometry, movement, senses, concealment, inventory, crafting and persistence. Cave checks traverse every corridor in both directions, raycast the ceiling, verify overburden and ore access, test stable rare-ore draws and entry-only bear rolls, and preserve the one-time reward.

`work/underground-maze-check.mjs` adds 13 private layout and geometry checks, including grid navigation to every room and the reward, route length, headroom, wall shortcuts and disposal. `work/cave-save-check.mjs` adds five integration checks for real journey storage, the persisted bear cap, cave-entry history, one-time rewards, mined rocks and permanent death. `work/first-person-body-check.mjs` verifies the unobstructed first-person view and retained equipment behavior. Geometry tests use placeholder textures without a WebGL renderer; appearance still requires the integrated browser preview.

`work/burrow-save-check.mjs` checks all 50 den identities through journey storage and controller reload, strict malformed-state rejection, stale timers and stage transitions, permanent kills and harvesting, new encounter cycles, rearming, independent inventory revisions and the permadeath lock. It uses isolated memory storage without altering the playable journey.

The new wildlife checks in `work/new-fauna-check.mjs` cover sanctuary boundary crossings, old hostile saves, the global Dillo-suare cap across streaming and reloading, respawn cooldown, marine beach/depth restrictions, and finite animated LOD geometry for all five new creatures. The broader wildlife checks cover all 68 model/LOD variants, saves, damage, concealment and habitat placement. These are simulation and geometry checks; on-screen appearance still needs browser review.
