import {createTripRisk,getTripChasers,normalizeTripState,tripRoll,passesTripChance,TRIP_CHANCE} from './trip-risk.js';
import {createJourneyStore,SAVE_KEY,DEATH_KEY} from './journey-store.js';

const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const creature=(kind='teethpeed',id='tree-a')=>({kind,id,position:{x:2,y:3,z:-4}});
const keyOf=chaser=>`${chaser.kind}:${chaser.id}`;
const input=(chasers,extra={})=>({moving:true,grounded:true,swimming:false,chasers,...extra});
function findSeed(predicate){for(let i=0;i<10000;i++){const seed=`visible-trip-${i}`;if(predicate(seed))return seed;}throw new Error('Could not construct a deterministic trip fixture.');}
function seedFor(chaser,fatal){return findSeed(seed=>passesTripChance(tripRoll(seed,keyOf(chaser)))===fatal);}
function chaserFor(seed,fatal,kind='teethpeed',prefix='fixture'){for(let i=0;i<10000;i++){const chaser=creature(kind,`${prefix}-${i}`);if(passesTripChance(tripRoll(seed,keyOf(chaser)))===fatal)return chaser;}throw new Error('Could not find an encounter for the fixed journey seed.');}
function memoryStorage(){const values=new Map();return {getItem:key=>values.has(key)?values.get(key):null,setItem:(key,value)=>values.set(key,String(value)),removeItem:key=>values.delete(key)};}
function life(){return {player:{x:0,z:0,yaw:0,pitch:0},health:82,survivedSeconds:95,discovered:[],waypoint:null,motion:{footY:3,verticalSpeed:0,grounded:true}};}

export const tripChecks=[
  ['The 10% boundary accepts lower rolls and rejects exactly 10%',()=>{
    assert(TRIP_CHANCE===.1,'The intended trip probability changed.');
    assert(passesTripChance(0)&&passesTripChance(.099999999),'A roll below 10% was rejected.');
    for(const roll of [.1,1,-.001,NaN,Infinity])assert(!passesTripChance(roll),'The 10% boundary or an invalid roll was accepted.');
  }],
  ['Stable encounter hashes distribute approximately 10% fatal trips',()=>{
    let fatalities=0;const seed='trip-distribution';
    for(let i=0;i<10000;i++){const key=`teethpeed:tree-${i}`,roll=tripRoll(seed,key);assert(Number.isFinite(roll)&&roll>=0&&roll<1,'The probability draw left the valid range.');assert(roll===tripRoll(seed,key),'An encounter draw changed within its journey.');if(passesTripChance(roll))fatalities++;}
    assert(fatalities>850&&fatalities<1150,`The distribution was ${fatalities}/10000, outside the expected range around 10%.`);
    assert(tripRoll('journey-a','teethpeed:a')!==tripRoll('journey-b','teethpeed:a'),'Different journeys did not receive different draws.');
  }],
  ['Standing still never trips or consumes a chase opportunity',()=>{
    const chaser=creature(),changes=[],risk=createTripRisk({seed:seedFor(chaser,true),onChange:(...args)=>changes.push(args)}),before=JSON.stringify(risk.snapshot());
    for(let i=0;i<40;i++)assert(risk.update(input([chaser],{moving:false}))===null,'A stationary player tripped.');
    assert(JSON.stringify(risk.snapshot())===before&&!changes.length,'Standing still consumed an opportunity or requested a save.');
  }],
  ['Jumping or falling never rolls the ground-trip risk',()=>{
    const chaser=creature(),risk=createTripRisk({seed:seedFor(chaser,true)});
    for(let i=0;i<40;i++)assert(risk.update(input([chaser],{grounded:false}))===null,'An airborne player tripped.');
    assert(!risk.snapshot().resolved.length,'Airborne movement consumed the chase opportunity.');
  }],
  ['Swimming suppresses trips even if a stale grounded flag is present',()=>{
    const chaser=creature(),risk=createTripRisk({seed:seedFor(chaser,true)});
    assert(risk.update(input([chaser],{swimming:true}))===null,'A swimmer tripped with a stale ground flag.');
    assert(risk.update(input([chaser],{swimming:true,grounded:false}))===null,'A normal swimmer tripped.');
    assert(!risk.snapshot().resolved.length,'Swimming consumed a ground-only opportunity.');
  }],
  ['Moving without a chasing creature leaves the risk untouched',()=>{
    const risk=createTripRisk({seed:'no-chasers'}),before=JSON.stringify(risk.snapshot());
    for(let i=0;i<100;i++)assert(risk.update(input([]))===null,'Moving without a chaser caused a trip.');
    assert(JSON.stringify(risk.snapshot())===before,'An empty chase list changed encounter history.');
  }],
  ['The real chase filter excludes hunting, hidden attacks and non-pursuit flight',()=>{
    const position={x:4,y:3,z:0},teethpeeds=[
      {treeId:'visible',stage:'attacking',senses:{lineOfSight:true},position},
      {treeId:'hunting',stage:'hunting',senses:{lineOfSight:true},position},
      {treeId:'hidden',stage:'attacking',senses:{lineOfSight:false},position},
      {treeId:'descending',stage:'descending',senses:{lineOfSight:true},position},
      {treeId:'retreating',stage:'retreating',senses:{lineOfSight:true},position},
    ],deatheaters=['circling','approaching','diving','recovering','retreating'].map(stage=>({id:stage,stage,position:{x:stage==='diving'?2:6,y:15,z:0}}));
    const chasers=getTripChasers({teethpeeds,deatheaters,player:{x:0,z:0}});
    assert(chasers.length===3&&chasers.map(keyOf).join('|')==='deatheater:diving|teethpeed:visible|deatheater:approaching','The chase filter admitted a search/hidden stage or failed to prefer the nearest threat.');
    chasers[1].position.x=100;assert(position.x===4,'Filtering exposed the creature controller’s mutable position.');
    const searching=getTripChasers({teethpeeds:teethpeeds.slice(1),deatheaters:deatheaters.filter(record=>!['approaching','diving'].includes(record.stage)),player:{x:0,z:0}});
    const risk=createTripRisk({seed:'searching-only'});assert(risk.update(input(searching))===null&&!risk.snapshot().resolved.length,'Searching-only encounters consumed trip opportunities.');
  }],
  ['A deferred opportunity is evaluated when grounded movement resumes',()=>{
    const chaser=creature(),risk=createTripRisk({seed:seedFor(chaser,true)});
    risk.update(input([chaser],{moving:false}));risk.update(input([chaser],{grounded:false}));risk.update(input([chaser],{swimming:true}));
    const fatal=risk.update(input([chaser]));
    assert(fatal?.kind===chaser.kind&&fatal.id===chaser.id,'Ineligible frames consumed the later grounded opportunity.');
    assert(risk.snapshot().resolved.includes(keyOf(chaser)),'The resumed opportunity was not recorded.');
  }],
  ['A safe encounter is rolled once despite many chase updates',()=>{
    const chaser=creature(),changes=[],risk=createTripRisk({seed:seedFor(chaser,false),onChange:(state,event)=>changes.push({state,event})});
    for(let i=0;i<2000;i++)assert(risk.update(input([chaser]))===null,'A previously safe encounter rerolled into a fatal trip.');
    assert(risk.snapshot().resolved.length===1&&changes.length===1,'The same chase was evaluated more than once.');
    assert(changes[0].event.fatal===false&&changes[0].event.key===keyOf(chaser),'The saved safe result identified the wrong opportunity.');
  }],
  ['A fatal result is consumed before another update can return it',()=>{
    const chaser=creature(),risk=createTripRisk({seed:seedFor(chaser,true)});
    assert(risk.update(input([chaser]))?.id===chaser.id,'The deterministic fatal opportunity did not trigger.');
    for(let i=0;i<100;i++)assert(risk.update(input([chaser]))===null,'The same creature returned a fatal trip repeatedly.');
    assert(risk.snapshot().resolved.length===1,'The fatal result was not recorded exactly once.');
  }],
  ['A hunting gap and later reacquisition cannot reroll the same encounter',()=>{
    const chaser=creature(),changes=[],risk=createTripRisk({seed:seedFor(chaser,false),onChange:()=>changes.push(true)});
    risk.update(input([chaser]));const before=JSON.stringify(risk.snapshot());
    // Hunting creatures are deliberately absent from the caller's chaser list.
    for(let i=0;i<100;i++)risk.update(input([]));
    for(let i=0;i<100;i++)assert(risk.update(input([chaser]))===null,'Reacquisition rerolled a resolved chase.');
    assert(JSON.stringify(risk.snapshot())===before&&changes.length===1,'The hunting gap reset the opportunity.');
  }],
  ['Creature kind and encounter ID each identify independent opportunities',()=>{
    const a=creature('teethpeed','same-id'),b=creature('deatheater','same-id'),c=creature('teethpeed','another-id');
    const seed=findSeed(value=>[a,b,c].every(chaser=>!passesTripChance(tripRoll(value,keyOf(chaser))))),risk=createTripRisk({seed});
    risk.update(input([a,b,c]));const keys=risk.snapshot().resolved;
    assert(keys.length===3&&[a,b,c].every(chaser=>keys.includes(keyOf(chaser))),'Independent creatures shared a trip opportunity.');
  }],
  ['The first fatal chaser leaves later simultaneous opportunities pending',()=>{
    const first=creature('teethpeed','first'),later=creature('deatheater','later'),risk=createTripRisk({seed:seedFor(first,true)});
    const fatal=risk.update(input([first,later])),keys=risk.snapshot().resolved;
    assert(fatal?.id==='first'&&fatal.kind==='teethpeed','The fatal creature did not follow the supplied chase order.');
    assert(keys.includes(keyOf(first))&&!keys.includes(keyOf(later)),'An unprocessed later chaser was incorrectly marked spent.');
  }],
  ['Callbacks receive resolved state and snapshots cannot mutate controller memory',()=>{
    const chaser=creature(),changes=[],risk=createTripRisk({seed:seedFor(chaser,true),onChange:(state,event)=>changes.push({state,event})});
    assert(!changes.length,'Construction emitted a premature save callback.');
    const fatal=risk.update(input([chaser]));
    assert(changes.length===1&&changes[0].event.fatal&&changes[0].state.resolved.includes(keyOf(chaser)),'The fatal callback ran before its opportunity was persisted in state.');
    const snapshot=risk.snapshot();snapshot.resolved.length=0;changes[0].state.resolved.length=0;fatal.position.x=900;
    assert(risk.snapshot().resolved.includes(keyOf(chaser)),'External snapshot mutation changed internal trip history.');
    assert(chaser.position.x===2,'The fatal result exposed the caller’s mutable creature position.');
  }],
  ['Saving and restoring trip state never rerolls a resolved encounter',()=>{
    const chaser=creature(),seed=seedFor(chaser,true),risk=createTripRisk({seed});risk.update(input([chaser]));
    const state=JSON.parse(JSON.stringify(risk.snapshot())),normalized=normalizeTripState(state),restored=createTripRisk({seed,state:normalized});
    assert(normalized&&restored.update(input([chaser]))===null,'Restoring the same journey rerolled its fatal opportunity.');
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(state),'Restoring changed the saved seed or opportunity history.');
  }],
  ['A different journey seed starts with fresh opportunities',()=>{
    const chaser=creature(),oldSeed=seedFor(chaser,false),risk=createTripRisk({seed:oldSeed});risk.update(input([chaser]));
    const newSeed=seedFor(chaser,true),fresh=createTripRisk({seed:newSeed,state:risk.snapshot()});
    assert(!fresh.snapshot().resolved.length&&fresh.snapshot().seed===newSeed,'Old encounter history leaked into a new journey.');
    assert(fresh.update(input([chaser]))?.id===chaser.id,'The new journey did not receive its own deterministic opportunity.');
  }],
  ['Legacy absence is accepted while malformed trip records are rejected',()=>{
    assert(normalizeTripState(undefined)===undefined,'A legacy save was required to contain trip history.');
    for(const value of [null,42,'bad',{version:2,seed:'a',resolved:[]},{version:1,seed:'a',resolved:'bad'},{version:1,seed:'a',resolved:['unknown:bad']}])assert(normalizeTripState(value)===null,'Malformed trip state was accepted.');
    const valid={version:1,seed:'valid',resolved:['teethpeed:a','deatheater:b']},normal=normalizeTripState(valid);
    assert(normal&&normal.resolved.length===2,'A valid two-species history could not be restored.');normal.resolved.length=0;assert(valid.resolved.length===2,'Normalization mutated its input.');
  }],
  ['The real journey store preserves trip history through save/read and restore',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),record=store.begin(life()).record,chaser=chaserFor(record.runId,false),risk=createTripRisk({seed:record.runId});risk.update(input([chaser]));
    const saved=store.save({...record,trips:risk.snapshot()});assert(saved?.trips,'The store discarded trip state.');
    const loaded=createJourneyStore(storage).read(),restored=createTripRisk({seed:loaded.runId,state:loaded.trips});
    assert(loaded.health===82&&loaded.trips.resolved.includes(keyOf(chaser)),'Reload lost the resolved chase or changed health.');
    assert(restored.update(input([chaser]))===null&&restored.snapshot().resolved.length===1,'The stored opportunity was rolled again on resume.');
  }],
  ['Stale saves merge encounter history and omitted trip fields cannot erase it',()=>{
    const storage=memoryStorage(),storeA=createJourneyStore(storage),original=storeA.begin(life()).record,storeB=createJourneyStore(storage);
    const a=chaserFor(original.runId,false,'teethpeed','tab-a'),b=chaserFor(original.runId,false,'deatheater','tab-b'),riskA=createTripRisk({seed:original.runId}),riskB=createTripRisk({seed:original.runId});
    riskA.update(input([a]));riskB.update(input([b]));
    assert(storeA.save({...original,trips:riskA.snapshot()})&&storeB.save({...original,trips:riskB.snapshot()}),'A valid same-run save was rejected.');
    let restored=storeA.read();assert([a,b].every(chaser=>restored.trips.resolved.includes(keyOf(chaser))),'A stale tab erased another tab’s trip opportunity.');
    storeA.save(original);restored=storeB.read();assert(restored.trips.resolved.length===2,'A legacy-shaped save erased current trip history.');
  }],
  ['A fatal trip locks the journey before its ending presentation can begin',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),record=store.begin(life()).record,chaser=chaserFor(record.runId,true),risk=createTripRisk({seed:record.runId}),staleTab=createJourneyStore(storage),stale=staleTab.read();
    const fatal=risk.update(input([chaser]));assert(fatal,'The fixture did not produce its fatal trip.');
    const ended=store.end({...record,trips:risk.snapshot()},'A Teethpeed caught you after a trip.');
    assert(ended.persisted&&ended.record.status==='dead'&&ended.record.health===0,'The trip did not persist a dead journey.');
    assert(store.read()===null&&createJourneyStore(storage).read()===null,'The ending presentation could begin with a resumable living save.');
    assert(staleTab.save(stale)===null,'A stale tab revived the player during the fatal sequence.');
    const tombstones=JSON.parse(storage.getItem(DEATH_KEY)),dead=JSON.parse(storage.getItem(SAVE_KEY));
    assert(tombstones[record.runId]&&dead.trips.resolved.includes(keyOf(chaser)),'Permanent death or the triggering trip history was missing.');
  }],
  ['Failed death writes report the failure while retaining the local death lock',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),record=store.begin(life()).record,chaser=chaserFor(record.runId,true,'deatheater'),risk=createTripRisk({seed:record.runId});assert(risk.update(input([chaser])),'The Deatheater fixture did not trigger.');
    storage.setItem=()=>{throw new Error('Simulated storage failure');};
    const ended=store.end({...record,trips:risk.snapshot()},'A Deatheater caught you after a trip.');
    assert(!ended.persisted&&store.lastError,'Failed permanent-death writes were reported as successful.');
    assert(store.isDead(record.runId)&&store.read()===null&&store.save(record)===null,'A write failure revived the local run during its ending.');
  }],
];

export async function runTripChecks(onResult=()=>{}){
  const results=[];
  for(const [name,check] of tripChecks){let result;try{await check();result={name,passed:true};}catch(error){result={name,passed:false,error:error.message};}results.push(result);onResult(result);await new Promise(resolve=>setTimeout(resolve,0));}
  return results;
}
if(typeof document!=='undefined'){
  const button=document.getElementById('run-checks'),list=document.getElementById('results'),summary=document.getElementById('summary');
  button?.addEventListener('click',async()=>{
    button.disabled=true;list.replaceChildren();summary.textContent='Running isolated trip and journey checks…';
    const results=await runTripChecks(result=>{const row=document.createElement('li');row.className=result.passed?'pass':'fail';const badge=document.createElement('strong');badge.textContent=result.passed?'PASS':'FAIL';const title=document.createElement('span');title.textContent=result.name;row.append(badge,title);if(!result.passed){const detail=document.createElement('p');detail.textContent=result.error;row.append(detail);}list.append(row);summary.textContent=`${list.children.length} / ${tripChecks.length} checks complete`;});
    const failed=results.filter(result=>!result.passed).length;summary.textContent=`${results.length-failed} passed · ${failed} failed · Journey save untouched`;button.disabled=false;button.textContent='Run checks again';
  });
}
