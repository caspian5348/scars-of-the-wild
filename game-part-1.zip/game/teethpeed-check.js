import {createTeethpeedEncounters,normalizeEncounterState,treeEncounterChance,passesTeethpeedChance,TEETHPEED_SPEED,TEETHPEED_BITE_DAMAGE} from './teethpeed-encounters.js';
import {evaluateTeethpeedSenses,hasTeethpeedLineOfSight} from './teethpeed-senses.js';

const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const near=(a,b,tolerance=1e-6)=>Math.abs(a-b)<=tolerance;
const copy=value=>JSON.parse(JSON.stringify(value));
const tree=(id='tree-a',x=0,z=0)=>({id,x,z,h:10,height:40,radius:1.5,angle:.2});
const flat=()=>10;
function fixture(options={}) {
  const events=[],changes=[],damage=[];
  const config={trees:[tree()],heightAt:flat,colliders:[],forestBlendAt:()=>1,seed:'visible-teethpeed-check',onEvent:event=>events.push(event),onChange:(state,event)=>changes.push({state,event}),onDamage:(amount,cause,active)=>damage.push({amount,cause,active}),...options};
  return {ai:createTeethpeedEncounters(config),config,events,changes,damage};
}
function advance(ai,seconds,player={x:500,y:10,z:500}) {
  let remaining=seconds;
  while(remaining>1e-8){const step=Math.min(.05,remaining);ai.update(step,player);remaining-=step;}
}
function attacking(options={}) {
  const f=fixture(options),id=f.config.trees[0].id;
  assert(f.ai.forceEncounter(id),'Fixture could not start an encounter.');
  const d=f.ai.getActive()[0].descent,nearby={x:d.treeX+Math.cos(d.angle)*(d.landingRadius+2),z:d.treeZ+Math.sin(d.angle)*(d.landingRadius+2)};
  nearby.y=f.config.heightAt(nearby.x,nearby.z);
  advance(f.ai,d.total,nearby);
  assert(f.ai.getActive()[0]?.stage==='attacking','Descent did not transition to attack.');
  return f;
}
function placeActive(f,position,extra={}) {
  const state=f.ai.snapshot(),record=state.active[0];
  // Teleported fixtures represent an established pursuit. Dedicated landing
  // regressions below retain the fresh timer and exercise its steering handoff.
  const remaining=['attacking','hunting'].includes(record.stage)?Math.min(record.remaining,record.attackDuration-.6):record.remaining;
  state.active[0]={...record,remaining,position:{...position},...extra};
  f.ai=createTeethpeedEncounters({...f.config,state});return f;
}
function eligibleSeed(id='tree-a') {
  for(let i=0;i<10000;i++)if(passesTeethpeedChance(treeEncounterChance(String(i),id)))return String(i);
  throw new Error('Could not find an eligible deterministic tree fixture.');
}
const cover=()=>Array.from({length:21},(_,i)=>({x:0,z:(i-10)*2.8,radius:1.6,height:12}));
function huntingFixture() {
  const f=attacking({trees:[tree('tree-a',-24,20)],colliders:cover()});
  placeActive(f,{x:-6,y:10,z:0},{lastKnownPlayer:{x:-4,y:10,z:0},sightLostFor:0,sightFoundFor:0});
  advance(f.ai,.2,{x:3,y:10,z:0});assert(f.ai.getActive()[0].stage==='hunting','Cover did not switch the fixture to hunting.');
  return f;
}

export const teethpeedChecks=[
  ['The encounter chance accepts values below 15%, never the boundary',()=>{
    assert(passesTeethpeedChance(0)&&passesTeethpeedChance(.14999999),'A valid sub-15% roll was rejected.');
    assert(!passesTeethpeedChance(.15)&&!passesTeethpeedChance(1)&&!passesTeethpeedChance(-.1)&&!passesTeethpeedChance(NaN),'The 15% boundary or an invalid roll was accepted.');
  }],
  ['Stable per-tree hashes distribute about 15% across 10,000 trees',()=>{
    let eligible=0;
    for(let i=0;i<10000;i++){const chance=treeEncounterChance('distribution-check',`tree-${i}`);assert(chance>=0&&chance<1,'Hash was outside the probability range.');if(passesTeethpeedChance(chance))eligible++;}
    assert(eligible>1350&&eligible<1650,`Distribution was ${eligible}/10000 rather than approximately15%.`);
    assert(treeEncounterChance('a','tree-17')===treeEncounterChance('a','tree-17'),'A tree rerolled within the same journey.');
    assert(treeEncounterChance('a','tree-17')!==treeEncounterChance('b','tree-17'),'Different journey seeds did not change the draw.');
  }],
  ['Real forest-edge trees retain their eligibility',()=>{
    let seed='';for(let i=0;i<100;i++)if(passesTeethpeedChance(treeEncounterChance(String(i),'tree-a'))){seed=String(i);break;}
    const f=fixture({seed,forestBlendAt:()=>.4909});
    assert(f.ai.getEligibility('tree-a'),'A tree accepted by forest placement lost its15% opportunity.');
    f.ai.update(.05,{x:9,y:10,z:0});assert(f.ai.getActive().length===1,'An eligible nearby forest-edge tree did not trigger.');
  }],
  ['Eligible trees detect at exactly 10m, never at 10.01m or outside forest',()=>{
    const seed=eligibleSeed(),f=fixture({seed});f.ai.update(.05,{x:10.01,y:10,z:0});assert(!f.ai.getActive().length,'A tree triggered beyond the 10m detection radius.');
    f.ai.update(.05,{x:10,y:10,z:0});assert(f.ai.getActive().length===1,'An eligible visible tree did not trigger at exactly 10m.');
    const outside=fixture({seed,forestBlendAt:()=>.1});outside.ai.update(.05,{x:1,y:10,z:0});assert(!outside.ai.getActive().length,'Encounter started outside forest.');
  }],
  ['Nearby cover blocks an initial tree encounter; force remains an isolated QA hook',()=>{
    const f=fixture({seed:eligibleSeed(),colliders:[{x:5.5,z:0,radius:.8,height:80}]});
    advance(f.ai,.4,{x:9,y:10,z:0});assert(!f.ai.getActive().length,'An occluded nearby player triggered a tree encounter.');
    assert(!f.ai.snapshot().spent.includes('tree-a'),'An unseen tree opportunity was spent.');
    assert(f.ai.forceEncounter('tree-a'),'The explicit QA hook failed to bypass initial sight detection.');
  }],
  ['Horizontal proximity and clear sight are independent senses',()=>{
    const atBoundary=evaluateTeethpeedSenses({position:{x:0,y:10,z:0},player:{x:10,y:10,z:0},heightAt:flat,colliders:[]});
    const outside=evaluateTeethpeedSenses({position:{x:0,y:10,z:0},player:{x:10.01,y:10,z:0},heightAt:flat,colliders:[]});
    assert(near(atBoundary.distance,10)&&atBoundary.withinDetection&&atBoundary.lineOfSight,'The 10m helper boundary failed.');
    assert(!outside.withinDetection&&outside.lineOfSight,'Leaving 10m incorrectly removed unobstructed sight.');
    const blocked=evaluateTeethpeedSenses({position:{x:-3,y:10,z:0},player:{x:3,y:10,z:0},heightAt:flat,colliders:[{x:0,z:0,radius:1,height:8}]});
    assert(blocked.withinDetection&&!blocked.lineOfSight,'Nearby occlusion was confused with range detection.');
  }],
  ['Eye-height rays clear low stones but stop at tall trunks',()=>{
    const ray={position:{x:-4,y:10,z:0},player:{x:4,y:10,z:0},heightAt:flat};
    assert(hasTeethpeedLineOfSight({...ray,colliders:[{x:0,z:0,radius:1,height:.12}]}),'A low stone blocked the raised eye ray.');
    assert(!hasTeethpeedLineOfSight({...ray,colliders:[{x:0,z:0,radius:1,height:5}]}),'A tall trunk did not block the same eye ray.');
  }],
  ['A terrain ridge blocks sight without a collider',()=>{
    const ridge=x=>Math.abs(x)<.8?13:10;
    assert(!hasTeethpeedLineOfSight({position:{x:-4,y:10,z:0},player:{x:4,y:10,z:0},heightAt:ridge,colliders:[]}),'A ridge above the eye ray did not occlude sight.');
    assert(hasTeethpeedLineOfSight({position:{x:-4,y:14,z:0},player:{x:4,y:14,z:0},heightAt:ridge,colliders:[]}),'The clear ray above the ridge was rejected.');
  }],
  ['Descent lasts 4–7s and independent attacks last 60–120s',()=>{
    const durations=new Set();
    for(let i=0;i<30;i++){
      const f=fixture({seed:`duration-${i}`});assert(f.ai.forceEncounter('tree-a'),'Valid forced encounter failed.');
      const record=f.ai.getActive()[0];assert(record.descent.total>=4&&record.descent.total<=7,'Descent was outside4–7s.');
      assert(record.attackDuration>=60&&record.attackDuration<=120,'Attack was outside60–120s.');durations.add(record.attackDuration);
    }
    assert(durations.size===30,'Attack durations were shared rather than independently drawn.');
  }],
  ['Crawling follows the tapered trunk and lands beyond buttress roots',()=>{
    const t={...tree('rainforest-000'),radius:2,height:44};
    const colliders=[{x:0,z:0,radius:2},...Array.from({length:6},(_,i)=>({x:Math.cos(i*Math.PI/3)*2*1.43,z:Math.sin(i*Math.PI/3)*2*1.43,radius:2*.48}))];
    const f=fixture({trees:[t],colliders});assert(f.ai.forceEncounter(t.id),'Root colliders prevented valid attachment.');
    const start=f.ai.getActive()[0];
    assert(start.descent.surfaceRadius<t.radius,'Upper-trunk attachment ignored taper.');
    assert(near(-Math.sin(start.heading),Math.cos(start.descent.angle))&&near(-Math.cos(start.heading),Math.sin(start.descent.angle)),'Climbing surface normal points inward.');
    advance(f.ai,start.descent.total);const landed=f.ai.getActive()[0];
    for(const c of colliders)assert(Math.hypot(landed.position.x-c.x,landed.position.z-c.z)>=c.radius+.85-1e-6,'The landing point overlaps a buttress root.');
    assert(near(landed.position.y,10),'Creature did not reach terrain height.');
  }],
  ['The actual descent path makes two full turns before landing',()=>{
    const t=tree('spiral-cylinder',17,-9),f=fixture({trees:[t]});
    assert(f.ai.forceEncounter(t.id),'Spiral encounter could not start.');
    const start=f.ai.getActive()[0],duration=start.descent.total;
    let previousAngle=Math.atan2(start.position.z-t.z,start.position.x-t.x),turn=0,previousY=start.position.y,left=duration*.9,rotationSign=0;
    while(left>1e-8){
      const dt=Math.min(.025,left);f.ai.update(dt,{x:500,y:10,z:500});left-=dt;
      const record=f.ai.getActive()[0],angle=Math.atan2(record.position.z-t.z,record.position.x-t.x);
      const delta=Math.atan2(Math.sin(angle-previousAngle),Math.cos(angle-previousAngle));
      if(Math.abs(delta)>1e-7){if(!rotationSign)rotationSign=Math.sign(delta);assert(delta*rotationSign>0,'The spiral reversed direction before leaving the trunk.');}
      turn+=delta;previousAngle=angle;
      assert(record.stage==='descending'&&record.position.y<=previousY+1e-7,'The creature stopped descending during the spiral.');
      previousY=record.position.y;
    }
    assert(near(Math.abs(turn)/(Math.PI*2),2,1e-5),`The sampled world path completed ${(Math.abs(turn)/(Math.PI*2)).toFixed(3)} turns instead of two.`);
    advance(f.ai,duration*.1);const landed=f.ai.getActive()[0];
    assert(['attacking','hunting'].includes(landed.stage),'The spiral did not finish at the original descent deadline.');
    assert(near(landed.position.x,t.x+Math.cos(start.descent.angle)*start.descent.landingRadius)&&near(landed.position.z,t.z+Math.sin(start.descent.angle)*start.descent.landingRadius),'Spiraling changed the chosen landing point.');
  }],
  ['A mid-spiral grip follows the bent rainforest trunk surface',()=>{
    const t={...tree('rainforest-000',23,-17),height:40,radius:2,angle:0},f=fixture({trees:[t]});
    assert(f.ai.forceEncounter(t.id),'Rainforest spiral could not start.');
    const start=f.ai.getActive()[0],ringY=t.h-.08+t.height*.4;
    // Locate the fixed scenery ring through observed trajectory samples. The
    // golden bark coordinates stay independent of the descent's easing curve.
    const initial=copy(f.ai.snapshot());let low=0,high=start.descent.total;
    for(let i=0;i<32;i++){
      const mid=(low+high)*.5,probe=createTeethpeedEncounters({...f.config,state:copy(initial)});advance(probe,mid);
      if(probe.getActive()[0].position.y>ringY)low=mid;else high=mid;
    }
    const timeToRing=(low+high)*.5;
    assert(timeToRing>0&&timeToRing<start.descent.total*.82,'Fixture did not sample the gripping portion of descent.');
    advance(f.ai,timeToRing);const record=f.ai.getActive()[0];
    // Golden coordinates of giantGeometry(0)'s fourth trunk ring, before its
    // instance scale/translation. This checks AI contact against the scenery.
    const centerX=t.x+.1897289299935345*t.radius,centerZ=t.z+.1839892765223138*t.radius;
    const gripRadius=.5381744406630179*t.radius+.08;
    const dx=record.position.x-centerX,dz=record.position.z-centerZ;
    assert(near(record.position.y,ringY)&&near(Math.hypot(dx,dz),gripRadius,1e-5),'Mid-turn position detached from the tapered, bent trunk.');
    assert(near(record.descent.surfaceRadius,gripRadius)&&record.descent.surfaceRadius>start.descent.surfaceRadius,'Grip radius did not grow as the tapered trunk widened.');
    assert(near(-Math.sin(record.heading),dx/gripRadius,1e-5)&&near(-Math.cos(record.heading),dz/gripRadius,1e-5),'The climbing body normal did not face out from its current side of the trunk.');
  }],
  ['Reloading mid-spiral preserves the exact next positions and turn direction',()=>{
    const t={...tree('rainforest-001',-11,7),radius:1.8,height:43,angle:.73},f=fixture({trees:[t]});
    assert(f.ai.forceEncounter(t.id),'Spiral reload fixture could not start.');
    advance(f.ai,f.ai.getActive()[0].descent.total*.373);
    const saved=copy(f.ai.snapshot()),before=f.ai.getActive()[0];
    assert(!Object.hasOwn(saved.active[0],'descentPose'),'Renderer-only spiral diagnostics leaked into the saved state.');
    const restored=createTeethpeedEncounters({...f.config,seed:'different-fallback-seed',state:saved,random:()=>{throw new Error('Spiral reload rerolled its direction.');}});
    assert(JSON.stringify(restored.getActive())===JSON.stringify(f.ai.getActive()),'Restoring a spiral changed its current pose or direction.');
    for(const dt of [.016,.031,.05,.024,.05,.016,.033]){
      const player={x:500,y:10,z:500};f.ai.update(dt,player);restored.update(dt,player);
      assert(JSON.stringify(restored.snapshot())===JSON.stringify(f.ai.snapshot()),'The next saved spiral position diverged after reload.');
      assert(JSON.stringify(restored.getActive())===JSON.stringify(f.ai.getActive()),'The next rendered spiral orientation diverged after reload.');
    }
    const after=f.ai.getActive()[0];
    assert(after.position.y<before.position.y&&Math.hypot(after.position.x-before.position.x,after.position.z-before.position.z)>.05,'The continuity check did not exercise a moving spiral.');
  }],
  ['The last descent step becomes a moving ground tangent without a vertical stop',()=>{
    const f=fixture({trees:[tree('landing-speed',12,-7)]});assert(f.ai.forceEncounter('landing-speed'),'Landing-speed fixture did not start.');
    const d=f.ai.getActive()[0].descent,epsilon=.001,player={x:d.treeX+Math.cos(d.angle)*(d.landingRadius+35),y:10,z:d.treeZ+Math.sin(d.angle)*(d.landingRadius+35)};
    advance(f.ai,d.total-epsilon*2,player);const a=f.ai.getActive()[0];
    f.ai.update(epsilon,player);const before=f.ai.getActive()[0];
    f.ai.update(epsilon,player);const landed=f.ai.getActive()[0];
    assert(before.stage==='descending'&&landed.stage==='attacking','The boundary samples did not straddle the original descent deadline.');
    const terminalVertical=(landed.position.y-before.position.y)/epsilon;
    const terminalHorizontal=Math.hypot(landed.position.x-before.position.x,landed.position.z-before.position.z)/epsilon;
    assert(Math.abs(terminalVertical)<.08,`Terminal vertical velocity was ${terminalVertical.toFixed(3)}m/s instead of approaching zero.`);
    assert(Math.abs(before.position.y-a.position.y)/epsilon<.15,'The penultimate descent step retained a falling impact speed.');
    assert(near(terminalHorizontal,TEETHPEED_SPEED,.08),`The rollout slowed to ${terminalHorizontal.toFixed(3)}m/s before reaching the ground.`);
    assert(near(landed.position.y,10)&&near(landed.remaining,landed.attackDuration),'Landing changed terrain height or consumed the pursuit deadline.');
    f.ai.update(epsilon,player);const next=f.ai.getActive()[0];
    const firstGroundSpeed=Math.hypot(next.position.x-landed.position.x,next.position.z-landed.position.z)/epsilon;
    assert(near(firstGroundSpeed,TEETHPEED_SPEED,.01)&&near(firstGroundSpeed,terminalHorizontal,.08),'The creature paused or changed speed at the first ground step.');
  }],
  ['An off-axis player cannot cause a position or heading snap at ground contact',()=>{
    const f=fixture({trees:[tree('landing-heading',-9,15)]});assert(f.ai.forceEncounter('landing-heading'),'Landing-heading fixture did not start.');
    const d=f.ai.getActive()[0].descent,epsilon=.001,landing={x:d.treeX+Math.cos(d.angle)*d.landingRadius,z:d.treeZ+Math.sin(d.angle)*d.landingRadius};
    const player={x:landing.x-Math.sin(d.angle)*30,y:10,z:landing.z+Math.cos(d.angle)*30};
    advance(f.ai,d.total-epsilon,player);const before=f.ai.getActive()[0];
    f.ai.update(epsilon,player);const landed=f.ai.getActive()[0];
    const turn=(a,b)=>Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));
    assert(landed.stage==='attacking'&&landed.senses.lineOfSight,'The visible off-axis player was not acquired on landing.');
    assert(Math.hypot(landed.position.x-before.position.x,landed.position.y-before.position.y,landed.position.z-before.position.z)<epsilon*8,'The position jumped at the descent-to-pursuit boundary.');
    assert(turn(landed.heading,before.heading)<.025,'The creature instantly turned toward an off-axis player at contact.');
    f.ai.update(epsilon,player);const next=f.ai.getActive()[0];
    assert(turn(next.heading,landed.heading)<.04,'The first pursuit step flipped the heading after a smooth landing.');
    assert(Math.hypot(next.position.x-landed.position.x,next.position.z-landed.position.z)>epsilon*2,'Steering toward the player introduced a pause at contact.');
  }],
  ['Saving during the terminal rollout preserves the next descent and pursuit frames',()=>{
    const t={...tree('rainforest-001',-16,11),radius:1.9,height:43,angle:.63},f=fixture({trees:[t]});
    assert(f.ai.forceEncounter(t.id),'Terminal reload fixture did not start.');
    const d=f.ai.getActive()[0].descent,player={x:d.treeX+Math.cos(d.angle)*35,y:10,z:d.treeZ+Math.sin(d.angle)*35};
    advance(f.ai,d.total*.91,player);const before=f.ai.getActive()[0],saved=copy(f.ai.snapshot());
    assert(before.stage==='descending'&&before.descentPose.groundBlend>0,'The saved sample did not reach the terminal transition.');
    const restored=createTeethpeedEncounters({...f.config,state:saved,seed:'unused-terminal-fallback',random:()=>{throw new Error('Terminal reload rerolled its path.');}});
    assert(JSON.stringify(restored.getActive())===JSON.stringify(f.ai.getActive()),'Restoring the terminal rollout changed its pose or velocity.');
    const steps=[.016,.031,.05,.024,.033];
    for(let i=0;i<48;i++){
      const dt=steps[i%steps.length];f.ai.update(dt,player);restored.update(dt,player);
      assert(JSON.stringify(restored.snapshot())===JSON.stringify(f.ai.snapshot()),'The saved terminal transition diverged after resume.');
      assert(JSON.stringify(restored.getActive())===JSON.stringify(f.ai.getActive()),'The resumed terminal or ground pose diverged.');
    }
    const after=f.ai.getActive()[0];
    assert(after.stage==='attacking'&&after.attackDuration-after.remaining>.55,'The reload check did not continue through the complete ground steering handoff.');
  }],
  ['Ground transition diagnostics are finite, continuous, and never persisted',()=>{
    const f=fixture({trees:[tree('landing-diagnostics')]});assert(f.ai.forceEncounter('landing-diagnostics'),'Landing diagnostics fixture did not start.');
    const d=f.ai.getActive()[0].descent,player={x:d.treeX+Math.cos(d.angle)*35,y:10,z:d.treeZ+Math.sin(d.angle)*35};
    advance(f.ai,d.total*.80,player);const attached=f.ai.getActive()[0];
    assert(near(attached.descentPose.groundBlend,0),'Ground blending began before the two-turn trunk phase was complete.');
    advance(f.ai,d.total*.1999,player);const terminal=f.ai.getActive()[0],pose=terminal.descentPose;
    assert(terminal.stage==='descending'&&pose.groundBlend>.99&&pose.groundBlend<=1,'Ground blending did not finish smoothly before contact.');
    assert(pose.velocity&&[pose.velocity.x,pose.velocity.y,pose.velocity.z].every(Number.isFinite),'The terminal pose has no finite three-dimensional velocity.');
    assert(Math.abs(pose.velocity.y)<.10&&Math.hypot(pose.velocity.x,pose.velocity.z)>TEETHPEED_SPEED*.8,'The renderer received a falling or stationary terminal velocity.');
    const saved=f.ai.snapshot();assert(!Object.hasOwn(saved.active[0],'descentPose'),'Derived ground-pose diagnostics leaked into the saved record.');
    pose.velocity.x=999;pose.groundBlend=-5;
    const again=f.ai.getActive()[0].descentPose;
    assert(again.velocity.x!==999&&again.groundBlend>0,'Mutating returned ground diagnostics changed the live trajectory.');
  }],
  ['An unobstructed chase moves at exactly 4.45m/s',()=>{
    const f=attacking(),before={...f.ai.getActive()[0].position},player={x:before.x+200,y:10,z:before.z};
    let distance=0,previous=before;
    for(let i=0;i<20;i++){f.ai.update(.05,player);const next=f.ai.getActive()[0].position;distance+=Math.hypot(next.x-previous.x,next.z-previous.z);previous={...next};}
    assert(near(distance,TEETHPEED_SPEED,1e-5),'Actual path length over one second does not equal4.45m/s.');
  }],
  ['Landing without sight enters hunting instead of attacking a hidden player',()=>{
    const f=fixture({trees:[tree('tree-a',-8,0)],colliders:cover()});assert(f.ai.forceEncounter('tree-a'),'Hidden landing fixture did not start.');
    const start=f.ai.getActive()[0];advance(f.ai,start.descent.total,{x:4,y:10,z:0});const landed=f.ai.getActive()[0];
    assert(landed.stage==='hunting'&&!landed.senses.lineOfSight,'An occluded landing incorrectly began a visible chase.');
    assert(near(landed.remaining,landed.attackDuration),'Landing lost or reset the allotted pursuit time.');
    const clear=attacking();assert(clear.ai.getActive()[0].senses.lineOfSight,'The visible landing control did not acquire sight.');
  }],
  ['Losing sight for 0.2s starts hunting even while the player stays within 10m',()=>{
    const f=attacking({trees:[tree('tree-a',-24,20)],colliders:cover()});
    placeActive(f,{x:-6,y:10,z:0},{lastKnownPlayer:{x:-4,y:10,z:0},sightLostFor:0,sightFoundFor:0});
    const hidden={x:3,y:10,z:0};advance(f.ai,.15,hidden);
    assert(f.ai.getActive()[0].stage==='attacking','Sight loss was confirmed before 0.2s.');
    advance(f.ai,.05,hidden);const a=f.ai.getActive()[0];
    assert(a.stage==='hunting'&&a.senses.withinDetection&&!a.senses.lineOfSight,'Proximity overrode the loss of sight.');
    assert(f.events.filter(e=>e.type==='hunting').length===1,'Confirmed sight loss did not emit exactly one hunting transition.');
  }],
  ['Crossing the 10m boundary behind cover never cancels hunting',()=>{
    const f=huntingFixture();
    advance(f.ai,.25,{x:15,y:10,z:0});assert(!f.ai.getActive()[0].senses.withinDetection,'The outside-range fixture did not cross the boundary.');
    advance(f.ai,.25,{x:3,y:10,z:0});const a=f.ai.getActive()[0];
    assert(a.senses.withinDetection&&!a.senses.lineOfSight&&a.stage==='hunting','Reentering 10m behind cover restored a chase.');
    assert(!f.events.some(e=>e.type==='reacquired'),'Hidden range reentry emitted reacquisition.');
  }],
  ['Clear sight reacquires after 0.2s beyond 10m without resetting the timer',()=>{
    const f=huntingFixture(),before=f.ai.getActive()[0].remaining,visible={x:-24,y:10,z:0};
    advance(f.ai,.15,visible);assert(f.ai.getActive()[0].stage==='hunting','Sight was reacquired before its confirmation interval.');
    advance(f.ai,.05,visible);const a=f.ai.getActive()[0];
    assert(a.stage==='attacking'&&a.senses.lineOfSight&&!a.senses.withinDetection,'Clear sight beyond initial detection range did not restore chase.');
    assert(near(a.remaining,before-.2),'Reacquisition reset or extended the shared hunt/attack timer.');
    assert(f.events.filter(e=>e.type==='reacquired').length===1,'Sight recovery did not emit exactly one reacquired event.');
  }],
  ['Hidden player movement cannot change the remembered search path',()=>{
    const f=huntingFixture(),saved=f.ai.snapshot(),a=createTeethpeedEncounters({...f.config,state:copy(saved)}),b=createTeethpeedEncounters({...f.config,state:copy(saved)});
    const remembered=copy(saved.active[0].lastKnownPlayer);
    for(let i=0;i<70;i++) {
      a.update(.05,{x:4,y:10,z:.8});b.update(.05,{x:12,y:10,z:-.8});const left=a.getActive()[0],right=b.getActive()[0];
      assert(left.stage==='hunting'&&right.stage==='hunting'&&!left.senses.lineOfSight&&!right.senses.lineOfSight,'A hidden trajectory fixture unexpectedly became visible.');
      for(const key of ['position','heading','lastKnownPlayer','searchTarget','searchIndex','searchWait'])assert(JSON.stringify(left[key])===JSON.stringify(right[key]),`Hidden player position changed ${key}.`);
      assert(JSON.stringify(left.lastKnownPlayer)===JSON.stringify(remembered),'The last seen position followed an unseen player.');
    }
  }],
  ['Hunting reaches the last seen area and persists a valid local search target',()=>{
    const f=huntingFixture(),hidden={x:8,y:10,z:0};
    for(let i=0;i<120&&f.ai.getActive()[0].searchIndex===0;i++)f.ai.update(.05,hidden);
    const a=f.ai.getActive()[0];assert(a.stage==='hunting'&&a.searchIndex>0&&a.huntingTime>0,'The creature never progressed from last seen position to local search.');
    assert(a.searchTarget&&near(a.searchTarget.y,10),'Search target is not on the terrain.');
    assert(Math.hypot(a.searchTarget.x-a.lastKnownPlayer.x,a.searchTarget.z-a.lastKnownPlayer.z)<=8,'Search jumped far from the last seen area.');
    for(const c of f.config.colliders)assert(Math.hypot(a.searchTarget.x-c.x,a.searchTarget.z-c.z)>=c.radius+.85-1e-6,'Search target was placed inside cover.');
    const saved=copy(f.ai.snapshot()),restored=createTeethpeedEncounters({...f.config,seed:'must-not-reroll-search',state:saved});
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(saved),'Reload changed saved search memory or timers.');
    for(let i=0;i<35;i++){f.ai.update(.05,hidden);restored.update(.05,hidden);assert(JSON.stringify(restored.snapshot())===JSON.stringify(f.ai.snapshot()),'Resumed searching diverged from uninterrupted searching.');}
  }],
  ['Terrain occlusion makes the actual controller search without tracking through a ridge',()=>{
    const heightAt=x=>Math.abs(x)<.8?13:10,f=attacking({heightAt,trees:[tree('tree-a',-20,20)]});
    placeActive(f,{x:-4,y:10,z:0},{lastKnownPlayer:{x:-3,y:10,z:0},sightLostFor:0,sightFoundFor:0});
    advance(f.ai,.25,{x:4,y:10,z:0});const a=f.ai.getActive()[0];
    assert(a.stage==='hunting'&&!a.senses.lineOfSight,'Terrain did not interrupt the actual AI chase.');
    assert(a.lastKnownPlayer.x===-3,'The controller updated its memory through terrain.');
  }],
  ['Hunting expiry shares the original deadline and cannot cause hidden damage',()=>{
    const f=huntingFixture(),a=f.ai.getActive()[0];placeActive(f,a.position,{stage:'hunting',remaining:.03,biteCooldown:0});
    f.ai.update(.05,{x:3,y:10,z:0});assert(f.ai.getActive()[0].stage==='retreating'&&f.damage.length===0,'Hunting failed to expire at the existing deadline.');
  }],
  ['Legacy encounter saves receive safe defaults for new sensory memory',()=>{
    const f=attacking(),legacy=copy(f.ai.snapshot());
    for(const key of ['lastKnownPlayer','huntingTime','searchIndex','searchTarget','searchWait','sightLostFor','sightFoundFor','senses'])delete legacy.active[0][key];
    const normalized=normalizeEncounterState(legacy);assert(normalized!==null,'An existing encounter save was rejected after the senses update.');
    const a=normalized.active[0];assert(a.lastKnownPlayer===null&&a.searchTarget===null&&a.huntingTime===0&&a.searchIndex===0&&a.sightLostFor===0&&a.sightFoundFor===0,'Legacy sensory defaults were unsafe or uninitialized.');
    const restored=createTeethpeedEncounters({...f.config,state:normalized});assert(restored.getActive()[0].stage==='attacking','A legacy restore changed its active encounter stage.');
  }],
  ['Search memory is validated and copies cannot mutate live senses',()=>{
    const f=huntingFixture(),saved=f.ai.snapshot(),returned=f.ai.getActive()[0];returned.lastKnownPlayer.x=999;returned.searchTarget.z=999;returned.senses.lineOfSight=true;
    const live=f.ai.getActive()[0];assert(live.lastKnownPlayer.x!==999&&live.searchTarget.z!==999&&!live.senses.lineOfSight,'Caller-owned data changed internal search memory.');
    for(const patch of [{lastKnownPlayer:{x:NaN,y:10,z:0}},{searchTarget:{x:0,y:Infinity,z:0}},{huntingTime:-1},{searchIndex:1.5},{searchWait:-1},{sightLostFor:NaN},{sightFoundFor:-1},{senses:{distance:2,withinDetection:true,lineOfSight:'yes'}}]){
      const bad=copy(saved);Object.assign(bad.active[0],patch);assert(normalizeEncounterState(bad)===null,'Malformed search memory was accepted.');
    }
  }],
  ['Teethpeed gains on walking and loses ground against sprinting',()=>{
    function gapAfter(speed){const f=attacking(),p=f.ai.getActive()[0].position,player={x:p.x+15,y:10,z:p.z};for(let i=0;i<160;i++){player.x+=speed*.05;f.ai.update(.05,player);}const end=f.ai.getActive()[0].position;return Math.hypot(player.x-end.x,player.z-end.z);}
    assert(gapAfter(4.2)<15,'Walking outpaced the creature.');assert(gapAfter(7.2)>15,'Sprinting did not gain distance.');
  }],
  ['No update means no timer, movement or simulation-clock changes',async()=>{
    const f=attacking(),before=JSON.stringify(f.ai.snapshot());await new Promise(resolve=>setTimeout(resolve,80));
    for(let i=0;i<20;i++)f.ai.getActive();assert(JSON.stringify(f.ai.snapshot())===before,'AI advanced while the game withheld update.');
  }],
  ['Saved state restores the same draw, pose, timers and clock',()=>{
    const f=attacking();advance(f.ai,2.3);const saved=f.ai.snapshot();
    const restored=createTeethpeedEncounters({...f.config,seed:'must-not-replace-persisted-seed',state:copy(saved),random:()=>{throw new Error('Reload called random.');}});
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(saved),'Reload changed the encounter snapshot.');
    const player={x:100,y:10,z:60};f.ai.update(.15,player);restored.update(.15,player);
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(f.ai.snapshot()),'Restored simulation diverged from uninterrupted simulation.');
  }],
  ['Simulation clock is monotonic and rejects negative persisted clocks',()=>{
    const f=fixture();f.ai.update(.20,{x:500,y:10,z:500});f.ai.update(.15,{x:500,y:10,z:500});
    assert(near(f.ai.snapshot().clock,.35),'Simulation seconds were not accumulated.');
    assert(normalizeEncounterState({...f.ai.snapshot(),clock:-1})===null,'A negative persisted clock was accepted.');
  }],
  ['Contact bites deal 22 damage no more frequently than every 1.8s',()=>{
    const f=attacking(),player={...f.ai.getActive()[0].position};f.ai.update(.05,player);
    assert(f.damage.length===1&&f.damage[0].amount===TEETHPEED_BITE_DAMAGE&&f.damage[0].cause==='Teethpeed','First contact did not apply the expected bite.');
    assert(f.damage[0].active.biteCooldown>1.7,'Cooldown was not advanced before the damage callback.');
    advance(f.ai,1.7,player);assert(f.damage.length===1,'A second bite arrived too soon.');advance(f.ai,.15,player);assert(f.damage.length===2,'The bite interval did not repeat.');
  }],
  ['A long frame cannot create a burst of catch-up damage',()=>{
    const f=attacking(),player={...f.ai.getActive()[0].position},before=f.ai.snapshot().clock;
    f.ai.update(1000,player);assert(f.damage.length<=1,'A large dt created a damage burst.');
    assert(near(f.ai.snapshot().clock-before,.25),'Large-frame simulation was not bounded to.25s.');
  }],
  ['A nearby bite cannot pass through a thin trunk or rock',()=>{
    const obstacle={x:0,z:0,radius:.1,height:8},f=attacking({colliders:[obstacle],trees:[tree('tree-a',-20,20)]});
    placeActive(f,{x:-1,y:10,z:0},{biteCooldown:0});f.ai.update(.05,{x:.5,y:10,z:0});
    assert(f.damage.length===0,'A bite passed through an intervening collider.');
    const clear=attacking({trees:[tree('tree-a',-20,20)]});placeActive(clear,{x:-1,y:10,z:0},{biteCooldown:0});
    clear.ai.update(.05,{x:.5,y:10,z:0});assert(clear.damage.length===1,'The clear control case did not bite at the same distance.');
  }],
  ['Moving behind terrain cover cancels a bite that was visible before the step',()=>{
    // This low ridge clears the initial eye ray. Walking closer lowers the ray
    // through the ridge, while the creature's actual ground remains level.
    const ridge=(x,z)=>x>.7&&x<1.25&&Math.abs(z)<.4?10.215+x*.5:10;
    const origin={x:0,y:10,z:0},player={x:1.7,y:10,z:0};
    const f=attacking({heightAt:ridge,trees:[tree('tree-a',-20,20)]});
    placeActive(f,origin,{biteCooldown:0,lastKnownPlayer:{...player},sightLostFor:0,sightFoundFor:0});
    assert(hasTeethpeedLineOfSight({position:origin,player,heightAt:ridge,colliders:[]}),'The regression fixture was already hidden before movement.');
    f.ai.update(.05,player);const after=f.ai.getActive()[0];
    assert(after.position.x>.1&&Math.hypot(player.x-after.position.x,player.z-after.position.z)<1.65,'The regression fixture did not move into bite range.');
    assert(!hasTeethpeedLineOfSight({position:after.position,player,heightAt:ridge,colliders:[]}),'The ridge did not block the post-move eye ray.');
    assert(f.damage.length===0,'A bite used stale pre-move visibility and passed through terrain.');
    const clear=attacking({trees:[tree('tree-a',-20,20)]});
    placeActive(clear,origin,{biteCooldown:0,lastKnownPlayer:{...player},sightLostFor:0,sightFoundFor:0});
    clear.ai.update(.05,player);
    assert(clear.damage.length===1&&clear.damage[0].amount===TEETHPEED_BITE_DAMAGE,'The same movement failed to bite without the intervening ridge.');
  }],
  ['Attack expiry stops bites, retreats, then leaves the tree spent',()=>{
    const f=attacking(),position={...f.ai.getActive()[0].position};placeActive(f,position,{remaining:.03,biteCooldown:0});
    f.ai.update(.05,position);assert(f.ai.getActive()[0].stage==='retreating'&&f.damage.length===0,'An expired attack kept biting.');
    advance(f.ai,7,position);assert(!f.ai.getActive().length&&!f.ai.forceEncounter('tree-a'),'A departed encounter was allowed to repeat.');
    assert(f.ai.snapshot().spent.includes('tree-a'),'Spent tree was not persisted.');
  }],
  ['Two active encounters leave a third tree pending, not spent',()=>{
    const trees=[tree('a',0,0),tree('b',8,0),tree('c',-8,0)],f=fixture({trees});
    assert(f.ai.forceEncounter('a')&&f.ai.forceEncounter('b')&&!f.ai.forceEncounter('c'),'The active cap is not two.');
    assert(!f.ai.snapshot().spent.includes('c'),'A pending tree was consumed before it could spawn.');
    const saved=f.ai.snapshot();saved.active=saved.active.map(record=>({...record,stage:'retreating',remaining:.01,retreatRemaining:.01}));
    f.ai=createTeethpeedEncounters({...f.config,state:saved});f.ai.update(.05,{x:500,y:10,z:500});
    assert(f.ai.forceEncounter('c'),'Pending tree remained blocked after a slot became available.');
  }],
  ['Directional avoidance keeps the body outside a giant trunk',()=>{
    const c={x:5,z:0,radius:2.5,height:12},f=attacking({colliders:[c],trees:[tree('tree-a',-20,20)]});placeActive(f,{x:0,y:10,z:0},{lastKnownPlayer:{x:15,y:10,z:0}});
    const initial={...f.ai.getActive()[0].position};
    for(let i=0;i<180;i++){f.ai.update(.05,{x:15,y:10,z:0});const p=f.ai.getActive()[0].position;assert(Math.hypot(p.x-c.x,p.z-c.z)>=c.radius+.85-1e-6,'Creature penetrated a trunk collider.');}
    const end=f.ai.getActive()[0].position;assert(Math.hypot(end.x-initial.x,end.z-initial.z)>2,'Avoidance never made progress.');
  }],
  ['Deep water blocks pursuit without teleporting across the river',()=>{
    const heightAt=x=>x>2?0:10,f=attacking({heightAt,trees:[tree('tree-a',-20,20)]});placeActive(f,{x:0,y:10,z:0});
    for(let i=0;i<100;i++){f.ai.update(.05,{x:15,y:10,z:0});const p=f.ai.getActive()[0].position;assert(p.x<=2&&p.y>=1.18,'Creature crossed deep water.');}
  }],
  ['Abrupt cliffs block movement while gentle terrain is followed',()=>{
    const cliff=attacking({heightAt:x=>x>2?45:10,trees:[tree('tree-a',-20,20)]});placeActive(cliff,{x:0,y:10,z:0},{lastKnownPlayer:{x:15,y:45,z:0}});
    for(let i=0;i<80;i++){cliff.ai.update(.05,{x:15,y:45,z:0});assert(cliff.ai.getActive()[0].position.x<=2,'Creature teleported up an abrupt cliff.');}
    const gentle=attacking({heightAt:x=>10+x*.2,trees:[tree('tree-a',0,20)]});placeActive(gentle,{x:0,y:10,z:0});advance(gentle.ai,2,{x:20,y:14,z:0});
    const p=gentle.ai.getActive()[0].position;assert(p.x>5&&near(p.y,10+p.x*.2),'Chase did not follow a walkable slope.');
  }],
  ['Callbacks happen at transitions and hits, never in the constructor',()=>{
    const f=fixture();assert(!f.events.length&&!f.changes.length,'Constructor called a callback before the owner was initialized.');
    f.ai.forceEncounter('tree-a');assert(f.changes.length===1,'Starting descent did not emit one change.');advance(f.ai,.4);
    assert(f.changes.length===1,'Routine movement emitted a save callback every frame.');
  }],
  ['Invalid state is rejected and returned snapshots cannot mutate AI',()=>{
    const f=attacking(),snapshot=f.ai.snapshot(),returned=f.ai.getActive();returned[0].position.x=999;returned[0].descent.elapsed=0;
    assert(f.ai.getActive()[0].position.x!==999,'Renderer-facing data mutated internal state.');
    for(const edit of [record=>record.stage='invalid',record=>record.remaining=NaN,record=>record.attackDuration=500,record=>record.biteCooldown=-1]){const bad=copy(snapshot);edit(bad.active[0]);assert(normalizeEncounterState(bad)===null,'Malformed encounter data was accepted.');}
    assert(normalizeEncounterState(undefined)===undefined&&normalizeEncounterState(null)===null,'Absent/invalid state contract changed.');
  }],
  ['Removed scenery cannot erase spent encounter history',()=>{
    const f=attacking(),saved=f.ai.snapshot(),restored=createTeethpeedEncounters({...f.config,trees:[],state:saved});
    assert(!restored.getActive().length&&restored.snapshot().spent.includes('tree-a'),'Removing a tree erased its spent history.');
  }],
];

export async function runTeethpeedChecks(onResult=()=>{}) {
  let passed=0;
  for(const [name,check] of teethpeedChecks){let error=null;try{await check();passed++;}catch(caught){error=caught;}onResult({name,passed:!error,error});}
  return {passed,total:teethpeedChecks.length};
}

if(typeof document!=='undefined') {
  const button=document.getElementById('run-checks'),results=document.getElementById('results'),summary=document.getElementById('summary');
  button?.addEventListener('click',async()=>{
    button.disabled=true;results.replaceChildren();summary.textContent='Running isolated encounter checks…';
    const outcome=await runTeethpeedChecks(result=>{
      const row=document.createElement('li'),label=document.createElement('strong'),copy=document.createElement('span');row.className=result.passed?'pass':'fail';
      label.textContent=result.passed?'PASS':'FAIL';copy.textContent=result.name;row.append(label,copy);
      if(result.error){const detail=document.createElement('p');detail.textContent=result.error.message;row.append(detail);}results.append(row);
    });
    summary.textContent=outcome.passed===outcome.total?`All ${outcome.total} checks passed.`:`${outcome.passed} passed · ${outcome.total-outcome.passed} failed.`;
    button.disabled=false;button.textContent='Run checks again';
  });
}
