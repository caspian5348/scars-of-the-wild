/** Data shared by inventory, world interactions and the crafting/building UI. */
const freeze = value => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
};
const items = {}, recipes = {}, buildings = {};
function item(id, name, kind, weight, extra = {}) {
  items[id] = {id, name, kind, weight, stack: ['tool', 'weapon', 'clothing', 'gear'].includes(kind) ? 1 : kind === 'food' ? 20 : 50,
    description: name, ...extra};
}
function recipe(id, name, cost, outputs, station = null, extra = {}) {
  recipes[id] = {id, name, description: name, cost, outputs, station, unlock: {resources: Object.keys(cost)}, ...extra};
}
function building(id, name, cost, extra = {}) {
  buildings[id] = {id, name, description: name, cost, station: null, unlock: {resources: Object.keys(cost)}, ...extra};
}

[
  ['branch', 'Dry Branch', .35], ['wood', 'Timber', 1.5], ['stone', 'Stone', .65], ['flint', 'Flint', .3],
  ['fiber', 'Plant Fiber', .035], ['leaf', 'Broad Leaf', .015], ['resin', 'Tree Resin', .08], ['vine', 'Vine', .12],
  ['clay', 'Clay', .65], ['sand', 'Sand', .6], ['bark', 'Bark', .16], ['feathers', 'Feathers', .015],
  ['bone', 'Bone', .3], ['hide', 'Raw Hide', 1.2], ['leather', 'Cured Leather', .65], ['sinew', 'Sinew', .08],
  ['salt', 'Mineral Salt', .12], ['charcoal', 'Charcoal', .22], ['coal', 'Coal', .45], ['copper_ore', 'Copper Ore', .9],
  ['tin_ore', 'Tin Ore', .9], ['iron_ore', 'Iron Ore', 1.1], ['gold_ore', 'Gold Ore', 1.1], ['cave_ore', 'Abyssal Ore', 1.2],
  ['obsidian', 'Obsidian', .65], ['frost_crystal', 'Frost Crystal', .4], ['crystal_shard', 'Crystal Shard', .3],
  ['chitin', 'Chitin Plate', .4], ['venom', 'Venom Sac', .08], ['ember_gland', 'Ember Gland', .18], ['fur', 'Thick Fur', .8], ['shell', 'Shell', .3],
  ['rope', 'Rope', .16], ['plank', 'Timber Plank', .85], ['cloth', 'Woven Cloth', .15], ['brick', 'Fired Brick', 1.1],
  ['copper_bar', 'Copper Bar', 1.2], ['tin_bar', 'Tin Bar', 1.2], ['bronze_bar', 'Bronze Bar', 1.25], ['iron_bar', 'Iron Bar', 1.4],
  ['gold_bar', 'Gold Bar', 1.5], ['abyssal_bar', 'Abyssal Alloy Bar', 1.4], ['nails', 'Iron Nails', .12], ['glass', 'Glass', .35],
].forEach(([id, name, weight]) => item(id, name, 'material', weight));

function food(id, name, weight, hunger, thirst, shelfLife, extra = {}) {
  item(id, name, 'food', weight, {nutrition: {hunger, thirst, healthDelta: 0, ...extra.nutrition}, shelfLife,
    ...Object.fromEntries(Object.entries(extra).filter(([key]) => key !== 'nutrition'))});
}
food('berries', 'Wild Berries', .08, 5, 3, 3600, {description: 'Edible berries. A little food and moisture.'});
food('mushroom', 'Edible Mushroom', .1, 7, 1, 3000, {description: 'A safely identified edible mushroom; can be roasted.'});
food('roots', 'Edible Roots', .22, 9, 0, 5400);
food('nuts', 'Forest Nuts', .08, 8, -1, 10800);
food('raw_meat', 'Raw Meat', .5, 10, -2, 1200, {nutrition: {healthDelta: -6}, description: 'Cook before eating. Eating it raw causes illness.'});
food('cooked_meat', 'Roasted Meat', .4, 32, 0, 3600, {nutrition: {healthDelta: 3}});
food('raw_fish', 'Raw Fish', .45, 9, 0, 1000, {nutrition: {healthDelta: -4}, description: 'Fresh fish. Cook it before eating.'});
food('cooked_fish', 'Roasted Fish', .35, 27, 2, 3000, {nutrition: {healthDelta: 3}});
food('cooked_mushroom', 'Roasted Mushroom', .08, 13, 1, 3600);
food('roasted_roots', 'Roasted Roots', .18, 20, 0, 5400);
food('dried_meat', 'Dried Meat', .22, 24, -4, 14400, {description: 'Preserved meat keeps much longer but makes you thirsty.'});
food('dried_fish', 'Dried Fish', .2, 22, -3, 14400);
food('berry_porridge', 'Berry and Root Mash', .35, 29, 9, 3000);
food('hearty_stew', 'Hunter’s Stew', .65, 52, 22, 3600, {nutrition: {healthDelta: 8}});
food('herbal_tea', 'Herbal Tea', .3, 0, 30, 7200, {nutrition: {healthDelta: 5}, warmth: 12});
food('spoiled_food', 'Spoiled Food', .08, 1, -6, 0, {stack: 50, nutrition: {healthDelta: -12}, description: 'Rotten food causes severe illness. Discard it.'});
item('herb', 'Medicinal Herb', 'material', .035, {description: 'Useful for poultices and restorative tea.'});
item('empty_waterskin', 'Empty Waterskin', 'container', .2, {stack: 4, description: 'Fill at a river, then boil the water at a campfire.'});
food('dirty_water', 'Unboiled Waterskin', 1.2, 0, 45, 0, {stack: 4, returns: {empty_waterskin: 1}, nutrition: {healthDelta: -3}, description: 'Boiling this water makes it safe to drink.'});
food('clean_water', 'Clean Waterskin', 1.2, 0, 55, 0, {stack: 4, returns: {empty_waterskin: 1}});
item('bandage', 'Plant-Fiber Bandage', 'medical', .08, {nutrition: {hunger: 0, thirst: 0, healthDelta: 14}, description: 'Use to restore 14 health.'});
item('poultice', 'Herbal Poultice', 'medical', .14, {nutrition: {hunger: 0, thirst: 0, healthDelta: 28}, description: 'Use to restore 28 health.'});
item('warming_tonic', 'Warming Tonic', 'medical', .18, {nutrition: {hunger: 0, thirst: 8, healthDelta: 3}, warmth: 35, description: 'Restores warmth during cold exposure.'});
item('cooling_salve', 'Cooling Salve', 'medical', .14, {nutrition: {hunger: 0, thirst: 0, healthDelta: 4}, warmth: -35, description: 'Cools overheated skin.'});

function tool(id, name, type, tier, durability, weight, damage, repair) {
  item(id, name, ['spear', 'bow', 'club'].includes(type) ? 'weapon' : 'tool', weight, {tool: type, tier, durability, slot: 'hand', damage,
    reach: type === 'spear' ? 3.15 : type === 'bow' ? 40 : 1.9, attackSeconds: type === 'pickaxe' ? .85 : type === 'bow' ? 1.1 : .65,
    repair, description: `Tier ${tier} ${type}. Wears with use; repair it before it breaks.`});
}
tool('stone_axe', 'Stone Axe', 'axe', 1, 70, 2.2, 14, {stone: 2, fiber: 1});
tool('copper_axe', 'Copper Axe', 'axe', 2, 120, 2.6, 19, {copper_bar: 1, wood: 1});
tool('bronze_axe', 'Bronze Axe', 'axe', 3, 170, 2.8, 25, {bronze_bar: 1, wood: 1});
tool('iron_axe', 'Iron Axe', 'axe', 4, 230, 3, 33, {iron_bar: 1, wood: 1});
tool('abyssal_axe', 'Abyssal Axe', 'axe', 5, 340, 2.9, 47, {abyssal_bar: 1, resin: 2});
tool('stone_pickaxe', 'Stone Pickaxe', 'pickaxe', 1, 85, 2.5, 9, {stone: 3, fiber: 1});
tool('copper_pickaxe', 'Copper Pickaxe', 'pickaxe', 2, 140, 2.8, 13, {copper_bar: 1, wood: 1});
tool('bronze_pickaxe', 'Bronze Pickaxe', 'pickaxe', 3, 190, 3, 18, {bronze_bar: 1, wood: 1});
tool('iron_pickaxe', 'Iron Pickaxe', 'pickaxe', 4, 260, 3.2, 24, {iron_bar: 1, wood: 1});
tool('abyssal_pickaxe', 'Abyssal Pickaxe', 'pickaxe', 5, 380, 3.1, 35, {abyssal_bar: 1, resin: 2});
tool('stone_knife', 'Flint Knife', 'knife', 1, 65, .45, 12, {flint: 1, fiber: 1});
tool('iron_knife', 'Iron Knife', 'knife', 4, 180, .65, 27, {iron_bar: 1});
tool('obsidian_knife', 'Obsidian Knife', 'knife', 5, 145, .6, 41, {obsidian: 2, resin: 1});
tool('stone_spear', 'Stone Spear', 'spear', 1, 80, 1.8, 22, {stone: 2, fiber: 1});
tool('bronze_spear', 'Bronze Spear', 'spear', 3, 160, 2.2, 34, {bronze_bar: 1});
tool('iron_spear', 'Iron Spear', 'spear', 4, 220, 2.5, 45, {iron_bar: 1});
tool('abyssal_spear', 'Abyssal Spear', 'spear', 5, 310, 2.4, 64, {abyssal_bar: 1});
tool('wood_club', 'Hardwood Club', 'club', 0, 60, 1.6, 13, {wood: 1, fiber: 1});
tool('hunting_bow', 'Hunting Bow', 'bow', 1, 110, 1.25, 27, {wood: 2, rope: 1});
tool('composite_bow', 'Reinforced Bow', 'bow', 4, 210, 1.6, 43, {iron_bar: 1, sinew: 2});
items.hunting_bow.ammo = 'arrow'; items.composite_bow.ammo = 'arrow';
tool('building_hammer', 'Building Hammer', 'hammer', 1, 150, 1.35, 8, {wood: 1, stone: 1});
tool('fishing_rod', 'Fishing Rod', 'fishing', 1, 100, .85, 2, {branch: 2, rope: 1});
tool('torch', 'Resin Torch', 'torch', 0, 180, .65, 8, {branch: 1, resin: 1});
item('arrow', 'Stone Arrow', 'ammo', .045, {stack: 50, damage: 0, description: 'Ammunition for either bow.'});
item('iron_arrow', 'Iron Arrow', 'ammo', .055, {stack: 50, damage: 12, description: 'Stronger bow ammunition.'});
item('venom_arrow', 'Venom Arrow', 'ammo', .045, {stack: 50, damage: 20, description: 'A venom-tipped hunting arrow.'});
item('fire_arrow', 'Ember Arrow', 'ammo', .07, {stack: 50, damage: 18, description: 'An ember-tipped hunting arrow.'});
item('hide_coat', 'Hide Coat', 'clothing', 2.2, {slot: 'body', durability: 180, insulation: .38, armor: .08, repair: {leather: 1, fiber: 2}});
item('fur_coat', 'Winter Fur Coat', 'clothing', 3.2, {slot: 'body', durability: 230, insulation: .8, armor: .12, repair: {fur: 1, leather: 1}});
item('chitin_armor', 'Chitin Armor', 'clothing', 4.5, {slot: 'body', durability: 290, insulation: .3, armor: .3, repair: {chitin: 2, leather: 1}});
item('abyssal_armor', 'Abyssal Scale Armor', 'clothing', 5.5, {slot: 'body', durability: 390, insulation: .5, armor: .44, repair: {abyssal_bar: 1, chitin: 2}});
item('leather_pack', 'Leather Backpack', 'gear', 1.1, {slot: 'back', extraSlots: 12, extraWeight: 30, description: 'Adds 12 inventory slots and 30kg carrying capacity.'});
item('expedition_pack', 'Expedition Backpack', 'gear', 1.7, {slot: 'back', extraSlots: 24, extraWeight: 55, description: 'Adds 24 inventory slots and 55kg carrying capacity.'});

recipe('rope', 'Twist Rope', {fiber: 4}, {rope: 1});
recipe('cloth', 'Weave Cloth', {fiber: 6}, {cloth: 1}, 'workbench');
recipe('plank', 'Saw Timber Planks', {wood: 2}, {plank: 3}, 'workbench');
recipe('bandage', 'Make Bandages', {fiber: 4, leaf: 2}, {bandage: 2});
recipe('poultice', 'Prepare Herbal Poultice', {herb: 3, bandage: 1, charcoal: 1}, {poultice: 1}, 'campfire');
recipe('stone_axe', 'Craft Stone Axe', {branch: 2, stone: 3, fiber: 2}, {stone_axe: 1});
recipe('stone_pickaxe', 'Craft Stone Pickaxe', {branch: 2, stone: 5, fiber: 3}, {stone_pickaxe: 1});
recipe('stone_knife', 'Craft Flint Knife', {flint: 2, branch: 1, fiber: 1}, {stone_knife: 1});
recipe('stone_spear', 'Craft Stone Spear', {branch: 3, stone: 2, fiber: 2}, {stone_spear: 1});
recipe('wood_club', 'Craft Hardwood Club', {wood: 2, fiber: 2}, {wood_club: 1});
recipe('building_hammer', 'Craft Building Hammer', {wood: 2, stone: 2, rope: 1}, {building_hammer: 1}, 'workbench');
recipe('torch', 'Bind Resin Torch', {branch: 1, resin: 2, fiber: 2}, {torch: 1});
recipe('hunting_bow', 'Craft Hunting Bow', {wood: 3, rope: 2, resin: 1}, {hunting_bow: 1}, 'workbench');
recipe('arrow', 'Fletch Stone Arrows', {branch: 2, stone: 2, feathers: 2}, {arrow: 8}, 'workbench');
recipe('fishing_rod', 'Craft Fishing Rod', {branch: 3, rope: 2, bone: 1}, {fishing_rod: 1}, 'workbench');
recipe('leather', 'Cure Leather', {hide: 1, bark: 2}, {leather: 1}, 'tanning_rack');
recipe('sinew', 'Prepare Sinew', {bone: 1, hide: 1}, {sinew: 3}, 'workbench');
recipe('empty_waterskin', 'Stitch Waterskin', {leather: 2, fiber: 3, resin: 1}, {empty_waterskin: 1}, 'workbench');
recipe('leather_pack', 'Stitch Leather Backpack', {leather: 5, rope: 3, cloth: 2}, {leather_pack: 1}, 'workbench');
recipe('hide_coat', 'Sew Hide Coat', {leather: 4, cloth: 2, fiber: 4}, {hide_coat: 1}, 'workbench');
recipe('fur_coat', 'Sew Winter Fur Coat', {fur: 5, leather: 3, cloth: 3}, {fur_coat: 1}, 'workbench');
recipe('charcoal', 'Burn Charcoal', {wood: 3}, {charcoal: 2}, 'campfire');
recipe('brick', 'Fire Clay Bricks', {clay: 3, charcoal: 1}, {brick: 2}, 'furnace');
recipe('glass', 'Melt Glass', {sand: 3, charcoal: 2}, {glass: 2}, 'furnace');
recipe('copper_bar', 'Smelt Copper', {copper_ore: 2, charcoal: 1}, {copper_bar: 1}, 'furnace');
recipe('tin_bar', 'Smelt Tin', {tin_ore: 2, charcoal: 1}, {tin_bar: 1}, 'furnace');
recipe('bronze_bar', 'Alloy Bronze', {copper_bar: 2, tin_bar: 1, coal: 1}, {bronze_bar: 3}, 'furnace');
recipe('iron_bar', 'Smelt Iron', {iron_ore: 2, coal: 2}, {iron_bar: 1}, 'furnace');
recipe('gold_bar', 'Smelt Gold', {gold_ore: 2, charcoal: 2}, {gold_bar: 1}, 'furnace');
recipe('abyssal_bar', 'Temper Abyssal Alloy', {cave_ore: 2, iron_bar: 1, frost_crystal: 1, charcoal: 3}, {abyssal_bar: 1}, 'furnace');
recipe('nails', 'Forge Iron Nails', {iron_bar: 1}, {nails: 12}, 'anvil');
for (const [metal, station] of [['copper', 'workbench'], ['bronze', 'workbench'], ['iron', 'anvil'], ['abyssal', 'anvil']]) {
  for (const type of ['axe', 'pickaxe']) recipe(`${metal}_${type}`, `Craft ${items[`${metal}_${type}`].name}`, {[`${metal}_bar`]: 3, wood: 2, rope: 1}, {[`${metal}_${type}`]: 1}, station);
}
recipe('bronze_spear', 'Craft Bronze Spear', {bronze_bar: 2, wood: 2, rope: 1}, {bronze_spear: 1}, 'workbench');
recipe('iron_spear', 'Forge Iron Spear', {iron_bar: 3, wood: 2, leather: 1}, {iron_spear: 1}, 'anvil');
recipe('abyssal_spear', 'Forge Abyssal Spear', {abyssal_bar: 3, wood: 2, chitin: 2}, {abyssal_spear: 1}, 'anvil');
recipe('iron_knife', 'Forge Iron Knife', {iron_bar: 2, wood: 1, leather: 1}, {iron_knife: 1}, 'anvil');
recipe('obsidian_knife', 'Knapp Obsidian Knife', {obsidian: 4, resin: 2, leather: 1}, {obsidian_knife: 1}, 'workbench');
recipe('composite_bow', 'Craft Reinforced Bow', {wood: 4, iron_bar: 2, sinew: 4, leather: 2}, {composite_bow: 1}, 'anvil');
recipe('iron_arrow', 'Forge Iron Arrows', {iron_bar: 1, branch: 2, feathers: 2}, {iron_arrow: 8}, 'anvil');
recipe('venom_arrow', 'Coat Venom Arrows', {arrow: 6, venom: 1, resin: 1}, {venom_arrow: 6}, 'workbench');
recipe('fire_arrow', 'Bind Ember Arrows', {arrow: 6, ember_gland: 1, cloth: 1}, {fire_arrow: 6}, 'workbench');
recipe('chitin_armor', 'Bind Chitin Armor', {chitin: 12, leather: 4, rope: 4}, {chitin_armor: 1}, 'workbench');
recipe('abyssal_armor', 'Forge Abyssal Scale Armor', {abyssal_bar: 6, chitin: 8, leather: 4, crystal_shard: 3}, {abyssal_armor: 1}, 'anvil');
recipe('expedition_pack', 'Stitch Expedition Backpack', {leather: 6, cloth: 4, rope: 4, iron_bar: 2}, {expedition_pack: 1}, 'workbench');
recipe('cooked_meat', 'Roast Meat', {raw_meat: 1, wood: 1}, {cooked_meat: 1}, 'campfire');
recipe('cooked_fish', 'Roast Fish', {raw_fish: 1, wood: 1}, {cooked_fish: 1}, 'campfire');
recipe('cooked_mushroom', 'Roast Mushrooms', {mushroom: 3, wood: 1}, {cooked_mushroom: 3}, 'campfire');
recipe('roasted_roots', 'Roast Roots', {roots: 2, wood: 1}, {roasted_roots: 2}, 'campfire');
recipe('clean_water', 'Boil Waterskin', {dirty_water: 1, wood: 1}, {clean_water: 1}, 'campfire');
recipe('dried_meat', 'Dry Meat', {raw_meat: 2, salt: 1}, {dried_meat: 2}, 'drying_rack');
recipe('dried_fish', 'Dry Fish', {raw_fish: 2, salt: 1}, {dried_fish: 2}, 'drying_rack');
recipe('berry_porridge', 'Cook Berry and Root Mash', {berries: 4, roots: 1, wood: 1}, {berry_porridge: 1}, 'campfire');
recipe('hearty_stew', 'Simmer Hunter’s Stew', {raw_meat: 1, mushroom: 2, roots: 2, clean_water: 1, wood: 1}, {hearty_stew: 2, empty_waterskin: 1}, 'campfire');
recipe('herbal_tea', 'Brew Herbal Tea', {herb: 2, clean_water: 1, wood: 1}, {herbal_tea: 2, empty_waterskin: 1}, 'campfire');
recipe('warming_tonic', 'Brew Warming Tonic', {herb: 3, ember_gland: 1, clean_water: 1}, {warming_tonic: 2, empty_waterskin: 1}, 'campfire');
recipe('cooling_salve', 'Mix Cooling Salve', {herb: 3, frost_crystal: 1, resin: 1}, {cooling_salve: 2}, 'workbench');

building('campfire', 'Campfire', {stone: 6, wood: 4}, {providesStation: 'campfire', description: 'Cooks food, boils water and warms nearby survivors.'});
building('workbench', 'Workbench', {wood: 12, stone: 6, fiber: 4}, {providesStation: 'workbench', description: 'Make planks, bows, backpacks and early metal tools.'});
building('tanning_rack', 'Tanning Rack', {branch: 6, wood: 4, fiber: 6}, {providesStation: 'tanning_rack', description: 'Cure animal hides into useful leather.'});
building('drying_rack', 'Food Drying Rack', {branch: 8, wood: 4, rope: 2}, {providesStation: 'drying_rack', description: 'Preserve salted meat and fish.'});
building('furnace', 'Stone Furnace', {stone: 22, clay: 12, charcoal: 6}, {providesStation: 'furnace', description: 'Smelt copper, bronze, iron and abyssal alloys.'});
building('anvil', 'Stone-Based Anvil', {iron_bar: 6, stone: 6, wood: 4}, {station: 'workbench', providesStation: 'anvil', description: 'Forge iron and abyssal equipment.'});
building('foundation', 'Timber Foundation', {plank: 4, wood: 4}, {station: 'workbench', category: 'structure', description: 'A sturdy floor and attachment point for a shelter.'});
building('floor', 'Timber Floor', {plank: 4, wood: 2}, {station: 'workbench', category: 'structure', description: 'Extend a shelter’s walkable floor.'});
building('wall', 'Timber Wall', {plank: 5, fiber: 3}, {station: 'workbench', requiresFoundation: true, category: 'structure'});
building('doorframe', 'Timber Doorframe', {plank: 4, wood: 2}, {station: 'workbench', requiresFoundation: true, category: 'structure'});
building('door', 'Timber Door', {plank: 4, rope: 2}, {station: 'workbench', requiresFoundation: true, category: 'structure'});
building('roof', 'Leaf and Timber Roof', {plank: 4, leaf: 12, fiber: 4}, {station: 'workbench', requiresFoundation: true, category: 'structure', description: 'Keeps rain and harsh sun off a shelter.'});
building('storage_chest', 'Storage Chest', {plank: 8, rope: 2, resin: 2}, {station: 'workbench', storageSlots: 24, storageWeight: 180, description: 'Store supplies outside the carried inventory.'});
building('bedroll', 'Fur Bedroll', {fur: 3, leaf: 10, fiber: 6}, {description: 'A warm place to rest. Permadeath still applies.'});
building('fish_trap', 'River Fish Trap', {branch: 8, vine: 5, fiber: 4}, {description: 'Place in shallow water to catch fish.'});
building('palisade', 'Timber Palisade', {wood: 10, rope: 3}, {station: 'workbench', category: 'structure', description: 'A thick timber barrier for a camp perimeter.'});

/** Hand collection is deliberately sufficient to reach the first tools. */
export const GATHER_RESOURCES = freeze({
  branch: {}, stone: {}, flint: {}, fiber: {}, leaf: {}, vine: {}, berries: {}, mushroom: {}, roots: {}, nuts: {}, herb: {},
  wood: {tool: 'axe', tier: 1, wear: 2}, bark: {tool: 'axe', tier: 1, wear: 1}, resin: {tool: 'axe', tier: 1, wear: 1},
  clay: {}, sand: {}, salt: {}, coal: {tool: 'pickaxe', tier: 1, wear: 2},
  copper_ore: {tool: 'pickaxe', tier: 1, wear: 2}, tin_ore: {tool: 'pickaxe', tier: 2, wear: 2},
  iron_ore: {tool: 'pickaxe', tier: 3, wear: 3}, gold_ore: {tool: 'pickaxe', tier: 4, wear: 3},
  obsidian: {tool: 'pickaxe', tier: 4, wear: 3}, frost_crystal: {tool: 'pickaxe', tier: 3, wear: 3}, cave_ore: {tool: 'pickaxe', tier: 4, wear: 4},
  crystal_shard: {tool: 'pickaxe', tier: 3, wear: 2}, dirty_water: {cost: {empty_waterskin: 1}},
});
export const ITEMS = freeze(items);
export const RECIPES = freeze(recipes);
export const BUILDINGS = freeze(buildings);
