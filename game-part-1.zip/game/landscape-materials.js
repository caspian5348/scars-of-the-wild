import * as THREE from './vendor/three.module.js';

/** Exclude the bark padding around the photographed shoot's irregular atlas island. */
export function clipPineShoot(material) {
  const previousCompile = material.onBeforeCompile;
  const previousKey = material.customProgramCacheKey.bind(material);
  const windKey = previousKey();
  material.onBeforeCompile = shader => {
    previousCompile(shader);
    shader.fragmentShader = shader.fragmentShader.replace('#include <alphamap_fragment>', `
      #include <alphamap_fragment>
      #ifdef USE_ALPHAMAP
        float shootImageY = 1.0 - vAlphaMapUv.y;
        float shootLeft = .035 + .040 * smoothstep(.28,.45,shootImageY);
        float shootRight = .208 + .024 * smoothstep(.01,.12,shootImageY)
                         - .076 * smoothstep(.28,.453,shootImageY);
        float shootIsland = smoothstep(shootLeft,shootLeft+.004,vAlphaMapUv.x)
                          * (1.0-smoothstep(shootRight-.004,shootRight,vAlphaMapUv.x));
        diffuseColor.a *= shootIsland;
      #endif
    `);
  };
  material.customProgramCacheKey = () => windKey + '-clean-pine-island-v1';
}

const patchNoise = `
  float terrainHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float terrainNoise(vec2 p) {
    vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
    return mix(mix(terrainHash(i), terrainHash(i+vec2(1.0,0.0)), f.x),
               mix(terrainHash(i+vec2(0.0,1.0)), terrainHash(i+vec2(1.0)), f.x), f.y);
  }
`;

/** A soft canopy mask supplements real moving shadows with shelter under each tree. */
export function createCanopyMask(trees, worldSize) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 2048;
  const ctx = canvas.getContext('2d'), metres = canvas.width / worldSize;
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  for (const tree of trees) {
    const x = (tree.x / worldSize + .5) * canvas.width;
    const y = (tree.z / worldSize + .5) * canvas.height;
    const radius = (2.8 + tree.scale * 3.3) * metres;
    const gradient = ctx.createRadialGradient(x, y, radius * .05, x, y, radius);
    gradient.addColorStop(0, 'rgba(0,0,0,.63)');
    gradient.addColorStop(.40, 'rgba(0,0,0,.34)'); gradient.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = gradient; ctx.fillRect(x-radius, y-radius, radius*2, radius*2);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.name = 'Forest canopy ambient shelter'; texture.colorSpace = THREE.NoColorSpace;
  return texture;
}

/** Combine the existing local scans at several scales without rotating their normal maps. */
export function createTerrainMaterial(scans, canopyUniform) {
  const material = new THREE.MeshStandardMaterial({
    ...scans.ground, normalScale: new THREE.Vector2(1.05,1.05), vertexColors: true, roughness: 1, dithering: true
  });
  material.name = 'Exposed brown soil, forest litter and wet river gravel';
  material.customProgramCacheKey = () => 'layered-terrain-soil-v2';
  material.onBeforeCompile = shader => {
    shader.uniforms.uDirtMap = {value: scans.dirt.map};
    shader.uniforms.uDirtNormal = {value: scans.dirt.normalMap};
    shader.uniforms.uDirtRoughness = {value: scans.dirt.roughnessMap};
    shader.uniforms.uRockMap = {value: scans.rock.map};
    shader.uniforms.uRockNormal = {value: scans.rock.normalMap};
    shader.uniforms.uRockRoughness = {value: scans.rock.roughnessMap};
    shader.uniforms.uCanopy = canopyUniform;
    shader.vertexShader = 'attribute float rockBlend; attribute float dirtBlend; varying float vRockBlend; varying float vDirtBlend; varying vec2 vDirtUv; varying vec2 vGroundUv; varying vec2 vCanopyUv; varying vec3 vTerrainPoint;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <uv_vertex>', `
      #include <uv_vertex>
      vRockBlend = rockBlend; vDirtBlend = dirtBlend; vGroundUv = uv * 444.444; vCanopyUv = uv;
      // The original soil scan covers 1.3 metres in this 800-metre world.
      vDirtUv = uv * 615.384615;
      vTerrainPoint = position;
    `);
    shader.fragmentShader = `
      uniform sampler2D uRockMap; uniform sampler2D uRockNormal; uniform sampler2D uRockRoughness;
      uniform sampler2D uDirtMap; uniform sampler2D uDirtNormal; uniform sampler2D uDirtRoughness;
      uniform sampler2D uCanopy;
      varying float vRockBlend; varying float vDirtBlend; varying vec2 vDirtUv; varying vec2 vGroundUv; varying vec2 vCanopyUv; varying vec3 vTerrainPoint;
      ${patchNoise}
    ` + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>', `
      float floorPatch = terrainNoise(vTerrainPoint.xz * .075);
      float floorMix = smoothstep(.25, .78, floorPatch) * .62;
      vec2 floorCoarseUv = vMapUv * .373 + vec2(.273, .419);
      vec2 gravelCoarseUv = vGroundUv * .417 + vec2(.613, .237);
      vec2 dirtCoarseUv = vDirtUv * .537 + vec2(.137, .781);
      float soilPatch = terrainNoise(vTerrainPoint.xz*.055+vec2(3.1,7.8))*.60
                      + terrainNoise(vTerrainPoint.xz*.22)*.25
                      + terrainNoise(vTerrainPoint.xz*.95+vec2(11.3,2.6))*.15;
      float soilMix = smoothstep(.26,.67,soilPatch+vDirtBlend-.5);
      float dirtScaleMix = .16 + floorPatch*.18;
      float gravelMix = .25 + floorPatch * .34;
      vec4 floorTexel = mix(texture2D(map, vMapUv), texture2D(map, floorCoarseUv), floorMix);
      vec4 dirtTexel = mix(texture2D(uDirtMap,vDirtUv),texture2D(uDirtMap,dirtCoarseUv),dirtScaleMix);
      floorTexel = mix(floorTexel,dirtTexel,soilMix);
      vec4 gravelTexel = mix(texture2D(uRockMap, vGroundUv), texture2D(uRockMap, gravelCoarseUv), gravelMix);
      diffuseColor *= mix(floorTexel, gravelTexel, vRockBlend);
      float floorMacro = terrainNoise(vTerrainPoint.xz * .025 + vec2(6.2, 19.3));
      diffuseColor.rgb *= mix(vec3(.77,.73,.66), vec3(1.05,1.025,.96), floorMacro);
      float dampSoil = soilMix * (1.0-vRockBlend) * smoothstep(.63,.85,terrainNoise(vTerrainPoint.xz*.11+vec2(21.6,8.3)));
      diffuseColor.rgb *= 1.0-dampSoil*.18;
      float wetGround = 1.0 - smoothstep(2.03, 2.95, vTerrainPoint.y);
      diffuseColor.rgb *= 1.0 - wetGround * .22;
    `);
    const floorNormal = 'mix(texture2D(normalMap,vNormalMapUv),texture2D(normalMap,vNormalMapUv*.373+vec2(.273,.419)),floorMix)';
    const dirtNormal = 'mix(texture2D(uDirtNormal,vDirtUv),texture2D(uDirtNormal,dirtCoarseUv),dirtScaleMix)';
    const gravelNormal = 'mix(texture2D(uRockNormal,vGroundUv),texture2D(uRockNormal,gravelCoarseUv),gravelMix)';
    shader.fragmentShader = shader.fragmentShader.replace('#include <normal_fragment_maps>', THREE.ShaderChunk.normal_fragment_maps.replaceAll('texture2D( normalMap, vNormalMapUv )', `mix(mix(${floorNormal},${dirtNormal},soilMix),${gravelNormal},vRockBlend)`));
    const floorRough = 'mix(texture2D(roughnessMap,vRoughnessMapUv),texture2D(roughnessMap,vRoughnessMapUv*.373+vec2(.273,.419)),floorMix)';
    const dirtRough = 'mix(texture2D(uDirtRoughness,vDirtUv),texture2D(uDirtRoughness,dirtCoarseUv),dirtScaleMix)';
    const gravelRough = 'mix(texture2D(uRockRoughness,vGroundUv),texture2D(uRockRoughness,gravelCoarseUv),gravelMix)';
    shader.fragmentShader = shader.fragmentShader.replace('#include <roughnessmap_fragment>',
      THREE.ShaderChunk.roughnessmap_fragment.replace('texture2D( roughnessMap, vRoughnessMapUv )', `mix(mix(${floorRough},${dirtRough},soilMix),${gravelRough},vRockBlend)`) + '\nroughnessFactor = mix(roughnessFactor, .67, dampSoil*.35);\nroughnessFactor = mix(roughnessFactor, .48, wetGround * .7);');
    shader.fragmentShader = shader.fragmentShader.replace('#include <aomap_fragment>', `
      #include <aomap_fragment>
      float forestShelter = texture2D(uCanopy, vCanopyUv).r;
      reflectedLight.indirectDiffuse *= mix(.48, 1.0, forestShelter);
    `);
  };
  return material;
}

/** The same rock scans gain mineral variation, damp feet, and moss on upward faces. */
export function createWeatheredStoneMaterial(rockMaps) {
  const material = new THREE.MeshStandardMaterial({
    ...rockMaps, color:'#c6c9b8', normalScale:new THREE.Vector2(.95,.95), roughness:1, dithering:true
  });
  material.name = 'Weathered stone with patchy moss';
  material.customProgramCacheKey = () => 'weathered-stone-v1';
  material.onBeforeCompile = shader => {
    const varyings = 'varying vec3 vStonePoint; varying vec3 vStoneNormal;\n';
    shader.vertexShader = varyings + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <defaultnormal_vertex>', `
      #include <defaultnormal_vertex>
      vStoneNormal = inverseTransformDirection(transformedNormal, viewMatrix);
    `);
    shader.vertexShader = shader.vertexShader.replace('#include <project_vertex>', `
      #include <project_vertex>
      vec4 stoneWorld = vec4(transformed, 1.0);
      #ifdef USE_INSTANCING
        stoneWorld = instanceMatrix * stoneWorld;
      #endif
      vStonePoint = (modelMatrix * stoneWorld).xyz;
    `);
    shader.fragmentShader = varyings + patchNoise + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>', `
      #include <map_fragment>
      vec2 mineralPoint = vStonePoint.xz + vStonePoint.y * vec2(.31,.43);
      float mineralPatch = terrainNoise(mineralPoint * 1.7);
      float mossDetail = terrainNoise(mineralPoint * 7.6);
      float moss = smoothstep(.39,.67,mineralPatch + (mossDetail-.5)*.34);
      moss *= smoothstep(.10,.82,normalize(vStoneNormal).y) * .73;
      moss *= smoothstep(2.1,3.8,vStonePoint.y);
      diffuseColor.rgb *= mix(vec3(.82,.85,.82), vec3(1.07,1.035,.96), mineralPatch);
      diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(.46,.66,.25), moss);
      float stoneWet = 1.0 - smoothstep(2.0,2.8,vStonePoint.y);
      diffuseColor.rgb *= 1.0 - .31 * stoneWet;
    `);
    shader.fragmentShader = shader.fragmentShader.replace('#include <roughnessmap_fragment>', `
      #include <roughnessmap_fragment>
      roughnessFactor = mix(roughnessFactor, .47, stoneWet * .6);
    `);
  };
  return material;
}
