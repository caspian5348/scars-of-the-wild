import * as THREE from './vendor/three.module.js';
import {createRiverMaterial} from './river-material.js';
import {riverPaths,riverSampleAt} from './river-network.js';

/** A single union mesh prevents overlapping ribbons or dry seams at confluences. */
export function createRiverSurface({heightAt,waterLevel=2,WORLD_SIZE=1800,time={value:0}}){
  const extent=WORLD_SIZE/2+5,step=2.5,columns=Math.ceil(extent*2/step)+1,cells=new Set();
  // The ocean surface begins at z477.5. A broad delta overlaps it and fades smoothly.
  const lastZ=Math.min(extent,530),cellKey=(ix,iz)=>iz*columns+ix;
  for(const path of riverPaths())for(let i=1;i<path.points.length;i++){
    const a=path.points[i-1],b=path.points[i],pad=Math.max(a.halfWidth,b.halfWidth)+5;
    const minX=Math.max(0,Math.floor((Math.min(a.x,b.x)-pad+extent)/step)),maxX=Math.min(columns-2,Math.ceil((Math.max(a.x,b.x)+pad+extent)/step));
    const minZ=Math.max(0,Math.floor((Math.min(a.z,b.z)-pad+extent)/step)),maxZ=Math.min(Math.floor((lastZ+extent)/step)-1,Math.ceil((Math.max(a.z,b.z)+pad+extent)/step));
    for(let iz=minZ;iz<=maxZ;iz++)for(let ix=minX;ix<=maxX;ix++)cells.add(cellKey(ix,iz));
  }
  const vertices=new Map(),positions=[],normals=[],uv=[],depth=[],current=[],indices=[];
  function vertex(ix,iz){
    const key=cellKey(ix,iz);if(vertices.has(key))return vertices.get(key);
    const x=-extent+ix*step,z=-extent+iz*step,river=riverSampleAt(x,z),at=positions.length/3;
    const cross=(x-river.x)*river.flowZ-(z-river.z)*river.flowX;
    vertices.set(key,at);positions.push(x,waterLevel,z);normals.push(0,1,0);
    uv.push(Math.max(0,Math.min(1,.5+cross/(river.halfWidth+4)*.5)),z*.07);
    depth.push(Math.max(0,waterLevel-heightAt(x,z)));current.push(river.flowX,river.flowZ);return at;
  }
  for(const key of cells){
    const ix=key%columns,iz=Math.floor(key/columns),x=-extent+(ix+.5)*step,z=-extent+(iz+.5)*step;
    if(riverSampleAt(x,z).bankDistance>4)continue;
    const a=vertex(ix,iz),b=vertex(ix+1,iz),c=vertex(ix,iz+1),d=vertex(ix+1,iz+1);
    indices.push(a,c,b,b,c,d);
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  geometry.setAttribute('waterDepth',new THREE.Float32BufferAttribute(depth,1));
  geometry.setAttribute('riverCurrent',new THREE.Float32BufferAttribute(current,2));
  geometry.setIndex(indices);geometry.computeBoundingBox();geometry.computeBoundingSphere();
  const material=createRiverMaterial({time,depthAttribute:true,deltaFade:true});
  const mesh=new THREE.Mesh(geometry,material);mesh.name='Three connected rivers and open ocean delta';mesh.receiveShadow=true;mesh.renderOrder=2;
  mesh.userData.branches=riverPaths().map(p=>p.id);mesh.userData.sharedWatershed=true;
  let disposed=false;
  return {mesh,dispose(){if(disposed)return;disposed=true;mesh.removeFromParent();geometry.dispose();material.dispose();}};
}
