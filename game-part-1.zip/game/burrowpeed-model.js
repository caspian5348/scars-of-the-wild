import * as THREE from './vendor/three.module.js';
import {createTeethpeedModel} from './teethpeed-model.js';

const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
const smooth=value=>{const t=clamp(value);return t*t*t*(t*(t*6-15)+10);};
const random=(index,seed=0)=>{const n=Math.sin(index*127.1+seed*311.7)*43758.5453;return n-Math.floor(n);};
const IVORY='#c8b797';

/** Eight tooth tips only: one small, mergeable geometry for the 50 dormant sites.
 * Place its origin on the ground. Tooth roots are below it; visible heights are
 * 8–18 cm. The geometry contains no mound, head, legs or hidden creature body. */
export function createBurrowpeedTeethGeometry() {
  const positions=[],uvs=[],indices=[],colors=[];
  const rootColor=new THREE.Color('#66513c'),tipColor=new THREE.Color(IVORY),color=new THREE.Color();
  for(let side=-1;side<=1;side+=2)for(let tooth=0;tooth<4;tooth++) {
    const height=.09+random(tooth+7,side+3)*.085,base=-.075;
    const x=side*(.19+Math.sin((tooth+.4)*.66)*.12),z=-.20-tooth*.11;
    const start=positions.length/3,sides=7,rows=6;
    for(let row=0;row<=rows;row++) {
      const t=row/rows,radius=(.028+random(tooth,side+4)*.013)*Math.pow(1-t,.92)+.0005;
      const bend=side*(.025*t-.077*t*t),forward=-.034*t*t;
      color.copy(rootColor).lerp(tipColor,smooth((t-.22)/.7));
      for(let k=0;k<=sides;k++) {
        const angle=k/sides*Math.PI*2;
        positions.push(x+bend+Math.cos(angle)*radius,base+(height-base)*t,z+forward+Math.sin(angle)*radius*.70);
        uvs.push(k/sides,t);colors.push(color.r,color.g,color.b);
        if(row<rows&&k<sides) {
          const a=start+row*(sides+1)+k,b=a+sides+1;
          indices.push(a,b,a+1,a+1,b,b+1);
        }
      }
    }
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('normal',new THREE.Float32BufferAttribute(new Float32Array(positions.length),3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));
  geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
  geometry.setIndex(indices);geometry.computeVertexNormals();geometry.computeBoundingBox();geometry.computeBoundingSphere();
  geometry.name='Eight buried Burrowpeed tooth tips';
  geometry.userData={toothCount:8,maximumVisibleHeight:geometry.boundingBox.max.y,bodyVisible:false};
  return geometry;
}

export function createBurrowpeedTeethMaterial() {
  return new THREE.MeshStandardMaterial({name:'Earth-stained ivory tooth tips',color:'#ffffff',vertexColors:true,roughness:.66,metalness:0});
}

/** Local -Z is forward. Place `group` at the head's ground position and yaw.
 * `progress` is normalized within the current stage. `groundHeightAt(x,z)` is
 * the actual world-space terrain sampler; groundAt is the optional local one.
 * The renderer must enable localClippingEnabled for the moving soil boundary. */
export function createBurrowpeedModel({surfaceTexture}={}) {
  const group=new THREE.Group();group.name='Burrowpeed earth ambusher';
  const body=createTeethpeedModel({surfaceTexture});group.add(body.group);
  body.group.name='Burrowpeed articulated dry cuticle';body.group.scale.set(1.15,1.04,.92);
  const groundPlane=new THREE.Plane(new THREE.Vector3(0,1,0),0),clipPlanes=[groundPlane];
  const finishes=new Set(),ownedFinishes=new Set();
  const darkBlade=new THREE.Color('#574230'),ivoryBlade=new THREE.Color(IVORY),color=new THREE.Color();
  body.group.traverse(part=>{
    if(part.name==='Flattened cephalic shield')part.scale.x*=1.17;
    if(!part.isMesh)return;
    const materials=Array.isArray(part.material)?part.material:[part.material];
    for(const material of materials)finishes.add(material);
    if(part.name==='Continuous serrated cuticle blade') {
      // The same serrated ant-jaw anatomy has worn ivory ends. Tint its actual
      // vertices instead of attaching decorative floating teeth to the mouth.
      const material=part.material.clone();material.name='Burrowpeed worn digging mandibles';
      material.color.set('#ffffff');material.map=null;material.roughness=.62;material.clearcoat=.025;
      const positions=part.geometry.attributes.position,colors=part.geometry.attributes.color;
      for(let i=0;i<positions.count;i++) {
        const wear=smooth((-positions.getZ(i)-.40)/.21);
        color.copy(darkBlade).lerp(ivoryBlade,wear);colors.setXYZ(i,color.r,color.g,color.b);
      }
      colors.needsUpdate=true;part.material=material;finishes.add(material);ownedFinishes.add(material);
    }
  });
  for(const material of finishes) {
    if(material.name.includes('biological cuticle')){material.color.set(surfaceTexture?'#b6aa8e':'#574c35');material.roughness=.81;material.clearcoat=.018;}
    else if(material.name.includes('chestnut legs')){material.color.set(surfaceTexture?'#b9a98b':'#746146');material.roughness=.80;material.clearcoat=.02;}
    else if(material.name.includes('plate margins')){material.color.set(surfaceTexture?'#9e957c':'#746344');material.roughness=.83;}
    material.clippingPlanes=clipPlanes;material.clipShadows=true;material.needsUpdate=true;
  }

  const dirtGeometry=new THREE.DodecahedronGeometry(1,0);
  const dirtMaterial=new THREE.MeshStandardMaterial({name:'Ejected damp earth',color:'#66523b',roughness:1,clippingPlanes:clipPlanes,clipShadows:true});
  const dirt=new THREE.InstancedMesh(dirtGeometry,dirtMaterial,48);dirt.name='Burrow eruption soil fragments';
  dirt.instanceMatrix.setUsage(THREE.DynamicDrawUsage);dirt.castShadow=true;dirt.receiveShadow=true;dirt.frustumCulled=false;
  group.add(dirt);
  for(let i=0;i<dirt.count;i++){color.setRGB(.61+random(i,5)*.38,.57+random(i,6)*.36,.48+random(i,7)*.35);dirt.setColorAt(i,color);}
  const transform=new THREE.Object3D(),worldOrigin=new THREE.Vector3(),normal=new THREE.Vector3(),sample=new THREE.Vector3();
  const diagnostics={stage:'buried',progress:0,bodyVisible:false,soilParticlesVisible:false,bodyLift:0,bodyPitch:0,toothCount:8,requiresLocalClipping:true};
  let disposed=false;
  function animate({time=0,stage='buried',progress=0,speed=0,groundHeightAt=null,groundAt=()=>0,attacking=0}={}) {
    if(disposed)return;
    const p=clamp(progress),emerging=stage==='emerging',burrowing=stage==='burrowing';
    const dead=stage==='dead',surfaced=stage==='chasing'||stage==='chase'||stage==='surfaced'||dead;
    const visible=surfaced||(emerging&&p>0)||(burrowing&&p<1);
    body.group.visible=visible;dirt.visible=visible&&(emerging||burrowing);
    group.updateWorldMatrix(true,false);worldOrigin.setFromMatrixPosition(group.matrixWorld);
    const sampleGround=(x,z)=>{const h=groundHeightAt?.(x,z);return Number.isFinite(h)?h:worldOrigin.y;};
    const ground=sampleGround(worldOrigin.x,worldOrigin.z);
    normal.set(-(sampleGround(worldOrigin.x+.3,worldOrigin.z)-sampleGround(worldOrigin.x-.3,worldOrigin.z))/.6,1,
      -(sampleGround(worldOrigin.x,worldOrigin.z+.3)-sampleGround(worldOrigin.x,worldOrigin.z-.3))/.6).normalize();
    sample.set(worldOrigin.x,ground-.025,worldOrigin.z);groundPlane.setFromNormalAndCoplanarPoint(normal,sample);
    let lift=0,pitch=0;
    if(emerging) {
      lift=p<.45?THREE.MathUtils.lerp(-1.42,.90,smooth(p/.45)):.90*(1-smooth((p-.45)/.55));
      pitch=.24*Math.sin(Math.PI*p)*(1-smooth((p-.65)/.35));
    } else if(burrowing) {
      lift=-3.05*smooth(p);pitch=-.56*smooth(p);
    }
    body.group.position.y=lift;body.group.rotation.x=pitch;
    if(visible) {
      // Surface locomotion uses the production planted-foot IK. The jump/bury
      // stages temporarily use the creature's own tilted plane; clipping and
      // opaque terrain conceal the body underneath the real ground.
      body.animate({time,speed:dead?0:surfaced?speed:(emerging?2.2:1.15),attacking:dead?0:attacking,
        groundHeightAt:surfaced&&groundHeightAt?groundHeightAt:null,groundAt:surfaced?groundAt:()=>0});
    }
    if(dirt.visible) {
      const seconds=p*(emerging?.85:1.1),burst=emerging?1:.65;
      for(let i=0;i<dirt.count;i++) {
        const delay=random(i,12)*.13,t=Math.max(0,seconds-delay),angle=random(i,3)*Math.PI*2;
        const radius=.12+(1.0+random(i,8)*1.5)*t*burst;
        const y=.05+(1.6+random(i,9)*2.2)*t*burst-4.9*t*t;
        const fade=1-smooth((p-.70)/.30),scale=(.019+random(i,10)*.037)*fade;
        transform.position.set(Math.cos(angle)*radius,y,Math.sin(angle)*radius-.10);
        transform.rotation.set(t*(i+1)*.9,t*(i%4)*1.5,t*2.3);
        transform.scale.set(scale,scale*(.6+random(i,13)),scale*.77);
        transform.updateMatrix();dirt.setMatrixAt(i,transform.matrix);
      }
      dirt.instanceMatrix.needsUpdate=true;
    }
    Object.assign(diagnostics,{stage,progress:p,bodyVisible:visible,soilParticlesVisible:dirt.visible,
      bodyLift:Number(lift.toFixed(4)),bodyPitch:Number(pitch.toFixed(4))});
  }
  animate();
  return {group,animate,requiresLocalClipping:true,getDiagnostics:()=>({...body.getDiagnostics(),...diagnostics}),dispose(){
    if(disposed)return;disposed=true;group.removeFromParent();body.dispose();
    for(const material of ownedFinishes)material.dispose();dirt.dispose();dirtGeometry.dispose();dirtMaterial.dispose();
  }};
}
