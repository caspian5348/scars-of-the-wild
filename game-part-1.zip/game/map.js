import { forestBlendAt, stormBlendAt, BIOMES,biomeAt,lavaAt,CAVE_ENTRANCE,coastZ } from './biomes.js';
import {riverPaths} from './river-network.js';

const CHART_SIZE = 1000;
const MARGIN = 64;
const FIELD_SIZE = CHART_SIZE - MARGIN * 2;
const GOLD = '#d9cba0';
const INK = '#122421';

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
const mix = (a, b, amount) => a + (b - a) * amount;
const hash = (x, y, seed = 0) => {
  const value = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123;
  return value - Math.floor(value);
};

/** A local field chart, sharing the playable terrain's height function. */
export function createMap({ canvas, landmarks = [], heightAt, riverX, WORLD_SIZE = 1800, waterLevel = 2, onWaypoint, getNetworkState=()=>null }) {
  const context = canvas.getContext('2d');
  if (!context) return { draw() {}, getWaypoint: () => null, destroy() {} };

  const extent = WORLD_SIZE / 2;
  const project = (value) => MARGIN + (value + extent) / WORLD_SIZE * FIELD_SIZE;
  const unproject = (value) => (value - MARGIN) / FIELD_SIZE * WORLD_SIZE - extent;
  const base = document.createElement('canvas');
  base.width = base.height = CHART_SIZE;
  const paint = base.getContext('2d');
  let selectedWaypoint = null;
  let lastPlayer = null;
  let lastDiscovered = new Set();
  let layout = { left: 0, top: 0, side: 1 };

  // A sampled height field keeps the chart and its contours consistent with the 3D map.
  const samples = 257;
  const heights = new Float32Array(samples * samples);
  let minHeight = Infinity;
  let maxHeight = -Infinity;
  for (let z = 0; z < samples; z++) {
    for (let x = 0; x < samples; x++) {
      const height = heightAt(x / (samples - 1) * WORLD_SIZE - extent, z / (samples - 1) * WORLD_SIZE - extent);
      heights[z * samples + x] = Number.isFinite(height) ? height : waterLevel;
      minHeight = Math.min(minHeight, heights[z * samples + x]);
      maxHeight = Math.max(maxHeight, heights[z * samples + x]);
    }
  }

  const sample = (x, z) => heights[clamp(z, 0, samples - 1) * samples + clamp(x, 0, samples - 1)];
  const palette = [
    [48, 72, 56], [70, 94, 65], [89, 107, 74], [123, 125, 91], [161, 152, 123],
  ];

  function paintTerrain() {
    const terrain = document.createElement('canvas');
    terrain.width = terrain.height = samples;
    const terrainContext = terrain.getContext('2d');
    const image = terrainContext.createImageData(samples, samples);
    const heightRange = Math.max(35, maxHeight - waterLevel);
    for (let z = 0; z < samples; z++) {
      for (let x = 0; x < samples; x++) {
        const elevation = sample(x, z);
        const worldX=x/(samples-1)*WORLD_SIZE-extent,worldZ=z/(samples-1)*WORLD_SIZE-extent,biome=biomeAt(worldX,worldZ).id;
        const water = elevation <= waterLevel;
        const slopeX = (sample(x + 1, z) - sample(x - 1, z)) / (WORLD_SIZE / (samples - 1));
        const slopeZ = (sample(x, z + 1) - sample(x, z - 1)) / (WORLD_SIZE / (samples - 1));
        const shade = clamp(1 + slopeX * 0.23 + slopeZ * 0.19, 0.64, 1.3);
        const grain = (hash(x, z) - 0.5) * 4;
        let color;
        if (water) {
          const depth = clamp((waterLevel - elevation) / 5, 0, 1);
          color = [mix(50, 29, depth), mix(99, 69, depth), mix(99, 76, depth)];
        } else {
          const gradient = clamp((elevation - waterLevel) / heightRange, 0, 1) * (palette.length - 1);
          const band = Math.floor(gradient);
          color = palette[band].map((channel, i) => mix(channel, palette[Math.min(band + 1, palette.length - 1)][i], gradient - band) * shade + grain);
          const forest=forestBlendAt(x/(samples-1)*WORLD_SIZE-extent,z/(samples-1)*WORLD_SIZE-extent);
          color=color.map((channel,i)=>mix(channel,[30,68,46][i]*shade,forest*.76));
          const storm=stormBlendAt(x/(samples-1)*WORLD_SIZE-extent,z/(samples-1)*WORLD_SIZE-extent);
          color=color.map((channel,i)=>mix(channel,[72,78,86][i]*shade,storm*.85));
          if(biome==='ice')color=[174,203,209].map(v=>v*shade+grain);
          if(biome==='beach')color=[198,181,129].map(v=>v*shade+grain);
          if(biome==='lava')color=(lavaAt(worldX,worldZ)?[227,101,39]:[97,75,63]).map(v=>v*shade+grain);
          if(biome==='cave')color=[113,105,142].map(v=>v*shade+grain);
          if(biome==='glow')color=[64,130,118].map(v=>v*shade+grain);
        }
        const offset = (z * samples + x) * 4;
        image.data[offset] = color[0];
        image.data[offset + 1] = color[1];
        image.data[offset + 2] = color[2];
        image.data[offset + 3] = 255;
      }
    }
    terrainContext.putImageData(image, 0, 0);
    paint.imageSmoothingEnabled = true;
    paint.drawImage(terrain, MARGIN, MARGIN, FIELD_SIZE, FIELD_SIZE);
  }

  function contourPath(level) {
    const path = new Path2D();
    const step = FIELD_SIZE / (samples - 1);
    for (let z = 0; z < samples - 1; z++) {
      for (let x = 0; x < samples - 1; x++) {
        const offset = z * samples + x;
        const a = heights[offset], b = heights[offset + 1];
        const c = heights[offset + samples + 1], d = heights[offset + samples];
        if (level < Math.min(a, b, c, d) || level > Math.max(a, b, c, d)) continue;
        const values = [a, b, c, d];
        const corners = [[x, z], [x + 1, z], [x + 1, z + 1], [x, z + 1]];
        const intersections = [];
        for (let edge = 0; edge < 4; edge++) {
          const next = (edge + 1) % 4;
          if ((values[edge] < level) === (values[next] < level)) continue;
          const amount = (level - values[edge]) / (values[next] - values[edge]);
          intersections.push([
            MARGIN + mix(corners[edge][0], corners[next][0], amount) * step,
            MARGIN + mix(corners[edge][1], corners[next][1], amount) * step,
          ]);
        }
        for (let i = 0; i + 1 < intersections.length; i += 2) {
          path.moveTo(...intersections[i]);
          path.lineTo(...intersections[i + 1]);
        }
      }
    }
    return path;
  }

  function paintContours() {
    const interval = Math.max(5, Math.ceil((maxHeight - minHeight) / 180) * 5);
    for (let level = Math.ceil((waterLevel + 1) / interval) * interval; level < maxHeight; level += interval) {
      const major = Math.round(level / interval) % 4 === 0;
      paint.lineWidth = major ? 1.3 : 0.65;
      paint.strokeStyle = major ? 'rgba(22,43,31,.38)' : 'rgba(23,43,30,.23)';
      paint.stroke(contourPath(level));
    }
    paint.lineWidth = 1.5;
    paint.strokeStyle = 'rgba(157,199,176,.54)';
    paint.stroke(contourPath(waterLevel));
  }

  function paintForest() {
    paint.lineCap = 'round';
    for (let z = 0; z < 67; z++) {
      for (let x = 0; x < 67; x++) {
        if (hash(x, z, 1) < 0.32) continue;
        const worldX = (x + hash(x, z, 2)) / 67 * WORLD_SIZE - extent;
        const worldZ = (z + hash(x, z, 3)) / 67 * WORLD_SIZE - extent;
        const elevation = heightAt(worldX, worldZ);
        if (elevation < waterLevel + 2 || elevation > maxHeight * 0.81 || !['forest','valley'].includes(biomeAt(worldX,worldZ).id)) continue;
        if (landmarks.some((landmark) => Math.hypot(worldX - landmark.x, worldZ - landmark.z) < 12)) continue;
        const px = project(worldX), py = project(worldZ);
        const size = 2.2 + hash(x, z, 4) * 2.1;
        paint.strokeStyle = 'rgba(22,45,28,.23)';
        paint.lineWidth = 1;
        paint.beginPath();
        paint.moveTo(px - size, py + size * 0.6);
        paint.lineTo(px, py - size);
        paint.lineTo(px + size, py + size * 0.6);
        paint.moveTo(px, py - size * 0.5);
        paint.lineTo(px, py + size * 1.35);
        paint.stroke();
      }
    }
  }

  function paintGrid() {
    const increment = WORLD_SIZE / 8;
    paint.lineWidth = 0.8;
    paint.strokeStyle = 'rgba(215,221,190,.105)';
    paint.beginPath();
    for (let i = 1; i < 8; i++) {
      const position = MARGIN + i / 8 * FIELD_SIZE;
      paint.moveTo(position, MARGIN);
      paint.lineTo(position, CHART_SIZE - MARGIN);
      paint.moveTo(MARGIN, position);
      paint.lineTo(CHART_SIZE - MARGIN, position);
    }
    paint.stroke();
    paint.fillStyle = 'rgba(200,209,184,.5)';
    paint.font = '11px "Segoe UI", sans-serif';
    paint.textAlign = 'center';
    for (let i = 0; i <= 8; i++) {
      const position = MARGIN + i / 8 * FIELD_SIZE;
      const number = String(Math.round(-extent + increment * i));
      paint.fillText(number, position, CHART_SIZE - MARGIN + 19);
      if (i > 0 && i < 8) {
        paint.save();
        paint.translate(MARGIN - 17, position);
        paint.rotate(-Math.PI / 2);
        paint.fillText(number, 0, 0);
        paint.restore();
      }
    }
  }

  function paintCompass() {
    const x = CHART_SIZE - MARGIN - 52, y = MARGIN + 52;
    paint.save();
    paint.translate(x, y);
    paint.strokeStyle = 'rgba(217,203,160,.57)';
    paint.lineWidth = 1;
    paint.beginPath();
    paint.arc(0, 0, 24, 0, Math.PI * 2);
    paint.stroke();
    paint.beginPath();
    paint.moveTo(0, -20);
    paint.lineTo(6, 11);
    paint.lineTo(0, 5);
    paint.lineTo(-6, 11);
    paint.closePath();
    paint.fillStyle = GOLD;
    paint.fill();
    paint.font = '600 14px "Segoe UI", sans-serif';
    paint.textAlign = 'center';
    paint.fillText('N', 0, -33);
    paint.restore();
  }

  function paintBase() {
    paint.fillStyle = INK;
    paint.fillRect(0, 0, CHART_SIZE, CHART_SIZE);
    paintTerrain();
    paint.save();
    paint.beginPath();
    paint.rect(MARGIN, MARGIN, FIELD_SIZE, FIELD_SIZE);
    paint.clip();
    paintContours();
    // Draw the exact watershed paths so all three branches remain legible at map scale.
    paint.lineJoin='round';paint.lineCap='round';
    for(const river of riverPaths()){
      paint.strokeStyle='rgba(78,151,156,.90)';paint.lineWidth=river.id==='main'?7:5;
      paint.beginPath();river.points.filter(p=>river.id!=='main'||p.z<=coastZ(p.x)+35).forEach((p,i)=>{if(i===0)paint.moveTo(project(p.x),project(p.z));else paint.lineTo(project(p.x),project(p.z));});paint.stroke();
      paint.strokeStyle='rgba(154,208,205,.50)';paint.lineWidth=1.2;paint.stroke();
    }
    paintForest();
    // The surface chart marks the entrance, not the hidden maze route.
    paint.strokeStyle='#d2c1e3';paint.lineWidth=3;paint.beginPath();paint.arc(project(CAVE_ENTRANCE.x),project(CAVE_ENTRANCE.z),6,0,Math.PI*2);paint.stroke();
    for(const biome of BIOMES) {
      paint.font='600 15px Georgia, serif';paint.textAlign='center';
      const x=project(biome.x),y=project(biome.z)+(biome.id==='forest'?-75:biome.id==='storm'?-58:10);
      const label=biome.name.toUpperCase(),width=paint.measureText(label).width;
      paint.fillStyle='rgba(12,30,21,.65)';paint.fillRect(x-width/2-12,y-20,width+24,30);
      paint.fillStyle='#e1d7b4';paint.fillText(label,x,y);
    }
    if (typeof riverX === 'function') {
      const labelZ = -extent * 0.73;
      const x = project(riverX(labelZ)) + 22, y = project(labelZ);
      paint.save();
      paint.translate(x, y);
      paint.rotate(-0.11);
      paint.font = 'italic 15px Georgia, serif';
      paint.fillStyle = 'rgba(193,220,206,.72)';
      paint.textAlign = 'left';
      paint.fillText('River', 0, 0);
      paint.restore();
    }
    const shade = paint.createRadialGradient(500, 440, 190, 500, 500, 620);
    shade.addColorStop(0, 'rgba(13,28,21,0)');
    shade.addColorStop(1, 'rgba(13,28,21,.32)');
    paint.fillStyle = shade;
    paint.fillRect(MARGIN, MARGIN, FIELD_SIZE, FIELD_SIZE);
    paint.restore();
    paintGrid();
    paint.strokeStyle = 'rgba(205,201,166,.4)';
    paint.lineWidth = 1;
    paint.strokeRect(MARGIN - 0.5, MARGIN - 0.5, FIELD_SIZE + 1, FIELD_SIZE + 1);
    paint.strokeStyle = 'rgba(205,201,166,.13)';
    paint.strokeRect(MARGIN - 6.5, MARGIN - 6.5, FIELD_SIZE + 13, FIELD_SIZE + 13);

    paint.fillStyle = GOLD;
    paint.textAlign = 'left';
    paint.font = '500 16px "Segoe UI", sans-serif';
    paint.fillText('WILDERNESS  /  FIELD CHART', MARGIN, 35);
    paint.textAlign = 'right';
    paint.font = '11px "Segoe UI", sans-serif';
    paint.fillStyle = '#a2b0a0';
    paint.fillText(`${Math.round(WORLD_SIZE)} × ${Math.round(WORLD_SIZE)} METRES`, CHART_SIZE - MARGIN, 35);
    paintCompass();

    const scaleMetres=WORLD_SIZE>1000?250:100,scaleLength=scaleMetres/WORLD_SIZE*FIELD_SIZE;
    const scaleX = MARGIN + 25, scaleY = CHART_SIZE - MARGIN - 34;
    paint.strokeStyle = GOLD;
    paint.lineWidth = 2;
    paint.beginPath();
    paint.moveTo(scaleX, scaleY - 5);
    paint.lineTo(scaleX, scaleY);
    paint.lineTo(scaleX + scaleLength, scaleY);
    paint.lineTo(scaleX + scaleLength, scaleY - 5);
    paint.stroke();
    paint.fillStyle = GOLD;
    paint.font = '12px "Segoe UI", sans-serif';
    paint.textAlign = 'center';
    paint.fillText(`${scaleMetres} m`, scaleX + scaleLength / 2, scaleY - 10);
    paint.textAlign = 'left';
    paint.font = '11px "Segoe UI", sans-serif';
    paint.fillStyle = '#a2b0a0';
    paint.fillText('△  YOU     ◇  LANDMARK', MARGIN, 985);
    paint.textAlign = 'right';
    paint.fillStyle = GOLD;
    paint.fillText('CLICK THE MAP TO SET A WAYPOINT', CHART_SIZE - MARGIN, 985);
  }

  function landmarkMarker(landmark, discovered) {
    const x = project(landmark.x), y = project(landmark.z);
    const visited = discovered?.has?.(landmark.id) || false;
    const color = visited ? '#ecdcab' : '#b2c0a7';
    context.save();
    context.translate(x, y);
    context.shadowColor = '#0b1b15';
    context.shadowBlur = 8;
    context.fillStyle = 'rgba(17,35,26,.88)';
    context.beginPath();
    context.arc(0, 0, 11, 0, Math.PI * 2);
    context.fill();
    context.shadowBlur = 0;
    context.strokeStyle = color;
    context.lineWidth = visited ? 1.8 : 1.2;
    context.beginPath();
    context.moveTo(0, -7);
    context.lineTo(6, 0);
    context.lineTo(0, 7);
    context.lineTo(-6, 0);
    context.closePath();
    context.stroke();
    if (visited) {
      context.fillStyle = color;
      context.beginPath();
      context.arc(0, 0, 2, 0, Math.PI * 2);
      context.fill();
    }
    context.font = `${visited ? '600' : '400'} 13px "Segoe UI", sans-serif`;
    const label = String(landmark.name || 'Landmark');
    const width = context.measureText(label).width;
    const rightSide = x + width + 32 < CHART_SIZE - MARGIN;
    const textX = rightSide ? 17 : -17;
    context.textAlign = rightSide ? 'left' : 'right';
    context.textBaseline = 'middle';
    context.fillStyle = 'rgba(17,35,26,.79)';
    context.fillRect(rightSide ? 11 : -width - 23, -13, width + 12, 26);
    context.fillStyle = color;
    context.fillText(label, textX, 0);
    context.restore();
  }

  function drawWaypoint(player, waypoint) {
    if (!waypoint || !Number.isFinite(waypoint.x) || !Number.isFinite(waypoint.z)) return;
    const x = project(waypoint.x), y = project(waypoint.z);
    context.save();
    if (player) {
      context.strokeStyle = 'rgba(245,220,155,.65)';
      context.lineWidth = 1.8;
      context.setLineDash([6, 7]);
      context.beginPath();
      context.moveTo(project(player.x), project(player.z));
      context.lineTo(x, y);
      context.stroke();
      context.setLineDash([]);
    }
    context.translate(x, y);
    context.shadowColor = '#0d1d16';
    context.shadowBlur = 8;
    context.fillStyle = '#e5cc88';
    context.strokeStyle = '#1a2b22';
    context.lineWidth = 2;
    context.beginPath();
    context.moveTo(0, 0);
    context.bezierCurveTo(-5, -9, -12, -15, -10, -23);
    context.bezierCurveTo(-8, -35, 8, -35, 10, -23);
    context.bezierCurveTo(12, -15, 5, -9, 0, 0);
    context.closePath();
    context.fill();
    context.stroke();
    context.shadowBlur = 0;
    context.fillStyle = '#273b2d';
    context.beginPath();
    context.arc(0, -22, 3.5, 0, Math.PI * 2);
    context.fill();
    if (player) {
      const distance = Math.round(Math.hypot(waypoint.x - player.x, waypoint.z - player.z));
      context.font = '600 14px "Segoe UI", sans-serif';
      context.textAlign = 'center';
      const label = `${distance} m`;
      const width = context.measureText(label).width + 16;
      const labelY = y > CHART_SIZE - MARGIN - 29 ? -44 : 19;
      const labelX = clamp(x, MARGIN + width / 2 + 3, CHART_SIZE - MARGIN - width / 2 - 3) - x;
      context.fillStyle = 'rgba(14,29,22,.94)';
      context.fillRect(labelX - width / 2, labelY - 13, width, 20);
      context.fillStyle = '#edda9e';
      context.fillText(label, labelX, labelY + 1);
    }
    context.restore();
  }

  function drawPlayer(player) {
    if (!player || !Number.isFinite(player.x) || !Number.isFinite(player.z)) return;
    const x = project(player.x), y = project(player.z);
    context.save();
    context.translate(x, y);
    context.fillStyle = 'rgba(227,231,198,.08)';
    context.strokeStyle = 'rgba(227,231,198,.35)';
    context.lineWidth = 1;
    context.beginPath();
    context.arc(0, 0, 23, 0, Math.PI * 2);
    context.fill();
    context.stroke();
    context.rotate(-(Number.isFinite(player.yaw) ? player.yaw : 0));
    context.fillStyle = '#f4edd4';
    context.strokeStyle = '#172e23';
    context.lineWidth = 2;
    context.shadowColor = '#0b1b15';
    context.shadowBlur = 9;
    context.beginPath();
    context.moveTo(0, -16);
    context.lineTo(9, 10);
    context.lineTo(0, 5);
    context.lineTo(-9, 10);
    context.closePath();
    context.fill();
    context.stroke();
    context.restore();
  }

  function draw(player, waypoint, discovered) {
    lastPlayer = player ? { x: player.x, z: player.z, yaw: player.yaw } : null;
    selectedWaypoint = waypoint ? { x: waypoint.x, z: waypoint.z } : null;
    lastDiscovered = discovered || new Set();
    const bounds = canvas.getBoundingClientRect();
    if (bounds.width < 1 || bounds.height < 1) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const pixelWidth = Math.max(1, Math.round(bounds.width * dpr));
    const pixelHeight = Math.max(1, Math.round(bounds.height * dpr));
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }
    layout.side = Math.min(bounds.width, bounds.height);
    layout.left = (bounds.width - layout.side) / 2;
    layout.top = (bounds.height - layout.side) / 2;
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.fillStyle = INK;
    context.fillRect(0, 0, canvas.width, canvas.height);
    const scale = layout.side / CHART_SIZE * dpr;
    context.setTransform(scale, 0, 0, scale, layout.left * dpr, layout.top * dpr);
    context.drawImage(base, 0, 0);
    context.save();
    context.beginPath();
    context.rect(MARGIN, MARGIN, FIELD_SIZE, FIELD_SIZE);
    context.clip();
    for (const landmark of landmarks) landmarkMarker(landmark, lastDiscovered);
    drawWaypoint(lastPlayer, selectedWaypoint);
    const network=getNetworkState();
    if(network){
        const nodes=network.world?.creatures?.infection?.nodes||[];
        for(const node of nodes){const points=node.path||[];if(points.length){context.beginPath();points.forEach((p,i)=>context[i?'lineTo':'moveTo'](project(p.x),project(p.z)));context.strokeStyle='#899d4277';context.lineWidth=3;context.stroke();}context.beginPath();context.arc(project(node.position.x),project(node.position.z),Math.max(1,(node.territoryRadius||node.radius)/WORLD_SIZE*FIELD_SIZE),0,Math.PI*2);context.fillStyle='#adc44655';context.fill();}
      for(const node of nodes){context.beginPath();context.arc(project(node.position.x),project(node.position.z),Math.max(5,node.radius/WORLD_SIZE*FIELD_SIZE),0,Math.PI*2);context.fillStyle='#bbc93ccc';context.fill();context.strokeStyle='#40320e';context.lineWidth=1.3;context.stroke();}
      if(nodes.length){context.fillStyle='#f0efad';context.font='bold 14px sans-serif';context.fillText(`INFECTION · ${nodes.length} spread nodes`,project(nodes[0].position.x)+10,project(nodes[0].position.z)-11);}
      for(const teammate of network.players||[]){if(teammate.id===network.selfId||!teammate.connected||!teammate.alive)continue;const x=project(teammate.position.x),z=project(teammate.position.z);context.beginPath();context.arc(x,z,5,0,Math.PI*2);context.fillStyle='#a0e2d0';context.fill();context.fillStyle='#e1eede';context.font='13px sans-serif';context.fillText(teammate.name,x+9,z-5);}
    }
    drawPlayer(lastPlayer);
    context.restore();
  }

  function chooseWaypoint(event) {
    const bounds = canvas.getBoundingClientRect();
    const side = Math.min(bounds.width, bounds.height);
    if (side < 1) return;
    const x = (event.clientX - bounds.left - (bounds.width - side) / 2) / side * CHART_SIZE;
    const y = (event.clientY - bounds.top - (bounds.height - side) / 2) / side * CHART_SIZE;
    if (x < MARGIN || y < MARGIN || x > CHART_SIZE - MARGIN || y > CHART_SIZE - MARGIN) return;
    selectedWaypoint = { x: Math.round(unproject(x)), z: Math.round(unproject(y)) };
    onWaypoint?.({ ...selectedWaypoint });
    draw(lastPlayer, selectedWaypoint, lastDiscovered);
  }

  paintBase();
  canvas.addEventListener('click', chooseWaypoint);
  return {
    draw,
    getWaypoint: () => selectedWaypoint ? { ...selectedWaypoint } : null,
    destroy() { canvas.removeEventListener('click', chooseWaypoint); },
  };
}
