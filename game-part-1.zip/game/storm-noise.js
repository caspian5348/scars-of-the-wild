import * as THREE from './vendor/three.module.js';

/** Bake periodic cloud detail once; storm fragments then need only texture taps. */
export function createStormNoiseTexture(size=256) {
  const bytes=new Uint8Array(size*size*4);
  function hash(x,y,period,seed){
    x=((x%period)+period)%period;y=((y%period)+period)%period;
    let n=Math.imul(x+seed,374761393)^Math.imul(y+seed,668265263);
    n=Math.imul(n^(n>>>13),1274126177);return((n^(n>>>16))>>>0)/4294967296;
  }
  function noise(u,v,period,seed){
    const x=u*period,y=v*period,ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy;
    const sx=fx*fx*(3-2*fx),sy=fy*fy*(3-2*fy);
    const a=hash(ix,iy,period,seed),b=hash(ix+1,iy,period,seed),c=hash(ix,iy+1,period,seed),d=hash(ix+1,iy+1,period,seed);
    return a+(b-a)*sx+(c-a)*sy+(a-b-c+d)*sx*sy;
  }
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const u=x/size,v=y/size,i=(y*size+x)*4;
    const large=noise(u,v,8,42793),middle=noise(u,v,16,717),fine=noise(u,v,32,291);
    bytes[i]=Math.round((large*.57+middle*.29+fine*.14)*255);
    bytes[i+1]=Math.round((middle*.48+fine*.35+noise(u,v,64,855)*.17)*255);
    bytes[i+2]=Math.round((noise(u,v,4,172)*.72+large*.28)*255);
    bytes[i+3]=255;
  }
  const texture=new THREE.DataTexture(bytes,size,size,THREE.RGBAFormat,THREE.UnsignedByteType);
  texture.name='Baked periodic storm cloud density';texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
  texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.generateMipmaps=true;texture.needsUpdate=true;
  return texture;
}
