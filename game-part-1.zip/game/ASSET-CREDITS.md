
## Scanned ground, bare soil and rock materials

Bundled maps are original 2048 × 2048 JPG material channels from [Poly Haven](https://polyhaven.com), licensed [CC0 1.0](https://polyhaven.com/license). They may be used and redistributed, including commercially. Retrieved September 12, 2026 using the documented [Poly Haven API](https://polyhaven.com/our-api) with application User-Agent `ScarsOfTheWildPrototype/0.2`. The game loads these bundled files locally and makes no live API request.

| Material | Creator | Included channels | Local files |
| --- | --- | --- | --- |
| [Forest Ground 01](https://polyhaven.com/a/forrest_ground_01) | Rob Tuytel | Albedo, OpenGL normal, roughness | `assets/materials/forest-albedo.jpg`, `forest-normal.jpg`, `forest-roughness.jpg` |
| [Rock Boulder Dry](https://polyhaven.com/a/rock_boulder_dry) | Dimitrios Savva (photography), Rico Cilliers (processing) | Albedo, OpenGL normal, roughness | `assets/materials/rock-albedo.jpg`, `rock-normal.jpg`, `rock-roughness.jpg` |
| [Brown Mud](https://polyhaven.com/a/brown_mud) | Rob Tuytel | Albedo, OpenGL normal, roughness | `assets/materials/dirt-albedo.jpg`, `dirt-normal.jpg`, `dirt-roughness.jpg` |

Forest Ground 01 represents a 2 m wide scan; Brown Mud represents a 1.3 m wide scan; Rock Boulder Dry represents a 1.8 m tall scan. Brown Mud supplies bare granular earth with small stones and sparse natural twigs, for exposed soil between the vegetation. Runtime tiling is selected to fit the game geometry. Albedo uses sRGB; normal and roughness channels are treated as linear data. No bitmap modifications were made. Nine files total 25,592,517 bytes; each source MD5 was checked after download. Exact source URLs, sizes, MD5 values and local SHA-256 values are recorded in `assets/materials/material-provenance.json`. The three soil files add 6,591,773 bytes and retain the original 2048 × 2048 source resolution.

## Aircraft and sound effects

The aircraft geometry, livery, wear patterns and breakaway panels are generated locally by `aircraft-model.js` and `crash.js`. The design uses no imported aircraft model or airline branding. `audio.js` synthesizes wind, foliage and wood movement, Teethpeed crawling, engine failure, river impact, metal damage, footsteps and thunder with Web Audio oscillators and generated noise buffers. No third-party audio recordings or sound downloads are used.

## Survivor character scan

The character editor uses **Infinite, 3D Head Scan** by **Lee Perry-Smith / Infinite Realities**, based on work at [Triplegangers](https://www.triplegangers.com/), licensed under [Creative Commons Attribution 3.0 Unported](https://creativecommons.org/licenses/by/3.0/). The original license is bundled at `assets/character/LeePerrySmith_License.txt`.

Source: [three.js LeePerrySmith assets](https://github.com/mrdoob/three.js/tree/dev/examples/models/gltf/LeePerrySmith). Bundled original files: `LeePerrySmith.glb`, `Map-COL.jpg`, `Map-SPEC.jpg`, and `Infinite-Level_02_Tangent_SmoothUV.jpg`. Downloaded September 13, 2026. Runtime adaptations fit the scan to the survivor body, tint the skin, add selectable hair/scars, and apply physically based lighting. Clothing and hair are original procedural geometry. The reference scan has a relaxed expression with closed eyelids; the editor currently uses one facial identity.

## Survivor clothing

The shirt and trousers use original 1024 × 1024 albedo, OpenGL normal and roughness maps from [Rough Linen](https://polyhaven.com/a/rough_linen), photographed by **colormass** and processed by **Rico Cilliers**. These Poly Haven assets are licensed [CC0 1.0](https://polyhaven.com/license). Retrieved through the documented Poly Haven API on September 13, 2026; bundled locally in `assets/character/linen-*.jpg` (2.84 MB combined). A shader uses restrained neutral luminance from the source blue fabric so the player's chosen garment dye remains visible. The original map files are unmodified. URLs, dimensions and SHA-256 hashes are recorded in `assets/character/linen-provenance.json`.
