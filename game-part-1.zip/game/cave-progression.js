export const RARE_ORE_CHANCE=.10;
export const CAVE_BEAR_CHANCE=.01;
export const RARE_STONE_ORES=Object.freeze(['gold_ore','cave_ore','obsidian','frost_crystal']);
export const CAVE_REWARD=Object.freeze({cave_ore:6,frost_crystal:6,gold_ore:4});

/** Stable per life and source: reloading never rerolls a mined rock or an entry. */
export function resourceRandom(seed,key){
  let value=2166136261;
  for(const c of `${seed}:${key}`){value^=c.charCodeAt(0);value=Math.imul(value,16777619);}
  value^=value>>>16;value=Math.imul(value,2246822507);value^=value>>>13;
  return (value>>>0)/4294967296;
}
export function rareOreAt(seed,rockId){
  if(resourceRandom(seed,`stone-rare:${rockId}`)>=RARE_ORE_CHANCE)return null;
  return RARE_STONE_ORES[Math.floor(resourceRandom(seed,`stone-kind:${rockId}`)*RARE_STONE_ORES.length)];
}
export function normalizeCaveProgress(value){
  if(value===undefined)return {revision:0,inside:false,entries:0,lastBearEntry:0,rewardClaimed:false};
  if(!value||typeof value!=='object'||Array.isArray(value)||typeof value.inside!=='boolean'||typeof value.rewardClaimed!=='boolean'||!Number.isSafeInteger(value.entries)||value.entries<0||value.entries>1e9||!Number.isSafeInteger(value.lastBearEntry)||value.lastBearEntry<0||value.lastBearEntry>value.entries)return null;
  if(value.revision!==undefined&&(!Number.isSafeInteger(value.revision)||value.revision<0))return null;
  return {revision:value.revision||0,inside:value.inside,entries:value.entries,lastBearEntry:value.lastBearEntry,rewardClaimed:value.rewardClaimed};
}
export function createCaveProgress({seed='wilderness',state}={}){
  let saved=normalizeCaveProgress(state);if(!saved)throw new Error('Invalid cave progress.');
  return {
    visit(inside){
      inside=Boolean(inside);if(inside===saved.inside)return null;
      saved.inside=inside;
      saved.revision++;
      if(!inside)return {exited:true,bear:false,entry:saved.entries};
      saved.entries++;
      const bear=resourceRandom(seed,`cave-bear-entry:${saved.entries}`)<CAVE_BEAR_CHANCE;
      if(bear)saved.lastBearEntry=saved.entries;
      return {entered:true,bear,entry:saved.entries};
    },
    claim(){if(saved.rewardClaimed)return false;saved.rewardClaimed=true;saved.revision++;return true;},
    snapshot:()=>({...saved})
  };
}
