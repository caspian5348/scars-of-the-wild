import * as THREE from './vendor/three.module.js';
import {CAVE_ID,CAVE_ENTRANCE,CAVE_BOUNDS,CAVE_ZONES,MAZE_REWARD_POSITION,caveMazeDistance,caveReferenceFloorAt,caveCeilingAt,caveOverburdenAt,caveWalkableAt} from './cave-maze.js';
const TAU=Math.PI*2;
const hash=(x,z)=>{const n=Math.sin(x*127.1+z*311.7)*43758.5453;return n-Math.floor(n);};
function random(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};}
function geometry(p,uv,index,colors){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));if(colors)g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(index);g.computeVertexNormals();g.computeBoundingSphere();return g;}

/** A roofed excavation in the hillside. Openings are the union of the shared
 * tunnel capsules, so intersections never contain overlapping tube end walls. */
export function createCaveMaze({group,heightAt,rockMaps}){
  const root=new THREE.Group();root.name='Underground Hollowroot labyrinth';root.userData.caveId=CAVE_ID;group.add(root);
  const resources=new Set(),own=r=>(resources.add(r),r),colliders=[],resourceNodes=[],rng=random(874921),dummy=new THREE.Object3D();
  const copies={};for(const key of ['map','normalMap','roughnessMap']){if(!rockMaps[key])continue;const texture=own(rockMaps[key].clone());texture.repeat.set(1,1);copies[key]=texture;}
  const wallsMaterial=own(new THREE.MeshStandardMaterial({...copies,color:'#71695b',roughness:.97,side:THREE.DoubleSide,vertexColors:true,normalScale:new THREE.Vector2(.9,.9)}));
  const ceilingMaterial=own(new THREE.MeshStandardMaterial({...copies,color:'#686253',roughness:.98,side:THREE.DoubleSide,normalScale:new THREE.Vector2(.85,.85)}));
  const exteriorMaterial=own(new THREE.MeshStandardMaterial({...copies,color:'#aca38b',roughness:.98,side:THREE.DoubleSide,normalScale:new THREE.Vector2(1,1)}));
  const dampMaterial=own(new THREE.MeshStandardMaterial({...copies,color:'#494840',roughness:.91,normalScale:new THREE.Vector2(.9,.9)}));
  function mesh(g,material,name){const m=new THREE.Mesh(own(g),material);m.name=name;m.castShadow=m.receiveShadow=true;root.add(m);return m;}
  function instances(g,material,points,name){const m=own(new THREE.InstancedMesh(g,material,points.length));m.name=name;points.forEach((p,i)=>{dummy.position.set(p.x,p.y,p.z);dummy.rotation.set(p.rx||0,p.angle||0,p.rz||0);dummy.scale.set(p.sx||1,p.sy||1,p.sz||1);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix);});m.castShadow=m.receiveShadow=true;m.computeBoundingSphere();root.add(m);return m;}

  // March the shared signed floor outline. Each segment has both a physical
  // wall and overlapping circle colliders; a player cannot cut across a bend.
  const grid=1.35,minX=-697,maxX=-508,minZ=-131,maxZ=11,segments=[];
  const crossing=(a,b)=>{const t=a.d/(a.d-b.d);return{x:a.x+(b.x-a.x)*t,z:a.z+(b.z-a.z)*t};};
  for(let x=minX;x<maxX;x+=grid)for(let z=minZ;z<maxZ;z+=grid){
    const corners=[[x,z],[x+grid,z],[x+grid,z+grid],[x,z+grid]].map(([px,pz])=>({x:px,z:pz,d:caveMazeDistance(px,pz)})),hits=[];
    for(let edge=0;edge<4;edge++){const a=corners[edge],b=corners[(edge+1)%4];if((a.d<=0)!==(b.d<=0))hits.push(crossing(a,b));}
    if(hits.length===2)segments.push(hits);
    else if(hits.length===4){segments.push([hits[0],hits[1]],[hits[2],hits[3]]);}
  }
  const p=[],uv=[],indices=[],colors=[],layers=6;
  for(const[a,b]of segments){
    const mx=(a.x+b.x)/2,mz=(a.z+b.z)/2;
    if(mx>-509.8)continue;
    const dx=caveMazeDistance(mx+.08,mz)-caveMazeDistance(mx-.08,mz),dz=caveMazeDistance(mx,mz+.08)-caveMazeDistance(mx,mz-.08),norm=Math.hypot(dx,dz)||1,nx=dx/norm,nz=dz/norm;
    const base=p.length/3,projectOnZ=Math.abs(nx)>Math.abs(nz);
    for(let layer=0;layer<=layers;layer++){
      for(const point of[a,b]){
        const t=layer/layers,floor=heightAt(point.x,point.z)-.38,roof=caveCeilingAt(point.x,point.z)+.55,y=floor+(roof-floor)*t;
        const strata=Math.sin(y*2.25+point.x*.027+point.z*.013)*.075+Math.sin(y*5.2+point.z*.12)*.023;
        const rough=(hash(point.x*.8+layer,point.z*.8)-.5)*.14,offset=(strata+rough)*Math.sin(t*Math.PI);
        p.push(point.x+nx*offset,y,point.z+nz*offset);uv.push((projectOnZ?point.z:point.x)/4,y/3.8);
        const damp=.66+Math.sin(point.x*.17+point.z*.08)*.06+Math.sin(y*1.9+point.x*.015)*.045+t*.10;colors.push(damp,damp*.98,damp*.9);
      }
      if(layer<layers){const n=base+layer*2;indices.push(n,n+1,n+2,n+1,n+3,n+2);}
    }
    const length=Math.hypot(b.x-a.x,b.z-a.z),steps=Math.max(1,Math.ceil(length/.88));
    for(let i=0;i<steps;i++){const t=(i+.5)/steps,x=a.x+(b.x-a.x)*t,z=a.z+(b.z-a.z)*t;colliders.push({x:x+nx*.20,z:z+nz*.20,radius:.70,height:48,baseY:caveReferenceFloorAt(x,z)-.5,kind:'cave-wall',caveId:CAVE_ID});}
  }
  mesh(geometry(p,uv,indices,colors),wallsMaterial,'Continuous weathered limestone maze walls');

  // Each ceiling tile sits beneath an opaque terrain cap. Its perimeter is
  // buried in solid hillside; the entrance is the only opening to daylight.
  const cp=[],cuv=[],ci=[],tp=[],tuv=[],ti=[],roofGrid=1.65,roofVertices=new Map();
  for(let x=-710;x<-510;x+=roofGrid)for(let z=-141;z<24;z+=roofGrid){
    const endX=Math.min(-510,x+roofGrid),points=[[x,z],[endX,z],[endX,z+roofGrid],[x,z+roofGrid]];
    // Ten metres of buried overlap reaches the untouched hill surface beyond
    // the excavated floor, so the roof has no exposed floating perimeter.
    if(Math.min(...points.map(([px,pz])=>caveMazeDistance(px,pz)))>10)continue;
    const quad=[];
    for(const[px,pz]of points){
      const key=`${Math.round(px*1000)},${Math.round(pz*1000)}`;let index=roofVertices.get(key);
      if(index===undefined){index=cp.length/3;roofVertices.set(key,index);const grain=(hash(px*.33,pz*.33)-.5)*.16;cp.push(px,caveCeilingAt(px,pz)+grain,pz);cuv.push(px/4.4,pz/4.4);tp.push(px,caveOverburdenAt(px,pz)+Math.sin(px*.27+pz*.33)*.12,pz);tuv.push(px/6,pz/6);}
      quad.push(index);
    }
    ci.push(quad[0],quad[1],quad[2],quad[0],quad[2],quad[3]);ti.push(quad[0],quad[2],quad[1],quad[0],quad[3],quad[2]);
  }
  mesh(geometry(cp,cuv,ci),ceilingMaterial,'Enclosed low arches and damp cave ceiling');
  mesh(geometry(tp,tuv,ti),exteriorMaterial,'Solid hillside overburden above the tunnels');

  const mouthP=[],mouthUV=[],mouthI=[];
  for(let i=0;i<=44;i++){
    const z=-76.5+i*.75,y0=Math.abs(z+60)<6.25?caveCeilingAt(-510,z)-.2:heightAt(-510,z)-.3,y1=Math.max(y0+.6,caveOverburdenAt(-510,z)+.5);
    mouthP.push(-509.9,y0,z,-509.9,y1,z);mouthUV.push(z/4,y0/4,z/4,y1/4);
    if(i<44){const n=i*2;mouthI.push(n,n+1,n+2,n+1,n+3,n+2);}
  }
  mesh(geometry(mouthP,mouthUV,mouthI),exteriorMaterial,'Broken hillside face over the descending entrance');

  const rock=own(new THREE.IcosahedronGeometry(1,1)),vertices=rock.attributes.position;
  for(let i=0;i<vertices.count;i++){const x=vertices.getX(i),y=vertices.getY(i),z=vertices.getZ(i),rough=.8+hash(x*9+y,z*11)*.26;vertices.setXYZ(i,x*rough,y*(.84+hash(y*9,z*3)*.21),z*rough);}rock.computeVertexNormals();
  const rubble=[],rim=[],roofRocks=[];
  for(let i=0;i<segments.length;i+=5){const[a,b]=segments[i],x=(a.x+b.x)/2,z=(a.z+b.z)/2;if(x>-513)continue;const size=.15+rng()*.5;rubble.push({x,z,y:heightAt(x,z)+size*.2,sx:size*1.4,sy:size*.72,sz:size,angle:rng()*TAU});}
  for(let i=0;i<48;i++){
    const a=(i%24+.4)/24*Math.PI,side=Math.cos(a),x=-510+(rng()-.5)*5,z=-60+side*(8.1+rng()*2),y=caveReferenceFloorAt(x,z)+Math.sin(a)*9.8+.5;
    rim.push({x,z,y,sx:1.4+rng()*1.6,sy:1.0+rng()*.8,sz:1.2+rng()*1.8,angle:rng()*TAU});
  }
  for(let i=0;i<160;i++){const x=-695+rng()*178,z=-128+rng()*137;if(caveMazeDistance(x,z)>10)continue;const size=.5+rng()*2.1;roofRocks.push({x,z,y:caveOverburdenAt(x,z)+size*.3,sx:size*1.6,sy:size*.7,sz:size,angle:rng()*TAU});}
  instances(rock,dampMaterial,rubble,'Angular fallen limestone chips along cave walls');
  instances(rock,exteriorMaterial,rim,'Broken limestone and root buttresses framing the entrance');
  instances(rock,exteriorMaterial,roofRocks,'Weathered strata exposed on the rocky hillside');

  const dripGeometry=own(new THREE.CylinderGeometry(.12,.40,1,7,6)),dripVertices=dripGeometry.attributes.position;
  for(let i=0;i<dripVertices.count;i++){const x=dripVertices.getX(i),y=dripVertices.getY(i),z=dripVertices.getZ(i),r=1+Math.sin(y*15)*.055;dripVertices.setXYZ(i,x*r+Math.sin(y*6)*.025,y,z*r);}dripGeometry.computeVertexNormals();
  const drips=[];
  for(let i=0;i<220;i++){
    const x=-689+rng()*162,z=-123+rng()*125,d=caveMazeDistance(x,z);if(d>-.65||d<-4.9)continue;const length=.45+rng()*1.55;
    drips.push({x,z,y:caveCeilingAt(x,z)-length*.47,sx:.35+rng()*.7,sy:length,sz:.35+rng()*.7,rx:Math.PI,angle:rng()*TAU});
  }
  instances(dripGeometry,dampMaterial,drips,'Tapered dripstone hanging above clear walking height');

  // A few distinguishable natural chambers help orientation without drawing a
  // solution on the player's map: white flowstone, a red seam and the geode.
  const flowstoneMaterial=own(new THREE.MeshStandardMaterial({...copies,color:'#b1a995',roughness:.8,normalScale:new THREE.Vector2(.25,.25)}));
  const flowstones=[];
  for(const id of ['0:0','2:1','3:4','4:2']){const room=CAVE_ZONES.find(p=>p.id===id);for(let i=0;i<7;i++){const angle=-.8+i*.22,x=room.x+Math.cos(angle)*5.4,z=room.z+Math.sin(angle)*5.4;if(caveMazeDistance(x,z)<-2)continue;const h=2.6+rng()*2.4;flowstones.push({x,z,y:heightAt(x,z)+h*.5,sx:.4+rng()*.3,sy:h,sz:.35+rng()*.45,angle:rng()*TAU});}}
  instances(dripGeometry,flowstoneMaterial,flowstones,'Pale calcite curtains marking side chambers');

  const rootMaterial=own(new THREE.MeshStandardMaterial({color:'#342f23',roughness:1})),roots=[];
  for(let i=0;i<24;i++){const x=-510-rng()*11,z=-60+(rng()-.5)*10;if(!caveWalkableAt(x,z,1))continue;const length=.8+rng()*2.8;roots.push({x,z,y:caveCeilingAt(x,z)-length*.49,sx:.045+rng()*.09,sy:length,sz:.04+rng()*.06,rx:Math.PI,rz:(rng()-.5)*.35,angle:rng()*TAU});}
  instances(dripGeometry,rootMaterial,roots,'Tangled roots descending from the entrance roof');

  const shard=own(new THREE.CylinderGeometry(.03,.32,1,6,1)),shardP=shard.attributes.position;
  for(let i=0;i<shardP.count;i++)if(shardP.getY(i)>.3)shardP.setY(i,shardP.getY(i)+shardP.getX(i)*.55);shard.computeVertexNormals();
  const crystalMaterial=own(new THREE.MeshPhysicalMaterial({color:'#729997',emissive:'#214747',emissiveIntensity:.16,roughness:.28,metalness:.04,clearcoat:.42,clearcoatRoughness:.18,flatShading:true})),rewardStones=[],shards=[];
  for(let i=0;i<19;i++){const a=i/19*TAU,r=1.8+rng()*.45,x=MAZE_REWARD_POSITION.x+Math.cos(a)*r,z=MAZE_REWARD_POSITION.z+Math.sin(a)*r;rewardStones.push({x,z,y:heightAt(x,z)+.35,sx:.6+rng()*.5,sy:.6+rng()*.7,sz:.6+rng()*.4,angle:a});}
  for(let i=0;i<37;i++){const a=i*2.39996,r=Math.sqrt(rng())*1.55,x=MAZE_REWARD_POSITION.x+Math.cos(a)*r,z=MAZE_REWARD_POSITION.z+Math.sin(a)*r,h=.55+rng()*1.15;shards.push({x,z,y:heightAt(x,z)+h*.48,sx:.65+rng()*.65,sy:h,sz:.65+rng()*.65,rx:Math.cos(a)*.25,rz:Math.sin(a)*.25,angle:a});}
  instances(rock,dampMaterial,rewardStones,'Ancient cracked geode at the labyrinth heart');
  const prize=instances(shard,crystalMaterial,shards,'Rare mineral heart reward formation');prize.userData.rewardId='hollowroot-geode';
  resourceNodes.push({id:'hollowroot-geode',kind:'maze-reward',...MAZE_REWARD_POSITION,radius:2});
  for(const [position,color,power]of [[{x:-516,z:-60},'#b5bda2',8],[{x:-626,z:-4},'#73978f',3],[MAZE_REWARD_POSITION,'#7ec1b9',11]]){const light=own(new THREE.PointLight(color,power,18,1.5));light.position.set(position.x,heightAt(position.x,position.z)+3.3,position.z);root.add(light);}

  root.userData.entrance={...CAVE_ENTRANCE};root.userData.rewardPosition={...MAZE_REWARD_POSITION};
  root.userData.maze={junctions:30,wallSegments:segments.length,underground:true,bounds:{...CAVE_BOUNDS}};
  return{group:root,colliders,resourceNodes,dispose(){root.removeFromParent();for(const r of resources)r.dispose();root.clear();}};
}
