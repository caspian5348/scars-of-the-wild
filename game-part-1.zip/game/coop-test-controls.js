/** Only rendered on the explicit co-op QA route; every action uses normal player/server rules. */
export function createCoopTestControls({lookDown,onInteract,onAttack,onInventory,onWalk,onTurn,onFaceResource,isPlaying=()=>true}={}){
  const params=new URLSearchParams(location.search);
  if(params.get('coop')!=='1'||params.get('check')!=='coop')return{dispose(){}};
  const panel=document.createElement('aside');panel.setAttribute('aria-label','Cooperative play test controls');
  panel.style.cssText='position:fixed;right:18px;bottom:20px;z-index:65;display:flex;flex-wrap:wrap;gap:6px;max-width:290px;padding:12px;background:#14261aed;border:1px solid #b9b28070;box-shadow:0 8px 28px #0006';
  const title=document.createElement('strong');title.textContent='Co-op play check';title.style.cssText='font:12px Segoe UI;color:#ddd7b3;flex-basis:100%;margin-bottom:4px';panel.append(title);
  for(const [label,action]of[['Walk forward',onWalk],['Turn left',()=>onTurn?.(Math.PI/4)],['Turn right',()=>onTurn?.(-Math.PI/4)],['Face nearest material',onFaceResource],['Look down',lookDown],['Pick up / Interact',onInteract],['Attack',onAttack],['Open pack',onInventory]]){
    const button=document.createElement('button');button.type='button';button.textContent=label;button.style.cssText='font:11px Segoe UI;background:#304431;color:#eee8cf;border:1px solid #c6be9355;padding:8px 10px;cursor:pointer';
    button.addEventListener('click',event=>{event.stopPropagation();if(isPlaying())void action?.();});panel.append(button);
  }
  const note=document.createElement('small');note.textContent='Use W A S D to walk. These actions follow the same co-op rules as the keyboard.';note.style.cssText='font:10px/1.6 Segoe UI;color:#afbca5';panel.append(note);
  panel.addEventListener('pointerdown',event=>event.stopPropagation());document.body.append(panel);
  return{dispose(){panel.remove();}};
}
