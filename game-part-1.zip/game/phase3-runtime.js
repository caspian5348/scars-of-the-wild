import * as THREE from './vendor/three.module.js';
import {createSurvivalSystem} from './survival-system.js';
import {ITEMS,RECIPES,BUILDINGS} from './survival-catalog.js';
import {createCampWorld} from './camp-world.js';
import {createSurvivalUI} from './survival-ui.js';
import {createWildlife,WILDLIFE_SPECIES} from './wildlife.js';
import {createHeldEquipment} from './held-equipment.js';
import {biomeAt} from './biomes.js';
import {CAVE_ZONES,caveWalkableAt} from './cave-maze.js';
import {CAVE_REWARD} from './cave-progression.js';
import {createBurrowpeedRuntime} from './burrowpeed-runtime.js';
const element=(tag,cls)=>{const e=document.createElement(tag);e.className=cls;document.querySelector('#game').append(e);return e;};
export function createPhase3({scene,camera,world,state,seed,character,surfaceTexture,prewarmedView,notify,onDamage,onHeal,onSave,onInventory,onRefreshCollision,onLegacyAttack,onBurrowEvent=()=>{},isPlaying=()=>true}){
  const survival=createSurvivalSystem({state:state?.survival}),camp=createCampWorld({scene,world,state:state?.world,seed,buildings:BUILDINGS});
  const wildlife=createWildlife({scene,heightAt:world.groundHeight,biomeAt,waterLevel:2,colliders:world.colliders,seed,state:state?.wildlife,onDamage:(amount,cause)=>onDamage(amount,typeof cause==='string'?cause:'A wild animal attacked you.',{creature:true})});
  const burrowers=createBurrowpeedRuntime({scene,world,seed,state:state?.burrowers,surfaceTexture,prewarmedView,onDamage:(amount,cause)=>onDamage(amount,`Killed by a ${cause}.`,{creature:true}),onEvent:onBurrowEvent,onChange:(_state,event)=>{if(event.type!=='harvested')onSave();}});
  const held=createHeldEquipment(camera),vitals=element('div','survival-vitals'),prompt=element('div','interaction-prompt'),hotbar=element('div','survival-hotbar');
  held.setProfile(character);
  let player={x:0,y:0,z:0},direction=new THREE.Vector3(0,0,-1),info={},cooldown=0,hudTime=0,selectedBuild=null,inventorySection='inventory',lastBiome='',damagePending=0,damageTime=0,resting=false,fishing=null,torchTime=0;
  const glyph=(text)=>{const span=document.createElement('span');span.textContent=text;return span;};
  const result=r=>{if(r?.message)notify(r.message);return r;};
  const equipped=()=>{const s=survival.snapshot();return s.inventory.find(i=>i.uid===s.equipment.hand)||null;};
  function applyHealth(r){if(r?.healthDelta>0)onHeal(r.healthDelta);else if(r?.healthDelta<0)onDamage(-r.healthDelta,'Something you consumed made you ill.');return r;}
  function changed(r){if(r?.ok!==false){onSave();refreshHUD();}return result(r);}
  const ui=createSurvivalUI({getSystem:()=>survival,onClose:()=>onInventory(null),species:{teethpeed:{name:'Teethpeed',biomes:['forest'],description:'A tree-dwelling predator. Break sight and use thick brush to lose its hunt.'},deatheater:{name:'Deatheater',biomes:['storm'],description:'A withered flying hunter. Dodge its committed dive; its circular jaws swallow prey whole.'},burrowpeed:{name:'Burrowpeed',biomes:['forest','valley'],description:'A buried Teethpeed relative with only its worn tooth tips exposed. Fifty dens lie at least 100 feet apart across the rainforest and river valley. Approach within 10 metres and it erupts, chases for ten seconds, then burrows away. It cannot enter Glowhaven or swim.'},...WILDLIFE_SPECIES},
    onCraft:id=>changed(survival.craft(id)),onEquip:id=>changed(survival.equip(id)),onConsume:id=>changed(applyHealth(survival.consume(id))),onRepair:id=>changed(survival.repair(id)),
    onBuild:id=>{cooldown=0;selectedBuild=id;camp.selectBuild(id);onInventory(null);notify('Aim at the ground. E places the structure; R rotates it; B cancels.');},
    onDrop:uid=>{if(camp.snapshot().drops.length>=1000)return {ok:false,message:'Pick up an existing dropped item first.'};const r=survival.extract(uid,1);if(r.ok)camp.drop(r.stack,{x:player.x+direction.x,y:player.y,z:player.z+direction.z});return changed(r);},
    onStorage:transferStorage});
  function transferStorage(id,uid,n,action){
    const contents=camp.storage(id);if(!contents)return {ok:false,message:'Storage is unavailable.'};let r;
    if(action==='take'){
      const index=contents.findIndex(s=>s.uid===uid),slot=contents[index];if(!slot||slot.count<n)return {ok:false,message:'Nothing remains in this slot.'};
      r=survival.insert({...slot,count:n});if(r.ok){slot.count-=n;if(!slot.count)contents.splice(index,1);}
    }else{
      const check=survival.canExtract(uid,n);if(!check.ok)return check;
      const building=camp.getBuildings().find(b=>b.id===id),def=BUILDINGS[building?.type],item=ITEMS[check.stack.id];
      const matches=contents.filter(s=>s.id===check.stack.id&&s.durability===check.stack.durability&&s.expiresAt===check.stack.expiresAt),room=matches.reduce((sum,s)=>sum+item.stack-s.count,0),weight=contents.reduce((sum,s)=>sum+(ITEMS[s.id]?.weight||0)*s.count,0);
      if(contents.length+Math.ceil(Math.max(0,n-room)/item.stack)>(def?.storageSlots||24)||weight+item.weight*n>(def?.storageWeight||180))return {ok:false,message:'This chest is full.'};
      r=survival.extract(uid,n);if(r.ok){let remaining=n;for(const s of matches){const moved=Math.min(remaining,item.stack-s.count);s.count+=moved;remaining-=moved;}if(remaining)contents.push({...r.stack,count:remaining,uid:crypto.randomUUID()});}
    }
    return changed(r);
  }
  function quickSlots(){return survival.snapshot().inventory.filter(s=>ITEMS[s.id]?.tool||ITEMS[s.id]?.slot==='hand'||ITEMS[s.id]?.kind==='weapon').slice(0,6);}
  const getChasers=p=>[...wildlife.getChasers(p),...burrowers.getChasers(p)];
  const nearbyCorpse=p=>[...wildlife.getNearbyTargets({origin:p,range:3.5}),...burrowers.getNearbyTargets({origin:p,range:3.5})].filter(t=>t.dead||t.stage==='dead'||t.state==='dead'||t.corpse).sort((a,b)=>a.distance-b.distance)[0];
  function refreshHUD(){const s=survival.snapshot(),slot=equipped(),item=ITEMS[slot?.id];held.set(slot?.id==='torch'&&slot.durability<=0?null:item);vitals.replaceChildren();
    for(const [label,value] of [['FOOD',`${Math.round(s.hunger??100)}%`],['WATER',`${Math.round(s.thirst??100)}%`],['EXPOSURE',s.temperature<-55?'Cold':s.temperature>55?'Hot':'Comfortable'],['IN HAND',item?.name||'Empty hands']]){const box=glyph(label),valueEl=document.createElement('strong');valueEl.textContent=value;box.append(valueEl);vitals.append(box);}
    hotbar.replaceChildren();quickSlots().forEach((s,i)=>{const b=document.createElement('button');b.className='quick-slot'+(s.uid===slot?.uid?' equipped':'');b.textContent=`${i+1} · ${ITEMS[s.id]?.name||s.id}`;b.onclick=()=>changed(survival.equip(s.uid));hotbar.append(b);});
    const open=document.createElement('button');open.className='quick-slot';open.textContent='I · Inventory';open.onclick=()=>onInventory('inventory');hotbar.append(open);
    if(ui.visible)ui.render();
  }
  function update(dt,p,dir,{moving=false,active=true,swimming=false,sprinting=false,speed=0,motionEffects=true}={}){
    player={...p};direction.copy(dir);cooldown=Math.max(0,cooldown-dt);info=camp.update(active?dt:0,{...player,survivalTime:survival.snapshot().elapsed},direction);survival.setStations(info.stations);
    if(active){const biome=biomeAt(p.x,p.z).id;if(biome!==lastBiome){lastBiome=biome;const r=survival.discoverBiome(biome);if(r?.unlocked?.length)notify('New crafting knowledge recorded.');}
      const visit=camp.visitCave(p);
      if(visit){
        if(visit.bear){
          const chambers=CAVE_ZONES.filter(zone=>caveWalkableAt(zone.x,zone.z,1.3)&&Math.hypot(zone.x-p.x,zone.z-p.z)>10).sort((a,b)=>Math.hypot(a.x-p.x,a.z-p.z)-Math.hypot(b.x-p.x,b.z-p.z));
          for(const chamber of chambers){const result=wildlife.spawnCaveBear({position:{x:chamber.x,y:world.groundHeight(chamber.x,chamber.z),z:chamber.z},encounterId:`${seed}:${visit.entry}`});if(result.spawned){notify('A low growl echoes from deeper in the cave.');break;}if(result.reason==='bear already present')break;}
        }
        onSave();
      }
      wildlife.update(dt,{...p,moving,concealed:info.concealment.concealed,hidingId:info.concealment.hidingId});
      if(isPlaying())burrowers.update(dt,p);
      const s=survival.step(dt,{moving,inCold:biome==='ice',inHeat:biome==='lava',nearFire:info.nearFire,sheltered:info.sheltered,swimming});
      const hazard=world.hazardAt?.(p.x,p.z),burning=(hazard?.kind||hazard?.type)==='lava'&&p.y<((hazard.surfaceY??29)+1);damagePending+=(s?.healthDamage||0)+(burning?(hazard.damagePerSecond||42)*dt:0);damageTime+=dt;
      if(damageTime>=.25&&damagePending>0){const amount=damagePending;damagePending=0;damageTime=0;onDamage(amount,burning?'The lava burned you.':'Exposure, hunger or thirst overwhelmed you.');}
      if(s?.healthDelta>0)onHeal(s.healthDelta);
      if(resting){if(moving||!info.bedroll||getChasers(p).length){resting=false;}else if(info.sheltered&&s.hunger>35&&s.thirst>35){onHeal(dt*.65);}}
      const hand=survival.getEquipment();if(hand?.id==='torch'&&hand.durability>0&&!swimming){torchTime+=dt;if(torchTime>=1){survival.damageEquipment(Math.floor(torchTime));torchTime%=1;}}else torchTime=0;
      if(fishing){if(moving||hand?.id!=='fishing_rod'||hand.durability<=0){fishing=null;notify('Your fishing line was pulled in.');}else{fishing.remaining-=dt;if(fishing.remaining<=0){const r=survival.add('raw_fish',1);if(r.ok)survival.damageEquipment(1);fishing=null;changed(r);notify(r.ok?'You caught a fish. Cook it before eating.':r.message);}}}
    }else burrowers.render(p);
    active=active&&isPlaying();
    const corpse=nearbyCorpse(p);
    let text='',sub='';if(selectedBuild){text=`Place ${BUILDINGS[selectedBuild]?.name||selectedBuild}`;sub=info.spot?.valid?'E place · R rotate · B cancel':info.spot?.reason||'Choose a clear patch of ground.';}
    else if(corpse){text=`Harvest ${corpse.name||corpse.species||'animal'}`;sub='E collect meat and materials';}
    else if(info.target){const t=info.target,textStone=t.item==='stone'&&!t.mineable;text=t.kind==='reward'?'Hidden mineral cache':t.kind==='tree'?`Chop tree · ${6-(camp.snapshot().treeHits[t.id]||0)} strikes`:t.mineable?`Mine stone · ${3-(camp.snapshot().rockHits[t.id]||0)} strikes`:textStone?`Loose stone · ${t.count||1}`:(ITEMS[t.item]?.name||BUILDINGS[t.type]?.name||'Camp structure');sub=t.kind==='reward'?'E collect the maze reward':t.mineable?'E mine with a pickaxe · 10% rare ore chance per rock':textStone?'E pick up · No tool needed':t.kind==='resource'?'E gather':'E interact';if(t.item&&t.kind!=='reward')survival.learnResource(t.item);}
    else if(swimming||world.groundHeight(p.x+dir.x*2,p.z+dir.z*2)<2.1){text='Water';sub='E drink · River water can carry illness. Ocean water is unsafe.';}
    if(fishing){text='Line cast';sub=`Hold still · ${Math.ceil(fishing.remaining)}s`;}
    if(info.concealment.concealed){sub+=(sub?' · ':'')+'Hidden in brush: hunters get one 45% search chance.';}
    prompt.hidden=!active||(!text&&!sub);prompt.replaceChildren(glyph(text));if(sub){const small=document.createElement('small');small.textContent=sub;prompt.append(small);}
    vitals.hidden=hotbar.hidden=!active;held.update(dt,moving,active,{swimming,sprinting,speed,motionEffects});hudTime+=dt;if(hudTime>.3){hudTime=0;refreshHUD();}
    return info.concealment;
  }
  function interact(){if(cooldown>0)return;cooldown=.55;
    if(selectedBuild){const spot=camp.buildSpot(player,direction);if(!spot.valid){notify(spot.reason);return;}const r=survival.consumeBuilding(selectedBuild);if(r?.ok===false){result(r);return;}camp.placeBuilding(spot);onRefreshCollision();changed(r);return;}
    const corpse=nearbyCorpse(player);
    if(corpse){const source=corpse.kind==='burrowpeed'?burrowers:wildlife,loot=source.getLoot(corpse.id);if(!loot)return;const check=createSurvivalSystem({state:survival.snapshot()});for(const [id,n] of Object.entries(loot))if(check.add(id,n)?.ok===false){notify('Make room in your pack before harvesting.');return;}const harvested=source.harvestCorpse(corpse.id);if(harvested){for(const [id,n] of Object.entries(harvested))survival.add(id,n);notify('Harvested food and crafting materials.');onSave();refreshHUD();}return;}
    const t=info.target;
    if(t?.kind==='reward'){
      const check=createSurvivalSystem({state:survival.snapshot()});
      for(const [id,count] of Object.entries(CAVE_REWARD))if(!check.add(id,count).ok){notify('Make room in your pack to collect the mineral cache.');return;}
      if(camp.claimCaveReward()){for(const [id,count] of Object.entries(CAVE_REWARD))survival.add(id,count);onSave();refreshHUD();notify('Maze cache recovered: 6 Abyssal Ore, 6 Frost Crystal and 4 Gold Ore.');}return;
    }
    if(t?.kind==='drop'){const r=survival.insert(t.stack);if(r.ok){camp.pickup(t.id);notify(`Picked up ${ITEMS[r.id]?.name||r.id}.`);}changed(r);return;}
    if(t?.kind==='resource'||t?.kind==='tree'){const r=survival.gather(t.item,{count:t.count||1,mining:!!t.mineable});if(r?.ok!==false){const action=camp.takeResource(t,{mined:!!t.mineable});held.swing();for(const [id,count] of Object.entries(action.loot||{})){const gain=survival.add(id,count);if(!gain.ok)camp.drop({uid:crypto.randomUUID(),id,count},player);}notify(`+${t.count||1} ${ITEMS[t.item]?.name||t.item}${action.felled?' · Tree felled; bark and resin recovered.':''}${action.rareOre?` · Rare find: ${ITEMS[action.rareOre].name}!`:''}`);if(action.felled)onRefreshCollision();}changed(r);return;}
    if(t?.kind==='building'){
      if(t.type==='door'){camp.interactBuilding(t.id,{toggle:true});onRefreshCollision();onSave();return;}
      if(/campfire/.test(t.type)){const r=survival.remove('wood',1);if(r?.ok!==false){camp.interactBuilding(t.id,{fuel:180});notify('The fire burns for another three minutes.');onSave();}else result(r);return;}
      if(/chest|storage/.test(t.type)){ui.setStorage(t.id,camp.storage(t.id));onInventory('storage');return;}
      if(t.type==='fish_trap'){const contents=camp.storage(t.id);if(!contents.length){notify('The trap catches one fish every two minutes in shallow water.');return;}const r=survival.insert(contents[0]);if(r.ok)contents.shift();changed(r);return;}
      if(t.type==='bedroll'){resting=true;notify('Resting. Shelter, food and water let you recover slowly. Move to get up.');return;}
      onInventory('craft');return;
    }
    const biome=biomeAt(player.x,player.z).id;if(world.groundHeight(player.x+direction.x*2,player.z+direction.z*2)<2.1||player.y<2){const hand=survival.getEquipment();if(hand?.id==='fishing_rod'){if(hand.durability<=0){notify('Repair your fishing rod first.');return;}if(!fishing)fishing={remaining:12};notify('Line cast. Hold still until a fish bites.');return;}if(biome==='ocean'||biome==='beach'){notify('Salt water will worsen your thirst. Find fresh water.');return;}changed(survival.count('empty_waterskin')?survival.gather('dirty_water',{count:1}):applyHealth(survival.hydrate(30,{unsafe:true})));return;}
    notify('Look toward a loose resource, tree, mineral deposit or camp structure.');
  }
  function attack(){if(cooldown>0)return;
    const use=survival.useEquipment();if(!use.ok){result(use);return;}
    const range=use.reach,damage=use.damage;cooldown=use.attackSeconds;held.swing();
    const origin={x:player.x,y:player.y+1.5,z:player.z};let hit=wildlife.attack({origin,direction:{x:direction.x,y:direction.y,z:direction.z},range,damage});
    if(!hit?.hit)hit=burrowers.attack({origin,direction,range,damage});
    if(!hit?.hit)hit=onLegacyAttack?.({origin,direction,range,damage});
    if(hit?.hit){notify(hit.killed?(hit.loot?'The creature fell. Its materials were collected.':'The animal fell. E harvests its remains.'):'Your strike connected.');if(hit.loot)for(const [id,n] of Object.entries(hit.loot)){const r=survival.add(id,n);if(!r.ok)camp.drop({uid:crypto.randomUUID(),id,count:n,...(ITEMS[id].shelfLife?{expiresAt:survival.snapshot().elapsed+ITEMS[id].shelfLife}:{})},player);}}
    onSave();
    refreshHUD();
  }
  refreshHUD();
  return{update,interact,attack,snapshot:()=>({version:1,survival:survival.snapshot(),world:camp.snapshot(),wildlife:wildlife.snapshot(),burrowers:burrowers.snapshot()}),getChasers,getConcealment:()=>info.concealment||{concealed:false,hidingId:null},
    open(section){inventorySection=section;ui.open(section);vitals.hidden=hotbar.hidden=prompt.hidden=true;held.update(0,false,false);},close(){ui.close();},cancelBuild(){selectedBuild=null;camp.selectBuild(null);},rotate:()=>camp.rotate(),quickEquip:i=>{const s=quickSlots()[i];if(s)changed(survival.equip(s.uid));},groundHeight:camp.groundHeight,blocking:camp.blocking,
    setCharacter:profile=>held.setProfile(profile),getDiagnostics:()=>({inventory:survival.snapshot(),camp:camp.getDiagnostics(),wildlife:wildlife.getDiagnostics(),burrowers:burrowers.getDiagnostics(),concealment:info.concealment,body:held.getDiagnostics?.()}),get survival(){return survival;},get camp(){return camp;},get wildlife(){return wildlife;},get burrowers(){return burrowers;},dispose(){ui.dispose();camp.dispose();wildlife.dispose();burrowers.dispose();held.dispose();vitals.remove();hotbar.remove();prompt.remove();}};
}

