import {CAVE_ENTRANCE,CAVE_LENGTH,caveSection,caveBlendAt} from './cave-maze.js';
export {CAVE_ENTRANCE,CAVE_LENGTH,caveSection,caveBlendAt} from './cave-maze.js';
const clamp = value => Math.max(0,Math.min(1,value));
const smooth = (a,b,value) => {const t=clamp((value-a)/(b-a));return t*t*(3-2*t);};
export const STORM_CENTER={x:180,z:-655};
export const GLOW_CENTER={x:390,z:185};

export const BIOMES = [
  {id:'forest', name:'Rainforest', x:-190, z:-25, color:'#254f39'},
  {id:'valley', name:'River Valley', x:135, z:85, color:'#a6ad79'},
  {id:'storm', name:'Stormlands', ...STORM_CENTER, color:'#635074'},
  {id:'cave',name:'Hollowroot Caverns',x:-619,z:-61,color:'#6e769a'},
  {id:'lava',name:'Ember Caldera',x:610,z:-350,color:'#ab5134'},
  {id:'ice',name:'Frostbound Highlands',x:-545,z:-570,color:'#bbd8dc'},
  {id:'beach',name:'Sundrift Coast',x:250,z:535,color:'#dacb94'},
  {id:'ocean',name:'Open Ocean',x:60,z:780,color:'#397c97'},
  {id:'glow',name:'Glowhaven',...GLOW_CENTER,color:'#68cbb4'},
];
export const FOREST_PREVIEW_SPAWN = {x:-112,z:-35,yaw:.85,pitch:.04};
export const STORM_PREVIEW_SPAWN = {...STORM_CENTER,yaw:-.32,pitch:.04};
export const GLOW_PREVIEW_SPAWN = {...GLOW_CENTER,yaw:-.65,pitch:.03};

/** An uneven ecotone, shared by vegetation, the field chart and encounters. */
export function forestBlendAt(x,z) {
  const dx=(x+190)/170, dz=(z+25)/245;
  const edge=Math.hypot(dx,dz)+Math.sin(z*.034+x*.016)*.045+Math.sin(x*.057-z*.017)*.025;
  const riverCenter=Math.sin(z*.013)*26+Math.sin(z*.006+.3)*18;
  // Keep the riverbanks and crash landing in an open valley, with a gradual western tree line.
  return (1-smooth(.76,1.055,edge))*smooth(32,85,riverCenter-x);
}
export function stormBlendAt(x,z) {
  const dx=(x-STORM_CENTER.x)/240,dz=(z-STORM_CENTER.z)/205;
  const edge=Math.hypot(dx,dz)+Math.sin(x*.026+z*.031)*.048+Math.sin(z*.058-x*.017)*.025;
  return 1-smooth(.72,1.09,edge);
}
export function glowBlendAt(x,z){
  const r=Math.hypot((x-GLOW_CENTER.x)/175,(z-GLOW_CENTER.z)/160)+Math.sin(x*.023+z*.017)*.025;
  return 1-smooth(.70,1.09,r);
}
/** The visible biome and protection boundary are the same coherent region. */
export const isGlowSafeAt=(x,z)=>glowBlendAt(x,z)>.45;
export const LAVA_CENTER={x:610,z:-350};
export const LAVA_LEVEL=29;
export function coastZ(x){return 545+Math.sin(x*.004)*31+Math.sin(x*.013)*12;}
export function iceBlendAt(x,z){const r=Math.hypot((x+545)/270,(z+570)/230)+Math.sin(x*.019+z*.011)*.025;return 1-smooth(.70,1.12,r);}
export function lavaBlendAt(x,z){const r=Math.hypot((x-610)/235,(z+350)/245)+Math.sin(x*.016-z*.019)*.03;return 1-smooth(.68,1.08,r);}
export function lavaRadius(angle){return 1+Math.sin(angle*3+.4)*.075+Math.sin(angle*7-1)*.035;}
export function lavaAt(x,z){const dx=(x-610)/105,dz=(z+350)/77;return Math.hypot(dx,dz)<lavaRadius(Math.atan2(dz,dx));}
export function beachBlendAt(x,z){return(1-smooth(8,65,Math.abs(z-coastZ(x))))*smooth(375,460,z);}
export function oceanBlendAt(x,z){return smooth(8,52,z-coastZ(x));}
export function biomeAt(x,z){if(oceanBlendAt(x,z)>.42)return BIOMES[7];if(beachBlendAt(x,z)>.28)return BIOMES[6];if(caveBlendAt(x,z)>.35)return BIOMES[3];if(iceBlendAt(x,z)>.40)return BIOMES[5];if(lavaBlendAt(x,z)>.42)return BIOMES[4];if(isGlowSafeAt(x,z))return BIOMES[8];return stormBlendAt(x,z)>.45?BIOMES[2]:forestBlendAt(x,z)>.45?BIOMES[0]:BIOMES[1];}
