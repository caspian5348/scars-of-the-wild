import * as THREE from './vendor/three.module.js';
import {riverBankDistanceAt} from './river-network.js';

const TAU = Math.PI * 2;
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
function random(seed) {
  return () => {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let value = Math.imul(seed ^ seed >>> 15, 1 | seed);
    value = value + Math.imul(value ^ value >>> 7, 61 | value) ^ value;
    return ((value ^ value >>> 14) >>> 0) / 4294967296;
  };
}

function geometryBuilder() {
  const positions = [], uv = [], colors = [], indices = [];
  return {
    vertex(x, y, z, u, v, color = [1, 1, 1]) {
      const index = positions.length / 3;
      positions.push(x, y, z); uv.push(u, v); colors.push(...color);
      return index;
    },
    quad(a, b, c, d) { indices.push(a, b, c, a, c, d); },
    triangle(a, b, c) { indices.push(a, b, c); },
    finish() {
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
      geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
      geometry.setIndex(indices); geometry.computeVertexNormals();
      geometry.computeBoundingBox(); geometry.computeBoundingSphere();
      return geometry;
    },
  };
}

function grassClumpGeometry() {
  const build = geometryBuilder(), rng = random(31415);
  // Each curved sheet uses only the dense grass tuft island at the atlas bottom.
  for (let sheet = 0; sheet < 3; sheet++) {
    const angle = sheet / 3 * Math.PI + .2, dx = Math.cos(angle), dz = Math.sin(angle);
    const height = .37 + rng() * .12, halfWidth = .41 + rng() * .09;
    const rows = [];
    for (let segment = 0; segment <= 3; segment++) {
      const t = segment / 3, bow = Math.sin(t * Math.PI * .5) * .12;
      const shade = .83 + t * .17;
      rows.push([-1, 1].map(side => build.vertex(
        dx * halfWidth * side - dz * bow, height * t, dz * halfWidth * side + dx * bow,
        side < 0 ? .187 : .491, .902 - t * .157, [shade, shade, shade * .98],
      )));
    }
    for (let i = 1; i < rows.length; i++) build.quad(rows[i - 1][0], rows[i - 1][1], rows[i][1], rows[i][0]);
  }
  return build.finish();
}

function reedGeometry() {
  const build = geometryBuilder(), rng = random(92541);
  for (let blade = 0; blade < 14; blade++) {
    const angle = rng() * TAU, dx = Math.cos(angle), dz = Math.sin(angle);
    const radius = rng() * .16, length = .30 + rng() * .47, lean = .14 + rng() * .37;
    const halfWidth = .010 + rng() * .020, rows = [];
    for (let segment = 0; segment <= 3; segment++) {
      const t = segment / 3, spread = radius + lean * t * t;
      const width = halfWidth * (1 - t * .97), height = length * (t - t * t * .16);
      const dry = blade % 6 === 0;
      const color = dry ? [.34 + t * .23, .30 + t * .16, .17 + t * .10] : [.10 + t * .15, .17 + t * .19, .045 + t * .075];
      rows.push([-1, 1].map(side => build.vertex(dx * spread - dz * width * side, height, dz * spread + dx * width * side, (side + 1) / 2, t, color)));
    }
    for (let i = 1; i < rows.length; i++) build.quad(rows[i - 1][0], rows[i - 1][1], rows[i][1], rows[i][0]);
  }
  return build.finish();
}

function fernRosetteGeometry() {
  const build = geometryBuilder(), rng = random(80331);
  for (let leaf = 0; leaf < 7; leaf++) {
    const angle = leaf / 7 * TAU + rng() * .32, dx = Math.cos(angle), dz = Math.sin(angle);
    const length = .32 + rng() * .21, width = .10 + rng() * .04, rows = [];
    for (let segment = 0; segment <= 3; segment++) {
      const t = segment / 3, r = .025 + t * length;
      const height = Math.sin(t * Math.PI * .8) * (.14 + leaf % 3 * .028) + .015;
      const shade = .67 + t * .31;
      rows.push([-1, 1].map(side => build.vertex(dx * r - dz * width * side, height, dz * r + dx * width * side, (side + 1) / 2, t, [shade, shade, shade])));
    }
    for (let i = 1; i < rows.length; i++) build.quad(rows[i - 1][0], rows[i - 1][1], rows[i][1], rows[i][0]);
  }
  return build.finish();
}

function twistedRootGeometry() {
  const build = geometryBuilder(), rng = random(28021);
  for (let branch = 0; branch < 3; branch++) {
    const angle = branch * 1.4 + .3, dx = Math.cos(angle), dz = Math.sin(angle), rings = [];
    const length = .50 + rng() * .47;
    for (let segment = 0; segment <= 5; segment++) {
      const t = segment / 5, r = .044 * (1 - t * .82), bend = Math.sin(t * 4.3 + branch) * .12;
      const x = dx * length * t - dz * bend, z = dz * length * t + dx * bend;
      const y = .025 + Math.sin(t * Math.PI) * (.06 + branch * .016);
      rings.push(Array.from({length:5}, (_, side) => {
        const a = side / 5 * TAU;
        return build.vertex(x - dz * Math.cos(a) * r, y + Math.sin(a) * r, z + dx * Math.cos(a) * r, side / 5, t, [.77, .72, .60]);
      }));
    }
    for (let i = 1; i < rings.length; i++) for (let side = 0; side < 5; side++) {
      const next = (side + 1) % 5;
      build.quad(rings[i - 1][side], rings[i - 1][next], rings[i][next], rings[i][side]);
    }
    build.triangle(rings[0][0], rings[0][2], rings[0][1]);
    build.triangle(rings[0][0], rings[0][3], rings[0][2]);
    build.triangle(rings[0][0], rings[0][4], rings[0][3]);
    const tip = rings.at(-1);
    build.triangle(tip[0], tip[1], tip[2]); build.triangle(tip[0], tip[2], tip[3]); build.triangle(tip[0], tip[3], tip[4]);
  }
  return build.finish();
}

function windMaterial(material, clock, amplitude, maximumHeight) {
  material.onBeforeCompile = shader => {
    shader.uniforms.uForestDetailTime = clock;
    shader.vertexShader = 'uniform float uForestDetailTime;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `
      #include <begin_vertex>
      vec3 detailAnchor = vec3(0.0);
      #ifdef USE_INSTANCING
        detailAnchor = instanceMatrix[3].xyz;
      #endif
      float rootedHeight = clamp(position.y / ${maximumHeight.toFixed(3)}, 0.0, 1.0);
      float detailPhase = detailAnchor.x * .37 + detailAnchor.z * .21;
      float detailGust = .54 + .46 * sin(uForestDetailTime * .43 + detailPhase * .21);
      float detailBend = sin(uForestDetailTime * 1.24 + detailPhase) * detailGust;
      transformed.x += detailBend * rootedHeight * rootedHeight * ${amplitude.toFixed(3)};
      transformed.z += sin(uForestDetailTime * 1.03 + detailPhase * .78) * rootedHeight * rootedHeight * ${(amplitude * .43).toFixed(3)};
    `);
  };
  material.customProgramCacheKey = () => `forest-detail-wind-${amplitude}-${maximumHeight}`;
}

function stoneMaterial(rockMaps) {
  const material = new THREE.MeshStandardMaterial({...rockMaps, color:'#d9d5bc', roughness:1, normalScale:new THREE.Vector2(.75,.75)});
  material.onBeforeCompile = shader => {
    shader.vertexShader = 'varying vec3 vDetailStone;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvDetailStone = position;');
    shader.fragmentShader = 'varying vec3 vDetailStone;\n' + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', `
      #include <color_fragment>
      float stonePatch = .5 + .25 * sin(vDetailStone.x * 15.0 + sin(vDetailStone.z * 9.0) * 2.0) + .25 * sin(vDetailStone.z * 18.0 + vDetailStone.y * 13.0);
      float stoneGrain = .5 + .5 * sin(vDetailStone.x * 89.0 + sin(vDetailStone.z * 72.0) * 3.0);
      float upwardMoss = smoothstep(-.12, .60, vDetailStone.y);
      float moss = smoothstep(.43, .72, stonePatch) * upwardMoss;
      vec3 mossTint = mix(vec3(.30,.39,.13), vec3(.54,.58,.25), stoneGrain);
      diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * mossTint, moss * .79);
      float lichen = smoothstep(.81,.91,stonePatch) * smoothstep(.40,.70,stoneGrain);
      diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(1.14,1.17,.91), lichen * .62);
    `);
  };
  material.customProgramCacheKey = () => 'forest-detail-moss-stones-v1';
  return material;
}

/** Decorative natural detail. Shared maps remain owned by the caller. */
export function createForestDetails({group, heightAt, riverX, waterLevel = 2, foliage, rockMaps = {}}) {
  const details = new THREE.Group(); details.name = 'Natural riverbank ground detail'; group.add(details);
  const resources = [], clock = {value:0}, rng = random(940127), meshes = [];
  const own = value => { resources.push(value); return value; };
  const survivor = {x:riverX(-25) - 27,z:-25}, spawn = {x:-65,z:95};
  const dummy = new THREE.Object3D(), color = new THREE.Color(), up = new THREE.Vector3(0,1,0), normal = new THREE.Vector3();

  function safePoint(x, z, vegetation = true) {
    if(riverBankDistanceAt(x,z)<.35)return null;
    const h = heightAt(x,z);
    if (!Number.isFinite(h) || h < waterLevel + .18 || h > 50) return null;
    if (vegetation && (Math.hypot(x-survivor.x,z-survivor.z) < 2.8 || Math.hypot(x-spawn.x,z-spawn.z) < 2.8)) return null;
    if (Math.abs(z-30) < 13 && Math.abs(x-riverX(z)) < 27) return null;
    const slope = Math.hypot(heightAt(x+.35,z)-heightAt(x-.35,z),heightAt(x,z+.35)-heightAt(x,z-.35)) / .7;
    if (slope > .92) return null;
    return {x,z,h,slope};
  }

  const centers = [];
  for (let i=0;i<155;i++) {
    let x,z;
    if (i<100) {
      const angle=rng()*TAU,radius=3.5+Math.pow(rng(),.64)*34;
      x=survivor.x+Math.cos(angle)*radius;z=survivor.z+Math.sin(angle)*radius;
    } else {
      z=-112+rng()*179;x=riverX(z)+(i%2?1:-1)*(16+rng()*26);
    }
    const point=safePoint(x,z);
    if(point)centers.push({...point,radius:1.1+rng()*2.2});
  }

  function patchPoints(target, spread, vegetation = true) {
    const points=[];
    if(!centers.length)return points;
    for(let attempt=0;attempt<target*12&&points.length<target;attempt++) {
      const center=centers[attempt%centers.length],angle=rng()*TAU,radius=Math.sqrt(rng())*center.radius*spread;
      const point=safePoint(center.x+Math.cos(angle)*radius,center.z+Math.sin(angle)*radius,vegetation);
      if(point)points.push({...point,angle:rng()*TAU,scale:.58+rng()*.76});
    }
    return points;
  }

  function instances(name, geometry, material, points, place, casts = false) {
    if(!points.length)return null;
    const mesh=new THREE.InstancedMesh(geometry,material,points.length);mesh.name=name;
    points.forEach((point,i)=>{
      dummy.position.set(point.x,point.h-.014,point.z);dummy.rotation.set(0,point.angle,0);dummy.scale.setScalar(point.scale);
      place(point,i);
      dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
      mesh.setColorAt(i,color);
    });
    mesh.instanceMatrix.needsUpdate=true;
    if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
    mesh.receiveShadow=true;mesh.castShadow=casts;
    mesh.computeBoundingBox();mesh.computeBoundingSphere();
    details.add(mesh);meshes.push(mesh);return mesh;
  }

  const grassMaterial=own(new THREE.MeshStandardMaterial({...foliage.grass,color:'#ffffff',vertexColors:true,side:THREE.DoubleSide,alphaTest:.25,roughness:1,normalScale:new THREE.Vector2(.18,.18),alphaToCoverage:true,emissive:'#627a36',emissiveIntensity:.30}));
  windMaterial(grassMaterial,clock,.045,.55);
  const grass=instances('Clustered photographic ground grass',own(grassClumpGeometry()),grassMaterial,patchPoints(1400,1),point=>{
    dummy.scale.set(point.scale*1.02,point.scale*.91,point.scale*1.02);
    const tint=.97+rng()*.11;color.setRGB(tint,tint,tint*(.94+rng()*.05));
  });

  const reeds=[];
  for(let attempt=0;attempt<1800&&reeds.length<180;attempt++) {
    const z=-102+rng()*154,side=attempt%3===0?1:-1,x=riverX(z)+side*(14+rng()*7.5);
    const point=safePoint(x,z);
    if(point&&point.h<waterLevel+4.8)reeds.push({...point,angle:rng()*TAU,scale:.69+rng()*.42});
  }
  const reedMaterial=own(new THREE.MeshStandardMaterial({color:'#e1e4bf',vertexColors:true,roughness:.87,side:THREE.DoubleSide,emissive:'#26321b',emissiveIntensity:.035}));
  windMaterial(reedMaterial,clock,.075,.78);
  instances('Curved sedge and reeds along the bank',own(reedGeometry()),reedMaterial,reeds,point=>{
    dummy.scale.set(point.scale,point.scale,point.scale);color.setRGB(.86+rng()*.13,.88+rng()*.12,.82+rng()*.13);
  });

  const fernMaps={};
  for(const [key,texture] of Object.entries(foliage.fern)) {
    const copy=own(texture.clone());copy.flipY=true;copy.repeat.set(.278,.874);copy.offset.set(.005,.028);fernMaps[key]=copy;
  }
  const fernMaterial=own(new THREE.MeshStandardMaterial({...fernMaps,color:'#fafbed',vertexColors:true,side:THREE.DoubleSide,alphaTest:.33,roughness:1,normalScale:new THREE.Vector2(.45,.45),alphaToCoverage:true,emissive:'#263919',emissiveIntensity:.045}));
  windMaterial(fernMaterial,clock,.025,.24);
  instances('Low spreading fern rosettes',own(fernRosetteGeometry()),fernMaterial,patchPoints(110,.72),point=>{
    dummy.scale.setScalar(point.scale*1.25);const tint=.84+rng()*.17;color.setRGB(tint,tint,tint*.96);
  });

  const pebbleGeometry=own(new THREE.IcosahedronGeometry(1,1)), vertices=pebbleGeometry.attributes.position;
  for(let i=0;i<vertices.count;i++) {
    const x=vertices.getX(i),y=vertices.getY(i),z=vertices.getZ(i),r=.90+Math.sin(x*11+z*7)*Math.cos(y*13+z*5)*.13;
    vertices.setXYZ(i,x*r,y*r,z*r);
  }
  pebbleGeometry.computeVertexNormals();
  instances('Moss and lichen on low bank stones',pebbleGeometry,own(stoneMaterial(rockMaps)),patchPoints(250,1.23,false),point=>{
    const radius=.14+rng()*.28;
    dummy.position.y=point.h+.023;
    normal.set(-(heightAt(point.x+.3,point.z)-heightAt(point.x-.3,point.z))/.6,1,-(heightAt(point.x,point.z+.3)-heightAt(point.x,point.z-.3))/.6).normalize();
    dummy.quaternion.setFromUnitVectors(up,normal);dummy.rotateY(point.angle);
    dummy.scale.set(radius,.045+rng()*.054,radius*(.72+rng()*.58));
    const tint=.74+rng()*.31;color.setRGB(tint,tint,tint*(.90+rng()*.08));
  },true);

  const rootMaps={};
  for(const [key,texture] of Object.entries(foliage.bark)) {
    const copy=own(texture.clone());copy.repeat.set(.65,1.9);rootMaps[key]=copy;
  }
  const rootMaterial=own(new THREE.MeshStandardMaterial({...rootMaps,color:'#afa386',vertexColors:true,roughness:1,normalScale:new THREE.Vector2(.58,.58)}));
  instances('Weathered twisted roots and broken twigs',own(twistedRootGeometry()),rootMaterial,patchPoints(65,1.03,false),point=>{
    normal.set(-(heightAt(point.x+.3,point.z)-heightAt(point.x-.3,point.z))/.6,1,-(heightAt(point.x,point.z+.3)-heightAt(point.x,point.z-.3))/.6).normalize();
    dummy.quaternion.setFromUnitVectors(up,normal);dummy.rotateY(point.angle);
    dummy.scale.set(point.scale*.88,.66+rng()*.33,point.scale*.88);
    const tint=.76+rng()*.21;color.setRGB(tint,tint*.97,tint*.91);
  },true);

  details.userData.detailBatches=meshes.length;
  details.userData.detailTriangles=meshes.reduce((sum,mesh)=>sum+(mesh.geometry.index?mesh.geometry.index.count:mesh.geometry.attributes.position.count)/3*mesh.count,0);
  let disposed=false;
  return {
    update(time,cameraPosition) {
      if(disposed)return;
      if(Number.isFinite(time))clock.value=time;
      // Alpha detail fades below the visual threshold at long range without changing nearby plants.
      if(grass&&cameraPosition&&Number.isFinite(cameraPosition.x)&&Number.isFinite(cameraPosition.z)) {
        const distance=Math.hypot(cameraPosition.x-survivor.x,cameraPosition.z-survivor.z);
        grassMaterial.alphaTest=.25+clamp((distance-110)/140,0,1)*.09;
      }
    },
    dispose() {
      if(disposed)return;disposed=true;
      group.remove(details);
      for(const mesh of meshes)mesh.dispose();
      for(const resource of resources)resource.dispose();
    },
  };
}
