// Locally synthesized sound. Only activation/the sound preference can unlock Web Audio.
import {createSanctuaryMusic} from './sanctuary-music.js';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const MAX_VOICES=36;
const isCrashVoice=kind=>/^(engine-|airframe-|metal-|river-impact-|fuselage-impact-|falling-debris$)/.test(kind);

export function createSoundscape({enabled=false,volume=.35,onUnavailable=()=>{}}={}) {
  enabled=!!enabled;volume=clamp(finite(volume,.35));
  let context,master,analyser,meterData,ambientBus,effectBus,limiter,noise,engineBus,enginePan,sanctuaryMusic;
  let windLeft,windRight,leafAir,rain,engineBody,engineSecond,engineProp,engineAir;
  let active=false,available=true,disposed=false,stormAmount=0,simulationTime=0;
  let planeWanted=false,engineFailure=0,airframeStress=0,engineCut=false,planeState=null;
  let treeScanTime=0,rustleTime=.8,creakTime=3.5,strainTime=1.5,stallTime=.7;
  let nearbyTrees=[],listener={x:0,y:1.7,z:0,yaw:0},biome='valley',voiceId=0,seed=903227,lastImpactAt=-Infinity,lastEvent=null,swimSide=1;
  const loops=[],infrastructure=[],voices=new Map(),actors=new Map(),crashEvents=new Set();
  const counters={treeRustles:0,treeCreaks:0,creatureTicks:0,creatureScratches:0,creatureBites:0,engineFailures:0,airframeStrains:0,waterContacts:0,impacts:0,metalTears:0,debris:0,footsteps:0,swimStrokes:0,swimEntries:0,tripFalls:0,tripStrikes:0,devourGrabs:0,devourSwallows:0,thunder:0};
  const random=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};
  const own=node=>{infrastructure.push(node);return node;};
  const visible=()=>typeof document==='undefined'||!document.hidden;
  const audible=()=>enabled&&active&&visible()&&!disposed&&available&&context?.state==='running';
  function record(kind,detail={}){counters[kind]++;lastEvent={kind,time:simulationTime,...detail};}
  function target(param,value,seconds=.13){if(context&&param)param.setTargetAtTime(value,context.currentTime,seconds);}
  function makeNoise(){
    const count=Math.ceil(context.sampleRate*6),white=context.createBuffer(1,count,context.sampleRate),pink=context.createBuffer(1,count,context.sampleRate),brown=context.createBuffer(1,count,context.sampleRate);
    const w=white.getChannelData(0),p=pink.getChannelData(0),b=brown.getChannelData(0);
    let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0,low=0;
    for(let i=0;i<count;i++){
      const sample=random()*2-1;w[i]=sample;
      b0=.99886*b0+sample*.0555179;b1=.99332*b1+sample*.0750759;b2=.969*b2+sample*.153852;
      b3=.8665*b3+sample*.3104856;b4=.55*b4+sample*.5329522;b5=-.7616*b5-sample*.016898;
      p[i]=clamp((b0+b1+b2+b3+b4+b5+b6+sample*.5362)*.11,-1,1);b6=sample*.115926;
      low=(low+sample*.024)/1.024;b[i]=low*3.3;
    }return{white,pink,brown};
  }
  function noiseLoop(buffer,type,frequency,pan,destination){
    const source=own(context.createBufferSource()),filter=own(context.createBiquadFilter()),gain=own(context.createGain()),panner=own(context.createStereoPanner());
    source.buffer=noise[buffer];source.loop=true;filter.type=type;filter.frequency.value=frequency;filter.Q.value=.55;gain.gain.value=0;panner.pan.value=pan;
    source.connect(filter).connect(gain).connect(panner).connect(destination);source.start(0,random()*4);loops.push(source);return{source,filter,gain,panner};
  }
  function oscillatorLoop(frequency,harmonics,destination){
    const source=own(context.createOscillator()),filter=own(context.createBiquadFilter()),gain=own(context.createGain());
    source.setPeriodicWave(context.createPeriodicWave(new Float32Array(harmonics.length),new Float32Array(harmonics)));source.frequency.value=frequency;
    filter.type='lowpass';filter.frequency.value=420;filter.Q.value=.55;gain.gain.value=0;
    source.connect(filter).connect(gain).connect(destination);source.start();loops.push(source);return{source,filter,gain};
  }
  function init(){
    if(context||!enabled||!active||!visible()||disposed||!available)return;
    try{
      const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)throw new Error('Web Audio unavailable');
      context=new Audio();noise=makeNoise();ambientBus=own(context.createGain());effectBus=own(context.createGain());limiter=own(context.createDynamicsCompressor());
      limiter.threshold.value=-9;limiter.knee.value=12;limiter.ratio.value=4;limiter.attack.value=.005;limiter.release.value=.22;
      master=own(context.createGain());master.gain.value=0;analyser=own(context.createAnalyser());analyser.fftSize=1024;meterData=new Float32Array(analyser.fftSize);
      ambientBus.connect(limiter);effectBus.connect(limiter);limiter.connect(master).connect(analyser).connect(context.destination);
      sanctuaryMusic=createSanctuaryMusic(context,ambientBus);
      windLeft=noiseLoop('pink','lowpass',650,-.62,ambientBus);windRight=noiseLoop('brown','lowpass',380,.58,ambientBus);
      leafAir=noiseLoop('pink','bandpass',2300,.13,ambientBus);rain=noiseLoop('white','highpass',1450,-.07,ambientBus);
      engineBus=own(context.createGain());engineBus.gain.value=0;enginePan=own(context.createStereoPanner());engineBus.connect(enginePan).connect(effectBus);
      engineBody=oscillatorLoop(53,[0,1,.46,.28,.14,.095,.052,.031],engineBus);engineSecond=oscillatorLoop(54.4,[0,1,.25,.18,.095,.08,.042],engineBus);
      engineProp=oscillatorLoop(28,[0,1,.15,.28,.06,.12],engineBus);engineAir=noiseLoop('pink','bandpass',690,0,engineBus);
      windLeft.gain.gain.value=.11;windRight.gain.gain.value=.15;leafAir.gain.gain.value=.025;rain.gain.gain.value=stormAmount*.20;
      updatePlane(0);
    }catch{
      available=false;enabled=false;sanctuaryMusic?.dispose();for(const source of loops){try{source.stop();}catch{}}
      for(const node of infrastructure){try{node.disconnect();}catch{}}context?.close().catch(()=>{});onUnavailable();
    }
  }
  function stopVoice(voice){
    if(!voice||voice.ended)return;voice.ended=true;voices.delete(voice.id);
    for(const source of voice.sources){source.onended=null;try{source.stop();}catch{}}
    for(const node of voice.nodes){try{node.disconnect();}catch{}}
  }
  function envelope(kind,{gain=.1,duration=.2,attack=.004,delay=0,pan=0,priority=0}={}){
    if(!audible()||gain<.00015)return null;
    if(voices.size>=MAX_VOICES){const candidate=[...voices.values()].find(v=>v.priority<priority);if(!candidate)return null;stopVoice(candidate);}
    duration=clamp(finite(duration,.2),.015,7);delay=clamp(finite(delay),0,4);
    const at=context.currentTime+.003+delay,end=at+duration,output=context.createGain(),panner=context.createStereoPanner();panner.pan.value=clamp(finite(pan),-1,1);
    output.gain.setValueAtTime(.00001,at);output.gain.linearRampToValueAtTime(clamp(gain,.00001,1.7),at+Math.min(attack,duration*.25));
    output.gain.exponentialRampToValueAtTime(.00001,end);output.connect(panner).connect(effectBus);
    const voice={id:++voiceId,kind,priority,at,end,output,nodes:[output,panner],sources:[],ended:false};voices.set(voice.id,voice);return voice;
  }
  function startVoice(voice,sources,nodes=[]){
    if(!voice)return false;voice.sources.push(...sources);voice.nodes.push(...sources,...nodes);let ended=0;
    for(const source of sources){source.onended=()=>{if(++ended===sources.length)stopVoice(voice);};source.start(voice.at,...(source.buffer?[random()*3.7]:[]));source.stop(voice.end+.025);}return true;
  }
  function noiseVoice(kind,{buffer='pink',frequency=1200,endFrequency=frequency,filterType='bandpass',q=.65,rate=1,...options}={}){
    const voice=envelope(kind,options);if(!voice)return false;
    const source=context.createBufferSource(),filter=context.createBiquadFilter();source.buffer=noise[buffer];source.loop=true;source.playbackRate.value=rate;
    filter.type=filterType;filter.Q.value=q;filter.frequency.setValueAtTime(clamp(frequency,20,16000),voice.at);
    filter.frequency.exponentialRampToValueAtTime(clamp(endFrequency,20,16000),voice.end);source.connect(filter).connect(voice.output);return startVoice(voice,[source],[filter]);
  }
  function toneVoice(kind,{frequencies=[180],endRatio=.72,type='sine',wobble=.025,...options}={}){
    const voice=envelope(kind,options);if(!voice)return false;const sources=[],weights=[];
    for(let index=0;index<Math.min(5,frequencies.length);index++){
      const source=context.createOscillator(),weight=context.createGain(),f=clamp(frequencies[index],22,12000),curve=new Float32Array(32);source.type=type;weight.gain.value=1/Math.pow(index+1,1.15);
      for(let i=0;i<curve.length;i++){const t=i/(curve.length-1);curve[i]=f*(1+(endRatio-1)*t)*(1+Math.sin(t*29+index)*wobble);}
      source.frequency.setValueCurveAtTime(curve,voice.at,voice.end-voice.at);source.connect(weight).connect(voice.output);sources.push(source);weights.push(weight);
    }return startVoice(voice,sources,weights);
  }
  function space(position,range=38,reference=9){
    if(!position||!Number.isFinite(position.x)||!Number.isFinite(position.z))return{gain:1,pan:0,distance:0};
    const dx=position.x-listener.x,dz=position.z-listener.z,dy=finite(position.y,listener.y)-listener.y,distance=Math.hypot(dx,dy,dz),horizontal=Math.max(.01,Math.hypot(dx,dz));
    return{distance,pan:clamp((dx*Math.cos(listener.yaw)-dz*Math.sin(listener.yaw))/horizontal,-1,1)*.90,gain:Math.pow(clamp(1-distance/range),.65)/(1+Math.pow(distance/reference,1.7))};
  }
  function crashSpace(options={}){
    const spatial=space(options.position,200,38);
    if(Number.isFinite(options.distance)){const d=Math.max(0,options.distance);spatial.gain=Math.pow(clamp(1-d/240),.55)/(1+Math.pow(d/42,1.6));}return spatial;
  }
  function activate(value){
    if(disposed)return;active=!!value;
    if(active&&enabled&&visible()){init();if(available&&context){
      context.resume().then(()=>{
        if((!active||!enabled||!visible()||disposed)&&context.state!=='closed'){
          master.gain.cancelScheduledValues(context.currentTime);master.gain.setValueAtTime(0,context.currentTime);context.suspend().catch(()=>{});
        }
      }).catch(()=>{});target(master.gain,volume,.045);
    }}
    else{sanctuaryMusic?.pause(true);if(master){master.gain.cancelScheduledValues(context.currentTime);master.gain.setValueAtTime(0,context.currentTime);}
      for(const voice of[...voices.values()])stopVoice(voice);actors.clear();
      // Queue suspension even while a previous resume() promise is still pending.
      if(context&&context.state!=='closed')context.suspend().catch(()=>{});
    }
  }
  function treeRustle(tree){
    const spatial=space(tree.position,48,13),strength=(.65+stormAmount*.8)*spatial.gain*(biome==='glow'?.42:1);
    if(noiseVoice('tree-rustle',{buffer:'pink',gain:.23*strength,duration:1.1+random()*1.6,attack:.16,frequency:1450+random()*1100,endFrequency:720,pan:spatial.pan})){
      noiseVoice('needle-rattle',{buffer:'white',gain:.047*strength,duration:.8+random()*.7,attack:.11,frequency:4300,endFrequency:1900,pan:spatial.pan,delay:.08});record('treeRustles',{distance:spatial.distance});
    }
  }
  function treeCreak(tree){
    const spatial=space(tree.position,42,11),strength=spatial.gain*(.60+stormAmount*.6)*(biome==='glow'?.38:1),duration=.85+random()*.9;
    if(toneVoice('branch-creak',{frequencies:[73+random()*25,143+random()*31,239],endRatio:.85+random()*.30,type:'triangle',wobble:.09,gain:.16*strength,duration,attack:.10,pan:spatial.pan})){
      noiseVoice('bark-strain',{buffer:'brown',frequency:390,endFrequency:170,q:1.5,gain:.13*strength,duration,attack:.06,pan:spatial.pan});record('treeCreaks',{distance:spatial.distance});
    }
  }
  function scanTrees(trees){
    const nearest=[];
    for(const tree of Array.isArray(trees)?trees:[]){
      if(!Number.isFinite(tree.x)||!Number.isFinite(tree.z))continue;const distance=Math.hypot(tree.x-listener.x,tree.z-listener.z);if(distance>43)continue;
      const height=finite(tree.height,16*finite(tree.scale,1)),ground=finite(tree.y,finite(tree.h,listener.y-1.65));
      nearest.push({position:{x:tree.x,y:ground+Math.min(7,height*.30),z:tree.z},distance});
    }nearest.sort((a,b)=>a.distance-b.distance);nearbyTrees=nearest.slice(0,5);
  }
  function updateCreatures(dt,list){
    const visible=new Set(),nearest=[];
    for(const actor of Array.isArray(list)?list:[]){if(!actor?.position)continue;const spatial=space(actor.position,40,8);if(spatial.distance<39&&spatial.gain>.008)nearest.push({actor,spatial});}
    nearest.sort((a,b)=>a.spatial.distance-b.spatial.distance);
    for(const{actor,spatial}of nearest.slice(0,4)){
      const id=String(actor.id??actor.treeId??'teethpeed'),stage=String(actor.stage||''),bark=/descend|climb/.test(stage);visible.add(id);let state=actors.get(id);
      if(!state){state={phase:random(),scratch:.08+random()*.2,last:{...actor.position},side:1};actors.set(id,state);}
      const measured=dt>0?Math.hypot(actor.position.x-state.last.x,finite(actor.position.y)-finite(state.last.y),actor.position.z-state.last.z)/dt:0;
      const speed=clamp(finite(actor.speed,measured),0,9);state.last={...actor.position};if(speed<.06)continue;
      state.phase+=dt*Math.min(24,(bark?5:7)+speed*(bark?3:4.5));
      for(let ticks=0;state.phase>=1&&ticks<2;ticks++){
        state.phase-=1;state.side*=-1;const pan=clamp(spatial.pan+state.side*.055,-1,1),gain=spatial.gain*(.060+random()*.060);
        if(noiseVoice('teethpeed-foot',{buffer:bark?'white':'pink',gain,duration:.023+random()*.038,attack:.0015,frequency:bark?3100+random()*1800:1500+random()*1200,endFrequency:bark?1500:850,q:bark?1.7:.85,pan}))record('creatureTicks',{actor:id,surface:bark?'bark':'ground'});
      }
      state.phase=Math.min(state.phase,1);state.scratch-=dt;
      if(state.scratch<=0){state.scratch=(bark?.25:.38)+random()*.32;
        if(noiseVoice('teethpeed-scrape',{buffer:bark?'pink':'brown',gain:spatial.gain*(bark?.17:.10),duration:bark?.19:.12,attack:.014,frequency:bark?1100+speed*80:730,endFrequency:bark?480:330,q:1.3,pan:spatial.pan}))record('creatureScratches',{actor:id,surface:bark?'bark':'ground'});
      }
    }for(const id of actors.keys())if(!visible.has(id))actors.delete(id);
  }
  function plane(value){
    planeWanted=!!value;
    if(planeWanted){engineFailure=0;airframeStress=0;engineCut=false;crashEvents.clear();stallTime=.6;strainTime=1.3;lastImpactAt=-Infinity;updatePlane(0);}
    else{
      planeState=null;if(engineBus)target(engineBus.gain,0,.07);
      for(const voice of[...voices.values()])if(isCrashVoice(voice.kind))stopVoice(voice);
    }
  }
  function metalStrain(strength=1,pan=0){
    if(toneVoice('airframe-groan',{frequencies:[178,337,569],endRatio:.63,type:'triangle',wobble:.075,gain:.12*strength,duration:1.2,attack:.06,pan,priority:1})){
      noiseVoice('metal-grind',{buffer:'white',frequency:1700,endFrequency:540,q:1.8,gain:.10*strength,duration:.9,attack:.025,pan,priority:1});record('airframeStrains');
    }
  }
  function waterContact(options={}){
    const spatial=crashSpace(options),gain=spatial.gain;
    if(noiseVoice('river-impact-roar',{buffer:'pink',filterType:'lowpass',frequency:2900,endFrequency:550,gain:.64*gain,duration:3.3,attack:.15,pan:spatial.pan,priority:2})){
      noiseVoice('river-impact-hiss',{buffer:'white',filterType:'highpass',frequency:1400,endFrequency:2300,gain:.19*gain,duration:1.45,attack:.10,pan:clamp(spatial.pan-.23,-1,1),delay:.07,priority:2});record('waterContacts');
    }
  }
  function impact(options={}){
    engineCut=true;planeWanted=false;if(engineBus)target(engineBus.gain,0,.028);
    if(!audible()||context.currentTime-lastImpactAt<.45)return;lastImpactAt=context.currentTime;const spatial=crashSpace(options),gain=spatial.gain;
    toneVoice('fuselage-impact-sub',{frequencies:[82,131],endRatio:.30,gain:.74*gain,duration:2.4,attack:.003,pan:spatial.pan,priority:3});
    noiseVoice('fuselage-impact-thud',{buffer:'brown',filterType:'lowpass',frequency:650,endFrequency:120,gain:1.2*gain,duration:.75,attack:.002,pan:spatial.pan,priority:3});
    noiseVoice('metal-tear',{buffer:'white',frequency:3400,endFrequency:390,q:1.1,gain:.65*gain,duration:1.7,attack:.006,pan:clamp(spatial.pan+.10,-1,1),priority:3});
    toneVoice('metal-resonance',{frequencies:[193,347,619,1053],endRatio:.74,type:'triangle',wobble:.042,gain:.28*gain,duration:2.25,attack:.003,pan:spatial.pan,priority:3});
    if(!crashEvents.has('water-contact'))waterContact(options);
    for(let i=0;i<7;i++){
      const pan=clamp(spatial.pan+(random()-.5)*1.2,-1,1),delay=.07+i*.17+random()*.13;
      if(noiseVoice('falling-debris',{buffer:'white',frequency:2300+random()*3000,endFrequency:650+random()*800,q:2,gain:gain*(.16-i*.012),duration:.07+random()*.18,attack:.001,pan,delay,priority:2}))counters.debris++;
    }record('metalTears');record('impacts',{distance:finite(options.distance)});
  }
  function crashEvent(type,options={}){
    if(typeof type!=='string'||crashEvents.has(type))return;crashEvents.add(type);const spatial=crashSpace(options);
    if(type==='engine-failure'){
      engineFailure=1;if(audible()){
        for(let i=0;i<5;i++)noiseVoice('engine-misfire',{buffer:'brown',filterType:'lowpass',frequency:530,endFrequency:115,gain:spatial.gain*(.13+random()*.12),duration:.07+random()*.08,attack:.001,delay:i*.105,pan:spatial.pan,priority:2});
        toneVoice('engine-stall',{frequencies:[128,241],endRatio:.34,type:'triangle',gain:.16*spatial.gain,duration:1.15,attack:.025,pan:spatial.pan,priority:2});record('engineFailures');
      }
    }else if(type==='airframe-stress'){airframeStress=1;metalStrain(spatial.gain*1.25,spatial.pan);}
    else if(type==='water-contact')waterContact(options);
    else if(type==='impact')impact(options);
    else if(type==='settled'){planeWanted=false;engineCut=true;if(engineBus)target(engineBus.gain,0,.10);}
  }
  function creatureEvent(type,position){
    if(type!=='bite'||!audible())return;const spatial=space(position,30,7);
    if(noiseVoice('teethpeed-jaw-clack',{buffer:'white',frequency:2700,endFrequency:1100,q:1.1,gain:.29*spatial.gain,duration:.11,attack:.001,pan:spatial.pan,priority:2})){
      toneVoice('teethpeed-jaw-knock',{frequencies:[450,937],endRatio:.69,gain:.11*spatial.gain,duration:.09,attack:.001,pan:spatial.pan,priority:2});record('creatureBites');
    }
  }
  function burrowEvent(type,position){
    if(type==='bite'){creatureEvent('bite',position);return;}
    if(!['emerge','burrow'].includes(type)||!audible())return;
    const spatial=space(position,35,8),emerging=type==='emerge';
    noiseVoice('burrowpeed-soil-rumble',{buffer:'brown',filterType:'lowpass',frequency:emerging?430:290,endFrequency:75,gain:(emerging?.38:.23)*spatial.gain,duration:emerging?.8:1.05,attack:emerging?.009:.09,pan:spatial.pan,priority:2});
    noiseVoice('burrowpeed-earth-scrape',{buffer:'pink',filterType:'bandpass',frequency:emerging?2300:1600,endFrequency:460,q:.7,gain:.20*spatial.gain,duration:emerging?.65:.9,attack:.025,pan:spatial.pan,priority:2});
    if(emerging)toneVoice('burrowpeed-mandible-snap',{frequencies:[360,810],endRatio:.58,gain:.12*spatial.gain,duration:.14,attack:.004,pan:spatial.pan,priority:2});
  }
  function swim({entering=false,fast=false}={}){
    if(!audible())return false;
    entering=!!entering;fast=!!fast;
    if(!entering)swimSide*=-1;
    const pan=entering?0:swimSide*.18,duration=entering?.76:fast?.34:.44,gain=entering?.21:fast?.12:.095;
    if(!noiseVoice(entering?'swim-entry-slosh':'swim-paddle',{
      buffer:'pink',filterType:'lowpass',frequency:entering?1550:1150+random()*180,endFrequency:entering?300:380,
      gain,duration,attack:entering?.026:.045,pan,priority:1
    }))return false;
    noiseVoice(entering?'swim-entry-splash':'swim-water-drips',{
      buffer:'white',filterType:'bandpass',frequency:entering?2700:2100,endFrequency:entering?850:900,q:.58,
      gain:entering?.045:fast?.029:.022,duration:entering?.45:.24,attack:.025,delay:entering?.04:.075,pan:-pan*.7,priority:1
    });
    if(entering)noiseVoice('swim-entry-body',{
      buffer:'brown',filterType:'lowpass',frequency:330,endFrequency:100,gain:.08,duration:.62,attack:.04,pan:0,priority:1
    });
    record(entering?'swimEntries':'swimStrokes',{fast});return true;
  }
  function updatePlane(dt){
    if(!engineBus)return;const spatial=crashSpace(planeState||{}),amount=planeWanted&&!engineCut?spatial.gain:0;target(engineBus.gain,amount,.14);target(enginePan.pan,spatial.pan,.18);
    const time=finite(planeState?.time,simulationTime),stress=Math.max(airframeStress,clamp(finite(planeState?.stress))),speed=Math.max(0,finite(planeState?.speed,42));
    const rpm=51+Math.min(15,speed*.15)-engineFailure*(12+Math.sin(time*5.3)*6),sputter=1-engineFailure*(.18+.16*Math.sin(time*19)*Math.sin(time*7.1)),propPulse=.86+Math.sin(time*17.7)*.14;
    target(engineBody.source.frequency,rpm+Math.sin(time*.9)*1.5,.055);target(engineSecond.source.frequency,rpm*1.023+Math.sin(time*1.35),.065);target(engineProp.source.frequency,rpm*.51,.09);
    target(engineBody.gain.gain,.13*sputter,.035);target(engineSecond.gain.gain,.068*sputter,.035);target(engineProp.gain.gain,.065*propPulse,.035);
    target(engineBody.filter.frequency,320+stress*240,.2);target(engineSecond.filter.frequency,230+stress*380,.2);
    target(engineAir.gain.gain,.043+stress*.058+engineFailure*.018,.12);target(engineAir.filter.frequency,530+speed*9+stress*480,.15);
    if(amount<.008)return;stallTime-=dt;strainTime-=dt;
    if(engineFailure&&stallTime<=0){stallTime=.42+random()*.66;noiseVoice('engine-sputter',{buffer:'brown',filterType:'lowpass',frequency:430,endFrequency:100,gain:.13*amount,duration:.075,attack:.001,pan:spatial.pan,priority:1});}
    if(stress>.2&&strainTime<=0){strainTime=1.4+random()*1.5;metalStrain(amount*stress,spatial.pan);}
  }
  function update(dt,state={}){
    if(disposed)return;dt=clamp(finite(dt),0,.25);
    if(state.listener)listener={x:finite(state.listener.x),y:finite(state.listener.y,1.7),z:finite(state.listener.z),yaw:finite(state.listener.yaw)};
    if(['forest','valley','storm','cave','lava','ice','beach','ocean','glow'].includes(state.biome))biome=state.biome;
    sanctuaryMusic?.update({inSanctuary:biome==='glow',active:audible(),enabled,hidden:!visible()});
    if('plane'in state){planeState=state.plane&&typeof state.plane==='object'?{...state.plane}:null;if(!planeState||planeState.done||planeState.active===false)planeWanted=false;else if(!engineCut)planeWanted=true;}
    if(!audible())return;simulationTime+=dt;const gust=.65+Math.sin(simulationTime*.34)*.20+Math.sin(simulationTime*.83+1.9)*.15;
    const sanctuaryWind=biome==='glow'?.40:1;
    target(windLeft.gain.gain,(.11+stormAmount*.19)*gust*sanctuaryWind,.3);target(windRight.gain.gain,(.15+stormAmount*.24)*(.83+Math.sin(simulationTime*.27+1.2)*.17)*sanctuaryWind,.3);
    target(windLeft.filter.frequency,470+gust*350+stormAmount*620,.4);target(windRight.filter.frequency,260+stormAmount*500,.4);
    target(leafAir.gain.gain,(biome==='forest'?.045:biome==='glow'?.008:.025)*gust*(1-stormAmount*.3),.3);target(rain.gain.gain,stormAmount*.20,.3);
    treeScanTime-=dt;if(treeScanTime<=0){treeScanTime=.5;scanTrees(state.trees);}
    rustleTime-=dt;creakTime-=dt;
    if(nearbyTrees.length&&rustleTime<=0){treeRustle(nearbyTrees[Math.floor(random()*Math.min(3,nearbyTrees.length))]);rustleTime=.75+random()*1.5-stormAmount*.3;}
    if(nearbyTrees.length&&creakTime<=0){treeCreak(nearbyTrees[Math.floor(random()*Math.min(3,nearbyTrees.length))]);creakTime=3.6+random()*5.8-stormAmount*1.8;}
    updateCreatures(dt,state.teethpeeds);updatePlane(dt);
  }
  function getState(){
    let rms=0,peak=0;if(audible()&&analyser){analyser.getFloatTimeDomainData(meterData);for(const value of meterData){rms+=value*value;peak=Math.max(peak,Math.abs(value));}rms=Math.sqrt(rms/meterData.length);}
    const voiceKinds=[],voiceCounts={};let crashVoices=0;for(const voice of voices.values()){voiceKinds.push(voice.kind);voiceCounts[voice.kind]=(voiceCounts[voice.kind]||0)+1;if(isCrashVoice(voice.kind))crashVoices++;}
    return{enabled,active,available,initialized:!!context,contextState:context?.state||'uninitialized',audible:!!audible(),volume,rms,peak,levelDb:20*Math.log10(Math.max(.000001,rms)),
      activeVoices:voices.size,voiceKinds,voiceCounts,crashVoices,maxVoices:MAX_VOICES,loopVoices:loops.length,nearbyTrees:nearbyTrees.length,trackedCreatures:actors.size,planeActive:planeWanted&&!engineCut,planeStage:planeState?.stage||null,biome,music:sanctuaryMusic?.getDiagnostics()||{state:'uninitialized',voices:0,timers:0},counters:{...counters},lastEvent:lastEvent?{...lastEvent}:null};
  }
  return{
    activate,update,plane,impact,crashEvent,creatureEvent,burrowEvent,swim,getState,
    tripEvent(type,kind){
      if(!audible())return;
      if(type==='trip')noiseVoice('trip-foot-scuff',{buffer:'pink',filterType:'bandpass',frequency:1700,endFrequency:410,gain:.21,duration:.55,attack:.02,priority:2});
      if(type==='ground-impact'){
        if(noiseVoice('trip-body-thud',{buffer:'brown',filterType:'lowpass',frequency:380,endFrequency:90,gain:.43,duration:.45,attack:.004,priority:2}))record('tripFalls');
        noiseVoice('trip-clothing-scrape',{buffer:'pink',filterType:'bandpass',frequency:1200,endFrequency:550,gain:.12,duration:.68,attack:.03,priority:2});
      }
      if(type==='strike'){
        const flying=kind==='deatheater';
        if(noiseVoice(flying?'trip-wing-strike':'trip-jaw-strike',{buffer:flying?'pink':'white',filterType:'lowpass',frequency:flying?850:2200,endFrequency:180,gain:.40,duration:flying?.62:.24,attack:.003,priority:2}))record('tripStrikes');
        toneVoice('trip-final-impact',{frequencies:flying?[92,181]:[173,417],endRatio:.42,gain:.17,duration:.4,attack:.004,priority:2});
      }
    },
    devourEvent(type){
      if(!audible())return;
      if(type==='grab'){
        if(noiseVoice('deatheater-mouth-grab',{buffer:'pink',filterType:'bandpass',frequency:950,endFrequency:210,gain:.24,duration:.62,attack:.018,priority:2}))record('devourGrabs');
        noiseVoice('deatheater-capture-wingbeat',{buffer:'brown',filterType:'lowpass',frequency:410,endFrequency:140,gain:.18,duration:.8,attack:.055,priority:2});
      }
      if(type==='swallow'){
        if(toneVoice('deatheater-swallow',{frequencies:[86,143,218],endRatio:.38,gain:.22,duration:.75,attack:.065,priority:2}))record('devourSwallows');
        noiseVoice('deatheater-gulp',{buffer:'brown',filterType:'bandpass',frequency:630,endFrequency:130,q:1.4,gain:.26,duration:.65,attack:.04,priority:2});
      }
    },
    setEnabled(value){enabled=!!value;activate(active);},
    storm(value){stormAmount=clamp(finite(value));if(rain){target(rain.gain.gain,stormAmount*.20,.3);target(windLeft.filter.frequency,650+stormAmount*620,.4);target(windRight.filter.frequency,380+stormAmount*500,.4);}},
    thunder(strength=1){
      strength=clamp(finite(strength,1),0,1.5);
      if(noiseVoice('thunder-roll',{buffer:'brown',filterType:'lowpass',frequency:270,endFrequency:70,gain:.95*strength,duration:4.1,attack:.035,pan:(random()-.5)*.9,priority:2})){
        noiseVoice('thunder-crack',{buffer:'pink',filterType:'lowpass',frequency:1200,endFrequency:170,gain:.26*strength,duration:.7,attack:.002,priority:2});record('thunder');
      }
    },
    step(surface){
      const water=surface==='water',rock=surface==='rock';
      if(noiseVoice('footstep',{buffer:water?'pink':'brown',filterType:'lowpass',frequency:water?2200:rock?1250:850,endFrequency:water?800:270,gain:water?.17:.13,duration:water?.26:.13,attack:.003,pan:(random()-.5)*.18}))record('footsteps');
    },
    dispose(){
      if(disposed)return;activate(false);disposed=true;sanctuaryMusic?.dispose();
      for(const source of loops){try{source.stop();}catch{}}for(const node of infrastructure){try{node.disconnect();}catch{}}
      context?.close().catch(()=>{});loops.length=infrastructure.length=0;nearbyTrees=[];actors.clear();noise=null;
    },
  };
}

