import * as THREE from './vendor/three.module.js';
import {embeddedTreeHeight} from './terrain-surface.js';
import {createTreeInstanceRegistry} from './tree-instances.js';
import {createJungleBarkMaterial,decorateJungleBarkMaterial} from './jungle-bark.js';
import {riverBankDistanceAt} from './river-network.js';
import {createForestFlowers} from './woodland-flowers.js';

const TAU = Math.PI * 2;
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const mix = (a, b, t) => a + (b - a) * t;
function random(seed) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let n = Math.imul(seed ^ seed >>> 15, 1 | seed); n = n + Math.imul(n ^ n >>> 7, 61 | n) ^ n; return ((n ^ n >>> 14) >>> 0) / 4294967296; };
}
const clearings = [[-112,-35,4],[-65,95,5],[-32.5,-25,8],[-148,-175,6],[94,-75,6]];
const clearAt = (x,z,extra=0) => clearings.every(([cx,cz,r]) => Math.hypot(x-cx,z-cz)>r+extra);

function buildGeometry() {
  const positions=[],uvs=[],colors=[],indices=[],flutter=[],vineDrop=[],swayRoots=[],swayEnabled=[];
  let currentSwayRoot=0,currentSwayEnabled=0;
  const vector = value => value instanceof THREE.Vector3 ? value : new THREE.Vector3(...value);
  function vertex(point,uv,color,leafFlex=0,drop=0) {const i=positions.length/3;point.toArray(positions,positions.length);uvs.push(...uv);color.toArray(colors,colors.length);flutter.push(leafFlex);vineDrop.push(drop);swayRoots.push(currentSwayRoot);swayEnabled.push(currentSwayEnabled);return i;}
  function triangle(a,b,c) {indices.push(a,b,c);}
  function tube(points,radii,sides,color,drops=null) {
    const start=positions.length/3,circumference=TAU*radii[0]/2;
    let distance=0;
    for(let j=0;j<points.length;j++) {
      const p=vector(points[j]),before=vector(points[Math.max(0,j-1)]),after=vector(points[Math.min(points.length-1,j+1)]);
      if(j>0)distance+=p.distanceTo(before);
      const direction=after.clone().sub(before).normalize(),rotation=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),direction);
      for(let i=0;i<=sides;i++) {
        const a=i/sides*TAU;
        const offset=new THREE.Vector3(Math.cos(a)*radii[j],0,Math.sin(a)*radii[j]).applyQuaternion(rotation);
        vertex(p.clone().add(offset),[i/sides*circumference,distance/2],color,0,drops?.[j]||0);
        if(j<points.length-1&&i<sides) {const n=start+j*(sides+1)+i;triangle(n,n+sides+1,n+1);triangle(n+1,n+sides+1,n+sides+2);}
      }
    }
  }
  // The center of the first row is the visible petiole, exactly on its twig.
  // This conservative strip encloses the generated leaf's alpha silhouette.
  function leaf(stem,length,width,angle,tilt,color,drop=0) {
    const c=vector(stem),forward=new THREE.Vector3(Math.cos(angle),Math.sin(tilt),Math.sin(angle)).normalize();
    const side=new THREE.Vector3(-Math.sin(angle),0,Math.cos(angle));
    const rows=[[0,.484,.516],[.07,.442,.588],[.17,.34,.668],[.30,.294,.721],[.45,.262,.742],[.61,.275,.738],[.77,.343,.675],[.9,.43,.575],[1,.486,.533]],start=positions.length/3;
    rows.forEach(([t,left,right],row)=>{
      for(const u of [left,.5,right]){
        const cross=(u-.5)/.47,p=c.clone().addScaledVector(forward,t*length).addScaledVector(side,cross*width);
        p.y+=Math.sin(t*Math.PI)*length*(.075-Math.abs(cross)*.15)-Math.pow(t,4)*length*.055;
        vertex(p,[u,.016+t*.974],color,t*t,drop);
      }
      if(row>0)for(let column=0;column<2;column++){const n=start+(row-1)*3+column;triangle(n,n+1,n+3);triangle(n+1,n+4,n+3);}
    });
  }
  return {tube,leaf,vertex,triangle,sway(rootY){currentSwayRoot=rootY;currentSwayEnabled=1;},finish(){
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.setAttribute('forestFlutter',new THREE.Float32BufferAttribute(flutter,1));geometry.setAttribute('forestVineDrop',new THREE.Float32BufferAttribute(vineDrop,1));geometry.setAttribute('forestSwayRoot',new THREE.Float32BufferAttribute(swayRoots,1));geometry.setAttribute('forestSwayEnabled',new THREE.Float32BufferAttribute(swayEnabled,1));geometry.setIndex(indices);geometry.computeVertexNormals();geometry.computeBoundingSphere();return geometry;
  }};
}

function pointOnPolyline(points,progress) {
  const p=clamp(progress)*(points.length-1),segment=Math.min(points.length-2,Math.floor(p));
  const a=points[segment] instanceof THREE.Vector3?points[segment]:new THREE.Vector3(...points[segment]);
  const b=points[segment+1] instanceof THREE.Vector3?points[segment+1]:new THREE.Vector3(...points[segment+1]);
  return a.clone().lerp(b,p-segment);
}

export function giantGeometry(variant,{leafCount=400,vineCount=13}={}) {
  const wood=buildGeometry(),leaves=buildGeometry(),rng=random(7712+variant*839),supports=[],mainBranches=[],attachments={forks:[],leaves:[],vines:[]};
  const bark=new THREE.Color('#ded5c3'),darkBark=new THREE.Color('#bcb7a2');
  const trunkPoints=[],trunkRadii=[];
  for(let i=0;i<=10;i++) {
    const t=i/10;trunkPoints.push([Math.sin(t*2.6+variant)*t*.55,t*42,Math.sin(t*3.9)*t*.46]);
    trunkRadii.push(mix(1,.055,Math.pow(t,.76))*(1+Math.sin(i*1.7)*.035));
  }
  wood.tube(trunkPoints,trunkRadii,10,bark);
  // Broad fluted roots join the trunk in tall, irregular fins; no sawn surfaces.
  for(let i=0;i<6;i++) {
    const a=i/6*TAU+variant*.24,tip=2.25+(i%3)*.20,spread=.19;
    const point=(r,angle,y)=>new THREE.Vector3(Math.cos(angle)*r,y,Math.sin(angle)*r);
    const v=[wood.vertex(point(.70,a,4.4+(i%2)*1.5),[.7,(4.4+(i%2)*1.5)/2],bark),wood.vertex(point(.80,a-spread,.02),[0,0],darkBark),wood.vertex(point(tip,a-spread*.35,.01),[tip/2,0],darkBark),wood.vertex(point(tip,a+spread*.35,.01),[tip/2+.1,0],darkBark),wood.vertex(point(.80,a+spread,.02),[.12,0],darkBark)];
    for(let j=1;j<4;j++)wood.triangle(v[0],v[j+1],v[j]);
    wood.triangle(v[0],v[4],v[1]);
  }
  // Every parent link uses the actual polyline used to build the visible wood.
  for(let branch=0;branch<11;branch++) {
    const a=branch*2.399+variant*.73,start=17.5+branch*1.72;
    const reach=branch<8?5.0+rng()*4.2:3.2+rng()*2.1;
    const tipY=Math.min(40.1,start+4.2+rng()*3.5),tip=new THREE.Vector3(Math.cos(a)*reach,tipY,Math.sin(a)*reach);
    const origin=pointOnPolyline(trunkPoints,start/42);
    const primary=[origin,new THREE.Vector3(origin.x+Math.cos(a)*reach*.24,start+1.8,origin.z+Math.sin(a)*reach*.24),new THREE.Vector3(Math.cos(a)*reach*.61,tipY-1.0,Math.sin(a)*reach*.61),tip];
    primary.swayRoot=start;wood.sway(start);
    wood.tube(primary,[.32-branch*.014,.24,.13,.035],5,bark);
    mainBranches.push(primary);supports.push(primary);attachments.forks.push({point:origin.clone(),parent:trunkPoints,progress:start/42});
    for(const sign of [-1,1]) {
      const subA=a+sign*(.36+rng()*.36),subR=reach*(.80+rng()*.32);
      const subTip=new THREE.Vector3(Math.cos(subA)*subR,tipY-1+rng()*2,Math.sin(subA)*subR);
      const progress=.62+sign*.075,fork=pointOnPolyline(primary,progress),secondary=[fork,subTip];
      secondary.swayRoot=start;
      wood.tube(secondary,[.13,.015],3,bark);supports.push(secondary);attachments.forks.push({point:fork.clone(),parent:primary,progress});
    }
  }
  // Eight individually curved leaves grow from each supported tapering shoot.
  for(let cluster=0,leafIndex=0;leafIndex<leafCount;cluster++) {
    const parent=supports[cluster%supports.length],progress=.44+rng()*.48,origin=pointOnPolyline(parent,progress);
    const a=rng()*TAU,reach=1.35+rng()*1.7,tip=origin.clone().add(new THREE.Vector3(Math.cos(a)*reach,(rng()-.5)*1.1,Math.sin(a)*reach));tip.y=Math.min(40.8,tip.y);
    const twig=[origin,tip];twig.swayRoot=parent.swayRoot;wood.sway(parent.swayRoot);leaves.sway(parent.swayRoot);wood.tube(twig,[.037,.009],3,bark);attachments.forks.push({point:origin.clone(),parent,progress});
    const count=Math.min(8,leafCount-leafIndex);
    for(let leaf=0;leaf<count;leaf++,leafIndex++) {
      const t=(leaf+1)/count,stem=pointOnPolyline(twig,t),leafAngle=a+(leaf%2?1:-1)*(.64+rng()*.63);
      const color=new THREE.Color().setHSL(.20+rng()*.04,.09+rng()*.10,.61+rng()*.18);
      leaves.leaf(stem,1.1+rng()*.9,.70+rng()*.40,leafAngle,(rng()-.5)*.48,color);
      attachments.leaves.push({point:stem.clone(),parent:twig,progress:t});
    }
  }
  const vines=vineGeometry(mainBranches,variant,attachments,vineCount);
  return {wood:wood.finish(),leaves:leaves.finish(),vines,attachments};
}

function vineGeometry(branches,variant,attachments,vineCount=13) {
  const geometry=buildGeometry(),leaves=buildGeometry(),rng=random(831991+variant*701),color=new THREE.Color('#9b9d79');
  for(let vine=0;vine<vineCount;vine++) {
    const parent=branches[(vine*3+2)%branches.length],progress=.60+rng()*.28,anchor=pointOnPolyline(parent,progress),length=Math.min(anchor.y-3,10+rng()*14);
    geometry.sway(parent.swayRoot);
    leaves.sway(parent.swayRoot);
    const points=[],radii=[],drops=[];attachments.vines.push({point:anchor.clone(),parent,progress});
    for(let j=0;j<8;j++) {
      const t=j/7;points.push([anchor.x+(Math.sin(t*6+vine)-Math.sin(vine))*.25,anchor.y-t*length,anchor.z+(Math.cos(t*5+vine)-Math.cos(vine))*.32]);radii.push(.055*(1-t*.62));drops.push(t);
    }
    geometry.tube(points,radii,3,color,drops);
    for(let j=0;j<4;j++) {
      const node=j+2,t=node/7,stem=new THREE.Vector3(...points[node]);leaves.leaf(stem,.65,.40,vine*2.399+j*2.4,-.4,new THREE.Color('#d3d9bb'),t);attachments.leaves.push({point:stem.clone(),parent:points,progress:t});
    }
  }
  return {wood:geometry.finish(),leaves:leaves.finish()};
}

function frondGeometry() {
  const positions=[],uvs=[],indices=[],flutter=[];
  for(let frond=0;frond<7;frond++) {
    const a=frond/7*TAU,length=.9+(frond%3)*.24,start=positions.length/3;
    for(let j=0;j<3;j++) {
      const t=j/2,r=t*length,y=Math.sin(t*Math.PI*.8)*length*.61;
      for(const side of [-1,1]){positions.push(Math.cos(a)*r-Math.sin(a)*side*.22*length,y,Math.sin(a)*r+Math.cos(a)*side*.22*length);uvs.push(side<0?0:1,t);flutter.push(t*t*.6);}
      if(j<2){const n=start+j*2;indices.push(n,n+1,n+2,n+1,n+3,n+2);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setAttribute('forestFlutter',new THREE.Float32BufferAttribute(flutter,1));geometry.setAttribute('forestVineDrop',new THREE.Float32BufferAttribute(new Float32Array(positions.length/3),1));geometry.setAttribute('forestSwayRoot',new THREE.Float32BufferAttribute(new Float32Array(positions.length/3),1));geometry.setAttribute('forestSwayEnabled',new THREE.Float32BufferAttribute(new Float32Array(positions.length/3),1));geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}

export function wind(material,time,{leaves=false}={}) {
  material.onBeforeCompile=shader=>{
    shader.uniforms.uRainforestTime=time;
    shader.vertexShader='uniform float uRainforestTime;attribute float forestFlutter;attribute float forestVineDrop;attribute float forestSwayRoot;attribute float forestSwayEnabled;\n'+shader.vertexShader;
    if(leaves){shader.vertexShader='varying vec2 vLeafUv;\n'+shader.vertexShader;shader.fragmentShader='varying vec2 vLeafUv;\n'+shader.fragmentShader;}
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
      vec3 forestAnchor=vec3(0.0);
      #ifdef USE_INSTANCING
        forestAnchor=instanceMatrix[3].xyz;
      #endif
      float forestPhase=forestAnchor.x*.025+forestAnchor.z*.018;
      float forestGust=sin(uRainforestTime*.49+forestPhase)+.35*sin(uRainforestTime*.91+forestPhase*.8);
      // A fork and every descendant share their main bough's linear shear.
      // It agrees at interpolated attachment points, not just at mesh vertices.
      // Trunk/root vertices have sway disabled, preserving the crawling profile.
      float forestBend=(position.y-forestSwayRoot)*forestSwayEnabled;
      transformed.x+=forestGust*.008*forestBend;
      transformed.z+=cos(uRainforestTime*.40+forestPhase)*.0037*forestBend;
      // Flutter is exactly zero at a leaf stem; liana sway is zero at its top.
      transformed.y+=sin(uRainforestTime*1.7+position.x*.7+position.z*.9+forestPhase)*.055*forestFlutter;
      transformed.x+=sin(uRainforestTime*.75+forestPhase)*.22*forestVineDrop*forestVineDrop;
      transformed.z+=cos(uRainforestTime*.61+forestPhase)*.11*forestVineDrop*forestVineDrop;
      ${leaves?'vLeafUv=uv;':''}
    `);
    if(leaves)shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
      // The texture supplies the veins; warmer undersides soften the canopy.
      if(!gl_FrontFacing)diffuseColor.rgb*=vec3(1.10,1.14,.92);
    `).replace('#include <lights_fragment_end>',`#include <lights_fragment_end>
      reflectedLight.indirectDiffuse+=diffuseColor.rgb*.055;
    `);
  };
  material.customProgramCacheKey=()=>`rainforest-textured-leaf-wind-v4-${leaves}`;
}

/** Giant-tree coordinates are stable for save data and tree-climbing creatures. */
export function createRainforest({group,heightAt,placementHeightAt=heightAt,forestBlendAt,foliage,rockMaps}) {
  const root=new THREE.Group();root.name='Rainforest: giant trees, vines and fern floor';group.add(root);
  const resources=[],own=value=>{resources.push(value);return value;},time={value:0},rng=random(901853),trees=[],colliders=[],registry=createTreeInstanceRegistry();
  const slopeAt=(x,z)=>Math.hypot(placementHeightAt(x+1,z)-placementHeightAt(x-1,z),placementHeightAt(x,z+1)-placementHeightAt(x,z-1))/2;
  for(let attempt=0;attempt<18000&&trees.length<145;attempt++) {
    const x=-353+rng()*320,z=-257+rng()*461,h=placementHeightAt(x,z),radius=1.1+rng()*1.1;
    if(forestBlendAt(x,z)<.48||h<4||slopeAt(x,z)>.9||!clearAt(x,z,radius*2.6))continue;
    const spacing=10+rng()*6;
    if(trees.some(tree=>Math.hypot(tree.x-x,tree.z-z)<Math.max(spacing,tree.spacing)))continue;
    const tree={id:`rainforest-${String(trees.length).padStart(3,'0')}`,x,z,h:embeddedTreeHeight(x,z,radius*2.65),height:32+rng()*26,radius,angle:rng()*TAU,spacing,kind:'rainforest',variant:trees.length%2,felled:false};tree.y=tree.h;
    trees.push(tree);colliders.push({x,z,radius,height:tree.height,treeId:tree.id});
    // Buttress roots remain solid at ground level without inflating the trunk
    // radius exposed to climbing creatures.
    for(let i=0;i<6;i++){const a=i/6*TAU+(trees.length-1)%2*.24-tree.angle;colliders.push({x:x+Math.cos(a)*radius*1.43,z:z+Math.sin(a)*radius*1.43,radius:radius*.48,height:2.5,treeId:tree.id});}
  }
  // Keep the original tree IDs/random sequence when a new tributary removes a tree.
  const flooded=new Set(trees.filter(t=>riverBankDistanceAt(t.x,t.z)<t.radius*2.8).map(t=>t.id));
  for(let i=trees.length-1;i>=0;i--)if(flooded.has(trees[i].id))trees.splice(i,1);
  for(let i=colliders.length-1;i>=0;i--)if(flooded.has(colliders[i].treeId))colliders.splice(i,1);
  const barkMaps={};
  for(const key of ['map','normalMap','roughnessMap']){const texture=own(foliage.bark[key].clone());texture.repeat.set(1,1);texture.offset.set(0,0);texture.needsUpdate=true;barkMaps[key]=texture;}
  const barkMaterial=own(createJungleBarkMaterial({maps:barkMaps}));
  wind(barkMaterial,time);decorateJungleBarkMaterial(barkMaterial);
  const leafMaterial=own(new THREE.MeshStandardMaterial({map:foliage.broadleaf,bumpMap:foliage.broadleaf,bumpScale:.012,vertexColors:true,side:THREE.DoubleSide,alphaTest:.38,alphaToCoverage:true,roughness:.68}));wind(leafMaterial,time,{leaves:true});
  const vineMaterial=own(createJungleBarkMaterial({maps:barkMaps,normalStrength:1.1}));wind(vineMaterial,time);decorateJungleBarkMaterial(vineMaterial);
  const forestDepth=own(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking,side:THREE.DoubleSide}));wind(forestDepth,time);
  const leafDepth=own(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking,map:foliage.broadleaf,alphaTest:.38,side:THREE.DoubleSide}));wind(leafDepth,time);
  const dummy=new THREE.Object3D();let triangleCount=0,drawBatches=0;
  function instances(geometry,material,points,name,transform) {
    const mesh=own(new THREE.InstancedMesh(geometry,material,points.length));mesh.name=name;
    points.forEach((p,i)=>{transform(p,dummy);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);registry.register(p.id,mesh,i,dummy.matrix);});
    mesh.computeBoundingSphere();mesh.receiveShadow=true;root.add(mesh);triangleCount+=(geometry.index?geometry.index.count:geometry.attributes.position.count)/3*points.length;drawBatches++;return mesh;
  }
  const treeTransform=(p,object)=>{object.position.set(p.x,p.h-.08,p.z);object.rotation.set(0,p.angle,0);object.scale.set(p.radius,p.height/42,p.radius);};
  for(let variant=0;variant<2;variant++) {
    const geometry=giantGeometry(variant),points=trees.filter(p=>p.variant===variant);
    const trunks=instances(own(geometry.wood),barkMaterial,points,`Buttressed rainforest trunks ${variant+1}`,treeTransform);trunks.castShadow=true;trunks.customDepthMaterial=forestDepth;
    const crowns=instances(own(geometry.leaves),leafMaterial,points,`Layered broadleaf crowns ${variant+1}`,treeTransform);crowns.castShadow=true;
    crowns.customDepthMaterial=leafDepth;
    const lianas=instances(own(geometry.vines.wood),vineMaterial,points,`Branch-anchored lianas ${variant+1}`,treeTransform);lianas.castShadow=true;lianas.customDepthMaterial=forestDepth;
    const vineLeaves=instances(own(geometry.vines.leaves),leafMaterial,points,`Textured liana leaves ${variant+1}`,treeTransform);vineLeaves.castShadow=true;vineLeaves.customDepthMaterial=leafDepth;
  }
  const understory=[];
  for(let attempt=0;attempt<18000&&understory.length<2200;attempt++) {
    const x=-342+rng()*317,z=-249+rng()*450,h=heightAt(x,z);
    if(forestBlendAt(x,z)<.50||h<4||riverBankDistanceAt(x,z)<1||slopeAt(x,z)>.92||!clearAt(x,z,.8)||trees.some(tree=>Math.hypot(x-tree.x,z-tree.z)<tree.radius*1.65))continue;
    understory.push({x,z,h,angle:rng()*TAU,scale:1.35+rng()*1.85});
  }
  understory.sort((a,b)=>Math.hypot(a.x+112,a.z+35)-Math.hypot(b.x+112,b.z+35));
  const fernMaterial=own(new THREE.MeshStandardMaterial({...foliage.fern,color:'#c7dec1',side:THREE.DoubleSide,alphaTest:.12,roughness:.94,normalScale:new THREE.Vector2(.65,.65),emissive:'#395b2c',emissiveIntensity:.045}));
  const fernTransform=(p,object)=>{object.position.set(p.x,p.h+.025,p.z);object.rotation.set(0,p.angle,0);object.scale.set(p.scale,p.scale,p.scale);};
  for(let variant=0;variant<2;variant++)instances(foliage.fernGeometries[variant],fernMaterial,understory.slice(0,156).filter((p,i)=>i%2===variant),`Scanned rainforest ferns ${variant+1}`,fernTransform);
  const frondMaps={};
  for(const key of ['map','alphaMap','normalMap','roughnessMap']){const texture=own(foliage.fern[key].clone());texture.flipY=true;texture.repeat.set(.278,.874);texture.offset.set(.005,.028);texture.needsUpdate=true;frondMaps[key]=texture;}
  const frondMaterial=own(new THREE.MeshStandardMaterial({...frondMaps,color:'#b5d4ae',side:THREE.DoubleSide,alphaTest:.12,roughness:.96,normalScale:new THREE.Vector2(.55,.55),emissive:'#395b2c',emissiveIntensity:.035}));wind(frondMaterial,time);
  instances(own(frondGeometry()),frondMaterial,understory.slice(156),'Layered forest-floor fronds',fernTransform);
  const flowers=own(createForestFlowers({root,heightAt,blendAt:forestBlendAt,center:{x:-190,z:-25},spread:{x:170,z:245},count:2100,seed:72209}));
  root.userData.triangleCount=triangleCount;root.userData.drawBatches=drawBatches;
  return {trees,colliders,setTreeFelled(id,value){const changed=registry.setTreeFelled(id,value);if(changed)trees.find(tree=>tree.id===id).felled=!!value;return changed;},update(elapsed,camera){time.value=elapsed;flowers.update(elapsed,camera);root.visible=!camera||Math.hypot(camera.x+190,camera.z+25)<790;},dispose(){group.remove(root);for(const resource of resources)resource.dispose();}};
}
