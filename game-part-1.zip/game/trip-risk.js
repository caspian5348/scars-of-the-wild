export const TRIP_CHANCE = .1;

const MAX_RESOLVED = 50000;
const kinds = new Set(['teethpeed', 'deatheater']);
const finite = Number.isFinite;
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const validId = value => typeof value === 'string' && value.length > 0 && value.length <= 256
  && value.trim().length > 0 && !/[\u0000-\u001f\u007f]/.test(value);
const validSeed = value => typeof value === 'string' && value.length > 0 && value.length <= 512 && value.trim().length > 0;
const validPosition = value => plain(value) && [value.x, value.y, value.z].every(finite);

function validKey(key) {
  if (typeof key !== 'string') return false;
  const separator = key.indexOf(':');
  return separator > 0 && kinds.has(key.slice(0, separator)) && validId(key.slice(separator + 1));
}

/** Deterministic per-life/per-creature draw. This never consumes Math.random. */
export function tripRoll(seed, key) {
  const text = JSON.stringify([String(seed), String(key), 'fatal-trip']);
  let value = 2166136261;
  for (let i = 0; i < text.length; i++) value = Math.imul(value ^ text.charCodeAt(i), 16777619);
  value ^= value >>> 16; value = Math.imul(value, 0x7feb352d);
  value ^= value >>> 15; value = Math.imul(value, 0x846ca68b);
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}

export function passesTripChance(roll) {
  return finite(roll) && roll >= 0 && roll < TRIP_CHANCE;
}

/** Absent fields preserve old saves; malformed present fields are rejected. */
export function normalizeTripState(value) {
  if (value === undefined) return undefined;
  if (!plain(value) || value.version !== 1 || !validSeed(value.seed) || !Array.isArray(value.resolved)
    || value.resolved.length > MAX_RESOLVED || !value.resolved.every(validKey)) return null;
  return { version: 1, seed: value.seed, resolved: [...new Set(value.resolved)] };
}

/** The caller supplies real controller records; only active pursuit qualifies. */
export function getTripChasers({ teethpeeds = [], deatheaters = [], player } = {}) {
  const chasers = [];
  for (const record of Array.isArray(teethpeeds) ? teethpeeds : []) {
    if (record?.stage !== 'attacking' || record.senses?.lineOfSight !== true || !validId(record.treeId) || !validPosition(record.position)) continue;
    chasers.push({ kind: 'teethpeed', id: record.treeId, position: { ...record.position }, heading: finite(record.heading) ? record.heading : 0 });
  }
  for (const record of Array.isArray(deatheaters) ? deatheaters : []) {
    if (!['approaching', 'diving'].includes(record?.stage) || !validId(record.id) || !validPosition(record.position)) continue;
    chasers.push({ kind: 'deatheater', id: record.id, position: { ...record.position }, heading: finite(record.heading) ? record.heading : 0 });
  }
  const distance = chaser => player && finite(player.x) && finite(player.z)
    ? Math.hypot(chaser.position.x - player.x, chaser.position.z - player.z) : 0;
  chasers.sort((a, b) => distance(a) - distance(b) || `${a.kind}:${a.id}`.localeCompare(`${b.kind}:${b.id}`));
  return chasers;
}

/**
 * One draw per creature encounter, when the player first moves on the ground
 * while pursued. Pause, swimming, jumping and later reacquisition do not reroll.
 * Unresolved chasers are processed in caller order, stopping at the first fatal
 * result. A full ledger stops new draws rather than forgetting earlier ones.
 */
export function createTripRisk({ seed, state, onChange = () => {} } = {}) {
  const normalized = normalizeTripState(state);
  const requestedSeed = seed === undefined ? normalized?.seed ?? 'unseeded-journey' : String(seed);
  if (!validSeed(requestedSeed)) throw new TypeError('Trip risk requires a nonempty journey seed of at most 512 characters.');
  const runSeed = requestedSeed;
  const resolved = new Set(normalized?.seed === runSeed ? normalized.resolved : []);
  const snapshot = () => ({ version: 1, seed: runSeed, resolved: [...resolved] });
  return {
    update({ moving = false, grounded = false, swimming = false, chasers = [] } = {}) {
      if (!moving || !grounded || swimming || !Array.isArray(chasers)) return null;
      for (const chaser of chasers) {
        if (!plain(chaser) || !kinds.has(chaser.kind) || !validId(chaser.id)) continue;
        const key = `${chaser.kind}:${chaser.id}`;
        if (resolved.has(key)) continue;
        if (resolved.size >= MAX_RESOLVED) return null;
        const roll = tripRoll(runSeed, key), fatal = passesTripChance(roll);
        resolved.add(key);
        onChange(snapshot(), { key, roll, fatal });
        if (fatal) return { ...chaser, ...(plain(chaser.position) ? { position: { ...chaser.position } } : {}) };
      }
      return null;
    },
    snapshot,
  };
}
