import {ITEMS, RECIPES, BUILDINGS, GATHER_RESOURCES} from './survival-catalog.js';

export const SURVIVAL_VERSION = 1;
export const BASE_INVENTORY_SLOTS = 36;
export const BASE_CARRY_WEIGHT = 75;
export const HUNGER_DRAIN = .035;
export const THIRST_DRAIN = .05;
const MAX_COUNT = 10000, MAX_CLOCK = 1e10, MAX_UID = 1e12, MAX_REVISION = Number.MAX_SAFE_INTEGER;
const EQUIPMENT_SLOTS = ['hand', 'body', 'back'];
const clamp = (n, a = 0, b = 100) => Math.max(a, Math.min(b, n));
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const integer = (n, low, high) => Number.isSafeInteger(n) && n >= low && n <= high;
const finiteRange = (n, low, high) => Number.isFinite(n) && n >= low && n <= high;
const itemExists = id => typeof id === 'string' && Object.hasOwn(ITEMS, id);
const validBiome = id => typeof id === 'string' && /^[a-z][a-z0-9_-]{0,63}$/.test(id);
const ok = extra => ({ok: true, code: 'ok', message: '', ...extra});
const fail = (code, message, extra = {}) => ({ok: false, code, message, ...extra});
const freshState = () => ({version: 1, revision: 0, nextUid: 1, inventory: [], equipment: {hand: null, body: null, back: null},
  knownResources: [], discoveredBiomes: [], hunger: 100, thirst: 100, temperature: 0, elapsed: 0});
const clone = state => ({...state, inventory: state.inventory.map(slot => ({...slot})), equipment: {...state.equipment},
  knownResources: [...state.knownResources], discoveredBiomes: [...state.discoveredBiomes]});
const weightOf = state => state.inventory.reduce((sum, slot) => sum + ITEMS[slot.id].weight * slot.count, 0);
function capacityOf(state) {
  const pack = state.inventory.find(slot => slot.uid === state.equipment.back), definition = pack && ITEMS[pack.id];
  return {slots: BASE_INVENTORY_SLOTS + (definition?.extraSlots || 0), weight: BASE_CARRY_WEIGHT + (definition?.extraWeight || 0)};
}
function capacityError(state) {
  const capacity = capacityOf(state), weight = weightOf(state);
  if (state.inventory.length > capacity.slots) return fail('inventory_full', 'There are no free inventory slots.', {slots: state.inventory.length, capacity});
  if (weight > capacity.weight + 1e-7) return fail('too_heavy', 'These supplies exceed your carrying capacity.', {weight, capacity});
  return null;
}

/** Missing data belongs to a legacy journey; malformed present data is rejected. */
export function normalizeSurvivalState(value) {
  if (value === undefined) return freshState();
  if (!plain(value) || value.version !== 1 || !Array.isArray(value.inventory) || value.inventory.length > 60) return null;
  const state = freshState();
  state.revision = value.revision ?? 0;
  if (!integer(state.revision, 0, MAX_REVISION)) return null;
  for (const [key, low, high] of [['hunger', 0, 100], ['thirst', 0, 100], ['temperature', -100, 100], ['elapsed', 0, MAX_CLOCK]]) {
    const number = value[key] ?? state[key]; if (!finiteRange(number, low, high)) return null; state[key] = number;
  }
  const seen = new Set(); let highestUid = 0;
  for (const source of value.inventory) {
    if (!plain(source) || !itemExists(source.id) || typeof source.uid !== 'string' || !/^s[1-9]\d{0,11}$/.test(source.uid) || seen.has(source.uid)) return null;
    const definition = ITEMS[source.id], uidNumber = Number(source.uid.slice(1));
    if (!integer(uidNumber, 1, MAX_UID - 1) || !integer(source.count, 1, definition.stack)) return null;
    const slot = {uid: source.uid, id: source.id, count: source.count}; seen.add(slot.uid); highestUid = Math.max(highestUid, uidNumber);
    if (definition.durability) {
      slot.durability = source.durability ?? definition.durability;
      if (!finiteRange(slot.durability, 0, definition.durability)) return null;
    } else if (source.durability !== undefined) return null;
    if (definition.shelfLife > 0) {
      slot.expiresAt = source.expiresAt ?? state.elapsed + definition.shelfLife;
      if (!finiteRange(slot.expiresAt, 0, MAX_CLOCK + 20000)) return null;
    } else if (source.expiresAt !== undefined) return null;
    state.inventory.push(slot);
  }
  state.nextUid = value.nextUid ?? highestUid + 1;
  if (!integer(state.nextUid, highestUid + 1, MAX_UID)) return null;
  if (value.equipment !== undefined && !plain(value.equipment)) return null;
  for (const key of EQUIPMENT_SLOTS) {
    const uid = value.equipment?.[key] ?? null;
    if (uid !== null) {
      const slot = state.inventory.find(entry => entry.uid === uid);
      if (!slot || ITEMS[slot.id].slot !== key) return null;
    }
    state.equipment[key] = uid;
  }
  const resources = value.knownResources ?? [], biomes = value.discoveredBiomes ?? [];
  if (!Array.isArray(resources) || resources.length > Object.keys(ITEMS).length || resources.some(id => !itemExists(id))) return null;
  if (!Array.isArray(biomes) || biomes.length > 128 || biomes.some(id => !validBiome(id))) return null;
  state.knownResources = [...new Set([...resources, ...state.inventory.map(slot => slot.id)])];
  state.discoveredBiomes = [...new Set(biomes)];
  return capacityError(state) ? null : state;
}

const countIn = (state, id) => state.inventory.reduce((sum, slot) => sum + (slot.id === id ? slot.count : 0), 0);
function remember(state, id) {if (!state.knownResources.includes(id)) state.knownResources.push(id);}
function findSlot(state, idOrUid) {
  return state.inventory.find(slot => slot.uid === idOrUid) || state.inventory.find(slot => slot.id === idOrUid && (slot.durability === undefined || slot.durability > 0)) || state.inventory.find(slot => slot.id === idOrUid);
}
function equipped(state, equipmentSlot = 'hand') {return state.inventory.find(slot => slot.uid === state.equipment[equipmentSlot]) || null;}
function removeSlots(state, idOrUid, count) {
  const exact = state.inventory.find(slot => slot.uid === idOrUid), id = exact?.id || idOrUid;
  if (!itemExists(id) || (exact ? exact.count : countIn(state, id)) < count) return fail('missing_items', `You need ${count} ${ITEMS[id]?.name || id}.`, {id, count});
  let remaining = count;
  // Spend un-equipped supplies first and the oldest perishable stack first.
  const selected = (exact ? [exact] : state.inventory.filter(slot => slot.id === id)).sort((a, b) =>
    Number(Object.values(state.equipment).includes(a.uid)) - Number(Object.values(state.equipment).includes(b.uid)) || (a.expiresAt ?? Infinity) - (b.expiresAt ?? Infinity));
  for (const slot of selected) {
    const amount = Math.min(remaining, slot.count); slot.count -= amount; remaining -= amount;
    if (!slot.count) for (const key of EQUIPMENT_SLOTS) if (state.equipment[key] === slot.uid) state.equipment[key] = null;
    if (!remaining) break;
  }
  state.inventory = state.inventory.filter(slot => slot.count > 0); return ok({id, count});
}
function addSlots(state, id, count) {
  const definition = ITEMS[id], expiresAt = definition.shelfLife > 0 ? state.elapsed + definition.shelfLife : undefined;
  let remaining = count;
  if (definition.stack > 1) for (const slot of state.inventory) {
    if (slot.id !== id || slot.count >= definition.stack || slot.expiresAt !== undefined && slot.expiresAt <= state.elapsed) continue;
    const amount = Math.min(remaining, definition.stack - slot.count); slot.count += amount; remaining -= amount;
    if (expiresAt !== undefined) slot.expiresAt = Math.min(slot.expiresAt, expiresAt); // Fresh food cannot refresh an old stack.
    if (!remaining) break;
  }
  while (remaining > 0) {
    if (state.nextUid >= MAX_UID) return fail('inventory_limit', 'This journey has reached its inventory identifier limit.');
    const slot = {uid: `s${state.nextUid++}`, id, count: Math.min(remaining, definition.stack)};
    if (definition.durability) slot.durability = definition.durability;
    if (expiresAt !== undefined) slot.expiresAt = expiresAt;
    state.inventory.push(slot); remaining -= slot.count;
  }
  remember(state, id); return ok({id, count});
}
function transferStack(value, elapsed) {
  if (!plain(value) || !itemExists(value.id)) return null;
  const definition = ITEMS[value.id];
  if (!integer(value.count, 1, definition.stack)) return null;
  if (value.uid !== undefined && (typeof value.uid !== 'string' || value.uid.length < 1 || value.uid.length > 96 || /[\x00-\x1f]/.test(value.uid))) return null;
  const stack = {id: value.id, count: value.count};
  if (definition.durability) {
    if (!finiteRange(value.durability, 0, definition.durability)) return null;
    stack.durability = value.durability;
  } else if (value.durability !== undefined) return null;
  if (definition.shelfLife > 0) {
    if (!finiteRange(value.expiresAt, 0, MAX_CLOCK + 20000)) return null;
    if (value.expiresAt <= elapsed) stack.id = 'spoiled_food'; else stack.expiresAt = value.expiresAt;
  } else if (value.expiresAt !== undefined) return null;
  return stack;
}
function insertExact(state, stack) {
  const definition = ITEMS[stack.id], uids = []; let remaining = stack.count;
  if (definition.stack > 1) for (const slot of state.inventory) {
    if (slot.id !== stack.id || slot.count >= definition.stack || slot.expiresAt !== stack.expiresAt || slot.durability !== stack.durability) continue;
    const amount = Math.min(remaining, definition.stack - slot.count); slot.count += amount; remaining -= amount; uids.push(slot.uid);
    if (!remaining) break;
  }
  while (remaining > 0) {
    if (state.nextUid >= MAX_UID) return fail('inventory_limit', 'This journey has reached its inventory identifier limit.');
    const slot = {...stack, uid: `s${state.nextUid++}`, count: Math.min(remaining, definition.stack)};
    state.inventory.push(slot); remaining -= slot.count; uids.push(slot.uid);
  }
  remember(state, stack.id);
  return ok({id: stack.id, count: stack.count, uid: uids[0], uids, stack: {...stack, uid: uids[0]}});
}
function missingCost(state, cost) {
  return Object.entries(cost).filter(([id, amount]) => countIn(state, id) < amount).map(([id, amount]) => ({id, needed: amount, have: countIn(state, id)}));
}
function pay(state, cost) {
  const missing = missingCost(state, cost);
  if (missing.length) return fail('missing_items', 'You do not have all the required supplies.', {missing});
  for (const [id, amount] of Object.entries(cost)) removeSlots(state, id, amount);
  return ok();
}
function unlockError(state, definition) {
  const resources = (definition.unlock?.resources || []).filter(id => !state.knownResources.includes(id));
  const biomes = definition.unlock?.biomes || [];
  if (resources.length || biomes.length && !biomes.some(id => state.discoveredBiomes.includes(id))) return fail('undiscovered', 'Discover the required materials or environment first.', {resources, biomes});
  return null;
}
function normalizeStations(value) {
  const list = value instanceof Set ? [...value] : Array.isArray(value) ? value : value ? [value] : [];
  return new Set(list.filter(id => typeof id === 'string' && Object.values(BUILDINGS).some(building => building.providesStation === id)));
}
const aliases = {tree: 'wood', rock: 'stone', grass: 'fiber', bush: 'berries', water: 'dirty_water', copper: 'copper_ore', tin: 'tin_ore', iron: 'iron_ore'};
const creatureLoot = new Set(['raw_meat', 'raw_fish', 'hide', 'bone', 'feathers', 'chitin', 'venom', 'crystal_shard', 'ember_gland', 'fur', 'shell', 'sinew']);

/**
 * Mutations return {ok,code,message,...}; failures leave the entire state intact.
 * Stations describe currently nearby, player-built stations and are not saved.
 * Slot uids identify individual tools. equip/consume/remove/repair accept either
 * a uid or an item id. World placement/collider validation belongs to the caller.
 */
export function createSurvivalSystem({state: initialState, onChange = () => {}} = {}) {
  let state = normalizeSurvivalState(initialState), stations = new Set();
  if (!state) throw new TypeError('Invalid survival state');
  const snapshot = () => clone(state);
  function notify(meta) {
    try {onChange(snapshot(), meta);} catch { /* A failed observer cannot undo a committed inventory transaction. */ }
  }
  function transaction(type, operation, dryRun = false) {
    const draft = clone(state), result = operation(draft);
    if (!result.ok) return result;
    const capacity = capacityError(draft); if (capacity) return capacity;
    if (dryRun || result.changed === false) return result;
    draft.revision = Math.min(MAX_REVISION, state.revision + 1); state = draft; notify({type, ...result}); return result;
  }
  function stationError(definition, options = {}) {
    const available = options.stations === undefined ? stations : normalizeStations(options.stations);
    if (definition.station && !available.has(definition.station)) return fail('station_required', `You must be near a ${BUILDINGS[definition.station]?.name || definition.station}.`, {station: definition.station});
    return null;
  }
  function craftOperation(recipeId, options = {}, dryRun = false) {
    const definition = typeof recipeId === 'string' && Object.hasOwn(RECIPES, recipeId) ? RECIPES[recipeId] : null, batches = options.count ?? 1;
    if (!definition) return fail('unknown_recipe', 'That recipe does not exist.');
    if (!integer(batches, 1, 99)) return fail('invalid_count', 'Craft between 1 and 99 batches.');
    const locked = unlockError(state, definition) || stationError(definition, options); if (locked) return locked;
    const cost = Object.fromEntries(Object.entries(definition.cost).map(([id, amount]) => [id, amount * batches]));
    const outputs = Object.fromEntries(Object.entries(definition.outputs).map(([id, amount]) => [id, amount * batches]));
    return transaction('craft', draft => {
      const paid = pay(draft, cost); if (!paid.ok) return paid;
      for (const [id, amount] of Object.entries(outputs)) {const added = addSlots(draft, id, amount); if (!added.ok) return added;}
      return ok({recipeId, count: batches, cost, outputs});
    }, dryRun);
  }
  function buildingOperation(buildingId, options = {}, dryRun = false) {
    const definition = typeof buildingId === 'string' && Object.hasOwn(BUILDINGS, buildingId) ? BUILDINGS[buildingId] : null, amount = options.count ?? 1;
    if (!definition) return fail('unknown_building', 'That building does not exist.');
    if (!integer(amount, 1, 99)) return fail('invalid_count', 'Build between 1 and 99 pieces.');
    const locked = unlockError(state, definition) || stationError(definition, options); if (locked) return locked;
    if (definition.requiresFoundation && options.hasFoundation === false) return fail('foundation_required', 'This piece needs a supporting foundation.');
    const cost = Object.fromEntries(Object.entries(definition.cost).map(([id, quantity]) => [id, quantity * amount]));
    return transaction('build', draft => {const paid = pay(draft, cost); return paid.ok ? ok({buildingId, count: amount, cost}) : paid;}, dryRun);
  }
  function gatherOperation(kind, options = {}, dryRun = false) {
    const id = aliases[kind] || kind, quantity = options.count ?? 1;
    if (!itemExists(id) || !Object.hasOwn(GATHER_RESOURCES, id) && !creatureLoot.has(id)) return fail('not_gatherable', 'This item must be crafted or found as loot.');
    if (!integer(quantity, 1, 100)) return fail('invalid_count', 'Gather between 1 and 100 items.');
    const rule = id==='stone'&&options.mining===true?{tool:'pickaxe',tier:1,wear:2}:GATHER_RESOURCES[id] || {};
    return transaction('gather', draft => {
      const hand = equipped(draft), tool = hand && ITEMS[hand.id];
      if (rule.tool && (!hand || tool.tool !== rule.tool)) return fail('tool_required', `Equip a ${rule.tool} to gather ${ITEMS[id].name}.`, {tool: rule.tool, tier: rule.tier});
      if (rule.tool && hand.durability <= 0) return fail('broken_tool', 'Repair the equipped tool before gathering.');
      if (rule.tool && tool.tier < rule.tier) return fail('tool_tier', `This deposit needs a tier ${rule.tier} ${rule.tool}.`, {tool: rule.tool, tier: rule.tier});
      const cost = Object.fromEntries(Object.entries(rule.cost || {}).map(([item, amount]) => [item, amount * quantity]));
      const paid = pay(draft, cost); if (!paid.ok) return paid;
      const added = addSlots(draft, id, quantity); if (!added.ok) return added;
      let durability = null, broken = false;
      if (rule.tool) {hand.durability = Math.max(0, hand.durability - (rule.wear || 1)); durability = hand.durability; broken = durability === 0;}
      return ok({id, count: quantity, durability, broken, toolId: rule.tool ? hand.id : null});
    }, dryRun);
  }
  function hydrate(amount = 35, {unsafe = false} = {}) {
    if (!finiteRange(amount, 0, 100)) return fail('invalid_amount', 'Water amount must be between 0 and 100.');
    return transaction('drink', draft => {
      const thirstGain = Math.min(amount, 100 - draft.thirst); if (thirstGain <= 0) return ok({changed: false, thirstGain: 0, healthDelta: 0});
      draft.thirst += thirstGain; return ok({thirstGain, healthDelta: unsafe ? -2 : 0, unsafe: Boolean(unsafe)});
    });
  }
  function extractOperation(idOrUid, count = 1, dryRun = false) {
    if (!integer(count, 1, MAX_COUNT)) return fail('invalid_count', 'Transfer a positive whole number of items.');
    return transaction('extract', draft => {
      const source = findSlot(draft, idOrUid);
      if (!source || source.count < count) return fail('insufficient_stack', 'Choose one carried stack that contains the requested quantity.');
      const stack = {...source, count};
      if (count < source.count) {
        if (draft.nextUid >= MAX_UID) return fail('inventory_limit', 'This journey has reached its inventory identifier limit.');
        stack.uid = `s${draft.nextUid++}`;
      }
      const removed = removeSlots(draft, source.uid, count);
      return removed.ok ? ok({id: stack.id, count, stack}) : removed;
    }, dryRun);
  }
  function insertOperation(value, dryRun = false) {
    const stack = transferStack(value, state.elapsed);
    if (!stack) return fail('invalid_stack', 'Transferred supplies must include their original durability and food expiry.');
    return transaction('insert', draft => insertExact(draft, stack), dryRun);
  }
  function repairOperation(idOrUid = state.equipment.hand, options = {}, dryRun = false) {
    const target = findSlot(state, idOrUid), definition = target && ITEMS[target.id];
    if (!target || !definition.durability || !definition.repair) return fail('not_repairable', 'Select a repairable tool or garment.');
    if (target.durability >= definition.durability) return ok({changed: false, id: target.id, durability: target.durability, cost: {}});
    const station = definition.tier >= 4 ? 'anvil' : definition.tier >= 2 || definition.slot === 'body' ? 'workbench' : null;
    const missingStation = stationError({station}, options); if (missingStation) return missingStation;
    return transaction('repair', draft => {
      const slot = draft.inventory.find(entry => entry.uid === target.uid), paid = pay(draft, definition.repair); if (!paid.ok) return paid;
      slot.durability = definition.durability; return ok({id: slot.id, uid: slot.uid, durability: slot.durability, cost: {...definition.repair}});
    }, dryRun);
  }
  function step(dt, {moving = false, inCold = false, inHeat = false, nearFire = false, sheltered = false} = {}) {
    if (!Number.isFinite(dt) || dt < 0) return fail('invalid_time', 'Simulation time must be a finite non-negative number.');
    dt = Math.min(dt, 60);
    if (!dt) return ok({changed: false, healthDamage: 0, healthDelta: 0, hunger: state.hunger, thirst: state.thirst, temperature: state.temperature, spoiled: 0});
    const cold = typeof inCold === 'number' ? Number.isFinite(inCold) ? clamp(inCold, 0, 1) : 0 : inCold ? 1 : 0;
    const heat = typeof inHeat === 'number' ? Number.isFinite(inHeat) ? clamp(inHeat, 0, 1) : 0 : inHeat ? 1 : 0;
    const garment = equipped(state, 'body'), definition = garment && garment.durability > 0 ? ITEMS[garment.id] : null;
    const insulation = definition?.insulation || 0;
    const hungerRate = HUNGER_DRAIN * (moving ? 1.22 : 1) * (1 + cold * .35);
    const thirstRate = THIRST_DRAIN * (moving ? 1.25 : 1) * (1 + heat * 1.1);
    const hungryTime = Math.max(0, dt - state.hunger / hungerRate), dryTime = Math.max(0, dt - state.thirst / thirstRate);
    state.hunger = Math.max(0, state.hunger - hungerRate * dt); state.thirst = Math.max(0, state.thirst - thirstRate * dt);
    const exposure = sheltered ? .38 : 1, ambient = -cold * 100 * (1 - insulation) * exposure + heat * 100 * (1 + insulation * .2) * exposure;
    const target = clamp(nearFire ? Math.max(25, ambient) : ambient, -100, 100);
    const previousTemperature = state.temperature, alpha = 1 - Math.exp(-dt / 100);
    state.temperature += (target - state.temperature) * alpha;
    // Integrate the time beyond each threshold analytically; split frame rates
    // therefore cannot change the amount of cold/heat damage.
    const exposureTime = (threshold, above) => {
      const starts = above ? previousTemperature > threshold : previousTemperature < threshold, ends = above ? state.temperature > threshold : state.temperature < threshold;
      if (starts && ends) return dt; if (!starts && !ends) return 0;
      const crossing = -100 * Math.log((threshold - target) / (previousTemperature - target));
      return starts ? clamp(crossing, 0, dt) : dt - clamp(crossing, 0, dt);
    };
    const healthDamage = hungryTime * .8 + dryTime * 1.25 + exposureTime(-70, false) * .65 + exposureTime(75, true) * .55;
    const oldElapsed = state.elapsed; state.elapsed = Math.min(MAX_CLOCK, state.elapsed + dt);
    let spoiled = 0;
    for (const slot of state.inventory) if (slot.expiresAt !== undefined && slot.expiresAt <= state.elapsed) {
      spoiled += slot.count; slot.id = 'spoiled_food'; delete slot.expiresAt;
    }
    if (spoiled) remember(state, 'spoiled_food');
    state.revision = Math.min(MAX_REVISION, state.revision + 1);
    const result = ok({healthDamage, healthDelta: -healthDamage, hunger: state.hunger, thirst: state.thirst, temperature: state.temperature, elapsed: state.elapsed, spoiled});
    if (spoiled || Math.floor(oldElapsed / 10) !== Math.floor(state.elapsed / 10)) notify({type: 'step', ...result});
    return result;
  }
  return {
    snapshot,
    count: id => itemExists(id) ? countIn(state, id) : 0,
    getStats: () => ({hunger: state.hunger, thirst: state.thirst, temperature: state.temperature, elapsed: state.elapsed, revision: state.revision}),
    getCapacity: () => ({...capacityOf(state), usedSlots: state.inventory.length, usedWeight: weightOf(state)}),
    getEquipment: (slot = 'hand') => {const entry = equipped(state, slot); return entry ? {...entry, item: ITEMS[entry.id]} : null;},
    setStations(value) {stations = normalizeStations(value); return [...stations];},
    add(id, count = 1) {
      if (!itemExists(id)) return fail('unknown_item', 'That item does not exist.');
      if (!integer(count, 1, MAX_COUNT)) return fail('invalid_count', 'Item count must be a positive whole number.');
      return transaction('add', draft => addSlots(draft, id, count));
    },
    canAdd(id, count = 1) {
      if (!itemExists(id) || !integer(count, 1, MAX_COUNT)) return fail('invalid_item', 'Choose a valid item and positive count.');
      return transaction('add', draft => addSlots(draft, id, count), true);
    },
    extract: (id, count) => extractOperation(id, count), canExtract: (id, count) => extractOperation(id, count, true),
    insert: value => insertOperation(value), canInsert: value => insertOperation(value, true),
    remove(idOrUid, count = 1) {
      if (!integer(count, 1, MAX_COUNT)) return fail('invalid_count', 'Item count must be a positive whole number.');
      return transaction('remove', draft => removeSlots(draft, idOrUid, count));
    },
    equip(idOrUid, options = {}) {
      return transaction('equip', draft => {
        if (idOrUid === null) {
          const slot = options.slot || 'hand'; if (!EQUIPMENT_SLOTS.includes(slot)) return fail('invalid_slot', 'Unknown equipment slot.');
          const changed = draft.equipment[slot] !== null; draft.equipment[slot] = null; return ok({slot, uid: null, changed});
        }
        const entry = findSlot(draft, idOrUid), definition = entry && ITEMS[entry.id];
        if (!entry || !definition.slot) return fail('not_equippable', 'That carried item cannot be equipped.');
        const changed = draft.equipment[definition.slot] !== entry.uid; draft.equipment[definition.slot] = entry.uid;
        return ok({id: entry.id, uid: entry.uid, slot: definition.slot, changed, broken: entry.durability === 0});
      });
    },
    consume(idOrUid) {
      return transaction('consume', draft => {
        const entry = findSlot(draft, idOrUid), definition = entry && ITEMS[entry.id];
        if (!entry || !definition.nutrition) return fail('not_consumable', 'Choose food, water or medicine from your inventory.');
        if (entry.expiresAt !== undefined && entry.expiresAt <= draft.elapsed) return fail('food_spoiled', 'That food has spoiled.');
        const nutrition = definition.nutrition, id = entry.id, removed = removeSlots(draft, entry.uid, 1); if (!removed.ok) return removed;
        for (const [returned, count] of Object.entries(definition.returns || {})) {const added = addSlots(draft, returned, count); if (!added.ok) return added;}
        const hungerGain = clamp(draft.hunger + (nutrition.hunger || 0)) - draft.hunger, thirstGain = clamp(draft.thirst + (nutrition.thirst || 0)) - draft.thirst;
        draft.hunger += hungerGain; draft.thirst += thirstGain; draft.temperature = clamp(draft.temperature + (definition.warmth || 0), -100, 100);
        return ok({id, count: 1, hungerGain, thirstGain, healthDelta: nutrition.healthDelta || 0});
      });
    },
    hydrate, drink: hydrate,
    discoverBiome(id) {
      if (!validBiome(id)) return fail('invalid_biome', 'Unknown environment identifier.');
      return transaction('discover', draft => {if (draft.discoveredBiomes.includes(id)) return ok({changed: false, biome: id});
        if (draft.discoveredBiomes.length >= 128) return fail('discovery_limit', 'This journey has reached its environment limit.');
        draft.discoveredBiomes.push(id); return ok({biome: id});});
    },
    learnResource(id) {
      if (!itemExists(id)) return fail('unknown_item', 'That item does not exist.');
      return transaction('learn', draft => {const changed = !draft.knownResources.includes(id); remember(draft, id); return ok({id, changed});});
    },
    isUnlocked(id) {const definition = typeof id === 'string' && (Object.hasOwn(RECIPES, id) ? RECIPES[id] : Object.hasOwn(BUILDINGS, id) ? BUILDINGS[id] : null); return Boolean(definition && !unlockError(state, definition));},
    canCraft: (id, options) => craftOperation(id, options, true), craft: (id, options) => craftOperation(id, options),
    canBuild: (id, options) => buildingOperation(id, options, true), consumeBuilding: (id, options) => buildingOperation(id, options),
    canGather: (id, options) => gatherOperation(id, options, true), gather: (id, options) => gatherOperation(id, options),
    canRepair: (id, options) => repairOperation(id, options, true), repair: (id, options) => repairOperation(id, options),
    damageEquipment(amount = 1, slot = 'hand') {
      if (!finiteRange(amount, 0, 10000) || !EQUIPMENT_SLOTS.includes(slot)) return fail('invalid_wear', 'Equipment wear must be a finite non-negative number.');
      return transaction('equipment_wear', draft => {
        const target = equipped(draft, slot); if (!target || target.durability === undefined) return fail('not_equipped', 'No durable equipment is equipped in that slot.');
        const before = target.durability; target.durability = Math.max(0, before - amount);
        return ok({id: target.id, uid: target.uid, durability: target.durability, broken: target.durability === 0, changed: target.durability !== before});
      });
    },
    useEquipment({ammoId} = {}) {
      return transaction('attack', draft => {
        const hand = equipped(draft), definition = hand && ITEMS[hand.id];
        if (!hand || !definition.tool) return ok({changed: false, damage: 5, reach: 1.55, attackSeconds: .65, tool: 'hand', healthDelta: 0});
        if (hand.durability <= 0) return fail('broken_tool', 'Repair the equipped tool before using it.');
        let ammunition = null;
        if (definition.tool === 'bow') {
          const candidates = ammoId ? [ammoId] : ['arrow', 'iron_arrow', 'venom_arrow', 'fire_arrow'];
          ammunition = candidates.find(id => ITEMS[id]?.kind === 'ammo' && countIn(draft, id) > 0);
          if (!ammunition) return fail('missing_ammo', 'You need arrows to fire this bow.');
          removeSlots(draft, ammunition, 1);
        }
        hand.durability = Math.max(0, hand.durability - 1);
        return ok({id: hand.id, tool: definition.tool, tier: definition.tier, damage: definition.damage + (ITEMS[ammunition]?.damage || 0), reach: definition.reach,
          attackSeconds: definition.attackSeconds, ammoId: ammunition, durability: hand.durability, broken: hand.durability === 0});
      });
    },
    step,
  };
}
