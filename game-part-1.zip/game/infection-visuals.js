import * as THREE from './vendor/three.module.js';
import {isGlowSafeAt,lavaAt} from './biomes.js';
import {riverBankDistanceAt} from './river-network.js';
import {WORLD_SIZE,TERRAIN_STEP,TERRAIN_SEGMENTS,terrainVertex} from './terrain-surface.js';

export const INFECTION_DETAIL_LIMIT=24;
const MAX_NODES=128;

function randomFor(text){let s=2166136261;for(const c of text)s=Math.imul(s^c.charCodeAt(0),16777619);return()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};}
function spikeGeometry(curve){
  const vertices=[],indices=[],rings=16,sides=9;
  for(let ring=0;ring<=rings;ring++){
    const t=ring/rings,y=t*2.7,shaft=Math.pow(1-t,1.45)*(.19+.04*Math.sin(t*13));
    const cx=curve*Math.pow(t,1.8)*.78,cz=Math.sin(t*2.3)*curve*.15;
    for(let side=0;side<sides;side++){const a=side/sides*Math.PI*2;vertices.push(cx+Math.cos(a)*shaft,y,cz+Math.sin(a)*shaft*.8);if(ring<rings){const u=ring*sides+side,v=ring*sides+(side+1)%sides;indices.push(u,u+sides,v,v,u+sides,v+sides);}}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}
function organicMaterial({patch=false,clock}){
  const material=new THREE.MeshStandardMaterial({color:patch?'#303421':'#292c24',roughness:patch?.98:.79,metalness:0,vertexColors:patch,emissive:'#afbf64',emissiveIntensity:patch?.10:.27,side:patch?THREE.DoubleSide:THREE.FrontSide});
  material.onBeforeCompile=shader=>{
    shader.uniforms.infectionTime=clock;
    shader.vertexShader='varying vec3 vInfectionPosition;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
      vec4 infectionSurfacePosition=vec4(position,1.0);
      #ifdef USE_INSTANCING
        infectionSurfacePosition=instanceMatrix*infectionSurfacePosition;
      #endif
      vInfectionPosition=(modelMatrix*infectionSurfacePosition).xyz;
    `);
    shader.fragmentShader='varying vec3 vInfectionPosition;uniform float infectionTime;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
      float infectionGrain=fract(sin(dot(floor(vInfectionPosition*93.0),vec3(12.9898,78.233,39.346)))*43758.5453);
      float infectionFold=sin(vInfectionPosition.y*24.0+sin(vInfectionPosition.x*7.0)*2.0+vInfectionPosition.z*15.0);
      float infectionMottle=.5+.5*sin(vInfectionPosition.x*6.0+sin(vInfectionPosition.z*4.0)*2.0)*sin(vInfectionPosition.y*8.0+vInfectionPosition.z*6.0);
      diffuseColor.rgb*=mix(vec3(.53,.48,.41),vec3(.95,.99,.85),infectionMottle)*(.92+infectionGrain*.13+infectionFold*.035);
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
      roughnessFactor=clamp(roughnessFactor+infectionMottle*.12-infectionFold*.045,.58,1.0);
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
      float infectionVein=pow(max(0.0,1.0-abs(sin(vInfectionPosition.x*15.0+vInfectionPosition.z*11.0+sin(vInfectionPosition.y*5.0+vInfectionPosition.z*3.0)*2.0))),25.0);
      float infectionPulse=.73+.27*sin(infectionTime*1.3+vInfectionPosition.y*1.8+vInfectionPosition.x*.5);
      totalEmissiveRadiance*=(${patch?'.10':'.03'}+infectionVein*.8)*infectionPulse;
    `);
  };
  material.customProgramCacheKey=()=>`infection-organic-${patch?'ground':'spike'}-v2`;
  return material;
}
function clipSurfacePolygon(polygon,footprint){
  let result=polygon;
  for(let edge=0;edge<footprint.length&&result.length;edge++){
    const a=footprint[edge],b=footprint[(edge+1)%footprint.length],side=p=>(b.x-a.x)*(p.z-a.z)-(b.z-a.z)*(p.x-a.x),next=[];
    let previous=result[result.length-1],previousSide=side(previous);
    for(const point of result){const pointSide=side(point);if((pointSide>=0)!==(previousSide>=0)){const t=previousSide/(previousSide-pointSide);next.push({x:previous.x+(point.x-previous.x)*t,z:previous.z+(point.z-previous.z)*t});}if(pointSide>=0)next.push(point);previous=point;previousSide=pointSide;}
    result=next;
  }
  return result;
}
// Clip each decal to the world's exact triangle grid. Sampling an unrelated
// radial mesh only at its vertices lets its faces cut through sloping ground.
function terrainDecalGeometry(footprints,heightAt,{offset=.026,node=null}={}){
  const vertices=[],colors=[],allowed=p=>heightAt(p.x,p.z)>=2.6&&!isGlowSafeAt(p.x,p.z)&&!lavaAt(p.x,p.z)&&riverBankDistanceAt(p.x,p.z)>.1;
  const gridIndex=value=>Math.max(0,Math.min(TERRAIN_SEGMENTS-1,Math.floor((value+WORLD_SIZE/2)/TERRAIN_STEP)));
  for(const original of footprints){
    let footprint=original;const area=footprint.reduce((sum,p,i)=>{const q=footprint[(i+1)%footprint.length];return sum+p.x*q.z-q.x*p.z;},0);if(area<0)footprint=[...footprint].reverse();
    const minX=gridIndex(Math.min(...footprint.map(p=>p.x))),maxX=gridIndex(Math.max(...footprint.map(p=>p.x))),minZ=gridIndex(Math.min(...footprint.map(p=>p.z))),maxZ=gridIndex(Math.max(...footprint.map(p=>p.z)));
    for(let iz=minZ;iz<=maxZ;iz++)for(let ix=minX;ix<=maxX;ix++){
      const a={x:terrainVertex(ix),z:terrainVertex(iz)},b={x:terrainVertex(ix+1),z:a.z},c={x:a.x,z:terrainVertex(iz+1)},d={x:b.x,z:c.z};
      for(const triangle of[[a,c,b],[b,c,d]]){
        const clipped=clipSurfacePolygon(triangle,footprint);
        for(let i=1;i<clipped.length-1;i++){
          const points=[clipped[0],clipped[i],clipped[i+1]],centre={x:points.reduce((v,p)=>v+p.x,0)/3,z:points.reduce((v,p)=>v+p.z,0)/3};
          if(!points.every(allowed)||!allowed(centre))continue;
          for(const p of points){vertices.push(p.x,heightAt(p.x,p.z)+offset,p.z);if(node){const fraction=Math.min(1,Math.hypot(p.x-node.position.x,p.z-node.position.z)/(node.territoryRadius??node.radius)),edge=1-.48*Math.max(0,(fraction-.72)/.28),shade=(.72+.08*Math.sin(p.x*3.1+p.z*2.7))*edge;colors.push(shade,shade*.98,shade*.56);}}
        }
      }
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));if(node)geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.computeVertexNormals();return geometry;
}
function groundGeometry(node,heightAt){
  const radius=node.territoryRadius??node.radius,phase=randomFor(node.id+'-soil')()*Math.PI*2,footprint=[];
  for(let side=0;side<40;side++){const angle=side/40*Math.PI*2+phase;footprint.push({x:node.position.x+Math.cos(angle)*radius,z:node.position.z+Math.sin(angle)*radius});}
  return terrainDecalGeometry([footprint],heightAt,{node});
}
function mergeGeometry(parts,{colors=false}={}){
  const geometries=parts.map(g=>g.index?g.toNonIndexed():g),length=geometries.reduce((sum,g)=>sum+g.attributes.position.array.length,0),positions=new Float32Array(length),normals=new Float32Array(length),color=colors?new Float32Array(length):null;let offset=0;
  for(const g of geometries){positions.set(g.attributes.position.array,offset);normals.set(g.attributes.normal.array,offset);if(colors)color.set(g.attributes.color?.array||new Float32Array(g.attributes.position.array.length).fill(1),offset);offset+=g.attributes.position.array.length;}
  const out=new THREE.BufferGeometry();out.setAttribute('position',new THREE.BufferAttribute(positions,3));out.setAttribute('normal',new THREE.BufferAttribute(normals,3));if(colors)out.setAttribute('color',new THREE.BufferAttribute(color,3));out.computeBoundingSphere();
  for(let i=0;i<parts.length;i++){if(parts[i]!==geometries[i])geometries[i].dispose();parts[i].dispose();}return out;
}
function rootRibbon(node,heightAt){
  const footprints=[],points=node.path||[];
  for(let leg=1;leg<points.length;leg++){
    const a=points[leg-1],b=points[leg],length=Math.hypot(b.x-a.x,b.z-a.z);if(length<.01)continue;
    const dx=(b.z-a.z)/length*.34,dz=-(b.x-a.x)/length*.34;
    footprints.push([{x:a.x-dx,z:a.z-dz},{x:b.x-dx,z:b.z-dz},{x:b.x+dx,z:b.z+dz},{x:a.x+dx,z:a.z+dz}]);
  }
  return terrainDecalGeometry(footprints,heightAt,{offset:.047});
}

/** Visual-only client replica. Health, spreading and clearance are supplied by the room server. */
export function createInfectionVisuals({scene,heightAt}){
  const root=new THREE.Group();root.name='Cooperative infection — thornblight';scene.add(root);
  const clock={value:0},views=new Map(),spikes=[spikeGeometry(-.7),spikeGeometry(.45),spikeGeometry(.95)];
  const shell=organicMaterial({clock}),soil=organicMaterial({patch:true,clock});
  // Indexed vertices keep the swollen tissue smooth after displacement, including
  // the texture seam and poles, rather than giving each triangle its own normal.
  const heartGeometry=new THREE.SphereGeometry(1,44,32);
  const positions=heartGeometry.getAttribute('position');
  for(let i=0;i<positions.count;i++){const x=positions.getX(i),y=positions.getY(i),z=positions.getZ(i),r=1+Math.sin(x*4.7+y*3.1+z*5.3)*.061+Math.sin(y*8.3-z*4.9+x*2.7)*.023+Math.sin(x*13.1-z*11.7+y*7.1)*.005;positions.setXYZ(i,x*r,y*r,z*r);}
  heartGeometry.computeVertexNormals();
  const normals=heartGeometry.getAttribute('normal'),normalGroups=new Map();
  for(let i=0;i<positions.count;i++){const key=[positions.getX(i),positions.getY(i),positions.getZ(i)].map(v=>Math.round(v*100000)).join(',');if(!normalGroups.has(key))normalGroups.set(key,{normal:new THREE.Vector3(),indices:[]});const group=normalGroups.get(key);group.normal.add(new THREE.Vector3(normals.getX(i),normals.getY(i),normals.getZ(i)));group.indices.push(i);}
  for(const group of normalGroups.values()){group.normal.normalize();for(const i of group.indices)normals.setXYZ(i,group.normal.x,group.normal.y,group.normal.z);}
  const pustuleGeometry=new THREE.SphereGeometry(1,16,12),pustuleMaterial=new THREE.MeshStandardMaterial({color:'#535432',roughness:.49,metalness:0,emissive:'#9ca952',emissiveIntensity:.14});
  const veinMaterial=new THREE.MeshStandardMaterial({color:'#4e5638',roughness:.78,emissive:'#94a447',emissiveIntensity:.10});
  const territory=new THREE.Mesh(new THREE.BufferGeometry(),soil),roots=new THREE.Mesh(new THREE.BufferGeometry(),veinMaterial);territory.receiveShadow=roots.receiveShadow=true;root.add(territory,roots);
  const coarseHearts=new THREE.InstancedMesh(heartGeometry,shell,MAX_NODES),coarseSpikes=new THREE.InstancedMesh(spikes[1],shell,MAX_NODES*3),dummy=new THREE.Object3D();coarseHearts.count=coarseSpikes.count=0;coarseHearts.castShadow=coarseSpikes.castShadow=true;coarseHearts.receiveShadow=coarseSpikes.receiveShadow=true;coarseHearts.frustumCulled=coarseSpikes.frustumCulled=false;root.add(coarseHearts,coarseSpikes);
  let records=[],disposed=false,lastPlayer=null,signature='';
  function createView(node){
    const rng=randomFor(node.id),group=new THREE.Group(),body=new THREE.Group();group.position.set(node.position.x,node.position.y,node.position.z);group.name=`Infection heart ${node.id}`;group.add(body);
    const heart=new THREE.Mesh(heartGeometry,shell);heart.position.y=.32;heart.scale.set(.92,.53,.76);heart.rotation.y=rng()*Math.PI*2;heart.castShadow=true;heart.receiveShadow=true;body.add(heart);
    const spikeInstances=spikes.map(g=>{const mesh=new THREE.InstancedMesh(g,shell,7);mesh.count=0;mesh.castShadow=mesh.receiveShadow=true;mesh.frustumCulled=false;body.add(mesh);return mesh;});
    for(let i=0;i<19;i++){
      const a=i/19*Math.PI*2+rng()*.24,r=.18+rng()*node.radius*.7,x=Math.cos(a)*r,z=Math.sin(a)*r;
      const spike=dummy;spike.position.set(x,heightAt(node.position.x+x,node.position.z+z)-node.position.y-.035,z);
      spike.rotation.set(Math.cos(a)*(.03+rng()*.15),a+rng()*.5,-Math.sin(a)*(.07+rng()*.18));
      const size=.35+rng()*.60;spike.scale.set(size*(.7+rng()*.4),size,size);spike.updateMatrix();const instance=spikeInstances[i%3];instance.setMatrixAt(instance.count++,spike.matrix);
    }
    const pustules=new THREE.InstancedMesh(pustuleGeometry,pustuleMaterial,13);pustules.castShadow=true;pustules.frustumCulled=false;body.add(pustules);
    for(let i=0;i<13;i++){
      const a=rng()*Math.PI*2,r=.24+rng()*.43,pustule=dummy;pustule.rotation.set(0,0,0);pustule.position.set(Math.cos(a)*r,.48+rng()*.22,Math.sin(a)*r*.75);pustule.scale.setScalar(.065+rng()*.12);pustule.scale.y*=.55;pustule.updateMatrix();pustules.setMatrixAt(i,pustule.matrix);
    }
    const veinGeometries=[];
    for(let i=0;i<7;i++){
      const a=i/7*Math.PI*2+rng()*.35,length=node.radius*(.6+rng()*.33),points=[];
      for(let s=0;s<7;s++){const t=s/6,r=t*length,angle=a+Math.sin(t*6+i)*.15,x=Math.cos(angle)*r,z=Math.sin(angle)*r;points.push(new THREE.Vector3(x,heightAt(node.position.x+x,node.position.z+z)-node.position.y+.05,z));}
      const geometry=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),14,.024+rng()*.025,5,false);veinGeometries.push(geometry);
    }
    const veinGeometry=mergeGeometry(veinGeometries),vein=new THREE.Mesh(veinGeometry,veinMaterial);vein.receiveShadow=true;body.add(vein);
    root.add(group);return{group,body,heart,node,phase:rng()*Math.PI*2,veinGeometry,instances:[...spikeInstances,pustules]};
  }
  function removeView(id){const view=views.get(id);if(!view)return;root.remove(view.group);view.veinGeometry.dispose();for(const mesh of view.instances)mesh.dispose();views.delete(id);}
  function selectViews(player){
    const nearest=records.map(n=>({n,d:player?Math.hypot(player.x-n.position.x,player.z-n.position.z):0})).filter(item=>item.d<180).sort((a,b)=>a.d-b.d).slice(0,INFECTION_DETAIL_LIMIT),ids=new Set(nearest.map(item=>item.n.id));
    for(const id of views.keys())if(!ids.has(id))removeView(id);for(const{n}of nearest){if(!views.has(n.id))views.set(n.id,createView(n));else views.get(n.id).node=n;}
  }
  function applySnapshot(snapshot){
    if(disposed)return;
    records=(Array.isArray(snapshot?.nodes)?snapshot.nodes:[]).filter(n=>n?.position&&[n.position.x,n.position.y,n.position.z,n.radius,n.health,n.maxHealth].every(Number.isFinite)&&n.health>0).slice(0,MAX_NODES).map(n=>({...n,territoryRadius:n.territoryRadius??n.radius,path:(n.path||[]).map(p=>({...p})),position:{...n.position}}));
    const nextSignature=records.map(n=>`${n.id}:${n.territoryRadius}`).join('|');
    if(nextSignature!==signature){signature=nextSignature;territory.geometry.dispose();roots.geometry.dispose();territory.geometry=mergeGeometry(records.map(n=>groundGeometry(n,heightAt)),{colors:true});roots.geometry=mergeGeometry(records.map(n=>rootRibbon(n,heightAt)));}
    selectViews(lastPlayer||records[0]?.position);
    root.visible=records.length>0;
  }
  function update(dt,player){
    if(disposed)return;
    const step=Math.max(0,Math.min(.25,Number.isFinite(dt)?dt:0));clock.value+=step;
    if(player)lastPlayer={...player};selectViews(lastPlayer);
    coarseHearts.count=records.length;coarseSpikes.count=records.length*3;
    records.forEach((node,i)=>{const far=lastPlayer?Math.hypot(lastPlayer.x-node.position.x,lastPlayer.z-node.position.z):0,visible=!views.has(node.id)&&far<650,growth=.18+.82*Math.min(1,((node.age||0)+.5)/7),size=visible?growth:0;dummy.position.set(node.position.x,node.position.y+.32,node.position.z);dummy.rotation.set(0,0,0);dummy.scale.set(.92*size,.53*size,.76*size);dummy.updateMatrix();coarseHearts.setMatrixAt(i,dummy.matrix);for(let k=0;k<3;k++){const a=k*Math.PI*2/3;dummy.position.set(node.position.x+Math.cos(a)*.58,node.position.y,node.position.z+Math.sin(a)*.58);dummy.rotation.set(0,a,0);dummy.scale.set(.7*size,(.64+k*.10)*size,.7*size);dummy.updateMatrix();coarseSpikes.setMatrixAt(i*3+k,dummy.matrix);}});coarseHearts.instanceMatrix.needsUpdate=coarseSpikes.instanceMatrix.needsUpdate=true;
    for(const view of views.values()){
      const node=view.node,distance=player?Math.hypot(player.x-node.position.x,player.z-node.position.z):0;
      view.group.visible=distance<650;
      if(!view.group.visible)continue;
      node.age=(node.age||0)+step;
      const growth=.18+.82*Math.min(1,(node.age+.5)/7),health=node.health/node.maxHealth;
      view.body.scale.y=growth;view.heart.scale.set(.92*(.992+Math.sin(clock.value*1.3+view.phase)*.008),.53*(.96+health*.04),.76);
    }
  }
  return{applySnapshot,update,getTargets:()=>records.map(n=>({...n,kind:'infection-node',name:'Infection heart',position:{...n.position}})),
    getDiagnostics:()=>({nodes:records.length,views:views.size,detailLimit:INFECTION_DETAIL_LIMIT,coarseCores:records.length-views.size,territoryDraws:records.length?2:0,visible:[...views.values()].filter(v=>v.group.visible).length}),
    dispose(){if(disposed)return;disposed=true;for(const id of [...views.keys()])removeView(id);scene.remove(root);territory.geometry.dispose();roots.geometry.dispose();coarseHearts.dispose();coarseSpikes.dispose();for(const g of [...spikes,heartGeometry,pustuleGeometry])g.dispose();for(const m of [shell,soil,pustuleMaterial,veinMaterial])m.dispose();records=[];}
  };
}
