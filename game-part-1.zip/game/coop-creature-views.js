import * as THREE from './vendor/three.module.js';
import {createWildlifeModel} from './wildlife-models.js';
import {WILDLIFE_SPECIES,WILDLIFE_LIMITS} from './wildlife-catalog.js';
import {createBurrowpeedModel,createBurrowpeedTeethGeometry,createBurrowpeedTeethMaterial} from './burrowpeed-model.js';
import {createInfectionVisuals} from './infection-visuals.js';
import {createTeethpeedModel} from './teethpeed-model.js';
import {createDeatheaterModel} from './deatheater-model.js';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
export function createCoopCreatureViews({scene,world,surfaceTexture,prewarmedView}){
  let state={},time=0;const views=new Map(),burrowViews=new Map(),remainsViews=new Map(),idle=prewarmedView?[prewarmedView]:[];
  if(prewarmedView){scene.add(prewarmedView.group);prewarmedView.group.visible=false;}
  const markerGeo=createBurrowpeedTeethGeometry(),markerMaterial=createBurrowpeedTeethMaterial(),markers=new THREE.InstancedMesh(markerGeo,markerMaterial,50),dummy=new THREE.Object3D();markers.count=0;markers.frustumCulled=false;markers.castShadow=markers.receiveShadow=true;scene.add(markers);
  const infection=createInfectionVisuals({scene,heightAt:world.groundHeight});
  function applySnapshot(next){state=next||{};infection.applySnapshot(state.infection);}
  const animals=()=>[...(state.wildlife?.actors||[]).map(r=>({...r,dead:false})),...(state.wildlife?.remains||[]).filter(r=>!r.harvested&&(state.wildlife.clock-r.deathTime)<WILDLIFE_LIMITS.corpseSeconds).map(r=>({...r,dead:true}))];
  function update(dt,p){time+=Math.min(dt,.1);const visible=animals().filter(r=>distance(r.position,p)<90).sort((a,b)=>distance(a.position,p)-distance(b.position,p)).slice(0,WILDLIFE_LIMITS.views),ids=new Set(visible.map(r=>r.id));
    for(const [id,v]of views)if(!ids.has(id)){v.dispose();views.delete(id);}
    for(const r of visible){let v=views.get(r.id);if(!v){v=createWildlifeModel(r.species,{lod:distance(r.position,p)>45?1:0});scene.add(v.group);v.group.position.set(r.position.x,r.position.y,r.position.z);views.set(r.id,v);}const previous=v.group.position.clone();v.group.position.lerp(new THREE.Vector3(r.position.x,r.position.y,r.position.z),1-Math.exp(-dt*15));v.group.rotation.y+=Math.atan2(Math.sin(r.heading-v.group.rotation.y),Math.cos(r.heading-v.group.rotation.y))*(1-Math.exp(-dt*12));v.animate({time,state:r.state,speed:dt>0?previous.distanceTo(v.group.position)/dt:0,dead:r.dead});}
    const dens=state.burrowers?.dens||[];markers.count=dens.length;dens.forEach((r,i)=>{const q=r.denPosition;dummy.position.set(q.x,q.y,q.z);const h=world.groundHeight,normal=new THREE.Vector3(-(h(q.x+.3,q.z)-h(q.x-.3,q.z))/.6,1,-(h(q.x,q.z+.3)-h(q.x,q.z-.3))/.6).normalize();dummy.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),normal).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),r.heading));dummy.scale.setScalar(r.tipsVisible&&distance(q,p)<85?1:0);dummy.updateMatrix();markers.setMatrixAt(i,dummy.matrix);});markers.instanceMatrix.needsUpdate=true;
    const surfaced=dens.filter(r=>['emerging','chasing','burrowing','dead'].includes(r.stage)&&!r.harvested&&distance(r.position,p)<105).sort((a,b)=>distance(a.position,p)-distance(b.position,p)).slice(0,6),keep=new Set(surfaced.map(r=>r.id));
    for(const [id,v] of burrowViews)if(!keep.has(id)){v.group.visible=false;burrowViews.delete(id);if(idle.length<2)idle.push(v);else v.dispose();}
    for(const r of surfaced){let v=burrowViews.get(r.id);if(!v){v=idle.pop()||createBurrowpeedModel({surfaceTexture});scene.add(v.group);burrowViews.set(r.id,v);v.group.position.set(r.position.x,r.position.y,r.position.z);v.animate({time:-1,stage:'chasing',groundHeightAt:world.groundHeight});}v.group.visible=true;v.group.position.lerp(new THREE.Vector3(r.position.x,r.position.y,r.position.z),1-Math.exp(-dt*18));v.group.rotation.y=r.heading;v.animate({time,stage:r.stage,progress:r.progress,speed:r.stage==='chasing'?4.65:0,groundHeightAt:world.groundHeight});}
    const remains=(state.legacyRemains||[]).filter(r=>!r.harvested&&distance(r.position,p)<80).sort((a,b)=>distance(a.position,p)-distance(b.position,p)).slice(0,4),remainsIds=new Set(remains.map(r=>r.id));
    for(const [id,v]of remainsViews)if(!remainsIds.has(id)){v.dispose();remainsViews.delete(id);}
    for(const r of remains){let v=remainsViews.get(r.id);if(!v){v=r.kind==='teethpeed'?createTeethpeedModel({surfaceTexture}):createDeatheaterModel();scene.add(v.group);remainsViews.set(r.id,v);}v.group.position.set(r.position.x,r.position.y+.35,r.position.z);v.group.rotation.set(0,r.heading||0,r.kind==='teethpeed'?.85:1.3);v.animate({time:0,speed:0,stage:'retreating',attacking:0});}
    infection.update(dt,p);
  }
  function nearbyCorpses(p){return [...animals().filter(r=>r.dead).map(r=>({...r,id:`wildlife/${r.id}`,name:WILDLIFE_SPECIES[r.species]?.name||r.species})),...(state.burrowers?.dens||[]).filter(r=>r.stage==='dead'&&!r.harvested).map(r=>({...r,id:`burrowpeed/${r.id}`,name:'Burrowpeed'})),...(state.legacyRemains||[]).filter(r=>!r.harvested).map(r=>({...r,name:r.kind==='teethpeed'?'Teethpeed':'Deatheater'}))].filter(r=>distance(r.position,p)<3.5&&Math.abs(r.position.y-p.y)<3.2).sort((a,b)=>distance(a.position,p)-distance(b.position,p));}
  function getChasers(p){return [...animals().filter(r=>r.state==='chase'),...(state.burrowers?.dens||[]).filter(r=>r.stage==='chasing')].filter(r=>distance(r.position,p)<40).map(r=>({...r,kind:r.species||'burrowpeed'}));}
  return{applySnapshot,update,nearbyCorpses,getChasers,infectedTargets:()=>infection.getTargets(),dispose(){for(const v of [...views.values(),...remainsViews.values()])v.dispose();for(const v of [...burrowViews.values(),...idle])v.dispose();markers.removeFromParent();markerGeo.dispose();markerMaterial.dispose();markers.dispose();infection.dispose();}};
}
