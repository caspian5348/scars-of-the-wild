import {evaluateTeethpeedSenses,hasTeethpeedLineOfSight,TEETHPEED_DETECTION_RADIUS} from './teethpeed-senses.js';
export {TEETHPEED_DETECTION_RADIUS} from './teethpeed-senses.js';

export const TEETHPEED_CHANCE = 0.15;
export const TEETHPEED_SPEED = 4.45;
export const TEETHPEED_BITE_DAMAGE = 22;
export const TEETHPEED_BITE_INTERVAL = 1.8;
export const TEETHPEED_SPIRAL_TURNS = 2;
export const TEETHPEED_SPIRAL_END = .82;

const BODY_RADIUS = .85;
const TRIGGER_DISTANCE = TEETHPEED_DETECTION_RADIUS;
const SIGHT_CONFIRM_TIME = .2;
const BITE_DISTANCE = 1.65;
const STOP_DISTANCE = 1.15;
const MIN_GROUND = 1.18;
const LANDING_STEER_SECONDS = .55;
const CORNER_CLEARANCE = .55;
const CELL_SIZE = 16;
const TAU = Math.PI * 2;
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const finite = Number.isFinite;
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const validId = value => typeof value === 'string' && value.length > 0 && value.length <= 256;
const validPosition = value => plain(value) && [value.x, value.y, value.z].every(finite) && Math.max(Math.abs(value.x), Math.abs(value.y), Math.abs(value.z)) <= 100000;
const angleOf = (dx, dz) => Math.atan2(-dx, -dz);

function hash(seed, treeId, purpose) {
  const text = JSON.stringify([String(seed), String(treeId), purpose]);
  let value = 2166136261;
  for (let i = 0; i < text.length; i++) value = Math.imul(value ^ text.charCodeAt(i), 16777619);
  value ^= value >>> 16; value = Math.imul(value, 0x7feb352d);
  value ^= value >>> 15; value = Math.imul(value, 0x846ca68b);
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}

export function treeEncounterChance(seed, treeId) { return hash(seed, treeId, 'eligibility'); }
export function passesTeethpeedChance(roll) { return finite(roll) && roll >= 0 && roll < TEETHPEED_CHANCE; }

/** Derived only: saved descent.angle continues to identify the terminal landing. */
export function getTeethpeedDescentPose(record, seed = '') {
  const d = record?.descent;
  if (!d || ![d.elapsed, d.total, d.angle, d.fromY, d.toY, d.surfaceRadius].every(finite) || d.total <= 0) return null;
  const progress = clamp(d.elapsed / d.total, 0, 1);
  const spiralProgress = clamp(progress / TEETHPEED_SPIRAL_END, 0, 1);
  const eased = spiralProgress * spiralProgress * (3 - 2 * spiralProgress);
  const handedness = hash(seed, record.treeId, 'spiral-handedness') < .5 ? -1 : 1;
  // Integer turns preserve the original starting face. The ease has zero angular
  // velocity at both ends, so the last fifth can leave the trunk without a turn.
  const angle = d.angle - handedness * TAU * TEETHPEED_SPIRAL_TURNS * (1 - eased);
  const angularSpeed = handedness * TAU * TEETHPEED_SPIRAL_TURNS * 6 * spiralProgress * (1 - spiralProgress) / (d.total * TEETHPEED_SPIRAL_END);
  const landingProgress = clamp((progress - TEETHPEED_SPIRAL_END) / (1 - TEETHPEED_SPIRAL_END), 0, 1);
  return {
    angle, progress, spiralProgress, turnCount: TEETHPEED_SPIRAL_TURNS, handedness,
    angularSpeed, verticalSpeed: (d.toY - d.fromY) / d.total, surfaceRadius: d.surfaceRadius,
    landingProgress, groundBlend: landingProgress * landingProgress * (3 - 2 * landingProgress),
  };
}

function copyActive(record) {
  return {...record, position:{...record.position}, descent:{...record.descent},
    lastKnownPlayer:record.lastKnownPlayer?{...record.lastKnownPlayer}:null,
    searchTarget:record.searchTarget?{...record.searchTarget}:null,
    senses:record.senses?{...record.senses}:null};
}

/** Tree-independent validation for journey persistence. It never calls random or touches storage. */
export function normalizeEncounterState(value) {
  if (value === undefined) return undefined;
  if (!plain(value) || value.version !== 1 || !((typeof value.seed === 'string' && value.seed.length > 0 && value.seed.length <= 512) || finite(value.seed))) return null;
  if(value.clock!==undefined&&(!finite(value.clock)||value.clock<0))return null;
  if (!Array.isArray(value.spent) || value.spent.length > 50000 || !value.spent.every(validId) || !Array.isArray(value.active) || value.active.length > 16) return null;
  const active = [], seen = new Set(), spent = new Set(value.spent);
  for (const source of value.active) {
    if (!plain(source) || !validId(source.treeId) || seen.has(source.treeId) || !['descending','attacking','hunting','retreating'].includes(source.stage)) return null;
    if (!validPosition(source.position) || !finite(source.heading) || !finite(source.remaining) || source.remaining < 0 || source.remaining > 120) return null;
    if(source.health!==undefined&&(!finite(source.health)||source.health<=0||source.health>100))return null;
    if (!finite(source.attackDuration) || source.attackDuration < 60 || source.attackDuration > 120 || !finite(source.biteCooldown) || source.biteCooldown < 0 || source.biteCooldown > TEETHPEED_BITE_INTERVAL) return null;
    if (!finite(source.retreatRemaining) || source.retreatRemaining < 0 || source.retreatRemaining > 8 || !finite(source.retreatHeading)) return null;
    const d = source.descent;
    if (!plain(d) || ![d.fromY,d.toY,d.total,d.elapsed,d.treeX,d.treeZ,d.angle,d.surfaceRadius,d.landingRadius].every(finite)) return null;
    if (d.total < 4 || d.total > 7 || d.elapsed < 0 || d.elapsed > d.total || d.fromY < d.toY || d.surfaceRadius <= 0 || d.landingRadius < d.surfaceRadius || d.landingRadius > 30 || Math.max(Math.abs(d.fromY),Math.abs(d.toY),Math.abs(d.treeX),Math.abs(d.treeZ)) > 100000) return null;
    if (source.stage === 'descending' && source.remaining > d.total || ['attacking','hunting'].includes(source.stage) && source.remaining > source.attackDuration || source.stage === 'retreating' && source.remaining > 8) return null;
    for(const key of ['lastKnownPlayer','searchTarget'])if(source[key]!=null&&!validPosition(source[key]))return null;
    for(const key of ['huntingTime','searchWait','sightLostFor','sightFoundFor'])if(source[key]!==undefined&&(!finite(source[key])||source[key]<0||source[key]>120))return null;
    if(source.searchIndex!==undefined&&(!Number.isInteger(source.searchIndex)||source.searchIndex<0||source.searchIndex>10000))return null;
    if(source.senses!=null&&(!plain(source.senses)||!finite(source.senses.distance)||source.senses.distance<0||source.senses.distance>300000||typeof source.senses.withinDetection!=='boolean'||typeof source.senses.lineOfSight!=='boolean'))return null;
    const record = {
      treeId:source.treeId, stage:source.stage, remaining:source.remaining,
      health:source.health??100,
      position:{x:source.position.x,y:source.position.y,z:source.position.z}, heading:source.heading,
      descent:{fromY:d.fromY,toY:d.toY,total:d.total,elapsed:d.elapsed,treeX:d.treeX,treeZ:d.treeZ,angle:d.angle,surfaceRadius:d.surfaceRadius,landingRadius:d.landingRadius},
      attackDuration:source.attackDuration, biteCooldown:source.biteCooldown,
      retreatRemaining:source.retreatRemaining, retreatHeading:source.retreatHeading,
      lastKnownPlayer:source.lastKnownPlayer?{...source.lastKnownPlayer}:null,
      searchTarget:source.searchTarget?{...source.searchTarget}:null,
      huntingTime:source.huntingTime??0,searchIndex:source.searchIndex??0,searchWait:source.searchWait??0,
      sightLostFor:source.sightLostFor??0,sightFoundFor:source.sightFoundFor??0,senses:source.senses?{...source.senses}:null,
      hidingId:typeof source.hidingId==='string'?source.hidingId.slice(0,180):null,
      hidingFound:!!source.hidingFound,hidingRolls:Number.isSafeInteger(source.hidingRolls)&&source.hidingRolls>=0?source.hidingRolls:0,
    };
    if(record.stage==='descending')record.remaining=Math.max(0,d.total-d.elapsed);
    if(record.stage==='retreating')record.retreatRemaining=record.remaining;
    active.push(record); seen.add(record.treeId); spent.add(record.treeId);
  }
  return {version:1,seed:String(value.seed),clock:value.clock??0,spent:[...spent],active};
}

/** Deterministic per-journey encounters; the caller controls pause by withholding update(). */
export function createTeethpeedEncounters({trees = [], heightAt, colliders = [], forestBlendAt = () => 1, isSafeAt = () => false, onDamage = () => {}, onEvent = () => {}, onChange = () => {}, random = Math.random, state, seed, maxActive = 2}) {
  const restored = normalizeEncounterState(state);
  const runSeed = restored?.seed ?? String(seed ?? Math.floor(clamp(random(),0,.999999999999) * 4294967296));
  const capacity = clamp(Math.trunc(maxActive) || 2,1,16);
  const spent = new Set(restored?.spent || []);
  const treeById = new Map(), treeGrid = new Map(), colliderGrid = new Map();
  const descentPaths = new WeakMap();
  let active = restored?.active.map(copyActive) || [];
  let clock = restored?.clock || 0;
  let lastPlayer = null;

  function gridKey(x,z) { return `${Math.floor(x/CELL_SIZE)},${Math.floor(z/CELL_SIZE)}`; }
  function addToGrid(grid, x, z, value) {
    const key=gridKey(x,z); if(!grid.has(key))grid.set(key,[]); grid.get(key).push(value);
  }
  for(let i=0;i<trees.length;i++) {
    const source=trees[i];
    if(!source||![source.x,source.z].every(finite))continue;
    const id=String(source.id ?? `tree-${i}`);
    if(!validId(id)||treeById.has(id))continue;
    const tree={id,x:source.x,z:source.z,h:finite(source.h)?source.h:heightAt(source.x,source.z),height:finite(source.height)?Math.max(5,source.height):16*(finite(source.scale)?source.scale:1),radius:finite(source.radius)?Math.max(.12,source.radius):.35*(finite(source.scale)?source.scale:1),angle:finite(source.angle)?source.angle:0,variant:finite(source.variant)?source.variant:(parseInt(id.split('-').at(-1),10)||0)%2};
    if(!finite(tree.h))continue;
    treeById.set(id,tree);addToGrid(treeGrid,tree.x,tree.z,tree);
  }
  for(const source of colliders) {
    if(!source||![source.x,source.z,source.radius].every(finite)||source.radius<=0)continue;
    const c={x:source.x,z:source.z,radius:source.radius,height:source.height},reach=c.radius+BODY_RADIUS;
    for(let x=Math.floor((c.x-reach)/CELL_SIZE);x<=Math.floor((c.x+reach)/CELL_SIZE);x++) {
      for(let z=Math.floor((c.z-reach)/CELL_SIZE);z<=Math.floor((c.z+reach)/CELL_SIZE);z++) {
        const key=`${x},${z}`;if(!colliderGrid.has(key))colliderGrid.set(key,[]);colliderGrid.get(key).push(c);
      }
    }
  }
  // Restored IDs remain spent even if a later scenery revision no longer contains that tree.
  active=active.filter(record=>treeById.has(record.treeId)).slice(0,capacity);

  function snapshot() { return {version:1,seed:runSeed,clock,spent:[...spent],active:active.map(copyActive)}; }
  function emit(type,record,extra={}) {
    const event={type,treeId:record.treeId,position:{...record.position},...extra};
    onEvent(event);onChange(snapshot(),event);
  }
  function forestAt(x,z) {
    const amount=forestBlendAt(x,z);
    return finite(amount)?amount:0;
  }
  function canOccupy(x,z) {
    if(isSafeAt(x,z))return null;
    const y=heightAt(x,z);
    if(!finite(y)||y<MIN_GROUND)return null;
    for(const c of colliderGrid.get(gridKey(x,z))||[])if(Math.hypot(x-c.x,z-c.z)<c.radius+BODY_RADIUS)return null;
    for(const [dx,dz] of [[BODY_RADIUS,0],[-BODY_RADIUS,0],[0,BODY_RADIUS],[0,-BODY_RADIUS]]) {
      if(isSafeAt(x+dx,z+dz))return null;
      const edge=heightAt(x+dx,z+dz);
      if(!finite(edge)||edge<MIN_GROUND||Math.abs(edge-y)>1.15)return null;
    }
    return y;
  }
  function validStep(from,x,z) {
    if(isSafeAt((from.x+x)/2,(from.z+z)/2))return null;
    const y=canOccupy(x,z);
    if(y===null)return null;
    const currentGround=heightAt(from.x,from.z),distance=Math.hypot(x-from.x,z-from.z);
    if(!finite(currentGround)||Math.abs(y-currentGround)>Math.max(.15,distance*1.08))return null;
    const middle=heightAt((from.x+x)/2,(from.z+z)/2);
    if(!finite(middle)||middle<MIN_GROUND||Math.abs(middle-currentGround)>Math.max(.13,distance*.6))return null;
    return y;
  }

  function landingFor(tree,player) {
    const firstAngle=player?Math.atan2(player.z-tree.z,player.x-tree.x):hash(runSeed,tree.id,'landing')*TAU;
    const radius=tree.radius*1.92+BODY_RADIUS+.16;
    for(let i=0;i<24;i++) {
      const step=i===0?0:Math.ceil(i/2)*(i%2?1:-1);
      const angle=firstAngle+step*TAU/24,x=tree.x+Math.cos(angle)*radius,z=tree.z+Math.sin(angle)*radius,y=canOccupy(x,z);
      if(y!==null)return {x,y,z,angle,radius};
    }
    return null;
  }

  function trunkAt(tree,y) {
    if(!tree.id.startsWith('rainforest-'))return {x:tree.x,z:tree.z,radius:tree.radius};
    const ring=clamp((y-tree.h+.08)/tree.height,0,1)*10,lower=Math.floor(ring),upper=Math.min(10,lower+1),blend=ring-lower;
    const sample=j=>{
      const t=j/10;
      return {x:Math.sin(t*2.6+tree.variant)*t*.55,z:Math.sin(t*3.9)*t*.46,radius:(1-.945*Math.pow(t,.76))*(1+Math.sin(j*1.7)*.035)};
    };
    const a=sample(lower),b=sample(upper),localX=(a.x+(b.x-a.x)*blend)*tree.radius,localZ=(a.z+(b.z-a.z)*blend)*tree.radius;
    return {x:tree.x+Math.cos(tree.angle)*localX+Math.sin(tree.angle)*localZ,z:tree.z-Math.sin(tree.angle)*localX+Math.cos(tree.angle)*localZ,radius:(a.radius+(b.radius-a.radius)*blend)*tree.radius};
  }

  function terrainGradient(x,z) {
    const e=.04,x0=heightAt(x-e,z),x1=heightAt(x+e,z),z0=heightAt(x,z-e),z1=heightAt(x,z+e);
    return {x:finite(x0)&&finite(x1)?(x1-x0)/(2*e):0,z:finite(z0)&&finite(z1)?(z1-z0)/(2*e):0};
  }
  function hermite(a,b,va,vb,u,duration) {
    const u2=u*u,u3=u2*u;
    return {value:(2*u3-3*u2+1)*a+(u3-2*u2+u)*va*duration+(-2*u3+3*u2)*b+(u3-u2)*vb*duration,
      speed:((6*u2-6*u)*a+(3*u2-4*u+1)*va*duration+(-6*u2+6*u)*b+(3*u2-2*u)*vb*duration)/duration};
  }
  function descentPath(record,elapsed=record.descent.elapsed) {
    const d=record.descent,tree=treeById.get(record.treeId);
    let path=descentPaths.get(record);
    if(!path) {
      const trunkDuration=d.total*TEETHPEED_SPIRAL_END,exitDuration=d.total-trunkDuration,radial={x:Math.cos(d.angle),z:Math.sin(d.angle)};
      const atHeight=y=>{const t=trunkAt(tree,y);return {x:t.x+radial.x*(t.radius+.08),y,z:t.z+radial.z*(t.radius+.08)};};
      // Reach the actual low bark/terrain corner before leaving the trunk. A
      // high diagonal departure would leave the legs hanging in empty space.
      let cornerY=Math.min(d.fromY-.1,tree.h+CORNER_CLEARANCE);
      for(let i=0;i<10;i++){const p=atHeight(cornerY),ground=heightAt(p.x,p.z);if(!finite(ground))break;cornerY=Math.min(d.fromY-.1,ground+CORNER_CLEARANCE);}
      const corner=atHeight(cornerY),cornerGround=heightAt(corner.x,corner.z),clearance=finite(cornerGround)?Math.max(.01,cornerY-cornerGround):CORNER_CLEARANCE;
      const below=atHeight(cornerY-.005),above=atHeight(cornerY+.005),gradient=terrainGradient(corner.x,corner.z);
      const tx=(above.x-below.x)/.01,tz=(above.z-below.z)/.01;
      // Match the derivative of terrain + clearance*(1-u)^2 at departure.
      const cornerSpeed=-2*clearance/exitDuration/Math.max(.2,1-gradient.x*tx-gradient.z*tz);
      const terminal={x:d.treeX+radial.x*d.landingRadius,y:d.toY,z:d.treeZ+radial.z*d.landingRadius};
      const landingGround=heightAt(terminal.x,terminal.z);
      path={trunkDuration,exitDuration,corner,clearance,cornerSpeed,atHeight,
        startSpeed:(cornerY-d.fromY)/trunkDuration,
        entryVelocity:{x:tx*cornerSpeed,y:cornerSpeed,z:tz*cornerSpeed},terminal,
        endVelocity:{x:radial.x*TEETHPEED_SPEED,z:radial.z*TEETHPEED_SPEED},
        endHeightOffset:finite(landingGround)?d.toY-landingGround:0};
      descentPaths.set(record,path);
    }
    const t=clamp(elapsed,0,d.total);
    function onTrunk(time) {
      const y=hermite(d.fromY,path.corner.y,path.startSpeed,path.cornerSpeed,time/path.trunkDuration,path.trunkDuration).value;
      const trunk=trunkAt(tree,y),timing=getTeethpeedDescentPose({...record,descent:{...d,elapsed:time}},runSeed);
      return {x:trunk.x+Math.cos(timing.angle)*(trunk.radius+.08),y,z:trunk.z+Math.sin(timing.angle)*(trunk.radius+.08)};
    }
    if(t<path.trunkDuration) {
      const position=onTrunk(t),epsilon=.0001,lo=Math.max(0,t-epsilon),hi=Math.min(path.trunkDuration,t+epsilon),a=onTrunk(lo),b=onTrunk(hi),span=hi-lo;
      return {position,velocity:{x:(b.x-a.x)/span,y:(b.y-a.y)/span,z:(b.z-a.z)/span}};
    }
    const u=clamp((t-path.trunkDuration)/path.exitDuration,0,1),x=hermite(path.corner.x,path.terminal.x,path.entryVelocity.x,path.endVelocity.x,u,path.exitDuration),z=hermite(path.corner.z,path.terminal.z,path.entryVelocity.z,path.endVelocity.z,u,path.exitDuration);
    const ground=heightAt(x.value,z.value),gradient=terrainGradient(x.value,z.value),blend=u*u*(3-2*u);
    // The head stays within leg reach of the terrain while its rear still uses
    // the preserved trunk trail. Landing has full outward speed, not an ease-stop.
    const y=(finite(ground)?ground:d.toY)+path.clearance*(1-u)*(1-u)+path.endHeightOffset*blend;
    return {position:{x:x.value,y,z:z.value},velocity:{x:x.speed,
      y:gradient.x*x.speed+gradient.z*z.speed-2*path.clearance*(1-u)/path.exitDuration+path.endHeightOffset*6*u*(1-u)/path.exitDuration,z:z.speed}};
  }

  function start(tree,player,forced=false) {
    if(!tree||active.length>=capacity||spent.has(tree.id)||forestAt(tree.x,tree.z)<.48)return false;
    if(isSafeAt(tree.x,tree.z)||(player&&isSafeAt(player.x,player.z)))return false;
    if(!forced&&!passesTeethpeedChance(treeEncounterChance(runSeed,tree.id)))return false;
    const landing=landingFor(tree,player);
    if(!landing)return false;
    for(let i=0;i<16;i++){
      const a=i*TAU/16,radius=tree.radius+BODY_RADIUS;
      if(isSafeAt(tree.x+Math.cos(a)*radius,tree.z+Math.sin(a)*radius))return false;
    }
    const total=4+hash(runSeed,tree.id,'descent-duration')*3;
    const fromY=Math.max(landing.y+3,tree.h+tree.height*(.55+hash(runSeed,tree.id,'descent-height')*.20));
    const trunk=trunkAt(tree,fromY),surfaceRadius=trunk.radius+.08;
    const position={x:trunk.x+Math.cos(landing.angle)*surfaceRadius,y:fromY,z:trunk.z+Math.sin(landing.angle)*surfaceRadius};
    const senses=player?evaluateTeethpeedSenses({position,player,heightAt,colliders,originTree:tree}):null;
    if(!forced&&(!player||Math.hypot(player.x-tree.x,player.z-tree.z)>TRIGGER_DISTANCE||!senses?.lineOfSight))return false;
    const record={
      treeId:tree.id,stage:'descending',remaining:total,health:100,
      position,
      heading:angleOf(landing.x-tree.x,landing.z-tree.z),
      descent:{fromY,toY:landing.y,total,elapsed:0,treeX:tree.x,treeZ:tree.z,angle:landing.angle,surfaceRadius,landingRadius:landing.radius},
      attackDuration:60+hash(runSeed,tree.id,'attack-duration')*60,
      biteCooldown:0,retreatRemaining:0,retreatHeading:0,
      lastKnownPlayer:senses?.lineOfSight?{x:player.x,y:finite(player.y)?player.y:heightAt(player.x,player.z),z:player.z}:null,
      searchTarget:null,huntingTime:0,searchIndex:0,searchWait:0,sightLostFor:0,sightFoundFor:0,senses,
      hidingId:null,hidingFound:false,hidingRolls:0,
    };
    spent.add(tree.id);active.push(record);
    emit('descent',record,{duration:total});return true;
  }

  function triggerNearby(player) {
    if(isSafeAt(player.x,player.z)||active.length>=capacity||forestAt(player.x,player.z)<.35)return;
    const candidates=[];
    const cx=Math.floor(player.x/CELL_SIZE),cz=Math.floor(player.z/CELL_SIZE);
    for(let x=cx-1;x<=cx+1;x++)for(let z=cz-1;z<=cz+1;z++)for(const tree of treeGrid.get(`${x},${z}`)||[]) {
      const distance=Math.hypot(tree.x-player.x,tree.z-player.z);
      if(distance<=TRIGGER_DISTANCE&&!spent.has(tree.id))candidates.push({tree,distance});
    }
    candidates.sort((a,b)=>a.distance-b.distance||a.tree.id.localeCompare(b.tree.id));
    for(const {tree} of candidates) {
      if(active.length>=capacity)break;
      start(tree,player);
    }
  }

  function move(record,directionX,directionZ,speed,dt,stopAt=0) {
    const length=Math.hypot(directionX,directionZ);
    if(length<=stopAt||length<1e-8)return 0;
    const step=Math.min(speed*dt,Math.max(0,length-stopAt));
    let base=Math.atan2(directionZ,directionX);
    const groundedAge=record.attackDuration-record.remaining;
    if(record.stage==='retreating'||(record.stage==='attacking'||record.stage==='hunting')&&groundedAge<LANDING_STEER_SECONDS) {
      const forward=Math.atan2(-Math.cos(record.heading),-Math.sin(record.heading)),difference=Math.atan2(Math.sin(base-forward),Math.cos(base-forward));
      const turnLimit=record.stage==='retreating'?2.8*dt:Math.PI*dt/LANDING_STEER_SECONDS;
      base=forward+clamp(difference,-turnLimit,turnLimit);
    }
    const preferred=hash(runSeed,record.treeId,'avoidance-side')<.5?1:-1;
    const offsets=[0,preferred*Math.PI/12,-preferred*Math.PI/12,preferred*Math.PI/6,-preferred*Math.PI/6,preferred*Math.PI/3,-preferred*Math.PI/3,preferred*Math.PI/2,-preferred*Math.PI/2,preferred*Math.PI*.67,-preferred*Math.PI*.67];
    let best=null,bestScore=-Infinity;
    for(const offset of offsets) {
      const angle=base+offset,dx=Math.cos(angle)*step,dz=Math.sin(angle)*step;
      const x=record.position.x+dx,z=record.position.z+dz,y=validStep(record.position,x,z);
      if(y===null)continue;
      // Prefer progress, with a small continuity preference to avoid left/right oscillation.
      const score=Math.cos(offset)*2+.13*Math.cos(angleOf(dx,dz)-record.heading);
      if(score>bestScore){best={x,y,z,dx,dz};bestScore=score;}
      if(offset===0)break;
    }
    if(!best)return 0;
    record.position={x:best.x,y:best.y,z:best.z};record.heading=angleOf(best.dx,best.dz);
    return step;
  }

  function beginRetreat(record,player) {
    record.stage='retreating';record.remaining=Math.max(4+hash(runSeed,record.treeId,'retreat-duration')*2,record.descent.total-record.descent.elapsed+.5);
    record.retreatRemaining=record.remaining;
    record.lastKnownPlayer=null;record.searchTarget=null;
    if(record.senses){record.senses.lineOfSight=false;record.senses.withinDetection=false;}
    let dx=record.position.x-player.x,dz=record.position.z-player.z;
    if(Math.hypot(dx,dz)<.01){dx=Math.cos(record.descent.angle);dz=Math.sin(record.descent.angle);}
    record.retreatHeading=angleOf(dx,dz);
    emit('retreat',record,{duration:record.remaining});
  }

  function bitePathClear(from,to) {
    const safeSamples=Math.max(1,Math.ceil(Math.hypot(to.x-from.x,to.z-from.z)/.2));
    for(let i=0;i<=safeSamples;i++){const t=i/safeSamples;if(isSafeAt(from.x+(to.x-from.x)*t,from.z+(to.z-from.z)*t))return false;}
    const dx=to.x-from.x,dz=to.z-from.z,length2=dx*dx+dz*dz,checked=new Set();
    for(let x=Math.floor(Math.min(from.x,to.x)/CELL_SIZE);x<=Math.floor(Math.max(from.x,to.x)/CELL_SIZE);x++) {
      for(let z=Math.floor(Math.min(from.z,to.z)/CELL_SIZE);z<=Math.floor(Math.max(from.z,to.z)/CELL_SIZE);z++) {
        for(const c of colliderGrid.get(`${x},${z}`)||[]) {
          if(checked.has(c))continue;checked.add(c);
          const t=length2>1e-12?clamp(((c.x-from.x)*dx+(c.z-from.z)*dz)/length2,0,1):0;
          if(Math.hypot(from.x+dx*t-c.x,from.z+dz*t-c.z)<c.radius+.04)return false;
        }
      }
    }
    return true;
  }

  function perceive(record,player) {
    record.senses=evaluateTeethpeedSenses({position:record.position,player,heightAt,colliders,
      ...(record.stage==='descending'?{originTree:treeById.get(record.treeId)}:{})});
    if(isSafeAt(player.x,player.z)){record.senses.lineOfSight=false;record.senses.withinDetection=false;return record.senses;}
    if(player.concealed&&player.hidingId){
      if(record.hidingId!==player.hidingId){record.hidingId=player.hidingId;record.hidingFound=false;record.hidingRolls=0;}
      if(record.stage==='hunting'&&record.senses.lineOfSight&&record.hidingRolls===0){record.hidingRolls=1;record.hidingFound=hash(runSeed,record.treeId,`bush:${record.hidingId}`)<.45;}
      if(!record.hidingFound)record.senses.lineOfSight=false;
      record.senses.concealed=true;record.senses.hidingFound=record.hidingFound;
    }else{record.hidingId=null;record.hidingFound=false;record.hidingRolls=0;}
    if(record.senses.lineOfSight)record.lastKnownPlayer={x:player.x,y:finite(player.y)?player.y:heightAt(player.x,player.z),z:player.z};
    return record.senses;
  }
  function beginHunting(record) {
    record.stage='hunting';record.sightFoundFor=0;record.sightLostFor=0;
    record.searchTarget={...(record.lastKnownPlayer||record.position)};record.searchIndex=0;record.searchWait=0;
    emit('hunting',record);
  }
  function chooseSearchTarget(record) {
    const center=record.lastKnownPlayer||record.position;
    for(let attempt=0;attempt<14;attempt++) {
      const index=++record.searchIndex,angle=hash(runSeed,record.treeId,'search-angle')*TAU+index*2.39996323;
      const radius=1.6+Math.min(6,index*.47),x=center.x+Math.cos(angle)*radius,z=center.z+Math.sin(angle)*radius,y=canOccupy(x,z);
      if(y!==null){record.searchTarget={x,y,z};record.searchWait=0;return;}
    }
    record.searchTarget={...record.position};record.searchWait=0;
  }
  function search(record,amount) {
    record.huntingTime=Math.min(120,record.huntingTime+amount);
    if(!record.searchTarget)record.searchTarget={...(record.lastKnownPlayer||record.position)};
    const target=record.searchTarget,dx=target.x-record.position.x,dz=target.z-record.position.z;
    const arrived=Math.hypot(dx,dz)<=1.0;
    const travelled=arrived?0:move(record,dx,dz,TEETHPEED_SPEED,amount,.8);
    if(arrived||travelled<.00001) {
      record.searchWait+=amount;record.heading+=amount*.65;
      if(record.searchWait>=1.1)chooseSearchTarget(record);
    } else record.searchWait=0;
  }

  function advance(record,dt,player) {
    if(record.stage!=='retreating'&&(isSafeAt(player.x,player.z)||isSafeAt(record.position.x,record.position.z)))beginRetreat(record,player);
    let left=dt;
    while(left>1e-8&&active.includes(record)) {
      const amount=Math.min(left,Math.max(0,record.remaining));
      if(record.stage==='descending') {
        const d=record.descent;
        d.elapsed=Math.min(d.total,d.elapsed+amount);record.remaining=Math.max(0,d.total-d.elapsed);
        const motion=descentPath(record),trunk=trunkAt(treeById.get(record.treeId),motion.position.y);
        d.surfaceRadius=trunk.radius+.08;
        const pose=getTeethpeedDescentPose(record,runSeed);
        record.position=motion.position;
        record.heading=angleOf(Math.cos(pose.angle),Math.sin(pose.angle));
        perceive(record,player);
        left-=amount;
        if(record.remaining<=1e-8) {
          record.stage='attacking';record.remaining=record.attackDuration;record.biteCooldown=0;
          const sense=perceive(record,player);
          if(sense.lineOfSight) {
            emit('attack',record,{duration:record.attackDuration});
          } else beginHunting(record);
        }
      } else if(record.stage==='attacking'||record.stage==='hunting') {
        record.remaining=Math.max(0,record.remaining-amount);
        record.biteCooldown=Math.max(0,record.biteCooldown-amount);
        left-=amount;
        if(record.remaining<=1e-8) {beginRetreat(record,player);continue;}
        const senses=perceive(record,player);
        if(record.stage==='attacking') {
          record.sightLostFor=senses.lineOfSight?0:record.sightLostFor+amount;
          if(record.sightLostFor>=SIGHT_CONFIRM_TIME-1e-8)beginHunting(record);
        } else {
          record.sightFoundFor=senses.lineOfSight?record.sightFoundFor+amount:0;
          if(record.sightFoundFor>=SIGHT_CONFIRM_TIME-1e-8) {
            record.stage='attacking';record.sightLostFor=0;record.sightFoundFor=0;record.searchTarget=null;record.searchWait=0;
            emit('reacquired',record);
          }
        }
        if(record.stage==='hunting') {search(record,amount);continue;}
        // While sight is briefly being confirmed lost, only the remembered
        // position may guide movement. Hidden players never update that memory.
        const target=senses.lineOfSight?player:record.lastKnownPlayer;
        if(target)move(record,target.x-record.position.x,target.z-record.position.z,TEETHPEED_SPEED,amount,STOP_DISTANCE);
        const playerY=finite(player.y)?player.y:heightAt(player.x,player.z);
        if(!isSafeAt(player.x,player.z)&&senses.lineOfSight&&record.biteCooldown<=1e-8&&Math.hypot(player.x-record.position.x,player.z-record.position.z)<=BITE_DISTANCE&&finite(playerY)&&Math.abs(playerY-record.position.y)<=1.8&&bitePathClear(record.position,player)&&hasTeethpeedLineOfSight({position:record.position,player,heightAt,colliders})) {
          record.biteCooldown=TEETHPEED_BITE_INTERVAL;
          onDamage(TEETHPEED_BITE_DAMAGE,'Teethpeed',copyActive(record));
          emit('bite',record,{damage:TEETHPEED_BITE_DAMAGE,cause:'Teethpeed'});
        }
      } else {
        // A cancelled tree encounter finishes its existing landing path without
        // snapping from upright bark to the ground; it cannot attack or reacquire.
        const d=record.descent;
        if(d.elapsed<d.total){
          const remainingDescent=d.total-d.elapsed,descentStep=Math.min(amount,remainingDescent);
          d.elapsed=Math.min(d.total,d.elapsed+descentStep);
          const motion=descentPath(record),pose=getTeethpeedDescentPose(record,runSeed),trunk=trunkAt(treeById.get(record.treeId),motion.position.y);
          d.surfaceRadius=trunk.radius+.08;
          if(!isSafeAt(motion.position.x,motion.position.z))record.position=motion.position;
          record.heading=angleOf(Math.cos(pose.angle),Math.sin(pose.angle));
          if(amount>descentStep)move(record,-Math.sin(record.retreatHeading)*100,-Math.cos(record.retreatHeading)*100,3.1,amount-descentStep);
        }else move(record,-Math.sin(record.retreatHeading)*100,-Math.cos(record.retreatHeading)*100,3.1,amount);
        record.remaining=Math.max(0,record.remaining-amount);record.retreatRemaining=record.remaining;left-=amount;
        if(record.remaining<=1e-8) {
          active=active.filter(value=>value!==record);emit('departed',record);
        }
      }
    }
  }

  return {
    updateMany(dt,players) {
      const valid=Array.isArray(players)?players.filter(p=>p&&[p.x,p.z].every(finite)&&p.alive!==false&&p.connected!==false):[];
      if(!finite(dt)||dt<=0||!valid.length)return;
      for(const p of valid)triggerNearby(p);
      let remaining=Math.min(dt,.25);
      while(remaining>1e-8){const step=Math.min(remaining,.05);remaining-=step;clock+=step;
        for(const record of [...active]){
          const eligible=valid.filter(p=>!isSafeAt(p.x,p.z));
          const player=[...(eligible.length?eligible:valid)].sort((a,b)=>Math.hypot(a.x-record.position.x,a.z-record.position.z)-Math.hypot(b.x-record.position.x,b.z-record.position.z))[0];
          record.targetPlayerId=player.id;lastPlayer=player;advance(record,step,player);
        }
      }
    },
    update(dt,player) {
      if(!finite(dt)||dt<=0||!player||![player.x,player.z].every(finite))return;
      lastPlayer={x:player.x,z:player.z,y:player.y,concealed:!!player.concealed,hidingId:player.hidingId||null};
      triggerNearby(lastPlayer);
      let remaining=Math.min(dt,.25);
      while(remaining>1e-8) {
        const step=Math.min(remaining,.05);remaining-=step;clock+=step;
        for(const record of [...active])advance(record,step,lastPlayer);
      }
    },
    snapshot,
    damage(treeId,amount){
      const record=active.find(r=>r.treeId===treeId);if(!record||!finite(amount)||amount<=0)return null;
      record.health=Math.max(0,(record.health??100)-amount);const killed=record.health<=0;
      if(killed){active=active.filter(r=>r!==record);emit('killed',record);}
      return{hit:true,killed,health:record.health,loot:killed?{raw_meat:2,chitin:3,venom:1}:null};
    },
    getActive:()=>active.map(record=>{
      let descentPose=null;
      if(record.stage==='descending'||record.stage==='retreating'&&record.descent.elapsed<record.descent.total){
        const motion=descentPath(record);
        descentPose={...getTeethpeedDescentPose(record,runSeed),velocity:{...motion.velocity},verticalSpeed:motion.velocity.y};
      }
      return {...copyActive(record),descentPose};
    }),
    forceEncounter(treeId,player=lastPlayer) { return start(treeById.get(String(treeId)),player,true); },
    getEligibility(treeId) {
      const tree=treeById.get(String(treeId));
      return !!tree&&!isSafeAt(tree.x,tree.z)&&forestAt(tree.x,tree.z)>=.48&&passesTeethpeedChance(treeEncounterChance(runSeed,tree.id));
    },
  };
}
