import {createSoundscape} from './audio.js';

const $=id=>document.getElementById(id);
const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const listener={x:0,y:11.6,z:0,yaw:0};
const trees=Array.from({length:8},(_,i)=>({id:`sound-check-tree-${i}`,x:Math.cos(i/8*Math.PI*2)*(3+i*.45),z:Math.sin(i/8*Math.PI*2)*(3+i*.45),h:10,height:38+i,radius:1.2}));
const emptyFrame=()=>({listener,biome:'forest',trees:[],teethpeeds:[],plane:null});
let sound=null,runToken=0,running=false,frameFactory=emptyFrame,meterLoop=0,lastFrame=0,frameSeconds=0,resumeAction=null,results=[];

function state() {return sound?.getState?.() || {};}
function rms(s=state()) {return Number(s.rms ?? s.outputRms ?? 0);}
function voices(s=state()) {return Number(s.activeVoices ?? s.voices ?? 0);}
function count(name,s=state()) {
  const value=s.counters?.[name];
  assert(Number.isFinite(value),`Audio diagnostics are missing the ${name} counter.`);return value;
}
function addResult(name,passed,error) {
  results.push({name,passed,error});const row=document.createElement('li');row.className=passed?'pass':'fail';
  const badge=document.createElement('strong');badge.textContent=passed?'PASS':'FAIL';const title=document.createElement('span');title.textContent=name;row.append(badge,title);
  if(error){const detail=document.createElement('p');detail.textContent=error;row.append(detail);}$('results').append(row);
  $('summary').textContent=`${results.filter(r=>r.passed).length} passed · ${results.filter(r=>!r.passed).length} failed · Checks in progress`;
}
function drawMeter(now) {
  const dt=lastFrame?Math.min(.1,(now-lastFrame)/1000):1/60;lastFrame=now;frameSeconds+=dt;
  if(sound&&running)sound.update(dt,frameFactory(frameSeconds));
  const s=state(),level=rms(s),db=level>1e-8?20*Math.log10(level):-100,percent=Math.max(0,Math.min(100,(db+70)/70*100));
  $('level-bar').style.width=`${percent}%`;document.querySelector('.bar').setAttribute('aria-valuenow',percent.toFixed(1));
  $('meter-value').textContent=level>1e-7?`${db.toFixed(1)} dBFS · RMS ${level.toFixed(5)}`:'Silent';
  $('context-state').textContent=`Context: ${s.contextState||s.context||'not started'}`;
  $('voice-count').textContent=`Voices: ${voices(s)}${s.maxVoices!==undefined?` / ${s.maxVoices}`:''}`;
  const counters=s.counters||{},environment=Object.entries(counters).filter(([key])=>/tree|teeth|rustle|creak|tick/i.test(key)).reduce((sum,[,value])=>sum+(Number(value)||0),0);
  $('environment-count').textContent=`Environment events: ${environment}`;
  meterLoop=requestAnimationFrame(drawMeter);
}
async function sample(ms,token) {
  const start=performance.now(),levels=[],voiceCounts=[];
  while(performance.now()-start<ms) {
    if(token!==runToken)throw new Error('Sound checks stopped.');
    levels.push(rms());voiceCounts.push(voices());await new Promise(resolve=>setTimeout(resolve,30));
  }
  return {peak:Math.max(0,...levels),tail:Math.max(0,...levels.slice(-5)),voices:Math.max(0,...voiceCounts)};
}
async function check(name,fn,token) {
  if(token!==runToken)return;try{await fn();if(token===runToken)addResult(name,true);}catch(error){if(token===runToken)addResult(name,false,error.message);}
}
function stop() {
  runToken++;running=false;frameFactory=emptyFrame;resumeAction?.();resumeAction=null;
  sound?.activate(false);sound?.dispose?.();sound=null;
  $('resume-checks').hidden=true;$('stop-checks').disabled=true;$('start-checks').disabled=false;
  $('phase').textContent='Sound stopped.';$('summary').textContent='Checks stopped. Your journey is untouched.';
}
async function run(token) {
  let baseline=0;
  await check('Enabled sound produces measurable output after the Start gesture',async()=>{
    $('phase').textContent='Listening to the wind bed and measuring the actual output…';
    const measured=await sample(900,token),s=state();baseline=measured.tail;
    assert((s.contextState||s.context)==='running','The audio context did not enter its running state.');
    assert(measured.tail>1e-5,'Enabled audio produced no measurable output.');
  },token);
  await check('Muting silences output and prevents environmental voices',async()=>{
    $('phase').textContent='Muting the soundscape. The output meter should fall to silence.';
    sound.setEnabled(false);frameFactory=()=>({...emptyFrame(),trees,teethpeeds:[{id:'muted-teethpeed',stage:'attacking',position:{x:4,y:10,z:0},speed:4.45}]});
    const before=state();await sample(400,token);const measured=await sample(250,token);
    assert(measured.tail<Math.max(2e-6,baseline*.02),'Muted output remained audible in the analyser.');
    assert(count('creatureTicks')===count('creatureTicks',before),'Muted motion emitted creature ticks.');frameFactory=emptyFrame;
  },token);
  await check('Pausing stops sound until a new Resume gesture',async()=>{
    sound.setEnabled(true);await sample(250,token);sound.activate(false);
    $('phase').textContent='Paused. Checking that the output has stopped…';await sample(400,token);const muted=await sample(250,token);
    assert(muted.tail<Math.max(2e-6,baseline*.02),'Paused output did not become silent.');
  },token);
  if(token!==runToken)return;
  $('phase').textContent='Pause verified. Click Resume sound checks to continue with forest and crash sounds.';
  $('summary').textContent='Waiting for your Resume sound checks gesture.';$('resume-checks').hidden=false;
  await new Promise(resolve=>{resumeAction=()=>{resumeAction=null;resolve();};});
  if(token!==runToken)return;
  await check('The Resume gesture restores measurable sound',async()=>{
    const measured=await sample(600,token);assert(measured.tail>1e-5,'The resumed context produced no sound.');
  },token);
  await check('Nearby trees produce rustles and wood creaks',async()=>{
    $('phase').textContent='Moving beneath synthetic nearby trees: listen for rustling and wood creaks.';
    const before=state();frameFactory=()=>({...emptyFrame(),trees});
    await sample(2300,token);
    assert(count('treeRustles')>count('treeRustles',before),'Nearby trees did not emit rustles.');
    assert(count('treeCreaks')>count('treeCreaks',before),'Nearby trees did not emit creaks.');
  },token);
  await check('Distant trees stop creating nearby tree voices',async()=>{
    frameFactory=()=>({...emptyFrame(),trees:trees.map(t=>({...t,x:t.x+500,z:t.z+500}))});
    await sample(550,token); // Allow the half-second nearest-tree scan to observe the new fixtures.
    const before=state();await sample(400,token);
    assert(count('treeRustles')===count('treeRustles',before)&&count('treeCreaks')===count('treeCreaks',before),'Distant trees continued emitting local forest voices.');
  },token);
  await check('A descending Teethpeed emits audible movement ticks',async()=>{
    $('phase').textContent='A nearby Teethpeed descends. Listen for dry clicking movement.';
    const before=state(),start=frameSeconds;frameFactory=t=>({...emptyFrame(),teethpeeds:[{id:'descending-check',stage:'descending',position:{x:4,y:15-(t-start)*.8,z:1},speed:.8}]});
    await sample(1000,token);assert(count('creatureTicks')>count('creatureTicks',before),'Descending movement did not emit ticks.');
    assert(count('creatureScratches')>count('creatureScratches',before),'Descending movement did not emit bark scratches.');
  },token);
  await check('An attacking Teethpeed emits faster movement ticks',async()=>{
    const before=state(),start=frameSeconds;frameFactory=t=>({...emptyFrame(),teethpeeds:[{id:'attacking-check',stage:'attacking',position:{x:Math.cos(t-start)*4,y:10,z:Math.sin(t-start)*4},speed:4.45}]});
    await sample(1000,token);assert(count('creatureTicks')>count('creatureTicks',before),'Attacking movement did not emit ticks.');
  },token);
  await check('Stationary and distant creatures stop ticking',async()=>{
    $('phase').textContent='The creature stops moving, then moves beyond hearing distance.';
    frameFactory=()=>({...emptyFrame(),teethpeeds:[{id:'stationary-check',stage:'attacking',position:{x:4,y:10,z:0},speed:0}]});
    const stationary=state();await sample(500,token);assert(count('creatureTicks')===count('creatureTicks',stationary),'A stationary creature emitted movement ticks.');
    frameFactory=()=>({...emptyFrame(),teethpeeds:[{id:'distant-check',stage:'attacking',position:{x:500,y:10,z:500},speed:4.45}]});
    const distant=state();await sample(500,token);assert(count('creatureTicks')===count('creatureTicks',distant),'A distant creature emitted nearby movement ticks.');frameFactory=emptyFrame;
  },token);
  await check('Crash timeline events create their corresponding sound voices',async()=>{
    $('phase').textContent='Checking aircraft failure, airframe stress, river contact and impact sounds.';
    const before=state();sound.plane(true);
    for(const type of ['engine-failure','airframe-stress','water-contact','impact']){sound.crashEvent(type,{position:{x:8,y:11,z:0},distance:8});await sample(200,token);}
    for(const counter of ['engineFailures','airframeStrains','waterContacts','impacts','metalTears'])assert(count(counter)>count(counter,before),`The ${counter} crash sound was not emitted.`);
    assert(voices()>0,'Crash events created no active voices.');
    const once=state();for(const type of ['engine-failure','airframe-stress','water-contact','impact'])sound.crashEvent(type,{distance:8});
    for(const counter of ['engineFailures','airframeStrains','waterContacts','impacts'])assert(count(counter)===count(counter,once),'A duplicate timeline event replayed its sound.');
  },token);
  await check('Overlapping crash effects respect the audio voice cap',async()=>{
    const cap=state().maxVoices;assert(Number.isFinite(cap)&&cap>0,'Audio diagnostics did not expose a voice cap.');
    for(let i=0;i<8;i++){sound.plane(true);sound.crashEvent('impact',{position:{x:40,y:11,z:0},distance:40});}
    const saturated=voices();assert(saturated===cap,`Synthetic overlap did not exercise the cap (${saturated}/${cap}).`);
    const measured=await sample(450,token);assert(measured.voices<=cap,`Active sound voices exceeded the cap (${measured.voices}/${cap}).`);
  },token);
  await check('Skipping cancels crash sounds and delayed debris while ambience continues',async()=>{
    $('phase').textContent='Skipping a synthetic impact. Crash sounds should stop while the environment remains audible.';
    const crashKind=kind=>/^(engine-|airframe-|metal-|river-impact-|fuselage-impact-|falling-debris$)/.test(kind);
    sound.plane(false); // Clear the preceding saturation fixture before this independent check.
    sound.thunder(.12);sound.plane(true);
    sound.crashEvent('impact',{position:{x:14,y:11,z:0},distance:14});
    const impact=state();assert(Array.isArray(impact.voiceKinds),'Audio diagnostics did not expose active voice kinds.');
    assert(impact.voiceKinds.includes('falling-debris')&&impact.voiceKinds.some(crashKind),'The impact fixture did not schedule crash sounds and delayed debris.');
    sound.plane(false);
    const skipped=state();assert(!skipped.voiceKinds.some(crashKind),'Skip left active or scheduled crash sounds behind.');
    assert(skipped.voiceKinds.includes('thunder-roll'),'Skip incorrectly cancelled a non-crash environment voice.');
    const measured=await sample(1700,token),after=state();
    assert(!after.voiceKinds.some(crashKind),'A delayed crash voice appeared after Skip.');
    assert(count('debris',after)===count('debris',skipped),'Additional debris sounds were scheduled after Skip.');
    assert(after.active&&after.audible&&measured.tail>1e-5,'Skip stopped the continuing environment soundscape.');
  },token);
  await check('Final Stop silences the entire soundscape',async()=>{
    $('phase').textContent='Stopping all sound after the checks.';sound.activate(false);await sample(400,token);const measured=await sample(250,token);
    assert(measured.tail<Math.max(2e-6,baseline*.02),'Output persisted after deactivation.');
  },token);
  if(token!==runToken)return;
  running=false;sound?.dispose?.();sound=null;$('resume-checks').hidden=true;$('start-checks').disabled=false;$('stop-checks').disabled=true;
  $('phase').textContent='Sound checks complete. Audio has stopped.';
  $('summary').textContent=`${results.filter(r=>r.passed).length} passed · ${results.filter(r=>!r.passed).length} failed · Journey save untouched`;
}

$('start-checks').addEventListener('click',()=>{
  if(running)return;const token=++runToken;results=[];frameFactory=emptyFrame;frameSeconds=0;lastFrame=0;
  $('results').replaceChildren();$('start-checks').disabled=true;$('stop-checks').disabled=false;running=true;
  // Context creation and resume remain directly inside the user's activation handler.
  sound=createSoundscape({enabled:true,volume:.40,onUnavailable:()=>{$('phase').textContent='Audio is unavailable in this browser.';}});sound.activate(true);
  run(token).catch(error=>{if(token===runToken){addResult('Sound check execution',false,error.message);sound?.activate(false);running=false;$('start-checks').disabled=false;}});
});
$('resume-checks').addEventListener('click',()=>{sound?.setEnabled(true);sound?.activate(true);$('resume-checks').hidden=true;resumeAction?.();});
$('stop-checks').addEventListener('click',stop);
window.addEventListener('pagehide',()=>{runToken++;sound?.activate(false);sound?.dispose?.();cancelAnimationFrame(meterLoop);});
meterLoop=requestAnimationFrame(drawMeter);
