import * as THREE from './vendor/three.module.js';

const clamp = n => Math.max(0, Math.min(1, n));
const UP = new THREE.Vector3(0, 1, 0);
export const PINE_SHOOT_ROOT_UV = Object.freeze({u: .518, v: .010});

function random(seed) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let n = Math.imul(seed ^ seed >>> 15, 1 | seed); n = n + Math.imul(n ^ n >>> 7, 61 | n) ^ n; return ((n ^ n >>> 14) >>> 0) / 4294967296; };
}

function geometryFrom(positions, uvs, indices) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); geometry.setIndex(indices); geometry.computeVertexNormals(); return geometry;
}

/** A 16 m conifer with physical support wood and rooted photographic needle shoots. */
export function createPineTreeGeometry() {
  const woodPosition = [], woodUV = [], woodIndex = [];
  const crownPosition = [], crownUV = [], crownIndex = [], shootRoots = [], shootFlex = [];
  const rng = random(8271), attachments = [], branchJoins = [];
  const tangent = new THREE.Vector3(), across = new THREE.Vector3(), normal = new THREE.Vector3();
  let boughCount = 0, twigCount = 0;

  function appendGeometry(geometry) {
    const offset = woodPosition.length / 3, p = geometry.attributes.position, uv = geometry.attributes.uv;
    for (let i = 0; i < p.count; i++) { woodPosition.push(p.getX(i), p.getY(i), p.getZ(i)); woodUV.push(uv.getX(i), uv.getY(i)); }
    for (const index of geometry.index.array) woodIndex.push(offset + index);
    geometry.dispose();
  }

  // Rings share a continuous centerline. Child twig origins use this same polyline.
  function support(points, radii, sides, textureOffset = 0) {
    const start = woodPosition.length / 3, distances = [0];
    for (let i = 1; i < points.length; i++) distances.push(distances[i - 1] + points[i - 1].distanceTo(points[i]));
    const length = distances.at(-1);
    for (let row = 0; row < points.length; row++) {
      tangent.subVectors(points[Math.min(row + 1, points.length - 1)], points[Math.max(0, row - 1)]).normalize();
      across.crossVectors(tangent, UP);
      if (across.lengthSq() < .00001) across.set(1, 0, 0); else across.normalize();
      normal.crossVectors(across, tangent).normalize();
      for (let side = 0; side <= sides; side++) {
        const angle = side / sides * Math.PI * 2, point = points[row].clone().addScaledVector(across, Math.cos(angle) * radii[row]).addScaledVector(normal, Math.sin(angle) * radii[row]);
        woodPosition.push(point.x, point.y, point.z); woodUV.push(side / sides + textureOffset, distances[row] / Math.max(.01, length) * Math.max(.08, length / 4));
        if (row < points.length - 1 && side < sides) {
          const at = start + row * (sides + 1) + side;
          woodIndex.push(at, at + sides + 1, at + 1, at + 1, at + sides + 1, at + sides + 2);
        }
      }
    }
  }

  function boughPoint(points, t) {
    const along = clamp(t) * (points.length - 1), segment = Math.min(points.length - 2, Math.floor(along));
    return points[segment].clone().lerp(points[segment + 1], along - segment);
  }

  function shoot(root, direction, widthAxis, length, halfWidth) {
    const first = crownPosition.length / 3;
    for (const [u, v] of [[0, 0], [1, 0], [1, 1], [0, 1]]) {
      const point = root.clone().addScaledVector(widthAxis, (u - PINE_SHOOT_ROOT_UV.u) * halfWidth * 2).addScaledVector(direction, (v - PINE_SHOOT_ROOT_UV.v) * length);
      crownPosition.push(point.x, point.y, point.z); crownUV.push(u, v); shootRoots.push(root.x, root.y, root.z);
      // Negative values below the actual stem root interpolate to exactly zero at the root.
      shootFlex.push((v - PINE_SHOOT_ROOT_UV.v) / (1 - PINE_SHOOT_ROOT_UV.v));
    }
    // Make the photographed stem base a real vertex, so vertex wind is exactly zero there.
    crownPosition.push(root.x, root.y, root.z); crownUV.push(PINE_SHOOT_ROOT_UV.u, PINE_SHOOT_ROOT_UV.v);
    shootRoots.push(root.x, root.y, root.z); shootFlex.push(0);
    crownIndex.push(first, first + 1, first + 4, first + 1, first + 2, first + 4, first + 2, first + 3, first + 4, first + 3, first, first + 4);
    attachments.push({firstVertex: first, rootVertex: first + 4, root: root.toArray(), rootUV: [PINE_SHOOT_ROOT_UV.u, PINE_SHOOT_ROOT_UV.v]});
  }

  // Preserve the original taper, trunk height and collision footprint.
  const trunk = new THREE.CylinderGeometry(.1, .33, 16, 7, 4); trunk.translate(0, 8, 0); appendGeometry(trunk);
  for (let tier = 0; tier < 15; tier++) {
    const y = 2.1 + tier * .98 + (rng() - .5) * .7;
    const radius = Math.pow(1 - tier / 15, .94) * 4.25 + .1, count = (tier > 10 ? 4 : 6) + Math.floor(rng() * 3);
    for (let branch = 0; branch < count; branch++) {
      const angle = branch / count * Math.PI * 2 + tier * 1.63 + rng() * .75;
      const ux = Math.cos(angle), uz = Math.sin(angle), vx = -uz, vz = ux;
      const length = radius * (.68 + rng() * .52), shootCount = Math.max(3, Math.ceil(length * 2.3));
      const points = [0, 1 / 3, 2 / 3, 1].map(t => new THREE.Vector3(ux * length * t, y - t * .65 + Math.sin(t * Math.PI) * .4, uz * length * t));
      const rootRadius = .027 + length * .018, branchRadii = [rootRadius, rootRadius * .68, rootRadius * .37, .008];
      support(points, branchRadii, 5, tier * .137); boughCount++;
      branchJoins.push({root: points[0].toArray(), trunkRadius: .33 - .23 * y / 16});
      for (let twig = 0; twig < shootCount; twig++) {
        const t = (twig + .7) / shootCount, side = twig % 2 ? 1 : -1;
        const along = length * t, spread = Math.sin(t * Math.PI) * .4 * side;
        const root = new THREE.Vector3(ux * along + vx * spread, y - t * .65 + Math.sin(t * Math.PI) * .4 + rng() * .3, uz * along + vz * spread);
        const shootAngle = angle + side * (.25 + rng() * .6);
        const direction = new THREE.Vector3(Math.cos(shootAngle), .12 + rng() * .52, Math.sin(shootAngle)).normalize();
        const sideways = new THREE.Vector3(-Math.sin(shootAngle), 0, Math.cos(shootAngle));
        const up = new THREE.Vector3().crossVectors(direction, sideways).normalize();
        const shootLength = .98 + rng() * .65, width = shootLength * .31;
        const origin = boughPoint(points, Math.max(0, t - .052));
        // The last 6% overlaps the atlas stem, including its small alpha-softened base.
        const stemEnd = root.clone().addScaledVector(direction, shootLength * .06);
        support([origin, root, stemEnd], [.023 + (1 - t) * .007, .014, .0075], 3, twig * .19); twigCount++;
        for (const rotation of [-.38, 1.23]) {
          const widthAxis = sideways.clone().multiplyScalar(Math.cos(rotation)).addScaledVector(up, Math.sin(rotation));
          shoot(root, direction, widthAxis, shootLength, width);
        }
      }
    }
  }
  const woodGeometry = geometryFrom(woodPosition, woodUV, woodIndex);
  const foliageGeometry = geometryFrom(crownPosition, crownUV, crownIndex);
  foliageGeometry.setAttribute('pineShootRoot', new THREE.Float32BufferAttribute(shootRoots, 3));
  foliageGeometry.setAttribute('pineShootFlex', new THREE.Float32BufferAttribute(shootFlex, 1));
  woodGeometry.computeBoundingBox(); woodGeometry.computeBoundingSphere(); foliageGeometry.computeBoundingBox(); foliageGeometry.computeBoundingSphere();
  return {
    woodGeometry, foliageGeometry,
    stats: {boughCount, twigCount, shootCards: attachments.length, woodTriangles: woodIndex.length / 3, foliageTriangles: crownIndex.length / 3},
    attachments, branchJoins,
  };
}

/** The same bend runs on support wood, crown and their shadow passes. */
export function applyPineWind(material, clock, foliage = false) {
  material.onBeforeCompile = shader => {
    shader.uniforms.uWindTime = clock;
    shader.vertexShader = 'uniform float uWindTime;\n' + (foliage ? 'attribute vec3 pineShootRoot;\nattribute float pineShootFlex;\n' : '') + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `
      #include <begin_vertex>
      vec3 treeAnchor = vec3(0.0);
      #ifdef USE_INSTANCING
        treeAnchor = instanceMatrix[3].xyz;
      #endif
      float branchHeight = clamp(position.y / 16.0, 0.0, 1.0);
      float windPhase = treeAnchor.x * .029 + treeAnchor.z * .017;
      float gust = .55 + .45 * sin(uWindTime * .37 + windPhase * .73);
      float sway = sin(uWindTime * .78 + windPhase) + .27 * sin(uWindTime * 1.61 + windPhase * 2.1);
      transformed.x += sway * gust * branchHeight * branchHeight * .280;
      transformed.z += cos(uWindTime * .64 + windPhase) * branchHeight * branchHeight * .1288;
      ${foliage ? `float needleFlex = clamp(pineShootFlex, 0.0, 1.0);
      needleFlex *= needleFlex;
      float shootPhase = pineShootRoot.x * 3.1 + pineShootRoot.z * 2.8 + pineShootRoot.y * .71 + windPhase;
      float flutter = sin(uWindTime * 2.45 + shootPhase);
      transformed.y += flutter * needleFlex * .045 * (.35 + gust * .65);
      transformed.x += sin(uWindTime * 3.0 + shootPhase * .81) * needleFlex * .013;` : ''}
    `);
  };
  material.customProgramCacheKey = () => `connected-pine-wind-v1-${foliage}`;
}
