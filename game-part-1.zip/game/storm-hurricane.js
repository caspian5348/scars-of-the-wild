import * as THREE from './vendor/three.module.js';
import {STORM_CENTER} from './biomes.js';
import {createStormNoiseTexture} from './storm-noise.js';

/** Broad rotating cloud bands are anchored above the northern Stormlands. */
export function createStormHurricane({scene,heightAt,noiseTexture=null}) {
  const group=new THREE.Group();group.name='Northern hurricane · fixed world cloud bands';scene.add(group);
  const centerHeight=heightAt(STORM_CENTER.x,STORM_CENTER.z),deck=centerHeight+118;
  const geometry=new THREE.PlaneGeometry(1,1);
  const noise=noiseTexture||createStormNoiseTexture();
  const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,fog:false,
    uniforms:{time:{value:0},flash:{value:0},fade:{value:1},stormNoise:{value:noise}},
    vertexShader:`varying vec2 cloudUv;varying vec3 cloudWorld;
      void main(){cloudUv=uv;vec4 p=vec4(position,1.);
        #ifdef USE_INSTANCING
          p=instanceMatrix*p;
        #endif
        cloudWorld=(modelMatrix*p).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(cloudWorld,1.);
      }`,
    fragmentShader:`varying vec2 cloudUv;varying vec3 cloudWorld;uniform float time;uniform float flash;uniform float fade;uniform sampler2D stormNoise;
      void main(){vec2 p=(cloudUv-.5)*2.;vec2 seed=cloudWorld.xz*.003;
        vec3 density=texture2D(stormNoise,p*.42+seed+vec2(time*.001,0.)).rgb;
        float billow=density.r;
        float edge=length(p*vec2(1.,1.06))+(billow-.5)*.42;
        float alpha=(1.-smoothstep(.56,.99,edge))*(.72+billow*.28)*fade;
        if(alpha<.012)discard;
        float detail=texture2D(stormNoise,p*.81+seed-vec2(time*.0015,time*.0005)).g;
        vec3 lower=vec3(.046,.052,.063),upper=vec3(.23,.25,.28);
        vec3 colour=mix(lower,upper,clamp(billow*.58+cloudUv.y*.27,0.,1.));
        colour+=vec3(.025,.028,.038)*detail;
        float violetPocket=.22+.78*density.b*density.b;
        colour+=vec3(.43,.055,.83)*flash*violetPocket;
        gl_FragColor=vec4(colour,alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
  });
  const bands=[];
  // Four interleaved spiral rain bands and a dense, broad inner cloud shield.
  for(let arm=0;arm<4;arm++)for(let j=0;j<18;j++){
    const t=j/17,r=28+t*292,angle=arm*Math.PI*.5+t*4.4;
    bands.push({r,angle,y:deck+Math.sin(t*3.8+arm)*13+t*8,w:91+Math.sin(t*Math.PI)*40,h:55+Math.sin(t*Math.PI)*18,speed:.010+(1-t)*.005});
  }
  for(let i=0;i<14;i++)bands.push({r:12+i%4*15,angle:i*2.399,y:deck+22+Math.sin(i*1.9)*14,w:110,h:80,speed:.012});
  const mesh=new THREE.InstancedMesh(geometry,material,bands.length);mesh.name='Layered hurricane cloud banks';mesh.frustumCulled=false;mesh.renderOrder=-15;group.add(mesh);
  const dummy=new THREE.Object3D(),cameraPoint=new THREE.Vector3(),up=new THREE.Vector3(0,1,0),side=new THREE.Vector3(),vertical=new THREE.Vector3(),direction=new THREE.Vector3(),basis=new THREE.Matrix4();
  let distance=0,canopyFade=1;
  return {
    update(time,camera,flash,{reducedMotion=false,localStrength=0}={}){
      const motionTime=reducedMotion?0:time;
      distance=Math.hypot(camera.x-STORM_CENTER.x,camera.z-STORM_CENTER.z);
      // Beneath the hurricane the local opaque ceiling already fills the sky.
      // Fade out overlapping distant cards instead of shading those layers again.
      canopyFade=1-THREE.MathUtils.smoothstep(localStrength,.24,.78);
      group.visible=distance<2300&&canopyFade>.005;
      if(!group.visible)return;
      material.uniforms.time.value=motionTime;material.uniforms.flash.value=reducedMotion?0:flash;
      material.uniforms.fade.value=(1-THREE.MathUtils.smoothstep(distance,1700,2300))*canopyFade;
      cameraPoint.copy(camera);
      for(let i=0;i<bands.length;i++){
        const p=bands[i],a=p.angle+motionTime*p.speed;
        dummy.position.set(STORM_CENTER.x+Math.cos(a)*p.r,p.y+Math.sin(motionTime*.10+i)*1.5,STORM_CENTER.z+Math.sin(a)*p.r*.79);
        direction.subVectors(cameraPoint,dummy.position).normalize();side.crossVectors(up,direction).normalize();
        if(side.lengthSq()<.001)side.set(1,0,0);
        vertical.crossVectors(direction,side).normalize();basis.makeBasis(side,vertical,direction);dummy.quaternion.setFromRotationMatrix(basis);
        dummy.scale.set(p.w,p.h,1);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
      }
      mesh.instanceMatrix.needsUpdate=true;
    },
    diagnostics(){return{center:{...STORM_CENTER},radius:320,cloudBanks:bands.length,cloudDeck:deck,visible:group.visible,distance:Math.round(distance),canopyFade,textureSamples:2};},
    dispose(){group.removeFromParent();geometry.dispose();material.dispose();mesh.dispose();if(!noiseTexture)noise.dispose();}
  };
}
