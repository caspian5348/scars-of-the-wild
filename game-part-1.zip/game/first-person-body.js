import * as THREE from './vendor/three.module.js';
import {normalizeCharacterProfile} from './character-profile.js';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));

/** Camera-space equipment support. Player hands and arms are never rendered. */
export function createFirstPersonBody(camera){
  const root=new THREE.Group();root.name='First person equipment support';camera.add(root);
  const wrist=new THREE.Group();wrist.name='Invisible equipment pivot';root.add(wrist);
  const toolMount=new THREE.Group();toolMount.name='Equipment attachment';wrist.add(toolMount);
  toolMount.position.set(0,.128,-.039);toolMount.rotation.set(.25,.10,1.10);
  let disposed=false,profile=normalizeCharacterProfile(),elapsed=0,gait=0,waterBlend=0,walkBlend=0,runBlend=0,mode='idle';
  function setProfile(value){if(!disposed)profile=normalizeCharacterProfile(value);}
  function update(dt,moving,visible,locomotion={},attack=0){
    if(disposed)return waterBlend;root.visible=Boolean(visible);if(!root.visible)return waterBlend;
    dt=Number.isFinite(dt)?clamp(dt,0,.1):0;
    const swim=Boolean(locomotion.swimming),run=Boolean(moving&&locomotion.sprinting&&!swim),motion=locomotion.motionEffects===false?.30:1;
    const speed=Number.isFinite(locomotion.speed)?clamp(locomotion.speed,0,12):moving?4.2:0;
    const blend=1-Math.exp(-dt*8),mix=(from,to)=>from+(to-from)*blend;
    elapsed+=dt;walkBlend=mix(walkBlend,moving?1:0);runBlend=mix(runBlend,run?1:0);waterBlend=mix(waterBlend,swim?1:0);
    gait+=dt*(run?10.3:6.8)*clamp(speed/(run?7.2:4.2),.65,1.30);
    const sway=Math.sin(gait),breath=Math.sin(elapsed*1.7)*.003*motion,strike=clamp(Number.isFinite(attack)?attack:0);
    wrist.position.set(.239-strike*.14,-.38+breath+sway*(.014+runBlend*.06)*walkBlend*motion+strike*.09,-.545+sway*(.015+runBlend*.05)*walkBlend*motion-strike*.16);
    wrist.rotation.set(-.25+sway*.05*walkBlend*motion-strike*.62,-.10+strike*.12,-1.10+sway*.08*runBlend*motion-strike*.36);
    mode=swim?(moving?'swimming':'treading water'):run?'running':moving?'walking':'idle';
    return waterBlend;
  }
  function getDiagnostics(){return{mode,visible:false,handsVisible:false,equipmentMountVisible:root.visible,skinTone:profile.skinTone,bodyType:profile.bodyType,topColor:profile.topColor,sleeve:profile.sleeve,waterBlend:Number(waterBlend.toFixed(3)),hands:[]};}
  update(0,false,false);
  return{root,toolMount,setProfile,update,getDiagnostics,dispose(){if(disposed)return;disposed=true;root.removeFromParent();root.clear();}};
}