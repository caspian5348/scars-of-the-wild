import * as THREE from './vendor/three.module.js';
import {createCrashSequence,CRASH_TIMING} from './crash.js';
import {riverX,heightAt,WATER_LEVEL} from './world.js';

const button=document.getElementById('run-checks'),summary=document.getElementById('summary'),results=document.getElementById('results');
const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const near=(a,b,epsilon=1e-6)=>Math.abs(a-b)<epsilon;
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
button.addEventListener('click',async()=>{
  button.disabled=true;results.replaceChildren();summary.textContent='Checking…';
  let passed=0,total=0,sequence;
  const events=[],scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(68,16/9,.09,1700);
  const run=async(name,test)=>{
    total++;const row=document.createElement('li');
    try{await test();passed++;row.className='pass';row.textContent=`PASS · ${name}`;}catch(error){row.className='fail';row.textContent=`FAIL · ${name}: ${error.message}`;}
    results.append(row);summary.textContent=`${passed} / ${total} checks passed`;await new Promise(requestAnimationFrame);
  };
  try{
    sequence=createCrashSequence({scene,camera,riverX,heightAt,waterLevel:WATER_LEVEL,onEvent:event=>events.push(event)});
    const reset=()=>{events.length=0;sequence.start();};
    const advance=(duration,step=.1)=>{let remaining=duration;while(remaining>1e-9){const amount=Math.min(step,remaining);sequence.update(amount);remaining-=amount;}};
    const colliders=JSON.stringify(sequence.colliders);
    await run('Opening lasts at least 24 seconds with ordered failure and impact stages',()=>{
      const t=CRASH_TIMING;assert(t.duration>=24,'Opening is too short');assert(t.engineFailure<t.airframeStress&&t.airframeStress<t.contact&&t.contact<t.impact&&t.impact<t.settled&&t.settled<t.duration,'Timeline is out of order');
    });
    await run('Aircraft begins over 300 metres from its final wreck',()=>{reset();const start=sequence.getState().position;sequence.finish();assert(distance(start,sequence.getState().position)>300,'Distant approach is missing');});
    await run('Aircraft and effects contain finite geometry and transforms',()=>{
      let meshes=0;scene.updateMatrixWorld(true);scene.traverse(node=>{assert(node.matrixWorld.elements.every(Number.isFinite),`Invalid transform: ${node.name}`);if(node.isMesh){meshes++;for(const name of ['position','normal']){const attr=node.geometry.getAttribute(name);if(attr)assert(attr.array.every(Number.isFinite),`Invalid ${name}: ${node.name}`);}}});assert(meshes>10,'Aircraft geometry missing');
    });
    await run('Invalid and negative time steps leave the active flight unchanged',()=>{reset();const state=JSON.stringify(sequence.getState());for(const dt of [-1,NaN,Infinity,0])sequence.update(dt);assert(JSON.stringify(sequence.getState())===state,'Invalid time changed flight');});
    await run('Every crash sound cue fires exactly once in timeline order',()=>{
      reset();advance(CRASH_TIMING.duration+1);const types=events.map(event=>event.type);assert(JSON.stringify(types)===JSON.stringify(['engine-failure','airframe-stress','water-contact','impact','settled']),`Unexpected events ${types}`);
    });
    await run('Event timestamps match physical contact and impact',()=>{
      for(const [type,key] of [['engine-failure','engineFailure'],['airframe-stress','airframeStress'],['water-contact','contact'],['impact','impact'],['settled','settled']])assert(near(events.find(event=>event.type===type)?.time,CRASH_TIMING[key]),`${type} timing drift`);
    });
    await run('Flight and camera remain finite throughout the long crash',()=>{
      reset();for(let t=0;t<CRASH_TIMING.duration;t+=.1){sequence.update(.1);const p=sequence.getState().position;assert([p.x,p.y,p.z,...camera.position.toArray(),...camera.quaternion.toArray()].every(Number.isFinite),'Nonfinite crash pose');}
    });
    await run('Different frame rates reach the same aircraft position',()=>{
      reset();advance(18.5,1/60);const first=sequence.getState().position;reset();advance(18.5,.25);assert(distance(first,sequence.getState().position)<.001,'Flight varies with frame rate');
    });
    await run('Large time steps still deliver each crossed event exactly once',()=>{
      reset();sequence.update(CRASH_TIMING.duration+3);assert(events.length===5,'A long frame lost or duplicated an event');assert(sequence.getState().done,'Long step did not finish');
    });
    await run('Skipping is silent and repeated finish calls are harmless',()=>{
      reset();sequence.update(2);sequence.finish();sequence.finish();sequence.update(1);assert(events.length===0,'Skip replayed crash sounds');assert(sequence.getState().done,'Skip did not settle wreck');
    });
    await run('Restart resets time and permits exactly one new impact',()=>{
      reset();assert(near(sequence.getState().time,0),'Time did not reset');advance(CRASH_TIMING.impact+.1);assert(events.filter(event=>event.type==='impact').length===1,'Restart impact incorrect');
    });
    await run('Final wreck and survivor retain their established river locations',()=>{
      sequence.finish();assert(distance(sequence.getState().position,{x:riverX(-35),y:WATER_LEVEL+.28,z:-35})<.001,'Wreck moved');const s=sequence.survivor;assert(near(s.x,riverX(-25)-27)&&near(s.z,-25)&&near(s.yaw,-1.18)&&near(s.pitch,-.12),'Survivor moved');assert(JSON.stringify(sequence.colliders)===colliders,'Wreck collisions changed during playback');
    });
    await run('Reduced motion keeps the same timeline and river impact',()=>{
      const other=createCrashSequence({scene,camera,riverX,heightAt,waterLevel:WATER_LEVEL,reducedMotion:true});try{other.start();other.update(CRASH_TIMING.duration);assert(other.getState().done,'Reduced motion did not complete');assert(distance(other.getState().position,sequence.getState().position)<.001,'Reduced motion changed wreck');}finally{other.dispose();}
    });
    await run('Disposing the opening removes its scene objects',()=>{sequence.dispose();assert(scene.children.length===0,'Crash objects remain after disposal');sequence=null;});
  }catch(error){const row=document.createElement('li');row.className='fail';row.textContent=`SETUP FAILED · ${error.message}`;results.append(row);summary.textContent=`Unable to finish: ${error.message}`;}
  finally{sequence?.dispose();button.disabled=false;}
});
