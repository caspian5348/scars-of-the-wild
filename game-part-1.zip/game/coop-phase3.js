import * as THREE from './vendor/three.module.js';
import {createSurvivalSystem} from './survival-system.js';
import {createSurvivalUI} from './survival-ui.js';
import {createCampWorld} from './camp-world.js';
import {ITEMS,BUILDINGS} from './survival-catalog.js';
import {WILDLIFE_SPECIES} from './wildlife-catalog.js';
import {hasTeethpeedLineOfSight} from './teethpeed-senses.js';
const element=(tag,cls)=>{const e=document.createElement(tag);e.className=cls;document.querySelector('#game').append(e);return e;};

/** Client presentation for server-owned inventory, gathering and construction. */
export function createCoopPhase3({scene,world,client,initial,notify,onInventory,onRefreshCollision,creatures,getMovement}){
  let current=initial,survival=createSurvivalSystem({state:initial?.self?.survival}),camp=createCampWorld({scene,world,state:initial?.world?.camp,seed:initial.seed,buildings:BUILDINGS});
  let campRevision=initial?.world?.revision??-1,selectedBuild=null,rotation=0,p={x:0,y:0,z:0},dir=new THREE.Vector3(0,0,-1),flatDir=new THREE.Vector3(0,0,-1),info={},busy=false,hudTime=0,motion='idle',storageId=null,disposed=false;
  const vitals=element('div','survival-vitals'),prompt=element('div','interaction-prompt'),hotbar=element('div','survival-hotbar');
  async function action(type,extra={}){
    if(busy||disposed)return{ok:false,message:'Wait for your previous action.'};busy=true;
    try{
      const frame=getMovement?.()||{position:{...p},yaw:Math.atan2(-dir.x,-dir.z),pitch:Math.asin(THREE.MathUtils.clamp(dir.y,-1,1)),mode:ui.visible?'inventory':'playing',motion};
      await client.move(frame);
      if(disposed)return{ok:false,message:'You have left this world.'};
      const response=await client.action({type,...extra});const r=response.result??response;
      if(response.snapshot)applySnapshot(response.snapshot);
      if(r.ok&&r.storageId){storageId=r.storageId;ui.setStorage(storageId,r.contents||camp.storage(storageId)||[]);onInventory('storage');}
      const message=r.message||r.reason;if(message)notify(message);refresh();return r;
    }
    catch(error){notify(error.message||'Connection lost. Reconnect before acting.');return{ok:false,message:error.message};}finally{busy=false;}
  }
  const ui=createSurvivalUI({getSystem:()=>survival,onClose:()=>onInventory(null),species:{...WILDLIFE_SPECIES,teethpeed:{name:'Teethpeed',biomes:['forest']},deatheater:{name:'Deatheater',biomes:['storm']},burrowpeed:{name:'Burrowpeed',biomes:['forest','valley']}},
    onCraft:recipeId=>action('craft',{recipeId}),onEquip:uid=>action('equip',{uid}),onConsume:uid=>action('consume',{uid}),onRepair:uid=>action('repair',{uid}),onDrop:uid=>action('drop',{uid}),
    onBuild:type=>{selectedBuild=type;setBuildRotation(0);camp.selectBuild(type);onInventory(null);notify('E places this structure for everyone. R rotates; B cancels.');},
    onStorage:(buildingId,uid,count,operation)=>action('storage',{buildingId,uid,count,operation})});
  const quickSlots=()=>survival.snapshot().inventory.filter(s=>ITEMS[s.id]?.tool||ITEMS[s.id]?.slot==='hand'||ITEMS[s.id]?.kind==='weapon').slice(0,6);
  function refresh(){const s=survival.snapshot(),hand=survival.getEquipment(),parts=[['FOOD',`${Math.round(s.hunger)}%`],['WATER',`${Math.round(s.thirst)}%`],['EXPOSURE',s.temperature<-55?'Cold':s.temperature>55?'Hot':'Comfortable'],['IN HAND',hand?.item?.name||'Empty hands']];vitals.replaceChildren();
    for(const [label,value] of parts){const box=document.createElement('span'),strong=document.createElement('strong');box.textContent=label;strong.textContent=value;box.append(strong);vitals.append(box);}
    hotbar.replaceChildren();quickSlots().forEach((s,i)=>{const b=document.createElement('button');b.className='quick-slot'+(hand?.uid===s.uid?' equipped':'');b.textContent=`${i+1} · ${ITEMS[s.id].name}`;b.onclick=()=>action('equip',{uid:s.uid});hotbar.append(b);});const open=document.createElement('button');open.className='quick-slot';open.textContent='I · Inventory';open.onclick=()=>onInventory('inventory');hotbar.append(open);
  }
  function setBuildRotation(next){while(rotation!==next){camp.rotate();rotation=(rotation+1)%4;}}
  function applySnapshot(snapshot){if(disposed||!snapshot?.self?.survival||Number.isFinite(current?.serverTime)&&Number.isFinite(snapshot.serverTime)&&snapshot.serverTime<current.serverTime)return;current=snapshot;survival=createSurvivalSystem({state:snapshot.self.survival});
    if(snapshot.world?.camp&&snapshot.world.revision!==campRevision){campRevision=snapshot.world.revision;const collision=camp.applyNetworkState(snapshot.world.camp);if(collision)onRefreshCollision?.();}
    info=camp.update(0,{...p,survivalTime:survival.snapshot().elapsed},flatDir);survival.setStations(info.stations);
    if(storageId)ui.setStorage(storageId,camp.storage(storageId)||[]);
    if(ui.visible&&ui.tab!=='storage')ui.render();
  }
  function aimedInfection(){
    const eye=new THREE.Vector3(p.x,p.y+1.55,p.z);
    return (creatures?.infectedTargets?.()||[]).map(node=>{const target=new THREE.Vector3(node.position.x,node.position.y+.55,node.position.z),offset=target.clone().sub(eye),along=offset.dot(dir),off=offset.clone().addScaledVector(dir,-along).length();return{node,along,off,target};})
      .filter(t=>t.along>0&&t.along<5&&t.off<.75&&hasTeethpeedLineOfSight({position:p,player:t.node.position,heightAt:world.groundHeight,colliders:world.colliders,originEyeHeight:1.55,playerEyeHeight:.55}))
      .sort((a,b)=>a.along-b.along)[0]?.node;
  }
  function update(dt,player,direction,{active=true,swimming=false,moving=false,sprinting=false}={}){if(disposed)return; p={...player};dir.copy(direction).normalize();flatDir.set(dir.x,0,dir.z);if(flatDir.lengthSq()>.0001)flatDir.normalize();else flatDir.set(0,0,-1);motion=swimming?'swimming':moving?sprinting?'running':'walking':'idle';info=camp.update(0,{...p,survivalTime:survival.snapshot().elapsed},flatDir);survival.setStations(info.stations);creatures?.update(dt,p);
    const corpse=creatures?.nearbyCorpses(p)?.[0],infection=aimedInfection(),target=info.target;let text='',sub='';
    if(selectedBuild){text=`Place ${BUILDINGS[selectedBuild].name}`;sub=info.spot?.valid?'E place · R rotate · B cancel':info.spot?.reason;}
    else if(corpse){text=`Harvest ${corpse.name}`;sub='E collect food and materials';}
    else if(infection){text=`Infection heart · ${Math.ceil(infection.health)} / ${infection.maxHealth}`;sub='F or click to cut it down · Spikes are dangerous';}
    else if(target){text=target.kind==='drop'?('Dropped '+(ITEMS[target.item]?.name||target.item)+' · '+target.stack.count):target.kind==='tree'?'Chop tree':target.mineable?'Mine stone':target.item==='stone'?'Loose stone · 2':ITEMS[target.item]?.name||BUILDINGS[target.type]?.name||'Camp structure';sub=target.mineable?'E mine with a pickaxe':['resource','drop'].includes(target.kind)?'E pick up':target.kind==='tree'?'E chop with an axe':'E interact';}
    else if(swimming||world.groundHeight(p.x+dir.x*2,p.z+dir.z*2)<2.1){text='Water';sub='E drink · Fresh river water can carry illness';}
    prompt.hidden=!active||!text;prompt.textContent=text;const small=document.createElement('small');small.textContent=busy?'Waiting for server…':sub||'';prompt.append(small);vitals.hidden=hotbar.hidden=!active;hudTime+=dt;if(hudTime>.4){hudTime=0;refresh();}
    return info.concealment;
  }
  async function interact(){if(selectedBuild)return action('build',{buildingType:selectedBuild,rotation:rotation*Math.PI/2});
    const corpse=creatures?.nearbyCorpses(p)?.[0];if(corpse)return action('harvest',{targetId:corpse.id});
    return action('interact',{targetId:info.target?.id});
  }
  refresh();
  return{update,interact,attack:()=>action('attack'),applySnapshot,snapshot:()=>({version:1,survival:survival.snapshot(),world:camp.snapshot()}),getChasers:p=>creatures?.getChasers(p)||[],getConcealment:()=>info.concealment||{concealed:false,hidingId:null},
    open:section=>{ui.open(section);vitals.hidden=hotbar.hidden=prompt.hidden=true;},close:()=>ui.close(),cancelBuild(){selectedBuild=null;setBuildRotation(0);camp.selectBuild(null);},rotate(){setBuildRotation((rotation+1)%4);},quickEquip:i=>{const s=quickSlots()[i];if(s)action('equip',{uid:s.uid});},groundHeight:(x,z)=>camp.groundHeight(x,z),blocking:(x,z)=>camp.blocking(x,z),setCharacter(){},
    getDiagnostics:()=>({network:true,inventory:survival.snapshot(),camp:camp.getDiagnostics(),revision:campRevision,busy,selectedBuild,rotation,aimedInfection:aimedInfection()?.id||null}),get survival(){return survival;},get camp(){return camp;},get wildlife(){return null;},get burrowers(){return null;},dispose(){if(disposed)return;disposed=true;camp.dispose();ui.dispose();creatures?.dispose();vitals.remove();prompt.remove();hotbar.remove();}};
}
