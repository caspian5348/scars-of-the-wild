import * as THREE from './vendor/three.module.js';
import {CAVE_ENTRANCE,LAVA_LEVEL,lavaRadius,coastZ,iceBlendAt,biomeAt,isGlowSafeAt} from './biomes.js';
import {riverBankDistanceAt} from './river-network.js';
import {createCaveMaze} from './cave-mesh.js';
import {embeddedTreeHeight} from './terrain-surface.js';
import {createTreeInstanceRegistry} from './tree-instances.js';
const TAU=Math.PI*2;
function random(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};}
const hash=(x,z)=>{const n=Math.sin(x*127.1+z*311.7)*43758.5453;return n-Math.floor(n);};
function geometryFrom(positions,indices,uvs){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));if(uvs)g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));g.setIndex(indices);g.computeVertexNormals();g.computeBoundingSphere();return g;}

/** Local geometry only: walk-in caverns, molten caldera, glacier and open coast. */
export function createExpandedBiomes({group,heightAt,rockMaps,foliage,waterLevel=2}){
  const root=new THREE.Group();root.name='Outer wilderness biomes';group.add(root);
  const resources=new Set(),own=value=>(resources.add(value),value),colliders=[],trees=[],resourceNodes=[],bushZones=[],registry=createTreeInstanceRegistry(),clock={value:0},rng=random(726450),dummy=new THREE.Object3D();
  const regions=[];
  const region=(name,x,z,radius)=>{const node=new THREE.Group();node.name=name;root.add(node);regions.push({node,x,z,radius});return node;};
  const cave=region('Hollowroot subterranean maze',-605,-60,145),lava=region('Active lava caldera',610,-350,230),ice=region('Frostbound ice formations',-545,-570,320),coast=region('Sundrift palms and beach',0,545,1000);
  const basalt=own(new THREE.MeshStandardMaterial({...rockMaps,color:'#343537',roughness:.91,normalScale:new THREE.Vector2(1.1,1.1)}));
  function batch(parent,geometry,material,points,name,transform,cast=true){const mesh=own(new THREE.InstancedMesh(geometry,material,points.length));mesh.name=name;points.forEach((p,i)=>{dummy.position.set(0,0,0);dummy.rotation.set(0,0,0);dummy.scale.set(1,1,1);transform(p,dummy);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);registry.register(p.id,mesh,i,dummy.matrix);});mesh.castShadow=cast;mesh.receiveShadow=true;mesh.computeBoundingSphere();parent.add(mesh);return mesh;}

  const caveLayout=own(createCaveMaze({group:cave,heightAt,rockMaps}));
  colliders.push(...caveLayout.colliders);resourceNodes.push(...caveLayout.resourceNodes);
  const rubbleGeometry=own(new THREE.IcosahedronGeometry(1,1));
  // Keep lava, glacier and palm placement stable across this cave replacement.
  for(let i=0;i<1350;i++)rng();

  const lp=[610,LAVA_LEVEL,-350],li=[],luv=[.5,.5];
  for(let i=0;i<=160;i++){const a=i/160*TAU,r=lavaRadius(a);lp.push(610+Math.cos(a)*105*r,LAVA_LEVEL,-350+Math.sin(a)*77*r);luv.push(.5+Math.cos(a)*r*.5,.5+Math.sin(a)*r*.5);if(i>0)li.push(0,i,i+1);}
  const lavaMaterial=own(new THREE.MeshStandardMaterial({color:'#ba3b09',emissive:'#ff5d08',emissiveIntensity:2.4,roughness:.42,side:THREE.DoubleSide}));
  lavaMaterial.onBeforeCompile=shader=>{shader.uniforms.uLavaTime=clock;shader.vertexShader='varying vec3 vLavaPoint;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvLavaPoint=position;');shader.fragmentShader='uniform float uLavaTime;varying vec3 vLavaPoint;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>',`float flow=sin(vLavaPoint.x*.19+sin(vLavaPoint.z*.16+uLavaTime*.22)*2.1-uLavaTime*.36)*sin(vLavaPoint.z*.17-vLavaPoint.x*.07+uLavaTime*.16);float molten=smoothstep(-.3,.75,flow);diffuseColor.rgb=mix(vec3(.05,.018,.008),vec3(.95,.26,.015),molten);totalEmissiveRadiance=mix(vec3(.10,.012,.001),vec3(3.0,.65,.035),molten);`);};lavaMaterial.customProgramCacheKey=()=> 'molten-caldera-v1';
  const molten=new THREE.Mesh(own(geometryFrom(lp,li,luv)),lavaMaterial);molten.name='Hazardous flowing molten lava';lava.add(molten);
  const basaltPoints=[];
  for(let i=0;i<150;i++){const a=rng()*TAU,r=135+rng()*83,x=610+Math.cos(a)*r,z=-350+Math.sin(a)*r*.78,scale=1.2+Math.pow(rng(),2)*9;if(riverBankDistanceAt(x,z)<scale+3||isGlowSafeAt(x,z))continue;basaltPoints.push({x,z,y:heightAt(x,z),scale,angle:rng()*TAU});if(scale>3)colliders.push({x,z,radius:scale*.64,height:scale*1.5,kind:'basalt'});}
  batch(lava,rubbleGeometry,basalt,basaltPoints,'Jagged basalt and cooled lava crust',(p,o)=>{o.position.set(p.x,p.y+p.scale*.27,p.z);o.rotation.set(.15,p.angle,.12);o.scale.set(p.scale,p.scale*.75,p.scale*.85);});
  const flameGeometry=own(new THREE.PlaneGeometry(2.7,4.8));flameGeometry.translate(0,2.0,0);
  const flameMaterial=own(new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,uniforms:{time:clock},vertexShader:'uniform float time;varying vec2 vUv;varying float phase;void main(){vUv=uv;vec3 p=position;phase=instanceMatrix[3].x*.07+instanceMatrix[3].z*.03;p.x+=sin(time*3.0+phase+p.y)*p.y*.07;gl_Position=projectionMatrix*modelViewMatrix*instanceMatrix*vec4(p,1.0);}',fragmentShader:'uniform float time;varying vec2 vUv;varying float phase;void main(){float edge=abs(vUv.x-.5)*2.0;float flicker=sin(vUv.y*19.0-time*5.0+phase)*.07;float body=1.0-smoothstep(.12,max(.13,1.0-vUv.y+flicker),edge);float alpha=body*(1.0-vUv.y)*smoothstep(0.0,.12,vUv.y);gl_FragColor=vec4(mix(vec3(1.0,.06,.003),vec3(1.0,.64,.055),1.0-vUv.y),alpha*.70);\n#include <colorspace_fragment>\n}'}));
  const vents=[];for(let i=0;i<20;i++){const a=i/20*TAU,r=lavaRadius(a)*1.035;vents.push({x:610+Math.cos(a)*105*r,z:-350+Math.sin(a)*77*r,angle:a});}
  batch(lava,flameGeometry,flameMaterial,[...vents,...vents.map(p=>({...p,angle:p.angle+Math.PI/2}))],'Flames rising from the molten shore',(p,o)=>{o.position.set(p.x,LAVA_LEVEL-.4,p.z);o.rotation.y=p.angle;o.scale.setScalar(.6+hash(p.x,p.z)*.6);},false);
  for(const [x,z]of [[565,-350],[658,-350]]){const glow=own(new THREE.PointLight('#ff641c',95,180,1.8));glow.position.set(x,LAVA_LEVEL+5,z);lava.add(glow);}

  const iceMaterial=own(new THREE.MeshPhysicalMaterial({color:'#aecbd3',normalMap:rockMaps.normalMap,normalScale:new THREE.Vector2(.14,.14),roughness:.43,metalness:0,clearcoat:.26,clearcoatRoughness:.31,flatShading:true}));
  const iceCrag=own(new THREE.CylinderGeometry(.34,.44,1,5,3)),iceVertices=iceCrag.attributes.position;
  for(let i=0;i<iceVertices.count;i++){const x=iceVertices.getX(i),y=iceVertices.getY(i),z=iceVertices.getZ(i),ridge=Math.sin(y*11+z*7)*.035;iceVertices.setXYZ(i,x+ridge+y*.045,y+(y>.4?(x*.24+z*.18+Math.sin(x*12+z*7)*.055):0),z+Math.sin(y*9-x*5)*.025);}iceCrag.computeVertexNormals();
  const glacier=[];for(let i=0;i<380;i++){const x=-805+rng()*520,z=-795+rng()*435;if(iceBlendAt(x,z)<.6||riverBankDistanceAt(x,z)<8||isGlowSafeAt(x,z))continue;const size=.5+Math.pow(rng(),2)*6;glacier.push({x,z,y:heightAt(x,z),size,angle:rng()*TAU});if(size>2.2)colliders.push({x,z,radius:size*.35,height:size*2,kind:'ice'});}
  batch(ice,iceCrag,iceMaterial,glacier,'Fractured blue ice crags',(p,o)=>{o.position.set(p.x,p.y+p.size*.43,p.z);o.rotation.set(.07,p.angle,.08);o.scale.set(p.size*.8,p.size*1.18,p.size*.8);});
  const snowMaterial=own(new THREE.MeshStandardMaterial({...rockMaps,color:'#e0e9e9',roughness:.85,normalScale:new THREE.Vector2(.55,.55)}));
  batch(ice,rubbleGeometry,snowMaterial,glacier.filter((_,i)=>i%2===0),'Snow-covered glacial rubble',(p,o)=>{o.position.set(p.x+2,heightAt(p.x+2,p.z+2)+p.size*.15,p.z+2);o.scale.set(p.size,p.size*.38,p.size*.8);},true);

  const seaGeometry=own(new THREE.PlaneGeometry(1900,475,100,38));seaGeometry.rotateX(-Math.PI/2);seaGeometry.translate(0,waterLevel+.015,715);
  const seaMaterial=own(new THREE.MeshPhysicalMaterial({color:'#2e899a',transparent:true,depthWrite:false,opacity:.94,roughness:.17,metalness:0,clearcoat:1,clearcoatRoughness:.11,side:THREE.DoubleSide}));
  seaMaterial.onBeforeCompile=shader=>{shader.uniforms.oceanTime=clock;shader.vertexShader='uniform float oceanTime;varying vec3 vSeaPoint;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>\nfloat deltaWaves=smoothstep(477.5,530.0,position.z);transformed.y+=(sin(position.x*.042+oceanTime*.9)*.07+sin(position.z*.074-oceanTime*1.1)*.045)*deltaWaves;vSeaPoint=transformed;`);shader.fragmentShader='uniform float oceanTime;varying vec3 vSeaPoint;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>\nfloat deltaBlend=smoothstep(477.5,525.0,vSeaPoint.z);diffuseColor.a*=deltaBlend;`);shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`normal=normalize(normal+vec3(cos(vSeaPoint.x*.25+oceanTime)*.18,0.0,sin(vSeaPoint.z*.21-oceanTime*.8)*.18)*smoothstep(477.5,530.0,vSeaPoint.z));`);};seaMaterial.customProgramCacheKey=()=> 'open-ocean-connected-delta-v2';
  const sea=new THREE.Mesh(seaGeometry,seaMaterial);sea.name='Open ocean with rolling surface waves';sea.renderOrder=2;root.add(sea);
  const foamPoints=[],foamUV=[],foamIndices=[],shoreSections=[];
  for(let i=0;i<=180;i++){const x=-900+i*10;let lo=coastZ(x)-50,hi=coastZ(x)+55;for(let n=0;n<16;n++){const mid=(lo+hi)/2;if(heightAt(x,mid)>waterLevel)lo=mid;else hi=mid;}const z=(lo+hi)/2;shoreSections.push(riverBankDistanceAt(x,z)>4);for(const offset of [0,3.8]){foamPoints.push(x,waterLevel+.085,z+offset);foamUV.push(i*.12,offset/3.8);}}
  // Shore wash follows sand banks and leaves the open river mouth clear.
  for(let i=0;i<180;i++)if(shoreSections[i]&&shoreSections[i+1]){const n=i*2;foamIndices.push(n,n+1,n+2,n+1,n+3,n+2);}
  const foamMaterial=own(new THREE.MeshBasicMaterial({color:'#e8f0dd',transparent:true,opacity:.25,depthWrite:false,side:THREE.DoubleSide}));const foam=new THREE.Mesh(own(geometryFrom(foamPoints,foamIndices,foamUV)),foamMaterial);foam.name='Pale shoreline wash';foam.renderOrder=3;root.add(foam);
  const palmWood=own(new THREE.CylinderGeometry(.13,.30,11,8,12));palmWood.translate(0,5.4,0);const pp=palmWood.attributes.position;for(let i=0;i<pp.count;i++){const y=pp.getY(i);pp.setX(i,pp.getX(i)+y*y*.014);}palmWood.computeVertexNormals();
  const palmLeaves=[],palmUV=[],palmIndex=[];
  for(let frond=0;frond<11;frond++){const a=frond/11*TAU,len=3.3+(frond%3)*.37,base=palmLeaves.length/3;for(let j=0;j<=12;j++){const t=j/12,r=t*len,y=10.7+Math.sin(t*Math.PI)*1.5-t*1.25,width=Math.sin(t*Math.PI)*.53;for(const sign of [-1,1]){palmLeaves.push(1.60+Math.cos(a)*r-Math.sin(a)*width*sign,y,Math.sin(a)*r+Math.cos(a)*width*sign);palmUV.push((sign+1)/2,t);}if(j<12){const n=base+j*2;palmIndex.push(n,n+1,n+2,n+1,n+3,n+2);}}}
  const palmCrown=own(geometryFrom(palmLeaves,palmIndex,palmUV)),palmBark=own(new THREE.MeshStandardMaterial({...foliage.bark,color:'#b3a483',roughness:1})),palmGreen=own(new THREE.MeshStandardMaterial({color:'#4f6c35',side:THREE.DoubleSide,roughness:.91}));
  for(let i=0;i<105;i++){const x=-840+rng()*1680,z=coastZ(x)-25-rng()*30;if(heightAt(x,z)<2.8||riverBankDistanceAt(x,z)<4||isGlowSafeAt(x,z))continue;const scale=.7+rng()*.65,h=embeddedTreeHeight(x,z,.4*scale),id=`palm-${String(i).padStart(3,'0')}`;trees.push({id,x,z,y:h,h,radius:.30*scale,height:11*scale,kind:'palm',felled:false,scale,angle:rng()*TAU});colliders.push({x,z,radius:.4*scale,height:11*scale,treeId:id});}
  const palmTransform=(p,o)=>{o.position.set(p.x,p.h,p.z);o.rotation.y=p.angle;o.scale.setScalar(p.scale);};batch(coast,palmWood,palmBark,trees,'Coastal palm trunks',palmTransform);batch(coast,palmCrown,palmGreen,trees,'Long green palm fronds',palmTransform);
  root.userData.caveEntrance={...CAVE_ENTRANCE};root.userData.biomes=9;
  return {colliders,trees,resourceNodes,bushZones,setTreeFelled(id,value=true){const changed=registry.setTreeFelled(id,value);if(changed)trees.find(p=>p.id===id).felled=!!value;return changed;},
    update(time,camera){clock.value=time;foamMaterial.opacity=.18+Math.sin(time*.7)*.055;for(const r of regions)r.node.visible=!camera||Math.hypot(camera.x-r.x,camera.z-r.z)<r.radius+650;},
    dispose(){root.removeFromParent();for(const resource of resources)resource.dispose();root.clear();}};
}
