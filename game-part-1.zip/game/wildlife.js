import {WILDLIFE_LIST,WILDLIFE_SPECIES,WILDLIFE_LIMITS,normalizeWildlifeState} from './wildlife-catalog.js';
import {createWildlifeModel} from './wildlife-models.js';
import {hasTeethpeedLineOfSight} from './teethpeed-senses.js';
import {lavaAt,isGlowSafeAt} from './biomes.js';
import {caveWalkableAt,caveFloorAt,caveCeilingAt,isInsideCave,CAVE_SEGMENTS,CAVE_ZONES} from './cave-maze.js';
export {WILDLIFE_LIST,WILDLIFE_SPECIES,WILDLIFE_LIMITS,normalizeWildlifeState} from './wildlife-catalog.js';

const TAU=Math.PI*2,CELL=38,ACTIVE_RADIUS=112,VIEW_RADIUS=88;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),finite=Number.isFinite;
const point=p=>p&&[p.x,p.y,p.z].every(finite),copy=p=>({x:p.x,y:p.y,z:p.z});
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const angleDifference=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
function randomFor(seed,key){let value=2166136261;for(const c of `${seed}:${key}`){value^=c.charCodeAt(0);value=Math.imul(value,16777619);}value^=value>>>16;value=Math.imul(value,2246822507);value^=value>>>13;return (value>>>0)/4294967296;}
const actorState=r=>({id:r.id,species:r.species,position:copy(r.position),home:copy(r.home),heading:r.heading,health:r.health,state:r.state,age:r.age,stateTime:r.stateTime,cooldown:r.cooldown,roamIndex:r.roamIndex,hidingEpisode:r.hidingEpisode,concealFound:r.concealFound,savedAt:r.savedAt,memory:r.memory?copy(r.memory):null,target:r.target?copy(r.target):null});
const remainsState=r=>({id:r.id,species:r.species,position:copy(r.position),heading:r.heading,deathTime:r.deathTime,respawnAt:r.respawnAt,harvested:r.harvested});

/** Deterministic local fauna. Original Teethpeed/Deatheater controllers stay separate. */
export function createWildlife({scene,headless=false,heightAt=()=>0,biomeAt=()=>({id:'valley'}),waterLevel=2,colliders=[],seed='wildlife',state,onDamage=()=>{},onLoot}={}){
  if(!headless&&!scene?.add)throw new Error('Wildlife requires a Three.js scene.');
  const saved=normalizeWildlifeState(state);if(saved===null)throw new Error('Invalid wildlife save.');
  seed=String(saved?.seed??seed??'wildlife').slice(0,160)||'wildlife';
  const actors=new Map(),remains=new Map(),views=new Map();
  let clock=saved?.clock??0,concealEpisode=saved?.concealEpisode??0,wasConcealed=saved?.wasConcealed??false;
  let lastPlayer=null,refreshIn=0,disposed=false,concealRolls=0,concealFinds=0,totalHits=0,totalKills=0,totalHarvests=0;
  let local=[],nearColliders=[];
  const multiplayerConceal=new Map(Array.isArray(state?.multiplayerConceal)?state.multiplayerConceal.filter(entry=>Array.isArray(entry)&&typeof entry[0]==='string'&&entry[1]&&Number.isInteger(entry[1].episode)):[]);
  const colliderGrid=new Map(),sourceColliders=Array.isArray(colliders)?colliders:[];let colliderCount=-1;
  const rand=key=>randomFor(seed,key),biomeId=(x,z)=>{const b=biomeAt(x,z);return typeof b==='string'?b:b?.id;};
  const safeAt=(x,z)=>biomeId(x,z)==='glow'||isGlowSafeAt(x,z);
  const hostile=spec=>spec.temperament==='predator'||spec.temperament==='defensive';
  // Check the player's actual position every simulation step, independently
  // of the throttled sight cache. Crossing the sanctuary is immediately safe.
  const mayThreaten=(spec,r,p)=>!safeAt(p.x,p.z)&&!safeAt(r.position.x,r.position.z)&&!(spec.habitat==='water'&&(biomeId(p.x,p.z)!=='ocean'||heightAt(p.x,p.z)>waterLevel-.65||p.y>waterLevel+.35));
  function rebuildColliders(){
    colliderGrid.clear();colliderCount=sourceColliders.length;
    for(const c of sourceColliders){
      if(!c||![c.x,c.z,c.radius].every(finite)||c.radius<=0)continue;
      const collider={...c,height:finite(c.height)&&c.height>0?c.height:Math.max(.6,c.radius*1.8)};
      const key=`${Math.floor(c.x/CELL)},${Math.floor(c.z/CELL)}`;
      if(!colliderGrid.has(key))colliderGrid.set(key,[]);colliderGrid.get(key).push(collider);
    }
    for(const r of actors.values())r.senseAt=-1;
  }
  rebuildColliders();
  const withinBounds=(x,z)=>Math.abs(x)<880&&Math.abs(z)<880;
  const caveSpecies=spec=>spec.biomes.length===1&&spec.biomes[0]==='cave';
  const habitatFloor=(spec,x,z)=>caveSpecies(spec)?caveFloorAt(x,z):heightAt(x,z);
  const caveRayClear=(a,b)=>{const steps=Math.max(1,Math.ceil(distance(a,b)/.65));for(let i=1;i<steps;i++)if(!caveWalkableAt(a.x+(b.x-a.x)*i/steps,a.z+(b.z-a.z)*i/steps))return false;return true;};
  function colliderAt(x,z,radius,y,height){
    const cx=Math.floor(x/CELL),cz=Math.floor(z/CELL);
    for(let ix=cx-1;ix<=cx+1;ix++)for(let iz=cz-1;iz<=cz+1;iz++)for(const c of colliderGrid.get(`${ix},${iz}`)||[]){
      const base=finite(c.baseY)?c.baseY:heightAt(c.x,c.z);
      if(y+height<base+.04||y>base+c.height+.1)continue;
      if(Math.hypot(c.x-x,c.z-z)<c.radius+radius)return true;
    }return false;
  }
  function habitatY(spec,x,z,previousY=null){
    const sanctuary=safeAt(x,z);
    if(!withinBounds(x,z)||sanctuary&&hostile(spec)||!spec.biomes.includes(biomeId(x,z))&&!(sanctuary&&!hostile(spec)&&spec.habitat!=='water'&&!caveSpecies(spec)))return null;
    const inCave=caveSpecies(spec),floor=habitatFloor(spec,x,z);if(!finite(floor)||spec.habitat!=='air'&&lavaAt(x,z))return null;
    if(inCave){if(!caveWalkableAt(x,z,spec.radius*.85))return null;return spec.habitat==='air'?Math.min(floor+(spec.altitude||3),caveCeilingAt(x,z)-spec.height-.6):floor;}
    const depth=waterLevel-floor;
    if(spec.habitat==='water'){
      if(depth<Math.max(.8,spec.height+.4))return null;
      return clamp(previousY??waterLevel-(spec.depth||1.6),floor+spec.height*.55+.12,waterLevel-spec.height*.55-.12);
    }
    if(spec.habitat==='air')return floor+(spec.altitude||4);
    if(spec.habitat==='shore')return depth<=.22&&floor<waterLevel+7?floor:null;
    if(spec.habitat==='amphibious'){
      if(spec.anatomy==='frog')return depth<.26?Math.max(floor,waterLevel-.12):null;
      return depth>.55?clamp(previousY??waterLevel-(spec.depth||.6),floor+.16,waterLevel-.12):floor;
    }
    return depth<.28?floor:null;
  }
  function validPosition(spec,x,z,previousY=null){
    const y=habitatY(spec,x,z,previousY);
    if(y===null||colliderAt(x,z,spec.radius*.7,y,spec.height))return null;
    if(spec.habitat!=='air'&&spec.habitat!=='water'){
      const d=.7,gradient=Math.max(Math.abs(habitatFloor(spec,x+d,z)-habitatFloor(spec,x-d,z)),Math.abs(habitatFloor(spec,x,z+d)-habitatFloor(spec,x,z-d)))/(d*2);
      if(!finite(gradient)||gradient>1.28)return null;
    }
    return {x,y,z};
  }
  function newActor(id,spec,position){
    return {id,species:spec.id,position:copy(position),home:copy(position),heading:rand(`${id}:heading`)*TAU,health:spec.health,state:'roam',age:0,stateTime:0,cooldown:0,roamIndex:0,hidingEpisode:0,concealFound:false,savedAt:clock,memory:null,target:null,speed:0,senses:{distance:Infinity,lineOfSight:false,visible:false},senseAt:-1};
  }
  for(const r of saved?.actors||[]){
    // A changed biome boundary must not restore an old hostile animal inside
    // the new sanctuary, or a marine animal onto dry land.
    const spec=WILDLIFE_SPECIES[r.species];
    if(hostile(spec)&&habitatY(spec,r.position.x,r.position.z,r.position.y)===null)continue;
    actors.set(r.id,{...actorState(r),speed:0,senses:{distance:Infinity,lineOfSight:false,visible:false},senseAt:-1});
  }
  for(const r of saved?.remains||[])if(r.respawnAt>clock)remains.set(r.id,remainsState(r));
  function setState(r,next){if(r.state===next)return;r.state=next;r.stateTime=0;r.target=null;}
  function selectSpecies(id,x,z){
    const available=WILDLIFE_LIST.filter(s=>!s.eventOnly&&s.biomes.includes(biomeId(x,z))&&habitatY(s,x,z)!==null);
    if(!available.length)return null;const total=available.reduce((n,s)=>n+s.weight,0);let pick=rand(`${id}:species`)*total;
    for(const spec of available){pick-=spec.weight;if(pick<=0)return spec;}return available.at(-1);
  }
  function refresh(player,allPlayers=null){
    if(colliderCount!==sourceColliders.length)rebuildColliders();
    for(const [id,r]of remains)if(r.respawnAt<=clock){remains.delete(id);removeView(id);}
    // Rebuild only a local cover list; visibility samples never scan the entire world.
    nearColliders=[];const px=Math.floor(player.x/CELL),pz=Math.floor(player.z/CELL);
    for(let x=px-4;x<=px+4;x++)for(let z=pz-4;z<=pz+4;z++)nearColliders.push(...colliderGrid.get(`${x},${z}`)||[]);
    const candidates=[];
    for(let cx=px-3;cx<=px+3;cx++)for(let cz=pz-3;cz<=pz+3;cz++)for(let slot=0;slot<2;slot++){
      const id=`fauna:${cx}:${cz}:${slot}`,x=(cx+.12+rand(`${id}:x`)*.76)*CELL,z=(cz+.12+rand(`${id}:z`)*.76)*CELL;
      const d=distance({x,z},player);if(d>ACTIVE_RADIUS-8||d<9||actors.has(id)||remains.has(id))continue;
      const spec=selectSpecies(id,x,z);if(!spec)continue;
      if(spec.temperament==='predator'&&d<34)continue;
      const pos=validPosition(spec,x,z);if(pos)candidates.push({id,spec,pos,d});
    }
    candidates.sort((a,b)=>a.d-b.d||a.id.localeCompare(b.id));
    // A single world identity survives streaming, saving and reloading. The
    // death journal enforces its respawn delay, and dormant pruning exempts it.
    const dilloId='unique:dillo_suare',dillo=WILDLIFE_SPECIES.dillo_suare;
    if(biomeId(player.x,player.z)==='storm'&&![...actors.values()].some(r=>r.species===dillo.id)&&![...remains.values()].some(r=>r.species===dillo.id&&r.respawnAt>clock)){
      for(let attempt=0;attempt<32;attempt++){
        const angle=rand(`${dilloId}:spawn:${attempt}`)*TAU,radius=46+rand(`${dilloId}:radius:${attempt}`)*34;
        const pos=validPosition(dillo,player.x+Math.sin(angle)*radius,player.z+Math.cos(angle)*radius);
        if(pos){actors.set(dilloId,newActor(dilloId,dillo,pos));break;}
      }
    }
    const nearbyAlive=[...actors.values()].filter(r=>distance(r.position,player)<ACTIVE_RADIUS);
    let room=Math.max(0,(allPlayers?32:WILDLIFE_LIMITS.actors)-nearbyAlive.length);
    for(const item of candidates){if(room--<=0)break;actors.set(item.id,newActor(item.id,item.spec,item.pos));}
    local=[...actors.values()].filter(r=>distance(r.position,player)<ACTIVE_RADIUS).sort((a,b)=>distance(a.position,player)-distance(b.position,player)||a.id.localeCompare(b.id)).slice(0,WILDLIFE_LIMITS.actors);
    const activeIds=new Set(allPlayers?[...actors.values()].filter(r=>allPlayers.some(p=>distance(r.position,p)<ACTIVE_RADIUS)).map(r=>r.id):local.map(r=>r.id));
    // Dormant wounded animals are remembered; ordinary healthy roamers can be
    // generated again from their fixed world cell without unbounded save growth.
    if(actors.size>WILDLIFE_LIMITS.savedActors){
      const dormant=[...actors.values()].filter(r=>!activeIds.has(r.id)&&!WILDLIFE_SPECIES[r.species].eventOnly).sort((a,b)=>(b.health===WILDLIFE_SPECIES[b.species].health)-(a.health===WILDLIFE_SPECIES[a.species].health)||a.savedAt-b.savedAt);
      for(const r of dormant){if(actors.size<=WILDLIFE_LIMITS.savedActors)break;actors.delete(r.id);removeView(r.id);}
    }
    refreshIn=1.6;
  }
  function physicalSight(r,player){
    const spec=WILDLIFE_SPECIES[r.species],d=distance(r.position,player),eye=spec.habitat==='water'?spec.height*.5:Math.max(.10,spec.height*.65);
    if(hostile(spec)&&!mayThreaten(spec,r,player))return {distance:d,lineOfSight:false,visible:false};
    const radius=spec.vision*(r.state==='chase'||r.state==='hunt'?1.35:1);
    if(d>radius)return {distance:d,lineOfSight:false,visible:false};
    if(caveSpecies(spec)&&isInsideCave(player.x,player.z,player.y)&&!caveRayClear(r.position,player))return {distance:d,lineOfSight:false,visible:false};
    // An animal cannot see directly through its own underside.
    const vertical=r.position.y+eye-(player.y+1.0);
    if(vertical>.85&&d<vertical*.58)return {distance:d,lineOfSight:false,visible:false};
    if(d>2.0&&r.state!=='chase'&&r.state!=='hunt'){
      const bearing=Math.atan2(-(player.x-r.position.x),-(player.z-r.position.z));
      if(Math.abs(angleDifference(bearing,r.heading))>Math.PI*.65)return {distance:d,lineOfSight:false,visible:false};
    }
    if(spec.habitat==='water'&&(heightAt(player.x,player.z)>waterLevel-.65||player.y>waterLevel+.35))return {distance:d,lineOfSight:false,visible:false};
    const lineOfSight=hasTeethpeedLineOfSight({position:r.position,player,heightAt,colliders:nearColliders,originEyeHeight:eye,playerEyeHeight:spec.habitat==='water'?.15:1.0});
    const visible=lineOfSight&&(!player.concealed||(r.hidingEpisode===concealEpisode&&r.concealFound));
    return {distance:d,lineOfSight,visible};
  }
  function chooseRoam(r,spec){
    r.roamIndex++;
    for(let attempt=0;attempt<7;attempt++){
      const key=`${r.id}:roam:${r.roamIndex}:${attempt}`,angle=rand(`${key}:a`)*TAU,radius=3+rand(`${key}:r`)*(spec.habitat==='air'?19:11);
      const candidate=validPosition(spec,r.home.x+Math.sin(angle)*radius,r.home.z+Math.cos(angle)*radius,r.position.y);
      if(candidate){r.target=candidate;return;}
    }
    if(caveSpecies(spec)){
      const rooms=CAVE_ZONES.filter(p=>distance(p,r.position)<36).sort((a,b)=>distance(a,r.position)-distance(b,r.position));
      const room=rooms[Math.floor(rand(`${r.id}:cave-roam:${r.roamIndex}`)*rooms.length)];
      if(room){r.target=validPosition(spec,room.x,room.z,r.position.y);if(r.target)return;}
    }
    r.target=copy(r.home);
  }
  function caveWaypoint(r,target,spec){
    if(!caveSpecies(spec))return target;
    const clear=(a,b)=>{const n=Math.ceil(distance(a,b)/1.4);for(let i=1;i<=n;i++)if(!caveWalkableAt(a.x+(b.x-a.x)*i/n,a.z+(b.z-a.z)*i/n,spec.radius*.9))return false;return true;};
    if(clear(r.position,target))return target;
    // The cave's authored corridors supply a small graph. Routing through it
    // prevents hunters pressing into rock at the inside of a maze corner.
    const start=[...CAVE_ZONES].sort((a,b)=>distance(a,r.position)-distance(b,r.position)).find(p=>clear(r.position,p));
    const end=[...CAVE_ZONES].sort((a,b)=>distance(a,target)-distance(b,target)).find(p=>clear(p,target));
    if(!start||!end)return target;
    const queue=[start.id],previous=new Map([[start.id,null]]);
    for(let i=0;i<queue.length&&!previous.has(end.id);i++)for(const edge of CAVE_SEGMENTS){const next=edge.a.id===queue[i]?edge.b.id:edge.b.id===queue[i]?edge.a.id:null;if(next&&!previous.has(next)){previous.set(next,queue[i]);queue.push(next);}}
    if(!previous.has(end.id))return start;
    const path=[end.id];while(previous.get(path[0])!==null)path.unshift(previous.get(path[0]));
    const next=distance(r.position,start)<2.5&&path.length>1?CAVE_ZONES.find(p=>p.id===path[1]):start;
    return next||target;
  }
  function move(r,spec,target,speed,dt){
    if(!target||speed<=0){r.speed=0;return;}
    target=caveWaypoint(r,target,spec);
    const dx=target.x-r.position.x,dz=target.z-r.position.z,d=Math.hypot(dx,dz);if(d<.20){r.speed=0;return;}
    const desired=Math.atan2(-dx,-dz),turn=clamp(angleDifference(desired,r.heading),-dt*3.7,dt*3.7);
    const base=r.heading+turn,step=Math.min(d,speed*dt);let next=null,usedHeading=base;
    for(const offset of [0,.48,-.48,.98,-.98,1.55,-1.55]){
      const angle=base+offset,x=r.position.x-Math.sin(angle)*step,z=r.position.z-Math.cos(angle)*step;
      const possible=validPosition(spec,x,z,r.position.y);if(!possible)continue;
      if(spec.habitat!=='air'&&spec.habitat!=='water'&&Math.abs(possible.y-r.position.y)>.09+step*1.25)continue;
      next=possible;usedHeading=angle;break;
    }
    if(!next){r.heading+=dt*.85;r.speed=0;if(r.state==='roam')r.target=null;return;}
    const old=copy(r.position);r.position.x=next.x;r.position.z=next.z;
    if(spec.habitat==='air')r.position.y=Math.max(habitatFloor(spec,next.x,next.z)+.35,r.position.y+(next.y-r.position.y)*Math.min(1,dt*2.5));
    else if(spec.habitat==='water'||spec.habitat==='amphibious'&&next.y>heightAt(next.x,next.z)+.2){
      const bottom=heightAt(next.x,next.z)+(spec.habitat==='water'?spec.height*.55+.12:.16),top=waterLevel-spec.height*.5-.08;
      const desiredY=clamp(target.y??next.y,bottom,top);
      r.position.y=clamp(r.position.y+clamp(desiredY-r.position.y,-dt*1.2,dt*1.2),bottom,top);
    }else r.position.y=next.y;
    r.heading+=clamp(angleDifference(usedHeading,r.heading),-dt*4.8,dt*4.8);r.speed=Math.hypot(r.position.x-old.x,r.position.y-old.y,r.position.z-old.z)/Math.max(.001,dt);
  }
  function simulationStep(dt,player,players=null){
    let chaseCount=local.filter(r=>r.state==='chase').length;
    for(const r of local){
      if(!actors.has(r.id))continue;const spec=WILDLIFE_SPECIES[r.species];
      if(players){
        const eligible=hostile(spec)?players.filter(p=>mayThreaten(spec,r,p)):players;
        player=[...(eligible.length?eligible:players)].sort((a,b)=>distance(r.position,a)-distance(r.position,b))[0];
        if(r.targetPlayerId!==player.id){r.targetPlayerId=player.id;r.senseAt=-1;}
        concealEpisode=multiplayerConceal.get(player.id)?.episode??0;
      }
      r.age+=dt;r.stateTime+=dt;r.cooldown=Math.max(0,r.cooldown-dt);r.savedAt=clock;
      if(hostile(spec)&&!mayThreaten(spec,r,player)){
        if(r.state==='chase')chaseCount--;
        setState(r,'roam');r.memory=null;r.target=copy(r.home);r.senseAt=-1;
        r.senses={distance:distance(r.position,player),lineOfSight:false,visible:false};
        // Retreat away from the refuge, rather than waiting on its border.
        if(safeAt(r.position.x,r.position.z)){
          const dx=r.position.x-player.x,dz=r.position.z-player.z,d=Math.max(.1,Math.hypot(dx,dz));
          r.target={x:r.position.x+dx/d*15,y:r.position.y,z:r.position.z+dz/d*15};
        }
        move(r,spec,r.target,spec.walkSpeed*1.3,dt);continue;
      }
      if(clock-r.senseAt>=.16){r.senses=physicalSight(r,player);r.senseAt=clock;}
      const senses=r.senses;
      // Concealment is one opportunity per continuous hiding episode, saved
      // with the creature. Search destinations use remembered visible ground.
      if(r.state==='hunt'&&player.concealed&&r.stateTime>.3&&senses.lineOfSight&&r.hidingEpisode!==concealEpisode){
        r.hidingEpisode=concealEpisode;r.concealFound=rand(`${r.id}:conceal:${concealEpisode}`)<.45;concealRolls++;
        if(r.concealFound){concealFinds++;senses.visible=true;}
      }
      if(r.state==='chase'&&!senses.visible){setState(r,'hunt');chaseCount--;}
      if(r.state==='hunt'&&senses.visible&&chaseCount<2){setState(r,'chase');chaseCount++;}
      if(r.state==='roam'&&senses.visible){
        if(spec.temperament==='skittish'&&(player.moving||senses.distance<Math.min(6,spec.vision))){r.memory=copy(player);setState(r,'flee');}
        else if((spec.temperament==='predator'||spec.temperament==='defensive'&&senses.distance<Math.min(3.1,spec.vision))&&chaseCount<2&&clock>12){r.memory=copy(player);setState(r,'chase');chaseCount++;}
      }
      if(r.state==='chase'){
        if(senses.visible)r.memory=copy(player);
        const target=r.memory,attackRange=spec.radius+1.05;
        if(target&&senses.visible&&senses.distance<attackRange&&Math.abs((r.position.y+spec.height*.5)-(player.y+.75))<Math.max(1.25,spec.height)){
          r.speed=0;if(r.cooldown<=0&&mayThreaten(spec,r,player)){r.cooldown=spec.biteInterval;onDamage(spec.damage,spec.name,{id:r.id,kind:'wildlife',species:spec.id,position:copy(r.position),targetPlayerId:player.id});}
        }else move(r,spec,target,spec.runSpeed,dt);
        if(distance(r.position,r.home)>92||r.stateTime>38){setState(r,'roam');r.memory=null;chaseCount--;}
      }else if(r.state==='hunt'){
        if(!r.memory||r.stateTime>24){setState(r,'roam');r.memory=null;}
        else{
          if(!r.target||distance(r.position,r.target)<.7){
            r.roamIndex++;const angle=rand(`${r.id}:search:${r.roamIndex}`)*TAU,radius=r.stateTime<4?0:2+rand(`${r.id}:search-radius:${r.roamIndex}`)*5;
            r.target=validPosition(spec,r.memory.x+Math.sin(angle)*radius,r.memory.z+Math.cos(angle)*radius,r.memory.y)||copy(r.memory);
          }move(r,spec,r.target,spec.walkSpeed*1.35,dt);
        }
      }else if(r.state==='flee'){
        if(senses.visible)r.memory=copy(player);
        if(r.stateTime>7&&!senses.visible||r.stateTime>14){setState(r,'roam');r.memory=null;}
        else if(r.memory){const dx=r.position.x-r.memory.x,dz=r.position.z-r.memory.z,d=Math.max(.1,Math.hypot(dx,dz));move(r,spec,{x:r.position.x+dx/d*8,z:r.position.z+dz/d*8,y:r.position.y},spec.runSpeed,dt);}
      }else{
        if(!r.target)chooseRoam(r,spec);
        if(distance(r.position,r.target)<.7){r.speed=0;if(r.stateTime>1.5+rand(`${r.id}:idle:${r.roamIndex}`)*3.5){r.target=null;r.stateTime=0;}}
        else move(r,spec,r.target,spec.walkSpeed,dt);
      }
    }
  }
  function removeView(id){const view=views.get(id);if(view){view.model.dispose();views.delete(id);}}
  function render(player=lastPlayer){
    if(disposed||headless||!player)return;
    const visible=[...local.filter(r=>actors.has(r.id)).map(r=>({record:r,dead:false,d:distance(r.position,player)})),...[...remains.values()].filter(r=>!r.harvested&&clock-r.deathTime<WILDLIFE_LIMITS.corpseSeconds).map(r=>({record:r,dead:true,d:distance(r.position,player)}))]
      .filter(item=>item.d<VIEW_RADIUS+(views.has(item.record.id)?6:0)).sort((a,b)=>a.d*(views.has(a.record.id)?.9:1)-b.d*(views.has(b.record.id)?.9:1)||a.record.id.localeCompare(b.record.id)).slice(0,WILDLIFE_LIMITS.views);
    const ids=new Set(visible.map(item=>item.record.id));for(const id of views.keys())if(!ids.has(id))removeView(id);
    for(const {record:r,dead,d}of visible){
      let view=views.get(r.id);if(!view){const model=createWildlifeModel(r.species,{lod:d>45?1:0});view={model,dead};views.set(r.id,view);scene.add(model.group);}
      const spec=WILDLIFE_SPECIES[r.species],root=view.model.group;root.position.set(r.position.x,r.position.y,r.position.z);root.rotation.set(0,r.heading,0);
      if(dead){root.position.y=spec.habitat==='water'?waterLevel-.1:heightAt(r.position.x,r.position.z)+spec.radius*.30;root.rotation.z=1.35;}
      else if(spec.habitat==='air')root.position.y+=Math.sin(clock*1.2+rand(r.id)*TAU)*.12;
      view.model.animate({time:clock+rand(r.id)*100,speed:dead?0:r.speed||0,state:dead?'dead':r.state});view.dead=dead;
    }
  }
  function update(dt,player){
    if(disposed||!player||![player.x,player.z].every(finite))return;
    lastPlayer={x:player.x,y:finite(player.y)?player.y:heightAt(player.x,player.z),z:player.z,moving:!!player.moving,concealed:!!player.concealed};
    if(lastPlayer.concealed!==wasConcealed){if(lastPlayer.concealed)concealEpisode++;for(const r of actors.values())r.senseAt=-1;}
    wasConcealed=lastPlayer.concealed;
    const elapsed=clamp(finite(dt)?dt:0,0,.25);refreshIn-=elapsed;
    if(refreshIn<=0||colliderCount!==sourceColliders.length)refresh(lastPlayer);
    let remaining=elapsed;while(remaining>.000001){const step=Math.min(.05,remaining);clock+=step;simulationStep(step,lastPlayer);remaining-=step;}
    render(lastPlayer);
  }
  function updateMany(dt,players){
    if(disposed||!Array.isArray(players))return;
    const valid=players.filter(p=>p&&[p.x,p.z].every(finite)&&p.alive!==false&&p.connected!==false).map(p=>({...p,y:finite(p.y)?p.y:heightAt(p.x,p.z),moving:!!p.moving,concealed:!!p.concealed}));
    if(!valid.length)return;
    let highestEpisode=Math.max(concealEpisode,...[...multiplayerConceal.values()].map(v=>v.episode));
    for(const p of valid){
      const previous=multiplayerConceal.get(p.id),concealed=!!p.concealed;
      if(!previous||previous.concealed!==concealed){multiplayerConceal.set(p.id,{concealed,episode:concealed?++highestEpisode:previous?.episode||0});for(const r of actors.values())r.senseAt=-1;}
    }
    const elapsed=clamp(finite(dt)?dt:0,0,.25);refreshIn-=elapsed;
    if(refreshIn<=0||colliderCount!==sourceColliders.length){
      for(const p of valid)refresh(p,valid);
      const nearest=r=>Math.min(...valid.map(p=>distance(r.position,p)));
      local=[...actors.values()].filter(r=>nearest(r)<ACTIVE_RADIUS).sort((a,b)=>nearest(a)-nearest(b)||a.id.localeCompare(b.id)).slice(0,WILDLIFE_LIMITS.savedActors);
      // Every simultaneous target contributes its local collision cover.
      const cover=new Set();for(const p of valid){const px=Math.floor(p.x/CELL),pz=Math.floor(p.z/CELL);for(let x=px-4;x<=px+4;x++)for(let z=pz-4;z<=pz+4;z++)for(const c of colliderGrid.get(`${x},${z}`)||[])cover.add(c);}nearColliders=[...cover];
    }
    lastPlayer=valid[0];let remaining=elapsed;
    while(remaining>.000001){const slice=Math.min(.05,remaining);clock+=slice;simulationStep(slice,lastPlayer,valid);remaining-=slice;}
    concealEpisode=highestEpisode;render(lastPlayer);
  }
  function attack({origin,direction,range=3,damage=20,radius=.55}={}){
    if(disposed||!point(origin)||!point(direction)||!finite(range)||!finite(damage)||damage<=0)return {hit:false};
    range=clamp(range,.1,90);damage=clamp(damage,0,500);radius=clamp(finite(radius)?radius:.55,.02,1.2);
    const length=Math.hypot(direction.x,direction.y,direction.z);if(length<.0001)return {hit:false};const dir={x:direction.x/length,y:direction.y/length,z:direction.z/length};
    let selected=null;
    for(const r of local){
      if(!actors.has(r.id))continue;const spec=WILDLIFE_SPECIES[r.species],center={x:r.position.x,y:r.position.y+spec.height*.5,z:r.position.z},dx=center.x-origin.x,dy=center.y-origin.y,dz=center.z-origin.z;
      const along=dx*dir.x+dy*dir.y+dz*dir.z;if(along<0||along>range+spec.radius)continue;
      const perpendicular=Math.hypot(dx-dir.x*along,dy-dir.y*along,dz-dir.z*along);if(perpendicular>radius+spec.radius)continue;
      if(caveSpecies(spec)&&isInsideCave(origin.x,origin.z,origin.y)&&!caveRayClear(origin,r.position))continue;
      if(!hasTeethpeedLineOfSight({position:origin,player:center,heightAt,colliders:nearColliders,originEyeHeight:0,playerEyeHeight:0}))continue;
      if(!selected||along<selected.distance)selected={r,spec,distance:along};
    }
    if(!selected)return {hit:false};const {r,spec}=selected,applied=Math.min(r.health,damage);r.health-=applied;totalHits++;
    if(r.health<=0){
      actors.delete(r.id);local=local.filter(a=>a!==r);const corpsePosition=copy(r.position);if(spec.habitat==='water')corpsePosition.y=waterLevel-.1;
      remains.set(r.id,{id:r.id,species:r.species,position:corpsePosition,heading:r.heading,deathTime:clock,respawnAt:clock+WILDLIFE_LIMITS.respawnSeconds,harvested:false});totalKills++;
      // A bounded journal never forgets a fresh death to make room for an old one.
      if(remains.size>WILDLIFE_LIMITS.remains){const oldest=[...remains.values()].sort((a,b)=>a.respawnAt-b.respawnAt)[0];remains.delete(oldest.id);removeView(oldest.id);}
    }else{
      r.memory=copy(origin);r.target=null;r.stateTime=0;r.state=hostile(spec)&&mayThreaten(spec,r,origin)?'chase':'flee';r.senseAt=-1;
    }
    render();return {hit:true,id:r.id,species:r.species,name:spec.name,damage:applied,killed:r.health<=0,distance:selected.distance};
  }
  function getLoot(id){const r=remains.get(id);return r&&!r.harvested&&clock-r.deathTime<WILDLIFE_LIMITS.corpseSeconds?{...WILDLIFE_SPECIES[r.species].loot}:null;}
  function harvestCorpse(id,player=lastPlayer){
    const r=remains.get(id),loot=getLoot(id);if(!loot||!player||distance(r.position,player)>3.5||Math.abs(r.position.y-player.y)>3.2)return null;
    r.harvested=true;totalHarvests++;removeView(id);if(typeof onLoot==='function')onLoot({...loot},{id,species:r.species});return loot;
  }
  function getNearbyTargets(options={},range=4){
    const origin=point(options.origin)?options.origin:point(options)?options:lastPlayer,reach=finite(options.range)?options.range:range;
    if(!origin)return [];const results=[];
    for(const r of [...local,...remains.values()]){
      const dead=remains.has(r.id);if(dead&&(r.harvested||clock-r.deathTime>=WILDLIFE_LIMITS.corpseSeconds))continue;
      const d=distance(origin,r.position);if(d>reach||Math.abs(origin.y-r.position.y)>Math.max(3.5,reach))continue;
      const spec=WILDLIFE_SPECIES[r.species];results.push({id:r.id,species:r.species,name:spec.name,kind:'wildlife',position:copy(r.position),distance:d,health:dead?0:r.health,maxHealth:spec.health,dead,harvestable:dead,stage:dead?'carcass':r.state,...(dead?{loot:{...spec.loot}}:{})});
    }return results.sort((a,b)=>a.distance-b.distance);
  }
  function getChasers(player=lastPlayer){
    if(!player)return [];return local.filter(r=>r.state==='chase'&&actors.has(r.id)&&physicalSight(r,player).visible).map(r=>({id:r.id,kind:'wildlife',species:r.species,name:WILDLIFE_SPECIES[r.species].name,state:'chase',stage:'attacking',position:copy(r.position),grounded:!['air','water'].includes(WILDLIFE_SPECIES[r.species].habitat)}));
  }
  function spawnCaveBear({position,encounterId}={}){
    if(disposed)return {spawned:false,reason:'disposed'};
    if(!point(position)||typeof encounterId!=='string'||!encounterId.length||encounterId.length>130)return {spawned:false,reason:'invalid encounter'};
    const id=`cave-bear:${encounterId}`;
    if(actors.has(id)||remains.has(id))return {spawned:false,reason:'encounter already exists',id};
    if([...actors.values()].some(r=>r.species==='cave_bear'))return {spawned:false,reason:'bear already present'};
    const spec=WILDLIFE_SPECIES.cave_bear,pos=validPosition(spec,position.x,position.z,position.y);
    if(!pos||!isInsideCave(pos.x,pos.z,pos.y))return {spawned:false,reason:'blocked cave habitat'};
    if(actors.size>=WILDLIFE_LIMITS.savedActors){const dormant=[...actors.values()].filter(r=>!WILDLIFE_SPECIES[r.species].eventOnly).sort((a,b)=>distance(b.position,lastPlayer||position)-distance(a.position,lastPlayer||position))[0];if(dormant){actors.delete(dormant.id);removeView(dormant.id);}}
    const bear=newActor(id,spec,pos);actors.set(id,bear);refreshIn=0;
    if(lastPlayer){refresh(lastPlayer);render(lastPlayer);}
    return {spawned:true,id,position:copy(pos)};
  }
  function snapshot(){return {version:1,seed,clock,concealEpisode,wasConcealed,actors:[...actors.values()].sort((a,b)=>Number(!!WILDLIFE_SPECIES[b.species].eventOnly)-Number(!!WILDLIFE_SPECIES[a.species].eventOnly)||b.savedAt-a.savedAt).slice(0,WILDLIFE_LIMITS.savedActors).map(r=>({...actorState(r),...(r.targetPlayerId?{targetPlayerId:r.targetPlayerId}:{})})),remains:[...remains.values()].map(remainsState),...(multiplayerConceal.size?{multiplayerConceal:[...multiplayerConceal.entries()]}:{})};}
  function getDiagnostics(){
    const modelStats=[...views.values()].map(v=>v.model.getDiagnostics()),byBiome={},bySpecies={};
    for(const r of local){const b=biomeId(r.position.x,r.position.z);byBiome[b]=(byBiome[b]||0)+1;bySpecies[r.species]=(bySpecies[r.species]||0)+1;}
    return {species:WILDLIFE_LIST.length,totalSpeciesWithOriginalCreatures:WILDLIFE_LIST.length+2,active:local.length,views:views.size,savedActors:actors.size,remains:remains.size,visibleCorpses:[...views.values()].filter(v=>v.dead).length,chasing:local.filter(r=>r.state==='chase').length,hunting:local.filter(r=>r.state==='hunt').length,drawCalls:modelStats.reduce((n,s)=>n+s.drawCalls,0),triangles:modelStats.reduce((n,s)=>n+s.triangles,0),byBiome,bySpecies,concealEpisode,concealRolls,concealFinds,totalHits,totalKills,totalHarvests,clock,limits:WILDLIFE_LIMITS,records:local.map(r=>({id:r.id,species:r.species,stage:r.state,position:copy(r.position),senses:{...r.senses},lastKnownPlayer:r.memory?copy(r.memory):null,hidingEpisode:r.hidingEpisode,concealFound:r.concealFound}))};
  }
  function dispose(){if(disposed)return;disposed=true;for(const id of views.keys())removeView(id);actors.clear();remains.clear();local=[];}
  return {update,updateMany,render,attack,getLoot,harvestCorpse,getNearbyTargets,getChasers,spawnCaveBear,snapshot,getDiagnostics,dispose};
}
