import * as THREE from './vendor/three.module.js';

const TAU = Math.PI * 2;
const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const signedPower = (n, exponent) => Math.sign(n) * Math.pow(Math.abs(n), exponent);
const random = (a, b = 0) => { const n = Math.sin(a * 127.1 + b * 311.7) * 43758.5453123; return n - Math.floor(n); };

function surface(positions, uv, indices) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

/** The dorsal surface is a flattened shield, not an ellipsoid. X and Z are unit half-extents. */
export function createTergiteGeometry(seed = 0) {
  const positions = [], uv = [], indices = [], sides = 64;
  // The narrow return on the lower edge makes a true cuticle thickness. The last
  // third forms the broad, almost level crown characteristic of centipede plates.
  const rings = [[.986, -.100], [1, -.064], [1.007, -.009], [.996, .054], [.969, .115],
    [.918, .193], [.817, .279], [.675, .325], [.50, .351], [.30, .362], [.12, .365]];
  for (let row = 0; row < rings.length; row++) {
    const [radius, elevation] = rings[row];
    for (let i = 0; i <= sides; i++) {
      const angle = i / sides * TAU;
      let x = signedPower(Math.sin(angle), .47) * radius;
      let z = signedPower(Math.cos(angle), .61) * radius;
      const anterior = Math.max(0, -z), posterior = Math.max(0, z);
      // A smaller front margin slips below the preceding shield; the back edge
      // is a very shallow lobe rather than a round bead or raised decorative rim.
      x *= 1 - anterior * .072 + posterior * .007;
      z += posterior * posterior * .027 * (1 - Math.pow(Math.abs(x), 3));
      const asymmetry = .005 * Math.sin(angle * 3 + seed * 1.73) + .003 * Math.cos(angle * 7 - seed);
      x += asymmetry * radius;
      const ridgeA = Math.exp(-Math.pow((Math.abs(x) - .51) / .071, 2));
      const ridgeB = Math.exp(-Math.pow((Math.abs(x) - .70) / .052, 2));
      const fineRelief = (.005 * Math.sin(z * 14 + x * 2 + seed) + .003 * Math.sin(x * 17 - z * 5)) * Math.min(1, row / 3);
      let y = elevation - .025 * ridgeA - .013 * ridgeB;
      y += .019 * z - .032 * anterior * anterior + fineRelief;
      if (row < 3) y += .0038 * Math.sin(angle * 13 + seed * 2.1);
      positions.push(x, y, z);
      uv.push((x + 1.04) / 2.08 + seed * .173, (z + 1.06) / 2.12 + seed * .091);
      if (row < rings.length - 1 && i < sides) {
        const n = row * (sides + 1) + i;
        indices.push(n, n + 1, n + sides + 1, n + 1, n + sides + 2, n + sides + 1);
      }
    }
  }
  const top = positions.length / 3;
  positions.push(0, .365, 0); uv.push(.5 + seed * .173, .5 + seed * .091);
  for (let i = 0; i < sides; i++) indices.push((rings.length - 1) * (sides + 1) + i, (rings.length - 1) * (sides + 1) + i + 1, top);
  const bottom = positions.length / 3;
  positions.push(0, -.095, 0); uv.push(.5, .5);
  for (let i = 0; i < sides; i++) indices.push(i + 1, i, bottom);
  return surface(positions, uv, indices);
}

/** Short flexible abdomen: unit X/Y half-extents, longitudinal Z from -.5 to .5. */
export function createMembraneGeometry() {
  const positions = [], uv = [], indices = [], sides = 32, rows = 16;
  for (let row = 0; row <= rows; row++) {
    const t = row / rows, z = t - .5;
    for (let i = 0; i <= sides; i++) {
      const angle = i / sides * TAU;
      const corrugation = .025 * Math.sin(t * TAU * 4.5) + .013 * Math.sin(t * TAU * 8);
      const radius = .88 + .12 * Math.sin(t * Math.PI) + corrugation;
      const x = Math.sin(angle) * radius;
      const y = Math.cos(angle) * radius;
      positions.push(x, y * (y > 0 ? .89 : 1), z);
      uv.push(i / sides, t);
      if (row < rows && i < sides) {
        const n = row * (sides + 1) + i;
        indices.push(n, n + sides + 1, n + 1, n + 1, n + sides + 1, n + sides + 2);
      }
    }
  }
  return surface(positions, uv, indices);
}

/** A gently bowed, tapering exoskeletal link, Y from -.5 to .5. */
export function createLegLinkGeometry() {
  const positions = [], uv = [], indices = [], sides = 16, rows = 12;
  for (let row = 0; row <= rows; row++) {
    const t = row / rows;
    const radius = .86 - .31 * t + .12 * Math.sin(t * Math.PI);
    const neck = 1 - .17 * Math.exp(-Math.pow((t - .06) / .065, 2)) - .12 * Math.exp(-Math.pow((t - .93) / .06, 2));
    for (let i = 0; i <= sides; i++) {
      const angle = i / sides * TAU;
      const fluting = 1 + .028 * Math.cos(angle * 3 + t * 1.3);
      const x = Math.sin(angle) * radius * neck * fluting + .11 * Math.sin(t * Math.PI);
      const z = Math.cos(angle) * radius * neck * .80;
      positions.push(x, t - .5, z);
      uv.push(i / sides, t);
      if (row < rows && i < sides) {
        const n = row * (sides + 1) + i;
        indices.push(n, n + 1, n + sides + 1, n + 1, n + sides + 2, n + sides + 1);
      }
    }
  }
  for (const end of [0, 1]) {
    const center = positions.length / 3, base = end * rows * (sides + 1);
    positions.push(0, end - .5, 0); uv.push(.5, end);
    for (let i = 0; i < sides; i++) {
      if (end === 0) indices.push(base + i, center, base + i + 1);
      else indices.push(base + i + 1, center, base + i);
    }
  }
  return surface(positions, uv, indices);
}

/** The unit claw is a curved tarsal hook, rooted at Y=-.5, tip at Y=.5. */
export function createClawGeometry() {
  const positions = [], uv = [], indices = [], sides = 10, rows = 14;
  for (let row = 0; row <= rows; row++) {
    const t = row / rows, taper = Math.max(.008, Math.pow(1 - t, .86));
    for (let i = 0; i <= sides; i++) {
      const angle = i / sides * TAU;
      const x = .55 * t * t + Math.sin(angle) * taper * .70;
      const z = Math.cos(angle) * taper * .48;
      positions.push(x, t - .5, z);
      uv.push(i / sides, t);
      if (row < rows && i < sides) {
        const n = row * (sides + 1) + i;
        indices.push(n, n + 1, n + sides + 1, n + 1, n + sides + 2, n + sides + 1);
      }
    }
  }
  return surface(positions, uv, indices);
}

function merged(geometries) {
  const position = [], normal = [], uv = [], color = [];
  for (const original of geometries) {
    const geometry = original.index ? original.toNonIndexed() : original;
    const p = geometry.attributes.position, n = geometry.attributes.normal, t = geometry.attributes.uv, c = geometry.attributes.color;
    for (let i = 0; i < p.count; i++) {
      position.push(p.getX(i), p.getY(i), p.getZ(i));
      normal.push(n.getX(i), n.getY(i), n.getZ(i));
      uv.push(t ? t.getX(i) : 0, t ? t.getY(i) : 0);
      color.push(c ? c.getX(i) : 1, c ? c.getY(i) : 1, c ? c.getZ(i) : 1);
    }
    if (geometry !== original) geometry.dispose();
    original.dispose();
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(position, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normal, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(color, 3));
  return geometry;
}

function curveGeometry(points, radius, segments = 20, radialSegments = 6) {
  return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p))), segments, radius, radialSegments, false);
}

function tinted(geometry, fn) {
  const p = geometry.attributes.position, colors = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) {
    const c = fn(p.getX(i), p.getY(i), p.getZ(i));
    colors.set(Array.isArray(c) ? c : [c, c, c], i * 3);
  }
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  return geometry;
}

function reverseWinding(geometry) {
  if (geometry.index) {
    const a = geometry.index.array;
    for (let i = 0; i < a.length; i += 3) [a[i + 1], a[i + 2]] = [a[i + 2], a[i + 1]];
  } else {
    for (const attribute of Object.values(geometry.attributes)) {
      const a = attribute.array, stride = attribute.itemSize;
      for (let i = 0; i < attribute.count; i += 3) for (let c = 0; c < stride; c++) {
        const from = (i + 1) * stride + c, to = (i + 2) * stride + c;
        [a[from], a[to]] = [a[to], a[from]];
      }
    }
  }
  geometry.computeVertexNormals();
  return geometry;
}

function outlinePlate(outline, thickness = .020, bevel = .005) {
  const shape = new THREE.Shape();
  outline.forEach(([x, z], i) => i ? shape.lineTo(x, -z) : shape.moveTo(x, -z));
  shape.closePath();
  const geometry = new THREE.ExtrudeGeometry(shape, { depth: thickness, bevelEnabled: true, bevelSegments: 3, bevelSize: bevel, bevelThickness: bevel, curveSegments: 16, steps: 1 });
  geometry.rotateX(-Math.PI / 2);
  geometry.translate(0, -thickness / 2, 0);
  const p = geometry.attributes.position, uv = geometry.attributes.uv;
  for (let i = 0; i < p.count; i++) uv.setXY(i, .5 + p.getX(i) * 1.4, -p.getZ(i) * 1.4);
  return geometry;
}

const HEAD_RINGS = [[.82, -.074], [.962, -.050], [1, -.012], [.950, .033], [.833, .085], [.641, .121], [.412, .141], [.192, .150], [.055, .152]];

function headGeometry() {
  const positions = [], uv = [], indices = [], sides = 64;
  for (let row = 0; row < HEAD_RINGS.length; row++) {
    const [radius, elevation] = HEAD_RINGS[row];
    for (let i = 0; i <= sides; i++) {
      const a = i / sides * TAU, nz = Math.cos(a) * radius;
      const taper = 1 - .30 * Math.max(0, -nz) - .08 * Math.max(0, nz);
      const nx = signedPower(Math.sin(a), .80) * radius;
      let x = nx * .329 * taper, z = nz * .354 - .043;
      x += .0015 * Math.sin(a * 3.1 + .3) * radius;
      const y = elevation + nz * .036 - .006 * Math.exp(-Math.pow(x / .013, 2)) * Math.min(1, row / 4);
      positions.push(x, y, z);
      uv.push(.5 + x * 1.6, .5 + z * 1.5);
      if (row < HEAD_RINGS.length - 1 && i < sides) {
        const n = row * (sides + 1) + i;
        indices.push(n, n + 1, n + sides + 1, n + 1, n + sides + 2, n + sides + 1);
      }
    }
  }
  const top = positions.length / 3;
  positions.push(0, .146, -.043); uv.push(.5, .5);
  for (let i = 0; i < sides; i++) indices.push((HEAD_RINGS.length - 1) * (sides + 1) + i, (HEAD_RINGS.length - 1) * (sides + 1) + i + 1, top);
  const bottom = positions.length / 3;
  positions.push(0, -.074, -.043); uv.push(.5, .5);
  for (let i = 0; i < sides; i++) indices.push(i + 1, i, bottom);
  return tinted(surface(positions, uv, indices), (x, y, z) => {
    const light = .81 + .19 * clamp((y + .045) / .20);
    return [light, light * (.97 + .018 * Math.cos(z * 7)), light * .94];
  });
}

function headSurfaceY(x, z) {
  const nz = (z + .043) / .354, taper = 1 - .30 * Math.max(0, -nz) - .08 * Math.max(0, nz);
  const nx = Math.abs(x) / (.329 * taper);
  let low = Math.max(nx, Math.abs(nz), .00001), high = 1.02;
  for (let step = 0; step < 14; step++) {
    const middle = (low + high) / 2;
    if (Math.pow(nx / middle, 2 / .80) + Math.pow(nz / middle, 2) > 1) low = middle;
    else high = middle;
  }
  const radius = clamp((low + high) / 2, 0, 1);
  for (let i = 2; i < HEAD_RINGS.length - 1; i++) {
    const [a, ay] = HEAD_RINGS[i], [b, by] = HEAD_RINGS[i + 1];
    if (radius >= b) return THREE.MathUtils.lerp(ay, by, clamp((a - radius) / (a - b))) + nz * .036 - .004 * Math.exp(-Math.pow(x / .013, 2));
  }
  return .149 + nz * .036;
}

function sweptCuticle(points, widthAt, heightAt, rows = 42, sides = 16) {
  const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  const positions = [], uv = [], indices = [];
  for (let row = 0; row <= rows; row++) {
    const t = row / rows, center = curve.getPoint(t), tangent = curve.getTangent(t);
    const horizontal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
    for (let i = 0; i <= sides; i++) {
      const angle = i / sides * TAU, flat = Math.sin(angle), dorsal = Math.cos(angle);
      const lateral = flat * widthAt(t), vertical = dorsal * heightAt(t) * (1 + .10 * Math.cos(angle * 3));
      positions.push(center.x + horizontal.x * lateral, center.y + vertical, center.z + horizontal.z * lateral);
      uv.push(i / sides, t);
      if (row < rows && i < sides) {
        const n = row * (sides + 1) + i;
        indices.push(n, n + sides + 1, n + 1, n + 1, n + sides + 1, n + sides + 2);
      }
    }
  }
  const geometry = surface(positions, uv, indices);
  // The swept blade progresses toward local -Z; the generated cross sections
  // wind in the opposite sense to longitudinal +Z membrane geometry.
  reverseWinding(geometry);
  return geometry;
}

function mandibleGeometry(side) {
  // The hook has an oval, tapering three-dimensional section. Teeth grow from
  // the inside of that cuticle instead of appearing as flat extruded cut-outs.
  const path = [[0, 0, .012], [.065, .014, -.074], [.097, .027, -.208], [.068, .037, -.351], [-.023, .030, -.493], [-.172, .007, -.620]];
  const curve = new THREE.CatmullRomCurve3(path.map(p => new THREE.Vector3(...p)));
  const widthAt = t => Math.max(.0008, (.052 + .017 * Math.sin(t * Math.PI)) * Math.pow(1 - t, .70));
  const heightAt = t => Math.max(.00065, (.038 + .007 * Math.sin(t * Math.PI)) * Math.pow(1 - t, .79));
  const pieces = [sweptCuticle(path, widthAt, heightAt, 58, 20)];
  const toothPhases = [.17, .285, .415, .532, .654, .766];
  for (let i = 0; i < toothPhases.length; i++) {
    const t = toothPhases[i], p = curve.getPoint(t), tangent = curve.getTangent(t);
    const inward = new THREE.Vector3(tangent.z, 0, -tangent.x).normalize();
    const length = [.060, .082, .067, .092, .073, .055][i] * (side < 0 ? 1.06 : 1);
    const root = p.clone().addScaledVector(inward, widthAt(t) * .60);
    const middle = root.clone().addScaledVector(inward, length * .64).addScaledVector(tangent, -.004);
    middle.y += .009 * Math.sin(i * 1.7);
    const tip = root.clone().addScaledVector(inward, length).addScaledVector(tangent, .019 + i * .0015);
    tip.y += .004 * Math.cos(i * 1.9);
    const tooth = sweptCuticle([root.toArray(), middle.toArray(), tip.toArray()], u => Math.max(.00045, (.027 - i * .0015) * Math.pow(1 - u, .83)), u => Math.max(.0004, (.023 - i * .0015) * Math.pow(1 - u, .96)), 16, 12);
    pieces.push(tooth);
  }
  const geometry = merged(pieces);
  if (side < 0) { geometry.scale(-1, 1, 1); reverseWinding(geometry); }
  return tinted(geometry, (x, y, z) => {
    const edge = clamp(-z / .62), light = .82 + .11 * edge + .025 * Math.sin(z * 29 + x * 13);
    return [light, light * .97, light * .93];
  });
}

/** Head anatomy only. Materials are borrowed; dispose releases owned geometries. */
export function createTeethpeedAnatomy({ materials }) {
  const group = new THREE.Group(); group.name = 'Centipede head anatomy';
  const head = new THREE.Group(); head.name = 'Flattened cephalic shield'; group.add(head);
  const owned = new Set(), batches = new Map(), transform = new THREE.Object3D();
  const own = value => { owned.add(value); return value; };
  const part = (geometry, material, position = [0, 0, 0], scale = [1, 1, 1], rotation = [0, 0, 0]) => {
    transform.position.set(...position); transform.scale.set(...scale); transform.rotation.set(...rotation); transform.updateMatrix();
    geometry.applyMatrix4(transform.matrix);
    if (!batches.has(material)) batches.set(material, []);
    batches.get(material).push(geometry);
  };
  part(headGeometry(), materials.shell);
  part(outlinePlate([[-.206, -.298], [-.225, -.350], [-.184, -.404], [-.109, -.428], [0, -.420], [.106, -.427], [.183, -.404], [.226, -.349], [.201, -.296]], .014, .004), materials.mandible, [0, -.046, -.012], [.78, .50, .93]);
  part(outlinePlate([[-.189, -.197], [-.184, -.347], [-.096, -.419], [.002, -.433], [.102, -.413], [.188, -.342], [.190, -.198], [.083, -.119], [-.079, -.122]], .026, .006), materials.membrane, [0, -.080, 0], [.90, .55, 1]);

  const suturePoints = [-.285, -.234, -.152, -.055, .054, .153, .226].map((z, i) => [.0018 * Math.sin(i * 1.4), headSurfaceY(0, z) + .0010, z]);
  part(curveGeometry(suturePoints, .0017, 28, 5), materials.membrane);
  for (const side of [-1, 1]) {
    const fork = [[0, -.246], [side * .055, -.273], [side * .111, -.286], [side * .166, -.279]].map(([x, z]) => [x, headSurfaceY(x, z) + .001, z]);
    part(curveGeometry(fork, .0016, 16, 5), materials.membrane);
    // Low lateral sockets and tiny ocelli remain insect scale, even in a close-up.
    const sockets = [[.224, -.192], [.230, -.216], [.244, -.146], [.245, -.176]];
    sockets.forEach(([x, z], i) => {
      const y = headSurfaceY(x, z) - .0025;
      const socket = new THREE.SphereGeometry(1, 12, 8);
      part(socket, materials.membrane, [side * x, y, z], [.0135, .0070, .0140], [0, side * .18, side * -.57]);
      const lens = new THREE.SphereGeometry(1, 12, 8);
      part(lens, materials.eye, [side * (x + .0008), y + .0031, z], [.0093 - i * .0006, .0046, .0100 - i * .0005], [0, side * .18, side * -.57]);
    });
    // Small depressed antennal socket. The animated antenna itself is built by
    // the model and is attached at the returned antennaRoots coordinate.
    part(outlinePlate([[-.020, -.024], [-.029, -.003], [-.018, .023], [.010, .029], [.023, .009], [.017, -.019]], .012, .005), materials.membrane, [side * .219, .039, -.292], [1, 1, 1], [0, side * .3, side * -.15]);
    for (let fold = 0; fold < 4; fold++) {
      const z = -.084 + fold * .041, x0 = side * (.235 - fold * .007);
      const points = [[x0, z], [x0 + side * .018, z + .008], [x0 + side * .032, z + .020]].map(([x, zz]) => [x, headSurfaceY(x, zz) + .0007, zz]);
      part(curveGeometry(points, .0011, 8, 4), materials.membrane);
    }
    // Two pairs of articulated-looking maxillary palps sit under the mouth.
    const palpA = [[side * .105, -.118, -.332], [side * .146, -.148, -.430], [side * .110, -.155, -.513], [side * .062, -.154, -.549]];
    const palpB = [[side * .054, -.134, -.386], [side * .074, -.150, -.470], [side * .031, -.146, -.537]];
    part(curveGeometry(palpA, .009, 21, 8), materials.limb);
    part(curveGeometry(palpB, .006, 15, 7), materials.mandible);
    const ventralPlate = outlinePlate([[-.032, .035], [-.049, -.016], [-.025, -.069], [.012, -.090], [.036, -.044], [.039, .013]], .018, .005);
    part(ventralPlate, materials.mandible, [side * .056, -.122, -.367], [1, 1, 1], [0, side * -.30, 0]);
    for (let i = 0; i < 41; i++) {
      const u = random(i + 8, side + 3), v = random(i + 97, side + 5);
      const z = -.260 + v * .421, nz = (z + .043) / .354;
      const availableWidth = .329 * (1 - .30 * Math.max(0, -nz) - .08 * Math.max(0, nz)) * Math.pow(Math.max(0, 1 - nz * nz), .40) * .925;
      const x = side * (.096 + u * (availableWidth - .096));
      const y = headSurfaceY(x, z) + .0014, length = .006 + random(i, side + 2) * .012;
      part(curveGeometry([[x, y, z], [x + side * length * .37, y + length * .60, z + length * .13], [x + side * length * .68, y + length * .75, z + length * .35]], .00048 + u * .00017, 4, 3), materials.hair);
    }
  }
  for (const [material, geometries] of batches) {
    const mesh = new THREE.Mesh(own(merged(geometries)), material);
    mesh.name = material === materials.shell ? 'Low cephalic cuticle' : material === materials.eye ? 'Minute lateral ocelli' : material === materials.hair ? 'Cephalic tactile setae' : 'Cephalic sutures and mouthparts';
    mesh.castShadow = material !== materials.hair; mesh.receiveShadow = true; head.add(mesh);
  }

  const jaws = [];
  for (const side of [-1, 1]) {
    const jaw = new THREE.Group(); jaw.name = side < 0 ? 'Left serrated ant mandible' : 'Right serrated ant mandible';
    jaw.position.set(side * .19, -.04, -.27); head.add(jaw);
    const blade = new THREE.Mesh(own(mandibleGeometry(side)), materials.mandible);
    blade.name = 'Continuous serrated cuticle blade'; blade.castShadow = blade.receiveShadow = true; jaw.add(blade);
    const condyle = outlinePlate([[-.041, .009], [-.038, -.033], [-.006, -.054], [.037, -.032], [.041, .013], [.007, .035]], .048, .010);
    if (side < 0) { condyle.scale(-1, 1, 1); reverseWinding(condyle); }
    const joint = new THREE.Mesh(own(condyle), materials.membrane);
    joint.name = 'Mandibular condyle'; joint.castShadow = joint.receiveShadow = true; jaw.add(joint);
    // A shallow reinforcing fold follows the outside edge. Its narrow, dark
    // surface reads as cuticle thickness rather than a contrasting horn ridge.
    const crease = curveGeometry([[side * .013, .035, -.007], [side * .069, .048, -.084], [side * .096, .052, -.205], [side * .069, .049, -.343], [side * -.018, .039, -.490], [side * -.113, .019, -.580]], .00135, 32, 5);
    const rim = new THREE.Mesh(own(crease), materials.edge);
    rim.name = 'Fine mandibular reinforcement'; rim.castShadow = false; rim.receiveShadow = true; jaw.add(rim);
    jaws.push({ group: jaw, side });
  }
  head.scale.set(.85, .65, .98);
  let disposed = false;
  return {
    group, head, jaws,
    antennaRoots: [-1, 1].map(side => ({ side, position: new THREE.Vector3(side * .219 * .85, .045 * .65, -.292 * .98) })),
    dispose() { if (disposed) return; disposed = true; for (const resource of owned) resource.dispose(); owned.clear(); }
  };
}
