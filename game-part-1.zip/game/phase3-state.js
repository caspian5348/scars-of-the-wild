import {normalizeSurvivalState} from './survival-system.js';
import {normalizeCampState} from './camp-world.js';
import {normalizeWildlifeState} from './wildlife.js';
import {normalizeBurrowpeedState} from './burrowpeed-encounters.js';
export function normalizePhase3State(value){
  if(value===undefined)return undefined;
  if(!value||value.version!==1)return null;
  const survival=normalizeSurvivalState(value.survival),world=normalizeCampState(value.world),wildlife=normalizeWildlifeState(value.wildlife),burrowers=normalizeBurrowpeedState(value.burrowers);
  if(!survival||!world||wildlife===null||burrowers===null)return null;
  return{version:1,survival,world,...(wildlife!==undefined?{wildlife}:{}),...(burrowers!==undefined?{burrowers}:{})};
}
