import * as THREE from './vendor/three.module.js';

const assetRoot = new URL('./assets/materials/', import.meta.url);

/** Loads the locally bundled CC0 scans. Tiling and strength are set by the world. */
export async function loadRealMaterials() {
  const loader = new THREE.TextureLoader();
  const specifications = [
    ['ground', 'forest', 'map', 'albedo', true],
    ['ground', 'forest', 'normalMap', 'normal', false],
    ['ground', 'forest', 'roughnessMap', 'roughness', false],
    ['rock', 'rock', 'map', 'albedo', true],
    ['rock', 'rock', 'normalMap', 'normal', false],
    ['rock', 'rock', 'roughnessMap', 'roughness', false],
    ['dirt', 'dirt', 'map', 'albedo', true],
    ['dirt', 'dirt', 'normalMap', 'normal', false],
    ['dirt', 'dirt', 'roughnessMap', 'roughness', false],
  ];
  const results = await Promise.allSettled(specifications.map(async ([group, prefix, channel, suffix, color]) => {
    const texture = await loader.loadAsync(new URL(`${prefix}-${suffix}.jpg`, assetRoot).href);
    texture.name = `Poly Haven / ${group} / ${channel}`;
    texture.colorSpace = color ? THREE.SRGBColorSpace : THREE.NoColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.anisotropy = 8;
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = true;
    return {group, channel, texture};
  }));
  const failure = results.find(result => result.status === 'rejected');
  if (failure) {
    for (const result of results) if (result.status === 'fulfilled') result.value.texture.dispose();
    throw new Error('The local scanned material textures could not be loaded.', {cause: failure.reason});
  }
  const materials = {ground: {}, rock: {}, dirt: {}};
  for (const result of results) {
    const {group, channel, texture} = result.value;
    materials[group][channel] = texture;
  }
  return materials;
}
