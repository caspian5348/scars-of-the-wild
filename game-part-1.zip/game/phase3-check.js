import * as THREE from './vendor/three.module.js';
import {ITEMS,RECIPES,BUILDINGS} from './survival-catalog.js';
import {createSurvivalSystem,normalizeSurvivalState} from './survival-system.js';
import {WORLD_SIZE,WATER_LEVEL,TERRAIN_SEGMENTS,terrainVertex,terrainGridHeight,heightAt,embeddedTreeHeight,hazardAt} from './terrain-surface.js';
import {BIOMES,biomeAt,CAVE_ENTRANCE,LAVA_CENTER} from './biomes.js';
import {CAVE_SEGMENTS,CAVE_NODES,CAVE_ZONES,CAVE_DEPOSITS,MAZE_REWARD_POSITION,caveWalkableAt,caveOverburdenAt,caveCeilingAt,isInsideCave} from './cave-maze.js';
import {RARE_ORE_CHANCE,CAVE_BEAR_CHANCE,RARE_STONE_ORES,rareOreAt,createCaveProgress,normalizeCaveProgress} from './cave-progression.js';
import {createExpandedBiomes} from './expanded-biomes.js';
import {getPlayerLocomotion,stepPlayerVertical,canTraverseGround,CHASE_SPEED_BOOST} from './player-motion.js';
import {hasTeethpeedLineOfSight,evaluateTeethpeedSenses} from './teethpeed-senses.js';
import {createTeethpeedEncounters,treeEncounterChance,passesTeethpeedChance,normalizeEncounterState} from './teethpeed-encounters.js';
import {createJourneyStore,SAVE_KEY} from './journey-store.js';
import {normalizeCampState} from './camp-world.js';
import {normalizePhase3State} from './phase3-state.js';
import {WILDLIFE_LIST,WILDLIFE_BIOMES,normalizeWildlifeState} from './wildlife-catalog.js';

const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const close=(a,b,tolerance=1e-7)=>assert(Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=tolerance,`${a} differs from ${b}.`);
const copy=value=>JSON.parse(JSON.stringify(value));
const equal=(a,b,message='State changed unexpectedly.')=>assert(JSON.stringify(a)===JSON.stringify(b),message);
const must=result=>{assert(result?.ok,`${result?.code}: ${result?.message}`);return result;};
const memoryStorage=()=>{const data=new Map();return{getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,String(value)),removeItem:key=>data.delete(key)};};
const baseJourney=()=>({player:{x:0,z:80,yaw:0,pitch:0},health:100,survivedSeconds:0,discovered:[],waypoint:null});
const supply=(system,items)=>{for(const[id,count]of Object.entries(items))must(system.add(id,count));};
const unchanged=(system,action)=>{const before=system.snapshot(),result=action();assert(result?.ok===false,'An invalid action unexpectedly succeeded.');equal(system.snapshot(),before,'Failed action consumed supplies, durability or a revision.');return result;};
const flat=()=>10;
const tree={id:'phase3-tree',x:-30,z:25,h:10,height:40,radius:1.5,angle:.2};
const player={x:16,y:10,z:0};
function advance(ai,seconds,subject=player){for(let left=seconds;left>1e-8;){const step=Math.min(.05,left);ai.update(step,subject);left-=step;}}
function encounterFixture({seed='phase3-bush',state,stage='hunting',colliders=[],onDamage=()=>{}}={}){
  const events=[],config={trees:[tree],heightAt:flat,forestBlendAt:()=>1,colliders,seed,onDamage,onEvent:event=>events.push(event)};
  let ai=createTeethpeedEncounters({...config,state});
  if(!state){assert(ai.forceEncounter(tree.id),'Could not create the isolated creature.');const saved=ai.snapshot(),r=saved.active[0];
    Object.assign(r,{stage,remaining:r.attackDuration-1,position:{x:0,y:10,z:0},heading:-Math.PI/2,lastKnownPlayer:{x:2,y:10,z:0},searchTarget:{x:2,y:10,z:0},huntingTime:0,searchIndex:0,searchWait:0,sightLostFor:0,sightFoundFor:0});r.descent.elapsed=r.descent.total;
    ai=createTeethpeedEncounters({...config,state:saved});}
  return{ai,events,config};
}
const hidden=(id='bush:episode-1',position=player)=>({...position,concealed:true,hidingId:id});
function bushOutcome(found){for(let i=0;i<100;i++){const f=encounterFixture({seed:`bush-outcome-${i}`});f.ai.update(.05,hidden());if(f.ai.getActive()[0].hidingFound===found)return f;}throw new Error(`No ${found?'found':'hidden'} fixture was generated.`);}
function wildlifeState(){return{version:1,seed:'phase3-check-fauna',clock:100,concealEpisode:2,wasConcealed:true,actors:[],remains:[{id:'fauna:0:0:0',species:'mossback_deer',position:{x:20,y:10,z:20},heading:0,deathTime:80,respawnAt:1880,harvested:true}]};}
function campFixture(){const world=normalizeCampState();world.depleted=['ore:18:5'];world.felled=['pine-0000'];world.treeHits={'pine-0001':2};world.hiding={zone:'bush:18:5',episode:4};world.buildings=[{id:'building-1',type:'storage_chest',x:610,y:39,z:-340,rotation:.4,fuel:0,open:false,contents:[{uid:'stored-axe',id:'stone_axe',count:1,durability:41}]}];return world;}
function phase3Fixture(){const survival=createSurvivalSystem();supply(survival,{berries:3,stone_axe:1,fiber:5});must(survival.equip('stone_axe'));must(survival.damageEquipment(6));return{version:1,survival:survival.snapshot(),world:campFixture(),wildlife:wildlifeState()};}

export const phase3Checks=[
  ['The playable catalog contains 101 items, 63 recipes and 16 building types',()=>{
    assert(Object.keys(ITEMS).length===101,`Found ${Object.keys(ITEMS).length} items.`);assert(Object.keys(RECIPES).length===63,`Found ${Object.keys(RECIPES).length} recipes.`);assert(Object.keys(BUILDINGS).length===16,`Found ${Object.keys(BUILDINGS).length} buildings.`);
    for(const definition of [...Object.values(RECIPES),...Object.values(BUILDINGS)]){for(const[id,n]of Object.entries({...definition.cost,...definition.outputs}))assert(ITEMS[id]&&Number.isInteger(n)&&n>0,`${definition.id} references an unusable item.`);if(definition.station)assert(Object.values(BUILDINGS).some(b=>b.providesStation===definition.station),`${definition.id} has no usable station.`);}
  }],
  ['All nine biomes have distinct map locations and supported wildlife',()=>{
    assert(WORLD_SIZE===1800,'The world is not 1,800m square.');assert(BIOMES.length===9&&new Set(BIOMES.map(b=>b.id)).size===9,'Biome list is incomplete.');
    for(const b of BIOMES){assert(biomeAt(b.x,b.z).id===b.id,`${b.name} map location enters a different biome.`);assert(WILDLIFE_BIOMES.includes(b.id)&&WILDLIFE_LIST.some(s=>s.biomes.includes(b.id)),`${b.id} has no fauna.`);}assert(WILDLIFE_LIST.length===34,'Expected 34 wildlife species, including the five new biome creatures and cave-entry bear.');assert(WILDLIFE_LIST.find(s=>s.id==='cave_bear')?.eventOnly,'Cave bears entered the ordinary roaming spawn pool.');
  }],
  ['Ground queries agree with both triangles of the rendered terrain cells',()=>{
    for(const[ix,iz]of [[52,245],[118,107],[264,262],[352,420],[468,168]])for(const[u,v]of [[.2,.3],[.8,.7]]){
      assert(ix<TERRAIN_SEGMENTS&&iz<TERRAIN_SEGMENTS,'Invalid test cell.');const x0=terrainVertex(ix),x1=terrainVertex(ix+1),z0=terrainVertex(iz),z1=terrainVertex(iz+1),a=terrainGridHeight(ix,iz),b=terrainGridHeight(ix+1,iz),c=terrainGridHeight(ix,iz+1),d=terrainGridHeight(ix+1,iz+1);
      const vertices=u+v<=1?[[a,1-u-v],[b,u],[c,v]]:[[b,1-v],[c,1-u],[d,u+v-1]];close(heightAt(x0+(x1-x0)*u,z0+(z1-z0)*v),vertices.reduce((sum,[y,w])=>sum+y*w,0));
    }
  }],
  ['Tree anchors are embedded across their footprint on sloped terrain',()=>{
    for(const[x,z,radius]of [[-190,-25,4],[-148,-175,2],[195,-190,3],[310,520,1]]){const y=embeddedTreeHeight(x,z,radius);for(let i=0;i<16;i++){const angle=i*Math.PI/8;assert(y<heightAt(x+Math.cos(angle)*radius,z+Math.sin(angle)*radius)-.08,'A root anchor floats above part of its footprint.');}}
  }],
  ['The underground maze has 30 connected chambers, dead ends, an enclosed roof and a traversable return route',()=>{
    const group=new THREE.Group(),texture=new THREE.Texture(),maps={map:texture,normalMap:texture,roughnessMap:texture};let biome;
    try{biome=createExpandedBiomes({group,heightAt,rockMaps:maps,foliage:{bark:maps},waterLevel:WATER_LEVEL});assert(biome.colliders.some(c=>c.kind==='cave-wall'),'Cave wall geometry was not built.');
      group.updateMatrixWorld(true);const adjacent=new Map(),points=new Map(),walls=biome.colliders.filter(c=>c.kind==='cave-wall');
      for(const edge of CAVE_SEGMENTS){for(const[a,b]of [[edge.a,edge.b],[edge.b,edge.a]]){points.set(a.id,a);if(!adjacent.has(a.id))adjacent.set(a.id,[]);adjacent.get(a.id).push(b.id);}const steps=Math.ceil(Math.hypot(edge.a.x-edge.b.x,edge.a.z-edge.b.z));
        for(const forward of [true,false]){let previous=forward?edge.a:edge.b;for(let i=1;i<=steps;i++){const t=forward?i/steps:1-i/steps,x=edge.a.x+(edge.b.x-edge.a.x)*t,z=edge.a.z+(edge.b.z-edge.a.z)*t,floor=heightAt(x,z),fromFloor=heightAt(previous.x,previous.z);assert(caveWalkableAt(x,z,1),'A corridor leaves its own walkable floor.');assert(!walls.some(c=>Math.hypot(c.x-x,c.z-z)<c.radius+.4),`A cave wall blocks ${edge.id}.`);assert(canTraverseGround({floor,fromFloor,footY:fromFloor,fromX:previous.x,fromZ:previous.z,x,z}),`The return grade is too steep in ${edge.id}.`);previous={x,z};}}
      }
      const parents=new Map([['entrance',null]]),queue=['entrance'];for(let i=0;i<queue.length;i++)for(const next of adjacent.get(queue[i]))if(!parents.has(next)){parents.set(next,queue[i]);queue.push(next);}
      assert(CAVE_NODES.length===30&&parents.size===31,'The maze contains disconnected chambers.');assert([...adjacent].filter(([id,edges])=>id!=='entrance'&&edges.length===1).length>=4,'The maze has no meaningful wrong turns.');let length=0;for(let id='5:0';parents.get(id);id=parents.get(id)){const a=points.get(id),b=points.get(parents.get(id));length+=Math.hypot(a.x-b.x,a.z-b.z);}assert(length>=450,'A direct shortcut bypasses the maze challenge.');
      const ray=new THREE.Raycaster(),ceiling=group.getObjectByName('Enclosed low arches and damp cave ceiling'),roof=group.getObjectByName('Solid hillside overburden above the tunnels');assert(ceiling&&roof,'The cavern has no enclosed ceiling or hillside above it.');
      for(const room of CAVE_ZONES){const floor=heightAt(room.x,room.z);assert(floor>WATER_LEVEL+4&&caveOverburdenAt(room.x,room.z)-floor>20,'A chamber is flooded or above ground.');ray.set(new THREE.Vector3(room.x,floor+1.7,room.z),new THREE.Vector3(0,1,0));const hit=ray.intersectObject(ceiling)[0];assert(hit&&hit.distance>2.5,'A chamber has an opening to the sky or insufficient headroom.');assert(caveCeilingAt(room.x,room.z)<caveOverburdenAt(room.x,room.z)-9,'The ceiling has no rock overburden.');}
      for(const vein of CAVE_DEPOSITS){assert(ITEMS[vein.kind]&&caveWalkableAt(vein.x,vein.z,1.3),'An ore seam is unusable or sealed in a wall.');assert(!walls.some(c=>Math.hypot(c.x-vein.x,c.z-vein.z)<c.radius+.7),'A vein cannot be reached by a miner.');}assert(isInsideCave(MAZE_REWARD_POSITION.x,MAZE_REWARD_POSITION.z,MAZE_REWARD_POSITION.y),'The reward is outside the underground maze.');
    }finally{biome?.dispose();texture.dispose();}
  }],
  ['Mining a stone outcrop requires an equipped working pickaxe and spends real durability',()=>{
    const s=createSurvivalSystem();assert(unchanged(s,()=>s.gather('stone',{count:2,mining:true})).code==='tool_required','Bare hands mined a stone outcrop.');must(s.add('stone_pickaxe'));must(s.equip('stone_pickaxe'));const before=s.getEquipment().durability;must(s.gather('stone',{count:2,mining:true}));assert(s.count('stone')===2,'An outcrop yielded no stone.');close(s.getEquipment().durability,before-2);must(s.damageEquipment(before));assert(unchanged(s,()=>s.gather('stone',{count:2,mining:true})).code==='broken_tool','A broken pickaxe mined an outcrop.');
  }],
  ['Loose hand stones remain gatherable while full packs reject mining without tool wear',()=>{
    const loose=createSurvivalSystem();must(loose.gather('stone',{count:2}));assert(loose.count('stone')===2&&!loose.getEquipment(),'Loose stone gathering unexpectedly needs equipment.');const full=createSurvivalSystem();must(full.add('stone_pickaxe'));must(full.equip('stone_pickaxe'));must(full.add('stone_knife',35));assert(full.getCapacity().usedSlots===36,'The full-pack mining fixture is invalid.');assert(unchanged(full,()=>full.gather('stone',{count:2,mining:true})).code==='inventory_full','A full pack consumed a mining strike.');
  }],
  ['Rare stone ore uses a stable ten-percent roll with all four rare ore kinds',()=>{
    close(RARE_ORE_CHANCE,.10,0);let hits=0;const kinds=new Set();for(let i=0;i<10000;i++){const node=`outcrop:${i}`,ore=rareOreAt('phase3-rare-stone',node);assert(rareOreAt('phase3-rare-stone',node)===ore,'Revisiting a stone node rerolled its reward.');if(ore){hits++;kinds.add(ore);assert(RARE_STONE_ORES.includes(ore)&&ITEMS[ore],'A rare node yielded an invalid ore.');}}assert(hits>=850&&hits<=1150,`The rare-ore sample was ${hits}/10,000, not about 10%.`);assert(kinds.size===4,'The sample did not contain all four rare ores.');
  }],
  ['Cave bear rolls happen only on entry, remain fixed inside, and resume with one roll on reentry',()=>{
    close(CAVE_BEAR_CHANCE,.01,0);const progress=createCaveProgress({seed:'phase3-entry-boundary'});assert(progress.visit(false)===null,'Starting outside rolled a bear.');const first=progress.visit(true);assert(first.entered&&first.entry===1,'Crossing the entrance did not roll once.');for(let i=0;i<50;i++)assert(progress.visit(true)===null,'Standing inside repeatedly rolled a bear.');const restored=createCaveProgress({seed:'phase3-entry-boundary',state:progress.snapshot()});assert(restored.visit(true)===null&&restored.snapshot().entries===1,'Reloading inside rerolled the encounter.');assert(restored.visit(false).exited,'Leaving did not clear the entry boundary.');const second=restored.visit(true);assert(second.entered&&second.entry===2&&restored.snapshot().entries===2,'Reentering did not receive exactly one new roll.');
  }],
  ['Actual entry outcomes yield about one percent bears and are deterministic after restore',()=>{
    const progress=createCaveProgress({seed:'phase3-bear-distribution'});let bears=0;for(let i=0;i<10000;i++){const before=progress.snapshot(),entry=progress.visit(true);if(entry.bear)bears++;const same=createCaveProgress({seed:'phase3-bear-distribution',state:before});equal(same.visit(true),entry,'Restoring an entry changed the bear result.');progress.visit(false);}assert(bears>=65&&bears<=135,`Observed ${bears}/10,000 bears; expected about 1%.`);
  }],
  ['The labyrinth reward is claimed once per life and legacy cave state normalizes safely',()=>{
    const expected={revision:0,inside:false,entries:0,lastBearEntry:0,rewardClaimed:false};equal(normalizeCaveProgress(),expected);const old=campFixture();delete old.caveProgress;delete old.rockHits;const normalized=normalizeCampState(old);equal(normalized.caveProgress,expected,'A legacy camp did not receive clean cave progress.');const progress=createCaveProgress({seed:'phase3-geode'});assert(progress.claim(),'First reward claim failed.');const saved=progress.snapshot();assert(!progress.claim(),'The same life claimed a second reward.');equal(progress.snapshot(),saved,'A rejected duplicate claim changed its revision.');const restored=createCaveProgress({seed:'phase3-geode',state:saved});assert(!restored.claim(),'Reloading restored the already collected reward.');assert(createCaveProgress({seed:'different-life'}).claim(),'A fresh life inherited an old claim.');assert(normalizeCaveProgress({...expected,lastBearEntry:1})===null,'Malformed cave history was accepted.');
  }],
  ['Molten ground damages at its surface while the open ocean remains deep water',()=>{
    const hazard=hazardAt(LAVA_CENTER.x,LAVA_CENTER.z);assert(hazard?.kind==='lava'&&hazard.damagePerSecond>0,'Lava has no damage rule.');assert(heightAt(LAVA_CENTER.x,LAVA_CENTER.z)<hazard.surfaceY,'Lava sits under dry terrain.');assert(!hazardAt(-33,-25),'The central spawn is marked as lava.');const ocean=BIOMES.find(b=>b.id==='ocean');assert(heightAt(ocean.x,ocean.z)<WATER_LEVEL-8,'Ocean water has no usable depth.');
  }],
  ['Walking, sprinting and swimming keep unlimited stamina outside a chase',()=>{
    for(const swimming of [false,true])for(const fastRequested of [false,true]){const result=getPlayerLocomotion({moving:true,swimming,fastRequested,chased:false,stamina:0,dt:3600});assert(result.stamina===100,'Stamina was depleted.');assert(result.fast===fastRequested,'An empty legacy stamina value blocked sprinting.');close(result.speed,swimming?fastRequested?4:2.6:fastRequested?7.2:4.2);}
  }],
  ['A chase adds exactly one mph to walk, sprint, swim and fast swim speeds',()=>{
    close(CHASE_SPEED_BOOST,.44704,1e-12);for(const swimming of [false,true])for(const fastRequested of [false,true]){const data={moving:true,swimming,fastRequested},normal=getPlayerLocomotion(data),chased=getPlayerLocomotion({...data,chased:true});close(chased.speed-normal.speed,.44704,1e-12);assert(chased.stamina===100,'Chasing reintroduced stamina drain.');}
  }],
  ['Deep ocean entry floats safely without lifting the actual seabed',()=>{
    const floor=heightAt(60,780),before=heightAt(60,780),float=stepPlayerVertical({footY:1.2,verticalSpeed:-35,grounded:false,floor,dt:.05});assert(float.swimming&&!float.grounded&&float.impactSpeed===0,'Deep-water contact behaved as a hard landing.');close(float.footY,WATER_LEVEL-1.25);close(heightAt(60,780),before);const paused=stepPlayerVertical({...float,floor,dt:0});close(paused.footY,float.footY);
  }],
  ['A creature or target underneath terrain cannot see through the ground',()=>{
    assert(!hasTeethpeedLineOfSight({position:{x:0,y:0,z:0},player:{x:5,y:10,z:0},heightAt:flat}),'An underground creature sees out.');assert(!hasTeethpeedLineOfSight({position:{x:0,y:10,z:0},player:{x:5,y:0,z:0},heightAt:flat}),'A creature sees an underground target.');assert(hasTeethpeedLineOfSight({position:{x:0,y:10,z:0},player:{x:5,y:10,z:0},heightAt:flat}),'The clear control sight line is blocked.');
  }],
  ['An animal on its own trunk sees outward but cannot see through the far side',()=>{
    const trunk={id:'own-tree',x:0,z:0,radius:2,height:30},options={position:{x:1.2,y:15,z:0},heightAt:flat,originTree:trunk,colliders:[trunk]};assert(hasTeethpeedLineOfSight({...options,player:{x:8,y:10,z:0}}),'Outward bark sight was rejected.');assert(!hasTeethpeedLineOfSight({...options,player:{x:-8,y:10,z:0}}),'The far side of the origin trunk was ignored.');
  }],
  ['Terrain ridges block sight while a low rock below the eye ray does not',()=>{
    const options={position:{x:0,y:10,z:0},player:{x:8,y:10,z:0}};assert(!hasTeethpeedLineOfSight({...options,heightAt:(x)=>Math.abs(x-4)<1?13:10}),'The ridge did not block sight.');assert(hasTeethpeedLineOfSight({...options,heightAt:flat,colliders:[{x:4,z:0,radius:.7,height:.12}]}),'A tiny rock became an infinitely tall blocker.');
  }],
  ['Initial tree detection remains 10m and the original 15% eligibility is unchanged',()=>{
    assert(passesTeethpeedChance(.149999)&&!passesTeethpeedChance(.15),'Encounter probability changed.');let seed;for(let i=0;i<1000;i++)if(passesTeethpeedChance(treeEncounterChance(String(i),tree.id))){seed=String(i);break;}assert(seed!==undefined,'No eligible fixture found.');const ai=createTeethpeedEncounters({trees:[tree],heightAt:flat,colliders:[],forestBlendAt:()=>1,seed});ai.update(.05,{x:tree.x+10.01,y:10,z:tree.z});assert(ai.getActive().length===0,'Detected beyond 10m.');ai.update(.05,{x:tree.x+10,y:10,z:tree.z});assert(ai.getActive().length===1,'Did not detect at 10m.');const senses=evaluateTeethpeedSenses({position:{x:0,y:10,z:0},player:{x:11,y:10,z:0},heightAt:flat});assert(!senses.withinDetection&&senses.lineOfSight,'Proximity was confused with sight.');
  }],
  ['Entering a bush breaks an established chase before any hunting discovery roll',()=>{
    const f=encounterFixture({stage:'attacking'});f.ai.update(.15,hidden());let r=f.ai.getActive()[0];assert(r.stage==='attacking'&&r.hidingRolls===0&&!r.senses.lineOfSight,'Concealment rerolled before hunting.');f.ai.update(.05,hidden());r=f.ai.getActive()[0];assert(r.stage==='hunting'&&r.hidingRolls===0,'The chase did not become hunting after sight was lost.');f.ai.update(.05,hidden());assert(f.ai.getActive()[0].hidingRolls===1,'Hunting did not make one discovery attempt.');
  }],
  ['Real hunting decisions find about 45% of concealed players across 1,000 journeys',()=>{
    let found=0;for(let i=0;i<1000;i++){const f=encounterFixture({seed:`phase3-bush-distribution-${i}`});f.ai.update(.05,hidden());const r=f.ai.getActive()[0];assert(r.hidingRolls===1,'Hunting attempted an invalid number of rolls.');if(r.hidingFound)found++;}assert(found>=400&&found<=500,`Discovery distribution was ${found}/1000; expected about 45%.`);
  }],
  ['A failed bush search stays hidden through repeated updates and cannot bite',()=>{
    const f=bushOutcome(false),before=f.ai.getActive()[0],memory=copy(before.lastKnownPlayer);advance(f.ai,2,hidden('bush:episode-1',{x:1.4,y:10,z:0}));const r=f.ai.getActive()[0];assert(r.stage==='hunting'&&!r.hidingFound&&r.hidingRolls===1,'The same hiding episode rerolled or resumed chasing.');equal(r.lastKnownPlayer,memory,'The hunter followed the hidden player’s actual position.');
    let damage=0;const contact=encounterFixture({state:f.ai.snapshot(),onDamage:()=>damage++});const p=contact.ai.getActive()[0].position;advance(contact.ai,.5,hidden('bush:episode-1',p));assert(damage===0,'A hidden player was bitten.');
  }],
  ['A successful bush discovery resumes chasing without resetting the attack timer',()=>{
    const f=bushOutcome(true),before=f.ai.getActive()[0];advance(f.ai,.25,hidden());const r=f.ai.getActive()[0];assert(r.stage==='attacking'&&r.hidingFound&&r.hidingRolls===1,'Successful discovery did not reacquire.');close(r.remaining,before.remaining-.25);assert(f.events.some(e=>e.type==='reacquired'),'No reacquisition event was emitted.');
  }],
  ['A failed hiding roll and the next search trajectory survive an actual save and restore',()=>{
    const f=bushOutcome(false);advance(f.ai,.5,hidden());const storage=memoryStorage(),store=createJourneyStore(storage),started=store.begin({...baseJourney(),encounters:f.ai.snapshot()});assert(started.persisted,'The memory save failed.');const saved=store.read(),restored=encounterFixture({state:saved.encounters});equal(restored.ai.snapshot(),normalizeEncounterState(f.ai.snapshot()),'Restored hunting memory differs.');for(let i=0;i<12;i++){f.ai.update(.05,hidden());restored.ai.update(.05,hidden());}equal(restored.ai.snapshot(),f.ai.snapshot(),'Restore rerolled or changed the next search route.');assert(restored.ai.getActive()[0].hidingRolls===1,'Reload repeated the hiding roll.');
  }],
  ['A new hiding episode receives one new attempt, with no repeat during that episode',()=>{
    const f=bushOutcome(false);f.ai.update(.05,hidden('bush:episode-2'));let r=f.ai.getActive()[0];assert(r.hidingId==='bush:episode-2'&&r.hidingRolls===1,'A new hiding episode inherited the old attempt.');const found=r.hidingFound;advance(f.ai,.4,hidden('bush:episode-2'));r=f.ai.getActive()[0];assert(r.hidingRolls===1&&r.hidingFound===found,'Repeated updates changed an episode’s result.');
  }],
  ['Expanded coordinates and swimming motion roundtrip at the new map boundary',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),data={...baseJourney(),player:{x:888,z:-888,yaw:.3,pitch:.1},waypoint:{x:-899,z:899},motion:{footY:.75,verticalSpeed:0,grounded:false}};const result=store.begin(data);assert(result.persisted,'Boundary journey did not persist.');const saved=store.read();equal(saved.player,data.player);equal(saved.waypoint,data.waypoint);equal(saved.motion,data.motion);storage.setItem(SAVE_KEY,JSON.stringify({...saved,player:{...saved.player,x:888.01}}));assert(store.read()===null,'An out-of-bounds journey was accepted.');
  }],
  ['Inventory, worn equipment, stored supplies, felled trees and harvested wildlife all roundtrip',()=>{
    const phase3=phase3Fixture(),store=createJourneyStore(memoryStorage()),begun=store.begin({...baseJourney(),phase3});assert(begun.persisted,'The Phase 3 snapshot was rejected.');const saved=store.read();equal(saved.phase3,normalizePhase3State(phase3),'A Phase 3 field was stripped during persistence.');const system=createSurvivalSystem({state:saved.phase3.survival});assert(system.count('berries')===3&&system.getEquipment().durability===64,'Equipped tool wear or food was restored incorrectly.');assert(saved.phase3.world.buildings[0].contents[0].durability===41&&saved.phase3.wildlife.remains[0].harvested,'Stored wear or harvested status was lost.');
  }],
  ['A stale tab cannot replace newer inventory, camp changes or wildlife history',()=>{
    const store=createJourneyStore(memoryStorage()),start=store.begin({...baseJourney(),phase3:phase3Fixture()}).record,system=createSurvivalSystem({state:start.phase3.survival});must(system.add('stone',2));const newer={...copy(start),phase3:{...copy(start.phase3),survival:system.snapshot()}};newer.phase3.world.felled.push('pine-0002');newer.phase3.wildlife.clock=120;assert(store.save(newer),'Fresh state did not save.');assert(store.save(start),'Same-run stale position save was unexpectedly rejected.');equal(store.read().phase3,normalizePhase3State(newer.phase3),'A stale tab rewound Phase 3 state.');
  }],
  ['Door and wildlife changes persist without an unrelated survival revision increase',()=>{
    const store=createJourneyStore(memoryStorage()),record=store.begin({...baseJourney(),health:57,phase3:phase3Fixture()}).record,changed=copy(record),revision=record.phase3.survival.revision;
    changed.phase3.world.buildings.push({id:'same-revision-door',type:'door',x:612,y:39,z:-340,rotation:0,fuel:0,open:true,contents:[]});
    changed.phase3.world.treeHits['pine-0001']=3;changed.phase3.wildlife.clock=101;changed.phase3.wildlife.remains[0].harvested=false;changed.health=100;
    assert(changed.phase3.survival.revision===revision,'The test accidentally changed survival state.');assert(store.save(changed),'A same-revision world update failed to save.');
    const restored=store.read();equal(restored.phase3,normalizePhase3State(changed.phase3),'A door, tree or wildlife change required an unrelated inventory mutation.');close(restored.health,57);
    assert(restored.phase3.world.buildings.find(b=>b.id==='same-revision-door').open,'The door closed again after reload.');
  }],
  ['Chest and dropped stacks retain their exact wear and original food deadlines through the whole save',()=>{
    const source=createSurvivalSystem();supply(source,{stone_axe:1,raw_meat:2,raw_fish:1});must(source.equip('stone_axe'));must(source.damageEquipment(29));source.step(25);
    const axe=must(source.extract('stone_axe')).stack,meat=must(source.extract('raw_meat',1)).stack,fish=must(source.extract('raw_fish')).stack,world=campFixture();
    world.buildings[0].contents=[copy(axe),copy(meat)];world.drops=[{id:'exact-dropped-fish',x:610,y:39,z:-341,stack:copy(fish)}];
    const phase3={version:1,survival:source.snapshot(),world,wildlife:wildlifeState()},store=createJourneyStore(memoryStorage());assert(store.begin({...baseJourney(),phase3}).persisted,'Exact stored and dropped supplies did not save.');
    const loaded=store.read().phase3;equal(loaded.world.buildings[0].contents,[axe,meat],'Chest normalization repaired equipment or replaced a stack.');equal(loaded.world.drops[0].stack,fish,'Drop normalization changed the original stack.');
    const recipient=createSurvivalSystem({state:loaded.survival});for(const stack of loaded.world.buildings[0].contents)must(recipient.insert(stack));must(recipient.insert(loaded.world.drops[0].stack));
    close(recipient.snapshot().inventory.find(s=>s.id==='stone_axe').durability,41);close(recipient.snapshot().inventory.find(s=>s.id==='raw_meat').expiresAt,meat.expiresAt);close(recipient.snapshot().inventory.find(s=>s.id==='raw_fish').expiresAt,fish.expiresAt);
    assert(recipient.count('raw_meat')===2&&recipient.count('raw_fish')===1,'Exact retrieval lost or duplicated supplies.');
  }],
  ['Expired food cannot become fresh by saving it in a chest or dropping and retrieving it',()=>{
    const source=createSurvivalSystem();must(source.add('raw_fish',2));const fish=must(source.extract('raw_fish',1)).stack,droppedFish=must(source.extract('raw_fish',1)).stack,world=campFixture();world.buildings[0].contents=[copy(fish)];world.drops=[{id:'expired-ground-fish',x:610,y:39,z:-341,stack:copy(droppedFish)}];
    const recipient=createSurvivalSystem();for(let time=0;time<fish.expiresAt+1;time+=60)recipient.step(Math.min(60,fish.expiresAt+1-time));
    const normalized=normalizeCampState(world);must(recipient.insert(normalized.buildings[0].contents[0]));must(recipient.insert(normalized.drops[0].stack));assert(recipient.count('raw_fish')===0&&recipient.count('spoiled_food')===2,'Transferring expired food refreshed its deadline.');
  }],
  ['Real medicine consumption persists its healing and consumed dose together',()=>{
    const system=createSurvivalSystem();must(system.add('bandage',2));const phase3=phase3Fixture();phase3.survival=system.snapshot();const store=createJourneyStore(memoryStorage()),record=store.begin({...baseJourney(),health:37,phase3}).record;
    const restoredSystem=createSurvivalSystem({state:record.phase3.survival}),dose=must(restoredSystem.consume('bandage')),healed={...record,health:record.health+dose.healthDelta,phase3:{...record.phase3,survival:restoredSystem.snapshot()}};
    assert(healed.phase3.survival.revision>record.phase3.survival.revision,'Medicine failed to advance the authoritative survival revision.');assert(store.save(healed),'The medicinal healing save failed.');
    const reloaded=store.read();close(reloaded.health,51);assert(createSurvivalSystem({state:reloaded.phase3.survival}).count('bandage')===1,'Healing did not consume exactly one dose.');
  }],
  ['A real medicine transaction after a fatal save cannot revive that journey',()=>{
    const system=createSurvivalSystem();must(system.add('bandage',2));const phase3=phase3Fixture();phase3.survival=system.snapshot();const storage=memoryStorage(),store=createJourneyStore(storage),alive=store.begin({...baseJourney(),health:12,phase3}).record;
    const ended=store.end(alive,'Killed by a Storm Wolf.');assert(ended.persisted,'The fatal snapshot was not committed.');
    const staleSystem=createSurvivalSystem({state:alive.phase3.survival}),dose=must(staleSystem.consume('bandage')),attempt={...copy(alive),health:alive.health+dose.healthDelta,phase3:{...copy(alive.phase3),survival:staleSystem.snapshot()}};
    assert(attempt.phase3.survival.revision>alive.phase3.survival.revision,'The test did not make a real new medicine transaction.');assert(store.save(attempt)===null&&store.read()===null,'Medicine revived a dead life.');
    storage.setItem(SAVE_KEY,JSON.stringify(attempt));assert(createJourneyStore(storage).read()===null,'Writing an older healed life bypassed the death tombstone.');
  }],
  ['Fatal wildlife damage permanently locks the journey despite fresh inventory or healing data',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),record=store.begin({...baseJourney(),phase3:phase3Fixture()}).record;const ended=store.end(record,'Killed by a Storm Wolf.');assert(ended.persisted&&ended.record.health===0&&store.read()===null,'Fatal wildlife damage did not end the journey.');const revived=copy(record);revived.health=100;revived.phase3.survival.revision+=100;assert(store.save(revived)===null,'Inventory progress revived a dead run.');storage.setItem(SAVE_KEY,JSON.stringify(revived));assert(createJourneyStore(storage).read()===null,'A stale tab bypassed the permanent tombstone.');
  }],
  ['Hand gathering makes a stone axe that gathers real timber and wears with use',()=>{
    const s=createSurvivalSystem();for(const[id,count]of Object.entries(RECIPES.stone_axe.cost))must(s.gather(id,{count}));must(s.craft('stone_axe'));must(s.equip('stone_axe'));const before=s.getEquipment().durability;must(s.gather('wood',{count:4}));assert(s.count('wood')===4,'The axe yielded no timber.');close(s.getEquipment().durability,before-2);assert(s.count('branch')===0&&s.count('stone')===0,'Crafting did not consume its inputs.');
  }],
  ['A stone pickaxe mines copper, wears down and cannot bypass stronger deposit tiers',()=>{
    const s=createSurvivalSystem();for(const[id,count]of Object.entries(RECIPES.stone_pickaxe.cost))must(s.gather(id,{count}));must(s.craft('stone_pickaxe'));must(s.equip('stone_pickaxe'));const before=s.getEquipment().durability;must(s.gather('copper_ore'));assert(s.count('copper_ore')===1,'Mining yielded no ore.');close(s.getEquipment().durability,before-2);assert(unchanged(s,()=>s.gather('iron_ore')).code==='tool_tier','The starter pick bypassed metal progression.');
  }],
  ['Full inventory rejects harvesting atomically, preserving the tool and its supplies',()=>{
    const s=createSurvivalSystem();must(s.add('stone_axe'));must(s.equip('stone_axe'));must(s.add('stone_knife',35));assert(s.getCapacity().usedSlots===36,'The fixture did not fill the inventory.');assert(unchanged(s,()=>s.gather('wood')).code==='inventory_full','Full inventory did not reject the harvest.');assert(s.count('wood')===0,'A failed harvest added resources.');
  }],
  ['Recipes unlock on discovery but still require their ingredients and a nearby station',()=>{
    const s=createSurvivalSystem();assert(!s.isUnlocked('stone_axe'),'Unknown recipe started unlocked.');for(const id of Object.keys(RECIPES.stone_axe.cost))must(s.learnResource(id));assert(s.isUnlocked('stone_axe'),'Discovering recipe materials did not unlock it.');assert(unchanged(s,()=>s.craft('stone_axe')).code==='missing_items','Unlocking conjured ingredients.');supply(s,RECIPES.copper_bar.cost);assert(unchanged(s,()=>s.craft('copper_bar')).code==='station_required','Smelting ignored its furnace.');must(s.craft('copper_bar',{stations:['furnace']}));assert(s.count('copper_bar')===1,'Valid smelting failed.');const restored=createSurvivalSystem({state:s.snapshot()});assert(restored.isUnlocked('copper_bar'),'Consumed discovery was forgotten on reload.');
  }],
  ['A broken tool stays broken on reload and repair consumes the real repair cost',()=>{
    const s=createSurvivalSystem();must(s.add('stone_axe'));must(s.equip('stone_axe'));must(s.damageEquipment(ITEMS.stone_axe.durability-1));assert(must(s.gather('wood')).broken,'The final use did not break the axe.');const r=createSurvivalSystem({state:s.snapshot()});assert(unchanged(r,()=>r.gather('wood')).code==='broken_tool','A broken axe worked after reload.');supply(r,ITEMS.stone_axe.repair);must(r.repair());close(r.getEquipment().durability,ITEMS.stone_axe.durability);assert(r.count('stone')===0&&r.count('fiber')===0,'Repair did not consume materials.');
  }],
  ['Building costs, station rules and foundation support are enforced before spending',()=>{
    const s=createSurvivalSystem();supply(s,BUILDINGS.wall.cost);assert(unchanged(s,()=>s.consumeBuilding('wall',{stations:['workbench'],hasFoundation:false})).code==='foundation_required','An unsupported wall was allowed.');must(s.consumeBuilding('wall',{stations:['workbench'],hasFoundation:true}));assert(s.count('plank')===0,'Building did not consume its planks.');const fire=createSurvivalSystem();supply(fire,BUILDINGS.campfire.cost);must(fire.consumeBuilding('campfire'));assert(fire.count('wood')===0&&fire.count('stone')===0,'Campfire building cost was not paid.');
  }],
  ['Transferring tools and food preserves durability and expiry, and malformed fauna is rejected',()=>{
    const a=createSurvivalSystem(),b=createSurvivalSystem();must(a.add('stone_axe'));must(a.equip('stone_axe'));must(a.damageEquipment(13));must(a.add('raw_meat'));const tool=must(a.extract('stone_axe')).stack,food=must(a.extract('raw_meat')).stack;must(b.insert(tool));must(b.insert(food));assert(b.snapshot().inventory.find(s=>s.id==='stone_axe').durability===57,'Storage repaired the tool for free.');assert(b.snapshot().inventory.find(s=>s.id==='raw_meat').expiresAt===food.expiresAt,'Storage refreshed food expiry.');const valid=wildlifeState();assert(normalizeWildlifeState(valid),'The valid wildlife save failed.');assert(normalizeWildlifeState({...valid,clock:NaN})===null,'Malformed wildlife time was accepted.');assert(normalizeSurvivalState({...b.snapshot(),inventory:[{uid:'s999',id:'imaginary',count:1}]})===null,'Malformed inventory was accepted.');
  }],
];

export async function runPhase3Checks(onResult=()=>{}){
  let passed=0,failed=0;
  for(const[name,check]of phase3Checks){let error=null;try{await check();passed++;}catch(value){error=value;failed++;}await onResult({name,passed:!error,error:error?String(error.stack||error):null});await new Promise(resolve=>setTimeout(resolve,0));}
  return{passed,failed,total:phase3Checks.length};
}
export function bindPhase3CheckPage(){
  const button=document.querySelector('#run-checks'),summary=document.querySelector('#summary'),results=document.querySelector('#results');
  button.disabled=false;summary.textContent=`Ready — ${phase3Checks.length} checks. Nothing has run yet.`;
  button.addEventListener('click',async()=>{button.disabled=true;results.replaceChildren();let complete=0;summary.textContent=`Running 0 / ${phase3Checks.length}…`;
    try{const result=await runPhase3Checks(({name,passed,error})=>{const row=document.createElement('li');row.className=passed?'pass':'fail';const status=document.createElement('strong');status.textContent=passed?'PASS':'FAIL';const label=document.createElement('span');label.textContent=name;row.append(status,label);if(error){const detail=document.createElement('p');detail.textContent=error;row.append(detail);}results.append(row);summary.textContent=`Running ${++complete} / ${phase3Checks.length}…`;});summary.textContent=`${result.passed} passed · ${result.failed} failed · ${result.total} checks`;
    }catch(error){const row=document.createElement('li');row.className='fail';row.textContent=`The check runner failed: ${error?.stack||error}`;results.append(row);summary.textContent='Check runner failed — details below.';}finally{button.disabled=false;}
  });
}
