/** Shared physical layout. Rendering, mining and encounters use these same tunnels. */
export const CAVE_ID='hollowroot-labyrinth';
export const CAVE_ENTRANCE=Object.freeze({x:-510,z:-60,yaw:Math.PI/2});
export const CAVE_BOUNDS=Object.freeze({minX:-700,maxX:-490,minZ:-136,maxZ:16});
export const CAVE_LENGTH=190;
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const smooth=(a,b,n)=>{const t=clamp((n-a)/(b-a));return t*t*(3-2*t);};

const point=(column,row)=>({id:`${column}:${row}`,x:-542-column*28,z:-116+row*28});
export const CAVE_NODES=Object.freeze(Array.from({length:30},(_,i)=>Object.freeze(point(i%6,Math.floor(i/6)))));
const byId=new Map(CAVE_NODES.map(p=>[p.id,p]));
// The long route folds around solid rock; its side branches end in distinct
// chambers. The one loop reconnects two branches without bypassing the reward.
const route=[[0,2],[1,2],[1,3],[0,3],[0,4],[1,4],[2,4],[2,3],[3,3],[3,4],[4,4],[5,4],[5,3],[4,3],[4,2],[5,2],[5,1],[4,1],[4,0],[5,0]];
const branches=[[[0,2],[0,1],[0,0]],[[1,2],[1,1],[1,0]],[[2,3],[2,2],[2,1],[2,0]],[[3,3],[3,2],[3,1],[3,0]],[[2,2],[3,2]]];
const edges=[],seen=new Set();
for(const chain of [route,...branches])for(let i=1;i<chain.length;i++){
  const a=byId.get(chain[i-1].join(':')),b=byId.get(chain[i].join(':')),key=[a.id,b.id].sort().join('|');
  if(!seen.has(key)){seen.add(key);edges.push(Object.freeze({id:key,a,b,radius:5.75}));}
}
edges.unshift(Object.freeze({id:'entrance-ramp',a:Object.freeze({id:'entrance',x:-493,z:-60}),b:byId.get('0:2'),radius:6.2}));
export const CAVE_SEGMENTS=Object.freeze(edges);
export const CAVE_REWARD_NODE=byId.get('5:0');
export function caveReferenceFloorAt(x,z){
  const ramp=1-smooth(-542,-496,x);
  return 19.25-ramp*10.9+Math.sin((x+542)*.029)*.19+Math.sin((z+60)*.039)*.16;
}
export const MAZE_REWARD_POSITION=Object.freeze({x:CAVE_REWARD_NODE.x,y:caveReferenceFloorAt(CAVE_REWARD_NODE.x,CAVE_REWARD_NODE.z),z:CAVE_REWARD_NODE.z});
export const caveRewardPosition=MAZE_REWARD_POSITION;
export const CAVE_ZONES=Object.freeze(CAVE_NODES.map(p=>Object.freeze({...p,y:caveReferenceFloorAt(p.x,p.z),radius:p.id==='5:0'?9.4:p.id==='0:2'?8.1:6.45})));
export const caveZones=CAVE_ZONES;

function segmentDistance(x,z,a,b){const dx=b.x-a.x,dz=b.z-a.z,t=clamp(((x-a.x)*dx+(z-a.z)*dz)/(dx*dx+dz*dz));return Math.hypot(x-a.x-dx*t,z-a.z-dz*t);}
/** Signed distance: negative is open floor, positive is solid rock. */
export function caveMazeDistance(x,z){
  if(!Number.isFinite(x)||!Number.isFinite(z))return Infinity;
  if(x<CAVE_BOUNDS.minX-15||x>CAVE_BOUNDS.maxX+15||z<CAVE_BOUNDS.minZ-15||z>CAVE_BOUNDS.maxZ+15)return Infinity;
  let distance=Infinity;
  for(const segment of CAVE_SEGMENTS)distance=Math.min(distance,segmentDistance(x,z,segment.a,segment.b)-segment.radius);
  for(const room of CAVE_ZONES)distance=Math.min(distance,Math.hypot(x-room.x,z-room.z)-room.radius);
  return distance;
}
export function caveWalkableAt(x,z,margin=0){return caveMazeDistance(x,z)<=-Math.max(0,Number.isFinite(margin)?margin:0);}
export function caveFloorAt(x,z){return caveWalkableAt(x,z)?caveReferenceFloorAt(x,z):null;}
export function caveCeilingAt(x,z){
  const arch=1-smooth(-4.8,.5,caveMazeDistance(x,z));
  return caveReferenceFloorAt(x,z)+5.85+arch*2.65+Math.sin(x*.09+z*.07)*.27;
}
export function isInsideCave(x,z,y){
  if(x>=-516||!caveWalkableAt(x,z))return false;
  return y===undefined||(Number.isFinite(y)&&y>=caveReferenceFloorAt(x,z)-1.5&&y<caveCeilingAt(x,z)-.2);
}
export function caveBlendAt(x,z){return 1-smooth(-1.4,2.6,caveMazeDistance(x,z));}
/** Natural overburden, distinct from the walkable floor underneath it. */
export function caveHillBlendAt(x,z){
  const dx=Math.max(0,Math.abs(x+607)-83),dz=Math.max(0,Math.abs(z+59)-60);
  return 1-smooth(0,36,Math.hypot(dx,dz));
}
export function caveOverburdenAt(x,z){
  const inland=smooth(0,48,-x-504);
  return 25.5+inland*20+Math.sin(x*.041+z*.033)*1.9+Math.sin(x*.093-z*.071)*.75;
}
/** Blend a heightfield into the hillside, then cut its floor below the roof. */
export function carveCaveTerrain(x,z,terrainHeight){
  const hill=caveHillBlendAt(x,z);if(hill<=0)return terrainHeight;
  let result=terrainHeight+(caveOverburdenAt(x,z)-terrainHeight)*hill;
  const distance=caveMazeDistance(x,z);
  // The mouth has a long dirt apron with a gentle grade to the outside valley.
  const entranceCut=1-smooth(2.2,8,distance),mouthFade=smooth(0,14,-x-485);
  result+=(caveReferenceFloorAt(x,z)-result)*entranceCut*mouthFade;
  return result;
}

const depositSpecs=[
  ['copper_ore',0,1],['copper_ore',1,2],['tin_ore',0,0],['tin_ore',1,3],['coal',1,0],['coal',2,2],
  ['iron_ore',2,0],['iron_ore',2,4],['gold_ore',3,1],['gold_ore',4,3],['obsidian',3,4],['obsidian',5,3],
  ['frost_crystal',4,1],['frost_crystal',5,1],['cave_ore',4,0],['cave_ore',5,0],
];
export const CAVE_DEPOSITS=Object.freeze(depositSpecs.map(([kind,c,r],index)=>{
  const room=byId.get(`${c}:${r}`),offset=index%2?2.8:-2.8,x=room.x,z=room.z+offset;
  return Object.freeze({id:`maze-vein-${kind}-${index}`,kind,x,y:caveReferenceFloorAt(x,z),z,radius:1.2,amount:8});
}));
export const caveDeposits=CAVE_DEPOSITS;

/** Compatibility for the former straight cave; new callers use CAVE_SEGMENTS. */
export function caveSection(x){return {t:clamp((-x-510)/CAVE_LENGTH),z:-60,width:6.2,height:8.2};}
