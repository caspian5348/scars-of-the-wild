import {iceBlendAt,lavaBlendAt,lavaAt,coastZ,LAVA_LEVEL} from './biomes.js';
import {carveCaveTerrain} from './cave-maze.js';
import {riverX,riverSampleAt} from './river-network.js';
export {riverX} from './river-network.js';
export const WORLD_SIZE=1800;
export const WATER_LEVEL=2;
export const TERRAIN_SEGMENTS=540;
export const TERRAIN_STEP=WORLD_SIZE/TERRAIN_SEGMENTS;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a));return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;
const hash=(x,z)=>{const n=Math.sin(x*127.1+z*311.7)*43758.5453123;return n-Math.floor(n);};
function noise(x,z){const ix=Math.floor(x),iz=Math.floor(z),fx=x-ix,fz=z-iz,u=fx*fx*(3-2*fx),v=fz*fz*(3-2*fz);return mix(mix(hash(ix,iz),hash(ix+1,iz),u),mix(hash(ix,iz+1),hash(ix+1,iz+1),u),v);}
function fbm(x,z){return noise(x,z)*.58+noise(x*2.03+4.2,z*2.03)*.28+noise(x*4.07,z*4.07-7.6)*.14;}
export function legacyHeightAt(x,z){const d=Math.abs(x-riverX(z)),w=10.4+Math.sin(z*.021)*1.25,hills=(fbm(x*.009,z*.009)-.42)*22;let h=.38+smooth(w-1,w+12,d)*5.5+smooth(18,98,d)*(17+hills);h+=Math.exp(-((x+165)**2/10500+(z+178)**2/18500))*38*smooth(20,95,d);h+=smooth(265,420,Math.max(Math.abs(x),Math.abs(z)))*(25+fbm(x*.014,z*.014)*70);h+=(noise(x*.065,z*.065)-.5)*.55*smooth(w+2,w+15,d);const shoal=1-smooth(7,24,Math.abs(z-30-Math.sin((x-riverX(30))*.08)*1.8)),gravel=1.37+noise(x*.10,z*.085)*.15;return Math.max(h,mix(.38,gravel,shoal));}
/** The central valley keeps its former shape; new land is blended outside it. */
export function rawHeightAt(x,z){
  const edge=Math.max(Math.abs(x),Math.abs(z)),outer=smooth(340,475,edge);
  let h=mix(legacyHeightAt(x,z),20+(fbm(x*.005,z*.005)-.4)*40+Math.sin(x*.005+z*.003)*6,outer);
  const ice=iceBlendAt(x,z);h=mix(h,62+fbm(x*.009,z*.009)*28+Math.sin(x*.012)*Math.cos(z*.009)*7,ice);
  const lava=lavaBlendAt(x,z),r=Math.hypot((x-610)/132,(z+350)/103);
  h=mix(h,33+fbm(x*.014,z*.014)*10+Math.exp(-((r-1.45)**2)/.10)*20,lava);
  if(lavaAt(x,z))h=LAVA_LEVEL-2.7+noise(x*.04,z*.04)*.25;
  const caveRegion=(1-smooth(36,90,Math.abs(z+55)))*(1-smooth(80,140,Math.abs(x+590)));
  h=mix(h,19+Math.sin(x*.011)*.7+Math.sin(z*.024)*.35,caveRegion);
  h=carveCaveTerrain(x,z,h);
  const coast=z-coastZ(x),shore=smooth(-72,28,coast);
  if(z>400)h=mix(h,mix(3.0,-3.4,smooth(-8,38,coast)),shore);
  if(coast>25)h=mix(h,-8-fbm(x*.006,z*.006)*18-smooth(30,230,coast)*16,smooth(25,100,coast));
  // Cut all three branches after the shore blend, so no sand dam can seal the mouth.
  const river=riverSampleAt(x,z),bank=river.bankDistance;
  if(bank<25){
    const channel=1-smooth(-1.5,25,bank);
    // Preserve the established walkable gravel shoal and aircraft crash riverbed.
    const shoal=river.id==='main'?1-smooth(7,24,Math.abs(z-30-Math.sin((x-riverX(30))*.08)*1.8)):0;
    const bed=mix(.34,1.37+noise(x*.10,z*.085)*.15,shoal);
    const bankProfile=bed+smooth(-1.5,12,bank)*5.2;
    h=Math.min(h,mix(h,bankProfile,channel));
  }
  return h;
}
const SIDE=TERRAIN_SEGMENTS+1,cache=new Float32Array(SIDE*SIDE);cache.fill(NaN);
export function terrainVertex(index){return Math.fround(-WORLD_SIZE/2+index*TERRAIN_STEP);}
export function terrainGridHeight(ix,iz){ix=clamp(ix,0,TERRAIN_SEGMENTS);iz=clamp(iz,0,TERRAIN_SEGMENTS);const i=iz*SIDE+ix;if(Number.isNaN(cache[i]))cache[i]=rawHeightAt(terrainVertex(ix),terrainVertex(iz));return cache[i];}
/** Exact barycentric height of the same Float32 triangles rendered by the world. */
export function heightAt(x,z){
  if(!Number.isFinite(x)||!Number.isFinite(z))return NaN;
  const gx=clamp((x+WORLD_SIZE/2)/TERRAIN_STEP,0,TERRAIN_SEGMENTS),gz=clamp((z+WORLD_SIZE/2)/TERRAIN_STEP,0,TERRAIN_SEGMENTS);
  const ix=Math.min(TERRAIN_SEGMENTS-1,Math.floor(gx)),iz=Math.min(TERRAIN_SEGMENTS-1,Math.floor(gz));
  const u=clamp((x-terrainVertex(ix))/(terrainVertex(ix+1)-terrainVertex(ix))),v=clamp((z-terrainVertex(iz))/(terrainVertex(iz+1)-terrainVertex(iz)));
  const a=terrainGridHeight(ix,iz),b=terrainGridHeight(ix+1,iz),c=terrainGridHeight(ix,iz+1),d=terrainGridHeight(ix+1,iz+1);
  return u+v<=1?a+(b-a)*u+(c-a)*v:d+(c-d)*(1-u)+(b-d)*(1-v);
}
/** Embed roots across their footprint instead of anchoring only at the centre. */
export function embeddedTreeHeight(x,z,radius,{samples=16,bury=.09}={}){let low=heightAt(x,z);for(let i=0;i<samples;i++){const a=i/samples*Math.PI*2;low=Math.min(low,heightAt(x+Math.cos(a)*radius,z+Math.sin(a)*radius));}return low-bury;}
export function hazardAt(x,z){return lavaAt(x,z)?{kind:'lava',damagePerSecond:42,surfaceY:LAVA_LEVEL,cause:'Burned in the lava.'}:null;}
