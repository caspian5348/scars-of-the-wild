export const SWIM_DEPTH = 1.25;
export const SWIM_SPEED = 2.6;
export const FAST_SWIM_SPEED = 4;
export const CHASE_SPEED_BOOST = .44704; // Exactly one mile per hour in metres/second.

const GRAVITY = 17;
const CONTACT_TOLERANCE = .08;
const EPSILON = 1e-8;
const finite = Number.isFinite;
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const levelOrDefault = value => finite(value) ? value : 2;

/** Feet float SWIM_DEPTH below the surface; the riverbed is never raised. */
export function getWaterState({ floor, footY, waterLevel = 2 } = {}) {
  const level = levelOrDefault(waterLevel);
  if (!finite(floor)) return { swimming: false, wading: false, supportY: finite(footY) ? footY : 0, depth: 0 };
  const depth = Math.max(0, level - floor);
  const supportY = Math.max(floor, level - SWIM_DEPTH);
  const swimming = finite(footY) && depth >= SWIM_DEPTH && footY <= supportY + CONTACT_TOLERANCE;
  const wading = finite(footY) && depth > 0 && !swimming && footY <= floor + CONTACT_TOLERANCE;
  return { swimming, wading, supportY, depth };
}

/**
 * Horizontal traversal only. The caller still checks world bounds/colliders.
 * Underwater slopes are measured from the floating support plane. Airborne feet
 * may clear a ledge already below them, but cannot climb above the step limit.
 */
export function canTraverseGround({ floor, fromFloor, footY, fromX, fromZ, x, z, waterLevel = 2 } = {}) {
  if (![floor, fromFloor, fromX, fromZ, x, z].every(finite)) return false;
  const level = levelOrDefault(waterLevel), floatY = level - SWIM_DEPTH;
  const destinationSupport = Math.max(floor, floatY), previousSupport = Math.max(fromFloor, floatY);
  const referenceY = Math.max(previousSupport, finite(footY) ? footY : previousSupport);
  const horizontal = Math.hypot(x - fromX, z - fromZ);
  return finite(horizontal) && destinationSupport - referenceY <= Math.max(.22, horizontal * .95) + EPSILON;
}

/**
 * A bounded vertical step. impactSpeed describes a new solid-ground landing;
 * deep-water contact reports zero so the caller's existing fall rule is kept.
 * Swimming is unsupported by the ground and therefore returns grounded=false.
 */
export function stepPlayerVertical({ footY = 0, verticalSpeed = 0, grounded = false, floor, dt = 0, waterLevel = 2 } = {}) {
  let y = finite(footY) ? footY : finite(floor) ? floor : 0;
  let velocity = finite(verticalSpeed) ? verticalSpeed : 0;
  const wasGrounded = !!grounded, level = levelOrDefault(waterLevel);
  const water = getWaterState({ floor, footY: y, waterLevel: level });
  const step = finite(dt) ? clamp(dt, 0, .25) : 0;
  if (!finite(floor) || step === 0) return {
    footY: y, verticalSpeed: velocity, grounded: finite(floor) && wasGrounded,
    swimming: water.swimming, wading: water.wading, impactSpeed: 0, enteredWater: false,
  };
  const deep = water.depth >= SWIM_DEPTH;
  const wasFloating = deep && !wasGrounded && Math.abs(y - water.supportY) <= EPSILON && Math.abs(velocity) <= EPSILON;
  const float = () => ({
    footY: water.supportY, verticalSpeed: 0, grounded: false,
    swimming: true, wading: false, impactSpeed: 0, enteredWater: !wasFloating,
  });
  // Saved grounded riverbed positions are corrected immediately. An ascending
  // shore jump stays airborne; existing submerged positions float without diving.
  if (deep && y <= water.supportY + CONTACT_TOLERANCE
    && (wasGrounded || velocity <= 0 || y < water.supportY - CONTACT_TOLERANCE)) return float();
  velocity -= GRAVITY * step;
  y += velocity * step;
  if (deep && velocity <= 0 && y <= water.supportY + CONTACT_TOLERANCE) return float();
  if (y <= floor) {
    const impactSpeed = wasGrounded ? 0 : Math.max(0, -velocity);
    const landing = getWaterState({ floor, footY: floor, waterLevel: level });
    return { footY: floor, verticalSpeed: 0, grounded: true, swimming: false, wading: landing.wading, impactSpeed, enteredWater: false };
  }
  const airborne = getWaterState({ floor, footY: y, waterLevel: level });
  return { footY: y, verticalSpeed: velocity, grounded: false, swimming: false, wading: airborne.wading, impactSpeed: 0, enteredWater: false };
}

/** Speeds and stamina use elapsed simulation seconds supplied by the caller. */
export function getPlayerLocomotion({ swimming = false, wading = false, moving = false, fastRequested = false, chased = false } = {}) {
  const fast = !!moving && !!fastRequested && !wading;
  const base = swimming ? fast ? FAST_SWIM_SPEED : SWIM_SPEED : wading ? 2.2 : fast ? 7.2 : 4.2;
  return { speed:base+(chased?CHASE_SPEED_BOOST:0),fast,stamina:100,chaseBoost:chased?CHASE_SPEED_BOOST:0 };
}
