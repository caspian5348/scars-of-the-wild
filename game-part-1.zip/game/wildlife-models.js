import * as THREE from './vendor/three.module.js';
import {WILDLIFE_SPECIES} from './wildlife-catalog.js';

const TAU=Math.PI*2,UP=new THREE.Vector3(0,1,0);
const hash=(a,b=0)=>{const n=Math.sin(a*127.1+b*311.7)*43758.5453;return n-Math.floor(n);};
const mix=THREE.MathUtils.lerp;

function surfaceGrain(anatomy){
  const fur=['deer','boar','goat','wolf','fox','snowfox','ox','mole','hare','bear','bat'].includes(anatomy),feather=['toucan','raven','owl','gull','turkey'].includes(anatomy);
  const size=128,data=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const i=(y*size+x)*4,grain=hash(x,y),strand=hash(Math.floor((x+Math.sin(y*.06)*1.3)/2),Math.floor(y/24));
    const sx=(x+(Math.floor(y/9)%2)*5)%10,sy=y%9,scale=Math.hypot((sx-5)/5,(sy-4)/4.5);
    const hair=Math.sin(x*2.13+Math.sin(y*.055+x*.10)*.75)+Math.sin(x*3.61-y*.022)*.38;
    const v=fur?218+hair*4+grain*7:feather?207+Math.sin(y*.58+x*.13)*8+grain*10:211+grain*10+(scale>.83?-12:Math.max(0,1-scale)*10);
    data[i]=data[i+1]=data[i+2]=v;data[i+3]=255;
  }
  const map=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);map.wrapS=map.wrapT=THREE.RepeatWrapping;map.repeat.set(fur?3:2,fur?2:3);map.colorSpace=THREE.SRGBColorSpace;map.needsUpdate=true;return map;
}

/** Small merged anatomical meshes keep each animal to a few draw calls. */
export function createWildlifeModel(species,{lod=0}={}){
  const spec=typeof species==='string'?WILDLIFE_SPECIES[species]:species;
  if(!spec)throw new Error('Unknown wildlife species.');
  const group=new THREE.Group();group.name=spec.name;
  const resources=new Set(),own=value=>(resources.add(value),value),grain=own(surfaceGrain(spec.anatomy));
  const shiny=['frog','salamander','reeffish','tuna','shark','manta','ocean_deatheater','jellyfish'].includes(spec.anatomy);
  const material=own(new THREE.MeshStandardMaterial({vertexColors:true,color:'#ffffff',roughness:shiny?.42:.92,metalness:0,map:grain,bumpMap:grain,bumpScale:shiny?.0007:.0015}));
  const wetMaterial=own(new THREE.MeshStandardMaterial({vertexColors:true,color:'#ffffff',roughness:.21,metalness:0}));
  const glowMaterial=spec.bioluminescent||spec.anatomy==='dinosaur'?own(new THREE.MeshStandardMaterial({vertexColors:true,color:'#ffffff',emissive:spec.anatomy==='dinosaur'?'#603585':'#8bdbc7',emissiveIntensity:spec.anatomy==='dinosaur'?.42:.70,roughness:.53,metalness:0})):null;
  const skin=spec.coat||'#817566',belly=spec.belly||'#b6a58b',dark='#272923',horn='#b6ac91';
  const bodyRoot=new THREE.Group();bodyRoot.name='Breathing torso';group.add(bodyRoot);
  const segmentCount=lod?10:16,ringCount=lod?7:10;
  function builder(meshMaterial=material){
    const p=[],n=[],uv=[],c=[];
    return {
      add(g,color='#ffffff',position=[0,0,0],scale=[1,1,1],rotation=[0,0,0]){
        const matrix=new THREE.Matrix4().compose(new THREE.Vector3(...position),new THREE.Quaternion().setFromEuler(new THREE.Euler(...rotation)),new THREE.Vector3(...scale));
        const normalMatrix=new THREE.Matrix3().getNormalMatrix(matrix),base=new THREE.Color(color),v=new THREE.Vector3(),nn=new THREE.Vector3();
        const pos=g.attributes.position,norm=g.attributes.normal,tex=g.attributes.uv,colors=g.attributes.color,count=g.index?.count||pos.count;
        for(let j=0;j<count;j++){
          const i=g.index?g.index.getX(j):j;v.fromBufferAttribute(pos,i).applyMatrix4(matrix);nn.fromBufferAttribute(norm,i).applyMatrix3(normalMatrix).normalize();
          p.push(v.x,v.y,v.z);n.push(nn.x,nn.y,nn.z);uv.push(tex?tex.getX(i):0,tex?tex.getY(i):0);
          const variation=.96+hash(Math.round(v.x*35),Math.round(v.z*35))* .055;c.push(base.r*variation*(colors?colors.getX(i):1),base.g*variation*(colors?colors.getY(i):1),base.b*variation*(colors?colors.getZ(i):1));
        }g.dispose();
      },
      finish(parent=bodyRoot,name='Anatomical surface'){
        if(!p.length)return null;const g=own(new THREE.BufferGeometry());g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(n,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('color',new THREE.Float32BufferAttribute(c,3));
        const mesh=new THREE.Mesh(g,meshMaterial);mesh.name=name;mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;
      }
    };
  }
  function oval(b,pos,scale,color=skin,rotation=[0,0,0],rough=.004){
    const g=new THREE.SphereGeometry(1,segmentCount,ringCount),p=g.attributes.position;
    for(let i=0;i<p.count;i++){const v=1+(hash(i,scale[0]*13)-.5)*rough;p.setXYZ(i,p.getX(i)*v,p.getY(i)*v,p.getZ(i)*v);}g.computeVertexNormals();b.add(g,color,pos,scale,rotation);
  }
  function tube(b,points,radius,color=skin,taper=1){
    const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),segments=Math.max(8,points.length*4),g=new THREE.TubeGeometry(curve,segments,radius,lod?5:7,false);
    if(taper!==1){const p=g.attributes.position;for(let i=0;i<p.count;i++){const t=g.attributes.uv.getX(i),center=curve.getPointAt(t),r=mix(1,taper,t);p.setXYZ(i,center.x+(p.getX(i)-center.x)*r,center.y+(p.getY(i)-center.y)*r,center.z+(p.getZ(i)-center.z)*r);}g.computeVertexNormals();}
    b.add(g,color);
  }
  function triangle(b,points,color=skin){
    const p=[...points[0],...points[1],...points[2],...points[2],...points[1],...points[0]],g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,0,1,0,1,1,0,0,0],2));g.computeVertexNormals();b.add(g,color);
  }
  // A continuous ring surface describes rib cages, skulls and fish bodies.
  // Width and vertical centre vary independently along the spine, avoiding a
  // chain of intersecting balls and preserving an actual abdominal tuck.
  function form(b,rings,color=skin,underside=belly){
    const silhouette=new THREE.CatmullRomCurve3(rings.map(r=>new THREE.Vector3(r[2],r[3],r[0]))),spine=new THREE.CatmullRomCurve3(rings.map(r=>new THREE.Vector3(r[1],0,r[0]))),steps=(rings.length-1)*(lod?2:4);
    rings=Array.from({length:steps+1},(_,i)=>{const s=silhouette.getPoint(i/steps),c=spine.getPoint(i/steps);return [s.z,c.x,Math.max(.004,s.x),Math.max(.004,s.y)];});
    const p=[],uv=[],cols=[],indices=[],top=new THREE.Color(color),low=new THREE.Color(underside),count=lod?12:20;
    for(let j=0;j<rings.length;j++)for(let k=0;k<=count;k++){
      const [z,cy,w,h]=rings[j],a=k/count*TAU,sy=Math.sin(a),tone=top.clone().lerp(low,Math.max(0,-sy)*.64);
      p.push(Math.cos(a)*w,cy+sy*h,z);uv.push(k/count,j/(rings.length-1));cols.push(tone.r,tone.g,tone.b);
      if(j<rings.length-1&&k<count){const n=j*(count+1)+k;indices.push(n,n+1,n+count+1,n+1,n+count+2,n+count+1);}
    }
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));g.setIndex(indices);g.computeVertexNormals();b.add(g,'#ffffff');
  }
  function feather(b,base,length,width,color,rotation=0){
    const rows=lod?4:7,p=[],uv=[],indices=[];
    for(let j=0;j<=rows;j++){const t=j/rows,w=Math.sin(Math.PI*Math.pow(t,.75))*width;for(const side of [-1,1]){const x=side*w,z=t*length,rx=x*Math.cos(rotation)-z*Math.sin(rotation),rz=x*Math.sin(rotation)+z*Math.cos(rotation);p.push(base[0]+rx,base[1]+Math.sin(t*Math.PI)*.012-side*.004,base[2]+rz);uv.push(side>0?1:0,t);}if(j<rows){const q=j*2;indices.push(q,q+1,q+2,q+1,q+3,q+2,q+2,q+1,q,q+2,q+3,q+1);}}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();b.add(g,color);
  }
  const body=builder(),wet=builder(wetMaterial),tailRig=new THREE.Group(),wingRigs=[],legDefs=[],specialLimbs=[],softRigs=[];bodyRoot.add(tailRig);
  let tailMesh=null,bodyLift=0,hop=false,swimTail=false,wingRate=6,wingAmplitude=.5;
  function eyes(pos,separation,radius=.018){for(const side of [-1,1]){
    oval(body,[side*separation,pos[1]+radius*.12,pos[2]+radius*.12],[radius*1.14,radius*.73,radius*.76],skin,[0,side*.25,0],0);
    oval(wet,[side*(separation+radius*.22),pos[1],pos[2]-radius*.25],[radius*.76,radius*.57,radius*.66],'#101411',[0,side*.25,0],0);
  }}
  function ears(y,z,x,size){for(const side of [-1,1]){oval(body,[side*x,y,z],[size*.46,size,size*.18],skin,[0,0,side*.22]);oval(body,[side*x,y,z-.01],[size*.24,size*.7,size*.05],belly,[0,0,side*.22]);}}
  function fourLegs({x=.22,y=.65,z=.44,r=.055,spread=0}={}){
    for(const side of [-1,1])for(const front of [-1,1])legDefs.push({hip:[side*x,y,front*z],side,front,r,spread,phase:(side===front?0:Math.PI),type:spread>.10?'splayed':'quad'});
  }
  function pointedHorn(points,r=.055){tube(body,points,r,horn,.08);}

  if(['deer','boar','goat','wolf','fox','snowfox','ox','mole','hare','bear'].includes(spec.anatomy)){
    const profiles={deer:[1.0,.29,.31,.78,1.38,-.93,.17,.20,.28,.24,.94,.48,.061],boar:[.61,.35,.34,.73,.55,-.84,.24,.23,.33,.27,.49,.46,.094],goat:[.78,.26,.29,.60,1.12,-.68,.15,.21,.24,.21,.74,.39,.067],wolf:[.79,.26,.30,.76,.90,-.88,.20,.23,.31,.22,.71,.51,.079],fox:[.44,.17,.18,.53,.54,-.60,.12,.15,.22,.14,.38,.35,.044],snowfox:[.40,.21,.20,.49,.51,-.55,.135,.16,.21,.16,.33,.31,.049],ox:[1.05,.51,.48,1.02,.93,-1.15,.28,.33,.40,.39,.82,.69,.14],mole:[.18,.16,.15,.31,.15,-.36,.105,.095,.16,.14,.13,.20,.041],hare:[.32,.16,.23,.37,.49,-.36,.11,.14,.17,.12,.24,.21,.032],bear:[1.00,.49,.48,.98,.94,-1.13,.29,.30,.37,.39,.83,.67,.155]};
    const p=profiles[spec.anatomy],longNeck=['deer','goat'].includes(spec.anatomy),heavy=['ox','bear','boar'].includes(spec.anatomy);
    const muzzle=spec.anatomy==='hare'?.82:spec.anatomy==='mole'?1.63:spec.anatomy==='bear'?1.21:1.48,muzzleWidth=spec.anatomy==='bear'?.43:.27;
    // One uninterrupted skin from the muzzle through the spine: the neck has
    // no open tube ends or intersecting skull/torso seams.
    form(body,[[p[5]-p[8]*muzzle-.007,p[4]-.07,.004,.004],[p[5]-p[8]*muzzle,p[4]-.07,p[6]*muzzleWidth,p[7]*.22],[p[5]-p[8]*.70,p[4]-.045,p[6]*.54,p[7]*.49],[p[5]-p[8]*.28,p[4]+.005,p[6]*.95,p[7]*.91],[p[5],p[4]+.015,p[6],p[7]],[p[5]+p[8]*.40,p[4]-.015,p[6]*.81,p[7]*.88],[p[5]*.68,(p[0]+p[4])*.5,p[1]*(longNeck?.63:.83),p[2]*(longNeck?.83:.95)],[-p[3]*.43,p[0]+.04,p[1],p[2]],[-p[3]*.08,p[0],p[1]*.95,p[2]*.98],[p[3]*.36,p[0]+(heavy?0:.065),p[1]*.80,p[2]*(heavy?.9:.69)],[p[3]*.70,p[0]+.015,p[1]*.84,p[2]*.83],[p[3]*.91,p[0],p[1]*.54,p[2]*.64],[p[3],p[0],.008,.012]]);
    eyes([0,p[4]+p[7]*.19,p[5]-p[8]*.32],p[6]*.98,spec.anatomy==='mole'?.005:spec.anatomy==='bear'?.017:.0135);
    oval(wet,[0,p[4]-.058,p[5]-p[8]*muzzle],[p[6]*muzzleWidth,p[7]*.17,p[8]*.07],dark);
    tube(body,[[-p[6]*.33,p[4]-.07-p[7]*.12,p[5]-p[8]*.94],[0,p[4]-.07-p[7]*.16,p[5]-p[8]*muzzle],[p[6]*.33,p[4]-.07-p[7]*.12,p[5]-p[8]*.94]],.0025,dark);
    const earSize=spec.anatomy==='hare'?.24:spec.anatomy==='snowfox'?.062:spec.anatomy==='mole'?.023:spec.anatomy==='bear'?.088:.125;
    if(['wolf','fox','boar'].includes(spec.anatomy))for(const side of [-1,1]){const x=side*p[6]*.72,y=p[4]+p[7]*.76,z=p[5]+.02;triangle(body,[[x-side*earSize*.53,y,z],[x+side*earSize*.52,y,z],[x+side*earSize*.15,y+earSize*1.55,z+.025]],skin);triangle(body,[[x-side*earSize*.34,y+.025,z-.004],[x+side*earSize*.32,y+.025,z-.004],[x+side*earSize*.10,y+earSize*1.22,z+.017]],'#796b61');}
    else if(spec.anatomy==='bear')for(const side of [-1,1]){oval(body,[side*p[6]*.78,p[4]+p[7]*.86,p[5]+.045],[.084,.087,.046],skin);oval(body,[side*p[6]*.78,p[4]+p[7]*.87,p[5]+.012],[.045,.045,.018],'#66584b');}
    else if(['deer','goat'].includes(spec.anatomy))for(const side of [-1,1]){oval(body,[side*p[6]*1.19,p[4]+p[7]*.66,p[5]+.075],[.135,.058,.046],skin,[0,0,side*.42]);oval(body,[side*p[6]*1.23,p[4]+p[7]*.67,p[5]+.035],[.089,.033,.016],'#86786a',[0,0,side*.42]);}
    else ears(p[4]+p[7]*.90,p[5]+.02,p[6]*.77,earSize);
    // Limb roots sit inside the shoulder and haunch, with overlapping joints.
    for(const side of [-1,1])for(const front of [-1,1])oval(body,[side*p[9]*.72,p[10]+p[12]*.72,front*p[11]],[p[12]*1.36,p[12]*2.1,p[12]*1.5],skin,[front*.14,0,side*.08]);
    fourLegs({x:p[9],y:p[10],z:p[11],r:p[12],spread:spec.anatomy==='mole'?.15:0});
    const tail=builder();
    if(spec.anatomy==='hare'){oval(tail,[0,.05,.12],[.095,.105,.11],belly);hop=true;}
    else if(spec.anatomy==='boar')tube(tail,[[0,0,0],[0,.08,.22],[.07,.14,.30],[.11,.07,.32]],.018,skin,.4);
    else if(spec.anatomy==='mole')tube(tail,[[0,0,0],[0,0,.22],[.035,-.025,.37]],.025,belly,.12);
    else if(['fox','snowfox','wolf'].includes(spec.anatomy)){tube(tail,[[0,0,0],[.015,-.09,.25],[.03,-.17,.49],[.07,-.14,.70]],p[1]*.70,skin,.08);if(spec.anatomy!=='wolf')tube(tail,[[.045,-.17,.50],[.065,-.15,.64],[.07,-.14,.70]],p[1]*.30,belly,.02);}
    else if(spec.anatomy==='bear')tube(tail,[[0,0,0],[0,-.035,.13]],.075,skin,.30);
    else tube(tail,[[0,0,0],[.015,-.07,.14],[.03,-.17,.24]],.045,skin,.45);
    tailRig.position.set(0,p[0],p[3]*.83);tailMesh=tail.finish(tailRig,'Balanced tail');
    if(spec.anatomy==='deer')for(const side of [-1,1]){
      const branch=[[side*.10,1.49,-.92],[side*.17,1.72,-.79],[side*.29,1.91,-.59],[side*.45,2.06,-.43]];pointedHorn(branch,.038);
      for(let i=1;i<4;i++){const a=branch[i];pointedHorn([a,[a[0]+side*.12,a[1]+.16,a[2]-.14],[a[0]+side*.14,a[1]+.29,a[2]-.19]],.025);}
    }
    if(spec.anatomy==='goat')for(const side of [-1,1])pointedHorn([[side*.11,1.29,-.57],[side*.15,1.54,-.49],[side*.13,1.64,-.26],[side*.09,1.52,-.16]],.045);
    if(spec.anatomy==='ox'){
      oval(body,[0,1.28,-.36],[.50,.33,.43]);for(const side of [-1,1])pointedHorn([[side*.22,.91,-1.00],[side*.54,.91,-1.05],[side*.73,1.12,-1.12],[side*.65,1.36,-1.16]],.088);
      for(let i=0;i<36;i++){const side=i%2?1:-1,x=side*(.37+hash(i)*.075),y=.80+hash(i,2)*.20,z=(hash(i,3)-.5)*1.35;tube(body,[[x,y,z],[x+side*.055,y-.19,z+.045],[x+side*.025,y-.37,z+.07]],.019,skin,.02);}
    }
    if(spec.anatomy==='boar'){
      for(const side of [-1,1])pointedHorn([[side*.18,.43,-.98],[side*.28,.47,-1.10],[side*.24,.65,-1.10]],.037);
      for(let i=0;i<18;i++)tube(body,[[(hash(i)-.5)*.16,.87,-.47+i*.053],[(hash(i)-.5)*.20,.97+hash(i,4)*.05,-.44+i*.053]],.005,dark,.1);
    }
    if(spec.anatomy==='mole')for(const side of [-1,1])for(let i=0;i<3;i++)pointedHorn([[side*.22,.055,-.18-i*.024],[side*.31,.04,-.27-i*.025]],.011);
    if(spec.anatomy==='hare'){oval(body,[-.14,.21,.17],[.13,.19,.17]);oval(body,[.14,.21,.17],[.13,.19,.17]);}
  } else if(['frog','monitor','salamander','tortoise','seaturtle'].includes(spec.anatomy)){
    const frog=spec.anatomy==='frog',monitor=spec.anatomy==='monitor',salamander=spec.anatomy==='salamander',sea=spec.anatomy==='seaturtle',turtle=sea||spec.anatomy==='tortoise';
    const width=frog?.16:monitor?.25:salamander?.12:sea?.53:.59,length=frog?.22:monitor?.62:salamander?.40:.70,y=frog?.13:monitor?.24:salamander?.11:sea?.27:.38;
    const height=turtle?(sea?.20:.33):width*.69;
    form(body,[[-length,y,.012,.012],[-length*.72,y,width*.69,height*.65],[-length*.30,y,width*.97,height*.97],[length*.28,y,width,height],[length*.76,y,width*.65,height*.76],[length,y,.01,.01]]);
    const headZ=-length*.94;oval(body,[0,y-.02,headZ],[frog?.19:width*.53,frog?.095:width*.38,frog?.13:width*.75]);
    eyes([0,y+(frog?.071:.035),headZ-.045],frog?.13:width*.42,salamander?.003:frog?.016:.010);
    if(turtle){
      if(sea){for(let ridge=-3;ridge<=3;ridge++)tube(body,[[ridge*.095,y+.075,-.53],[ridge*.12,y+.19,.02],[ridge*.082,y+.105,.53]],.009,belly,.65);}
      else for(let ring=0;ring<3;ring++)for(let i=0;i<(ring?6:1);i++){
        const a=i/6*TAU,r=ring/3,x=Math.cos(a)*width*r,z=Math.sin(a)*length*r,cy=y+height*Math.sqrt(Math.max(.01,1-r*r));
        for(let edge=0;edge<6;edge++){const ea=edge/6*TAU,eb=(edge+1)/6*TAU;triangle(body,[[x,cy+.005,z],[x+Math.cos(ea)*width*.23,cy-.018,z+Math.sin(ea)*length*.21],[x+Math.cos(eb)*width*.23,cy-.018,z+Math.sin(eb)*length*.21]],ring%2?skin:'#777061');}
      }
      if(sea){
        for(const side of [-1,1]){const wing=new THREE.Group();wing.position.set(side*.38,.25,-.35);bodyRoot.add(wing);const b=builder();triangle(b,[[0,0,0],[side*.62,-.05,.12],[side*.30,-.07,.38]],skin);oval(b,[side*.18,-.035,.08],[.31,.04,.14]);b.finish(wing,'Leatherback foreflipper');wingRigs.push({group:wing,side,sea:true});}
        for(const side of [-1,1])legDefs.push({hip:[side*.35,.16,.45],side,front:1,r:.034,spread:.24,phase:side>0?0:Math.PI,type:'quad'});
      }else fourLegs({x:.38,y:.26,z:.40,r:.09,spread:.16});
    } else {
      fourLegs({x:width*.62,y:y*.82,z:length*.58,r:frog?.033:monitor?.055:.023,spread:frog?.19:monitor?.22:.13});
      const tail=builder();if(!frog){tube(tail,[[0,0,0],[.03,0,length*.8],[.12,-.025,length*1.7],[.20,-.04,length*2.1]],width*.45,skin,.035);tailRig.position.set(0,y,length*.62);tailMesh=tail.finish(tailRig,'Tapered reptile tail');}
      if(monitor)for(let i=0;i<12;i++)triangle(body,[[-.05,y+.13,-.4+i*.075],[0,y+.20,-.36+i*.075],[.05,y+.13,-.32+i*.075]],belly);
      if(salamander)for(const side of [-1,1])for(let i=0;i<3;i++)tube(body,[[side*.07,y,-.31],[side*(.13+i*.025),y+.035,-.34+i*.028],[side*(.17+i*.022),y+.08,-.31+i*.030]],.009,'#8b716c',.2);
      hop=frog;
    }
  } else if(['spider','scorpion','crab','mantis'].includes(spec.anatomy)){
    const spider=spec.anatomy==='spider',scorpion=spec.anatomy==='scorpion',crab=spec.anatomy==='crab',mantis=spec.anatomy==='mantis';
    const y=spider?.32:mantis?.46:.14;
    const az=spider?.23:0,aw=spider?.26:mantis?.105:crab?.29:.20,ah=spider?.19:mantis?.11:.105,al=spider?.36:mantis?.42:crab?.22:.38;
    form(body,[[az-al,y,.012,.012],[az-al*.66,y,aw*.72,ah*.75],[az-al*.08,y,aw,ah],[az+al*.58,y,aw*.81,ah*.79],[az+al,y,.008,.008]]);
    oval(body,[0,y,-(spider?.22:mantis?.28:.25)],[mantis?.095:.17,mantis?.17:.12,.19],belly);
    if(mantis){
      tube(body,[[0,.40,-.19],[0,.68,-.35],[0,.90,-.43]],.058,skin,.5);
      triangle(body,[[-.17,.93,-.40],[.17,.93,-.40],[0,.83,-.54]],belly);eyes([0,.94,-.46],.125,.025);
      for(const side of [-1,1]){tube(body,[[side*.09,.94,-.44],[side*.14,1.11,-.53],[side*.19,1.17,-.69]],.006,dark,.2);specialLimbs.push({side,type:'raptor'});}
    }else{
      const pairs=spider?4:1;
      for(let i=0;i<pairs;i++)for(const side of [-1,1])oval(body,[side*(.05+i*.031),y+.095,-.38+i*.025],[.014,.014,.012],dark);
    }
    for(const side of [-1,1])for(let i=0;i<(mantis?2:4);i++)legDefs.push({hip:[side*(mantis?.08:crab?.19:.12),y,(i/(mantis?1:3)-.5)*(mantis?.54:.62)],side,front:i%2?1:-1,r:spider?.026:mantis?.022:crab?.026:.022,spread:spider?.64:mantis?.37:crab?.36:.35,phase:i*.9+(side>0?Math.PI:0),type:'splayed'});
    if(spider){
      for(const side of [-1,1])pointedHorn([[side*.08,.29,-.36],[side*.13,.22,-.45],[side*.08,.15,-.46]],.036);
      for(let i=0;i<(lod?8:32);i++){const side=i%2?1:-1,x=side*(.16+hash(i)*.08),z=-.02+hash(i,3)*.47;pointedHorn([[x,.40,z],[x+side*.035,.43+hash(i,4)*.04,z+.025]],.0045);}
    }
    if(crab||scorpion)for(const side of [-1,1]){
      const x=side*(crab?.41:.34);tube(body,[[side*.15,y,-.24],[x,y+.09,-.40]],.045);
      oval(body,[x,y+.11,-.49],[.10,.075,.13]);pointedHorn([[x-side*.05,y+.10,-.55],[x-side*.075,y+.11,-.68],[x-side*.015,y+.12,-.72]],.038);pointedHorn([[x+side*.06,y+.10,-.55],[x+side*.085,y+.12,-.68],[x+side*.025,y+.12,-.72]],.032);
    }
    if(scorpion){const tail=builder();tube(tail,[[0,0,0],[0,.10,.24],[0,.34,.29],[0,.56,.10],[0,.52,-.14]],.057,skin,.50);tube(tail,[[0,.52,-.14],[0,.43,-.22],[0,.37,-.20]],.043,dark,.05);tailRig.position.set(0,y,.29);tailMesh=tail.finish(tailRig,'Curled venom tail');for(let i=0;i<6;i++)tube(body,[[-.16,.175,-.18+i*.082],[0,.248,-.20+i*.085],[.16,.175,-.18+i*.082]],.009,belly,.85);}
    if(crab)for(const side of [-1,1]){tube(body,[[side*.12,.17,-.16],[side*.16,.28,-.20]],.014,belly);oval(body,[side*.16,.29,-.21],[.027,.023,.028],dark);}
  } else if(['toucan','raven','owl','gull','bat','turkey'].includes(spec.anatomy)){
    const bat=spec.anatomy==='bat',owl=spec.anatomy==='owl',turkey=spec.anatomy==='turkey',toucan=spec.anatomy==='toucan',gull=spec.anatomy==='gull';
    const y=turkey?.43:0,scale=bat?.11:turkey?.28:.19,length=bat?.17:turkey?.35:.29;
    form(body,[[-length,y,.012,.012],[-length*.70,y+.02,scale*.66,scale*.86],[-length*.15,y,scale,scale*1.04],[length*.50,y-.025,scale*.74,scale*.78],[length,y-.025,.012,.016]]);
    const hy=y+(turkey?.34:owl?.15:bat?.04:.13),hz=turkey?-.27:bat?-.15:-.24;
    if(turkey)tube(body,[[0,.53,-.20],[0,.71,-.29],[0,.81,-.29]],.045,'#8f7770',.8);
    oval(body,[0,hy,hz],[owl?.17:bat?.085:turkey?.09:.115,owl?.18:bat?.085:turkey?.10:.13,owl?.105:.12],owl?belly:skin);
    if(owl)for(const side of [-1,1]){oval(body,[side*.067,hy,hz-.07],[.072,.092,.017],belly);oval(wet,[side*.069,hy+.009,hz-.091],[.017,.019,.009],'#746943');oval(wet,[side*.069,hy+.009,hz-.100],[.010,.012,.004],dark);}
    else eyes([0,hy+.028,hz-.075],bat?.060:turkey?.071:.088,bat?.010:.011);
    if(!bat){const bill=toucan?.40:gull?.22:.16,bw=toucan?.070:.025,bh=toucan?.075:.026;form(body,[[hz-bill,hy-.032,.001,.001],[hz-bill*.67,hy-.010,bw*.62,bh*.8],[hz-.07,hy-.015,bw,bh]],toucan?'#b39a58':gull?'#b4a372':dark,dark);}
    else ears(hy+.086,hz,.058,.08);
    if(turkey){
      for(let i=0;i<11;i++){const x=(i-5)*.024;feather(body,[x,.43,.16],.39,.033,i%3?skin:belly,(i-5)*.068);}
      for(const side of [-1,1])for(let row=0;row<3;row++)for(let i=0;i<6;i++)feather(body,[side*(.18+row*.022),.52-row*.046,-.12+i*.040],.25,.033,i%4?skin:belly,side*.14);
      for(const side of [-1,1])legDefs.push({hip:[side*.105,.30,.03],side,front:side,r:.021,spread:0,phase:side>0?Math.PI:0,type:'quad'});
    } else {
      const span=bat?.54:gull?.97:owl?.76:toucan?.60:.83;
      for(const side of [-1,1]){
        const wing=new THREE.Group();wing.position.set(side*scale*.67,y+.03,0);bodyRoot.add(wing);wingRigs.push({group:wing,side,bat});const b=builder();
        if(bat){
          const anchor=[0,0,0],elbow=[side*span*.41,.035,-.08],tip=[side*span,.0,.08];
          triangle(b,[anchor,elbow,tip],'#686158');
          for(let i=0;i<5;i++){const edge=[side*span*(.94-i*.14),-.045,.11+i*.063];triangle(b,[anchor,i? [side*span*(1.08-i*.14),-.045,.047+i*.063]:tip,edge],'#726a60');tube(b,[anchor,elbow,edge],.007,belly,.25);}
        }else{
          triangle(b,[[0,0,-.08],[side*span,.015,.03],[side*span*.46,-.025,.35]],skin);
          for(let row=0;row<2;row++)for(let i=0;i<(lod?7:11);i++){const x=span*(.10+i*(lod?.115:.074)),z=.015+row*.095;feather(b,[side*x,-.005-row*.008,z],.24+row*.08+(i>4?.03:0),span*(row?.061:.074),i%4===0?belly:skin,side*(-.48+i*.045));}
        }
        b.finish(wing,bat?'Finger-supported wing membrane':'Layered flight feathers');
      }
      const tail=builder();for(let i=0;i<5;i++)feather(tail,[(i-2)*.021,0,0],bat?.12:gull?.27:.33,.026,i%2?skin:belly,(i-2)*.10);tailRig.position.set(0,y,length*.78);tailMesh=tail.finish(tailRig,'Flight tail');
      if(!bat)for(const side of [-1,1])tube(body,[[side*.07,y-.13,.12],[side*.075,y-.19,.21],[side*.09,y-.19,.24]],.013,'#85735c',.7);
      wingRate=bat?13:toucan?8:6.5;wingAmplitude=bat?.8:gull?.30:.50;
    }
  } else if(spec.anatomy==='jellyfish'){
    const membrane=own(new THREE.MeshPhysicalMaterial({color:'#88c0bb',roughness:.24,metalness:0,transparent:true,opacity:.48,side:THREE.DoubleSide,emissive:'#508d93',emissiveIntensity:.30,depthWrite:false}));
    const dome=builder(membrane),ribs=builder(glowMaterial);
    const profile=[new THREE.Vector2(.015,.30),new THREE.Vector2(.13,.28),new THREE.Vector2(.26,.21),new THREE.Vector2(.36,.11),new THREE.Vector2(.41,-.035),new THREE.Vector2(.385,-.095)];
    dome.add(new THREE.LatheGeometry(profile,lod?18:32),'#bcd7d0');dome.finish(bodyRoot,'Translucent jellyfish bell');
    for(let i=0;i<8;i++){
      const a=i/8*TAU,dx=Math.cos(a),dz=Math.sin(a);
      tube(ribs,[[dx*.05,.292,dz*.05],[dx*.23,.23,dz*.23],[dx*.35,.12,dz*.35],[dx*.39,-.075,dz*.39]],.006,'#a0f0d5',.65);
    }
    const rim=new THREE.TorusGeometry(.391,.012,5,lod?24:48);ribs.add(rim,'#a8e5d4',[0,-.08,0],[1,1,1],[Math.PI/2,0,0]);
    oval(ribs,[0,.12,0],[.09,.1,.09],'#8bc4da');ribs.finish(bodyRoot,'Luminous bell canals');
    for(let rig=0;rig<2;rig++){
      const tentacleRoot=new THREE.Group();tentacleRoot.position.y=-.07;bodyRoot.add(tentacleRoot);softRigs.push({group:tentacleRoot,phase:rig*Math.PI});const b=builder(glowMaterial);
      for(let i=0;i<(lod?3:5);i++){
        const a=(i/(lod?3:5)+rig*.11)*TAU,r=.18+rig*.13,len=.55+hash(i,rig)*.45;
        tube(b,[[Math.cos(a)*r,0,Math.sin(a)*r],[Math.cos(a+.12)*r,-len*.35,Math.sin(a+.12)*r],[Math.cos(a-.15)*r*.9,-len*.73,Math.sin(a-.15)*r*.9],[Math.cos(a+.25)*r*.8,-len,Math.sin(a+.25)*r*.8]],rig?.007:.014,rig?'#b4dbe9':'#abdccc',.10);
      }b.finish(tentacleRoot,'Trailing luminous filaments');
    }
  } else if(spec.anatomy==='butterfly'){
    tube(body,[[0,.02,-.085],[0,.025,0],[0,.02,.13]],.017,'#313f40',.18);
    oval(body,[0,.025,-.072],[.021,.018,.02],'#394b46');eyes([0,.03,-.083],.018,.005);
    for(const side of [-1,1]){
      tube(body,[[side*.014,.035,-.077],[side*.035,.08,-.12],[side*.053,.09,-.14]],.002,'#97b2a8',.35);
      const wing=new THREE.Group();wing.position.set(side*.012,.023,0);bodyRoot.add(wing);wingRigs.push({group:wing,side});const b=builder(glowMaterial);
      oval(b,[side*.125,0,-.055],[.14,.004,.13],skin,[0,side*.24,0],0);
      oval(b,[side*.095,0,.088],[.105,.004,.095],belly,[0,side*-.20,0],0);
      for(let i=0;i<(lod?4:7);i++){
        const angle=-1.0+i*.30;
        tube(b,[[0,.006,.008],[side*.08,.007,-.015+i*.013],[side*(.12+Math.cos(angle)*.1),.006,-.055+Math.sin(angle)*.11]],.0018,'#38595d',.5);
      }
      oval(b,[side*.18,.006,-.075],[.027,.002,.031],'#d6f0d1',[],0);
      oval(b,[side*.18,.009,-.075],[.014,.002,.017],'#45626c',[],0);
      b.finish(wing,'Veined luminous butterfly wings');
      for(let i=0;i<3;i++)tube(body,[[side*.008,.015,-.02+i*.024],[side*.033,-.012,-.025+i*.022],[side*.05,-.02,-.042+i*.027]],.0018,dark,.35);
    }wingRate=18;wingAmplitude=1.02;
  } else if(spec.anatomy==='dinosaur'){
    form(body,[[-2.23,2.42,.018,.02],[-2.18,2.44,.15,.13],[-1.83,2.57,.25,.29],[-1.41,2.61,.26,.30],[-1.13,2.40,.21,.36],[-.65,1.99,.43,.56],[-.03,1.79,.60,.66],[.67,1.66,.52,.57],[1.03,1.57,.34,.34],[1.18,1.54,.12,.13]]);
    form(wet,[[-2.22,2.28,.01,.008],[-2.14,2.29,.13,.025],[-1.84,2.34,.22,.035],[-1.48,2.36,.21,.035],[-1.35,2.42,.10,.02]],'#2e2528','#2e2528');
    eyes([0,2.70,-1.72],.249,.030);
    for(const side of [-1,1]){
      // Paired bony crests and a narrow serrated jaw identify a theropod,
      // rather than a four-legged lizard scaled up.
      triangle(body,[[side*.13,2.73,-1.88],[side*.14,3.31,-1.28],[side*.15,2.85,-1.01]],'#75646b');
      tube(body,[[side*.14,2.83,-1.89],[side*.14,3.19,-1.32],[side*.15,2.87,-1.08]],.035,'#a79592',.35);
      for(let i=0;i<(lod?8:13);i++)pointedHorn([[side*(.13+i*.006),2.43+i*.003,-2.13+i*.047],[side*(.125+i*.006),2.34+i*.003,-2.13+i*.047]],.018);
      oval(body,[side*.48,1.30,.45],[.28,.57,.35]);
      legDefs.push({hip:[side*.48,1.38,.48],side,front:1,r:.13,spread:.08,phase:side>0?0:Math.PI,type:'quad'});
      for(let toe=-1;toe<=1;toe++)pointedHorn([[side*.56+toe*.05,.04,.45],[side*.56+toe*.085,.025,.21]],.03);
      tube(body,[[side*.33,2.02,-.62],[side*.51,1.74,-.87],[side*.43,1.76,-1.14]],.087,skin,.40);
      for(let claw=0;claw<3;claw++)pointedHorn([[side*.43+claw*.026,1.77,-1.10],[side*.42+claw*.028,1.70,-1.25],[side*.40+claw*.028,1.63,-1.25]],.023);
    }
    const tail=builder();tube(tail,[[0,0,0],[0,-.03,.70],[.03,.02,1.48],[.06,.17,2.44],[.08,.34,3.13]],.36,skin,.018);tailRig.position.set(0,1.55,.88);tailMesh=tail.finish(tailRig,'Long muscular balancing tail');
    const scars=builder(glowMaterial);for(const side of [-1,1])for(let i=0;i<4;i++)tube(scars,[[side*.48,2.10,-.42+i*.20],[side*.58,1.85,-.36+i*.20],[side*.54,1.62,-.24+i*.20]],.006,'#a675bc',.35);scars.finish(bodyRoot,'Faint storm scars');
  } else if(spec.anatomy==='ocean_deatheater'){
    form(body,[[-2.41,.0,.68,.65],[-2.19,0,.81,.77],[-1.51,.02,.94,.84],[-.55,.03,.88,.80],[.54,.01,.66,.62],[1.61,0,.31,.38],[2.42,0,.13,.18]]);
    // Open throat, muscular circular lip, and several inward-facing tooth
    // rings preserve the Deatheater family silhouette underwater.
    form(wet,[[-2.44,0,.64,.61],[-2.20,0,.56,.53],[-1.91,0,.31,.30],[-1.71,0,.012,.014]],'#291f25','#3d2b31');
    body.add(new THREE.TorusGeometry(.665,.092,lod?7:12,lod?24:40),'#706767',[0,0,-2.43],[1,1,.82]);
    for(let ring=0;ring<3;ring++){
      const count=lod?12:24,r=.60-ring*.135,z=-2.49+ring*.22;
      for(let i=0;i<count;i++){
        const a=(i+.5*(ring%2))/count*TAU,length=.22+hash(i,ring)*.1,geometry=new THREE.ConeGeometry(.037,length,lod?4:6);
        const dir=new THREE.Vector3(-Math.cos(a),-Math.sin(a),.6).normalize();geometry.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(UP,dir));
        body.add(geometry,'#c9c1a4',[Math.cos(a)*r+dir.x*length*.38,Math.sin(a)*r+dir.y*length*.38,z+dir.z*length*.38]);
      }
    }
    eyes([0,.32,-1.74],.88,.039);
    triangle(body,[[0,.68,-.58],[0,1.65,.54],[0,.57,1.38]],skin);
    for(const side of [-1,1]){
      triangle(body,[[side*.66,-.12,-.94],[side*2.05,-.54,.45],[side*.48,-.25,.78]],skin);
      triangle(body,[[side*.32,-.16,1.06],[side*.80,-.33,1.64],[side*.22,-.14,1.82]],belly);
      for(let i=0;i<5;i++)tube(body,[[side*.89,.37,-1.13+i*.14],[side*.93,-.04,-1.07+i*.14],[side*.76,-.48,-.95+i*.14]],.018,'#293a40',.65);
      for(let i=0;i<3;i++)tube(body,[[side*.53,.63,-.18+i*.33],[side*.72,.44,-.02+i*.33],[side*.73,.27,.09+i*.33]],.012,'#8b9690',.5);
    }
    const tail=builder();tailRig.position.set(0,0,2.16);tube(tail,[[0,0,0],[0,0,.47]],.15,skin,.50);
    triangle(tail,[[0,0,.27],[0,1.23,1.2],[0,.15,.90]],skin);triangle(tail,[[0,0,.27],[0,-.80,1.00],[0,-.12,.81]],belly);tailMesh=tail.finish(tailRig,'Powerful shark caudal fin');swimTail=true;
  } else if(['reeffish','tuna','shark','manta'].includes(spec.anatomy)){
    const shark=spec.anatomy==='shark',tuna=spec.anatomy==='tuna',manta=spec.anatomy==='manta';
    const width=shark?.31:tuna?.22:manta?.43:.13,height=shark?.25:tuna?.24:manta?.075:.24,length=shark?1.21:tuna?.75:manta?.66:.36;
    form(body,[[-length,0,width*(shark?.20:.02),height*.13],[-length*.80,0,width*.68,height*.66],[-length*.43,0,width,height],[-length*.04,0,width*.98,height*.98],[length*.40,0,width*.64,height*.71],[length*.75,0,width*.28,height*.34],[length,0,width*.12,height*.16]]);
    eyes([0,height*.17,-length*.71],width*.77,shark?.022:.012);
    if(manta){
      for(const side of [-1,1]){const wing=new THREE.Group();bodyRoot.add(wing);wingRigs.push({group:wing,side,sea:true});const b=builder();triangle(b,[[0,.0,-.58],[side*1.35,.0,.04],[side*.48,-.025,.64]]);triangle(b,[[0,-.018,-.55],[side*1.32,-.025,.04],[side*.47,-.044,.61]],belly);b.finish(wing,'Broad ray fin');tube(body,[[side*.16,.0,-.58],[side*.20,.06,-.81],[side*.12,.07,-.88]],.037,skin,.65);}
      const tail=builder();tube(tail,[[0,0,0],[0,0,.70],[.04,.01,1.35],[.06,.01,1.70]],.025,skin,.05);tailRig.position.set(0,0,.55);tailMesh=tail.finish(tailRig,'Whiplike ray tail');
    } else {
      const tail=builder();tailRig.position.set(0,0,length*.84);
      tube(tail,[[0,0,0],[0,0,length*.25]],width*.27,skin,.55);
      const spread=shark?.48:tuna?.37:.22,back=shark?.57:tuna?.34:.18;
      triangle(tail,[[0,0,length*.17],[0,spread,back],[0,.06,back*.55]],skin);triangle(tail,[[0,0,length*.17],[0,-spread*.83,back],[0,-.06,back*.55]],belly);tailMesh=tail.finish(tailRig,'Forked swimming tail');swimTail=true;
      triangle(body,[[0,height*.74,-length*.22],[0,height+(shark?.40:tuna?.22:.14),length*.12],[0,height*.8,length*.42]],skin);
      for(const side of [-1,1])triangle(body,[[side*width*.65,-height*.13,-length*.22],[side*(shark?1.0:tuna?.49:.26),-height*.9,length*.20],[side*width*.6,-height*.2,length*.38]],skin);
      for(let i=0;i<(shark?5:3);i++)for(const side of [-1,1])tube(body,[[side*width*.93,height*.36,-length*.39+i*.045],[side*width*.985,-height*.3,-length*.34+i*.045]],.006,dark,.75);
      if(!shark&&!tuna)for(let i=0;i<5;i++)for(const side of [-1,1])oval(body,[side*width*.92,0,-.24+i*.10],[.014,height*.80,.025],i%2?'#9f935f':'#425f66');
    }
  }
  if(spec.id==='glow_deer'){
    const markings=builder(glowMaterial);
    for(const side of [-1,1]){
      for(let i=0;i<(lod?10:24);i++){
        const z=-.35+hash(i,2)*.90,y=1.01+hash(i,4)*.17,x=side*(.27-Math.abs(z)*.04);
        oval(markings,[x,y,z],[.006,.008+hash(i)*.004,.019],'#b2e4ba',[0,0,side*.1],0);
      }
      tube(markings,[[side*.17,1.74,-.78],[side*.30,1.92,-.58],[side*.45,2.06,-.43]],.010,'#8be4c8',.10);
      for(let i=1;i<4;i++){const a=[[0,0,0],[side*.17,1.72,-.79],[side*.29,1.91,-.59],[side*.45,2.06,-.43]][i];tube(markings,[[a[0]+side*.12,a[1]+.16,a[2]-.14],[a[0]+side*.14,a[1]+.29,a[2]-.19]],.008,'#c8e9b0',.12);}
    }markings.finish(bodyRoot,'Bioluminescent flank freckles and antler tips');
  }
  body.finish(bodyRoot,`${spec.name} body and distinguishing anatomy`);
  wet.finish(bodyRoot,'Recessed eyes and moist nose');
  const limbCount=legDefs.length*3+specialLimbs.length*3;
  let limbMesh=null;
  if(limbCount){
    const limbProfile=[new THREE.Vector2(.035,-.50),new THREE.Vector2(.79,-.43),new THREE.Vector2(1,-.30),new THREE.Vector2(.85,-.12),new THREE.Vector2(.68,.13),new THREE.Vector2(.62,.34),new THREE.Vector2(.49,.46),new THREE.Vector2(.04,.5)];
    const g=own(new THREE.LatheGeometry(limbProfile,lod?7:11)),colors=new Float32Array(g.attributes.position.count*3);colors.fill(1);g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
    limbMesh=new THREE.InstancedMesh(g,material,limbCount);limbMesh.name='Articulated limbs';limbMesh.castShadow=limbMesh.receiveShadow=true;limbMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);limbMesh.frustumCulled=false;bodyRoot.add(limbMesh);
  }
  const dummy=new THREE.Object3D(),a=new THREE.Vector3(),b=new THREE.Vector3(),delta=new THREE.Vector3();let disposed=false,lastTime=null,stridePhase=0;
  function rod(index,start,end,r,color=skin){a.set(...start);b.set(...end);delta.subVectors(b,a);dummy.position.copy(a).add(b).multiplyScalar(.5);dummy.quaternion.setFromUnitVectors(UP,delta.clone().normalize());dummy.scale.set(r,Math.max(.008,delta.length())+r*1.75,r);dummy.updateMatrix();limbMesh.setMatrixAt(index,dummy.matrix);limbMesh.setColorAt(index,new THREE.Color(color));}
  function animate({time=0,speed=0,state='roam'}={}){
    if(disposed)return;const dead=state==='dead',moving=!dead&&speed>.03,pace=Math.min(1,speed/Math.max(1,spec.runSpeed)),dt=lastTime===null?0:Math.max(0,Math.min(.1,time-lastTime));lastTime=time;
    if(moving)stridePhase+=dt*(2.6+pace*8.2)*(['bear','ox','tortoise'].includes(spec.anatomy)?.76:1);const phase=stridePhase;
    bodyRoot.position.y=dead?0:Math.sin(time*1.7)*.004+(hop&&moving?Math.max(0,Math.sin(phase))*.065:moving?Math.cos(phase*2)*.007:0)+bodyLift;
    bodyRoot.rotation.z=dead?0:(spec.habitat==='air'?Math.sin(time*.7)*.045:moving?Math.sin(phase)*.015:0);
    bodyRoot.rotation.x=dead?0:hop&&moving?Math.sin(phase)*.05:moving?Math.sin(phase*2)*.008:0;
    let index=0;
    for(const leg of legDefs){
      const p=phase+leg.phase,swing=moving?Math.sin(p):0,lift=moving?Math.max(0,swing)*(leg.type==='splayed'?.055:.12):0;
      const [hx,hy,hz]=leg.hip,footX=hx+leg.side*leg.spread,footZ=hz+(moving?Math.cos(p)*(.08+pace*.12):0),foot=[footX,.018+lift,footZ];
      const knee=leg.type==='splayed'?[hx+leg.side*leg.spread*.65,hy+.11,hz+(leg.front||1)*.12]:[hx+leg.side*leg.spread*.55,hy*.48,hz+(moving?swing*.10:0)+(leg.front>0?-.10:.065)];
      rod(index++,[hx,hy+.012,hz],knee,leg.r*1.15);rod(index++,knee,foot,leg.r*.78);rod(index++,foot,[footX,.014+lift,footZ-Math.max(.055,leg.r*1.5)],leg.r*.84,['spider','mantis','crab','scorpion'].includes(spec.anatomy)?belly:skin);
    }
    for(const limb of specialLimbs){
      const s=limb.side,strike=state==='chase'?Math.max(0,Math.sin(time*7))*.12:0;
      rod(index++,[s*.07,.68,-.30],[s*.24,.63,-.52],.025);rod(index++,[s*.24,.63,-.52],[s*.19,.87,-.65-strike],.033,belly);rod(index++,[s*.19,.87,-.65-strike],[s*.12,.70,-.76-strike],.018,dark);
    }
    if(limbMesh){limbMesh.instanceMatrix.needsUpdate=true;if(limbMesh.instanceColor)limbMesh.instanceColor.needsUpdate=true;}
    if(tailMesh){tailRig.rotation.y=dead?0:Math.sin(time*(swimTail?5.8:2.4)+.6)*(swimTail?.22:moving?.10:.035);tailRig.rotation.x=dead?0:Math.sin(time*1.5)*.017;}
    if(spec.anatomy==='jellyfish'){
      const pulse=dead?0:Math.sin(time*2.15);bodyRoot.scale.set(1+pulse*.06,1-pulse*.08,1+pulse*.06);
      for(const rig of softRigs){rig.group.rotation.z=dead?0:Math.sin(time*1.35+rig.phase)*.09;rig.group.rotation.x=dead?0:Math.cos(time*1.05+rig.phase)*.07;}
    }
    if(glowMaterial)glowMaterial.emissiveIntensity=(spec.anatomy==='dinosaur'?.42:.70)*(dead?.15:1+Math.sin(time*.8)*.12);
    for(const wing of wingRigs){wing.group.rotation.z=dead?0:wing.side*Math.sin(time*(wing.sea?2.7:wingRate))*(wing.sea?.18:wingAmplitude);wing.group.rotation.y=dead?0:wing.side*Math.sin(time*(wing.sea?2.7:wingRate)-.5)*.06;}
  }
  animate();
  if(spec.anatomy==='ocean_deatheater')group.scale.z=1.18;
  const getDiagnostics=()=>{let calls=0,triangles=0;group.traverse(node=>{if(node.isMesh){calls++;triangles+=(node.geometry.index?.count||node.geometry.attributes.position.count)/3*(node.isInstancedMesh?node.count:1);}});return {species:spec.id,anatomy:spec.anatomy,drawCalls:calls,triangles:Math.round(triangles),articulatedLegs:legDefs.length,wingPairs:wingRigs.length/2,continuousSurfaces:true,surfaceDetail:spec.anatomy==='bear'?'coarse fur':'anatomical texture',lod};};
  return {group,animate,getDiagnostics,dispose(){if(disposed)return;disposed=true;group.removeFromParent();limbMesh?.dispose();for(const resource of resources)resource.dispose();group.clear();}};
}
