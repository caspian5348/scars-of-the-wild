import * as THREE from './vendor/three.module.js';
import {biomeAt} from './biomes.js';
import {ITEMS} from './survival-catalog.js';
import {CAVE_ID,CAVE_DEPOSITS,MAZE_REWARD_POSITION,caveWalkableAt,isInsideCave} from './cave-maze.js';
import {rareOreAt,normalizeCaveProgress,createCaveProgress} from './cave-progression.js';
import {createCampVisuals} from './camp-visuals.js';

const finite=Number.isFinite,clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const hash=(x,z,s=0)=>{const v=Math.sin(x*127.1+z*311.7+s*74.3)*43758.5453;return v-Math.floor(v);};
const MATERIALS={branch:0x70523a,stone:0x969a91,flint:0x555c66,fiber:0xc5cbb0,leaf:0xbcc9ac,berries:0xa9b79b,mushroom:0xbb966b,herb:0xb9c8a6,roots:0x927553,nuts:0x8b653b,vine:0x6c793c,salt:0xe1dacf,clay:0x99714d,sand:0xcbb984,coal:0x303137,copper_ore:0x9b7349,tin_ore:0x9ea89c,iron_ore:0x725f52,gold_ore:0x9d8653,cave_ore:0x67bfc9,obsidian:0x302c3b,frost_crystal:0xa8e0ec,resin:0xad7b31,shell:0xd8c9ab};
export const RESOURCE_POOLS={glow:['branch','stone','fiber','berries','mushroom','herb','resin','leaf','nuts'],valley:['branch','stone','fiber','berries','flint','herb','clay','roots','nuts'],forest:['branch','fiber','berries','mushroom','herb','resin','leaf','stone','vine'],storm:['stone','stone','flint','branch'],cave:['cave_ore','iron_ore','coal','copper_ore','tin_ore','gold_ore','obsidian','frost_crystal','stone','mushroom','salt'],lava:['stone','flint','clay','stone'],ice:['stone','stone','flint','branch'],beach:['sand','shell','branch','stone','fiber','clay','salt'],ocean:['shell','sand']};
const POOLS=RESOURCE_POOLS;
const FOOD=new Set(['berries','mushroom','herb']),PLANTS=new Set(['fiber','leaf','berries','herb']);
const ORES=new Set(['coal','copper_ore','tin_ore','iron_ore','gold_ore','cave_ore','obsidian','frost_crystal']);

/** Curved leaf fans with connected stems; one shared instanced pickup mesh. */
function forageGeometry(){
  const positions=[],uvs=[],colors=[],indices=[];
  const vertex=(x,y,z,u,v,color)=>{positions.push(x,y,z);uvs.push(u,v);colors.push(...color);};
  for(let shoot=0;shoot<5;shoot++){
    const a=shoot*2.39996,r=shoot===0?0:.18,baseX=Math.cos(a)*r,baseZ=Math.sin(a)*r,h=.75+(shoot%3)*.17,lean=.16;
    const at=t=>({x:baseX+Math.cos(a)*lean*t,y:h*t,z:baseZ+Math.sin(a)*lean*t});
    // Two crossed narrow stem ribbons keep their root and leaf attachments exact.
    for(const angle of [a,a+Math.PI/2]){const first=positions.length/3,b=at(0),e=at(1),dx=Math.cos(angle)*.012,dz=Math.sin(angle)*.012;
      vertex(b.x-dx,0,b.z-dz,.49,.45,[.64,.62,.38]);vertex(b.x+dx,0,b.z+dz,.51,.45,[.64,.62,.38]);vertex(e.x+dx,e.y,e.z+dz,.51,.55,[.53,.60,.35]);vertex(e.x-dx,e.y,e.z-dz,.49,.55,[.53,.60,.35]);indices.push(first,first+1,first+2,first,first+2,first+3);}
    for(let pair=0;pair<3;pair++)for(const sign of [-1,1]){
      const start=at(.28+pair*.25),angle=a+sign*(.9+pair*.45),length=.48-pair*.055,width=.14-pair*.018,first=positions.length/3;
      for(let row=0;row<=3;row++){const t=row/3,spread=Math.sin(t*Math.PI)*width,lift=Math.sin(t*Math.PI)*.14+t*.05;for(const side of [-1,0,1]){
        const tone=.84+shoot*.018+row*.025;vertex(start.x+Math.cos(angle)*length*t-Math.sin(angle)*spread*side,start.y+lift-(side?spread*.18:0),start.z+Math.sin(angle)*length*t+Math.cos(angle)*spread*side,(side+1)/2,t,[tone,tone,.82* tone]);}}
      for(let row=0;row<3;row++)for(let col=0;col<2;col++){const n=first+row*3+col;indices.push(n,n+3,n+1,n+1,n+3,n+4);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.setIndex(indices);geometry.computeVertexNormals();geometry.computeBoundingSphere();return geometry;
}
export function normalizeCampState(value){
  if(value===undefined)return {version:1,depleted:[],felled:[],buildings:[],treeHits:{},rockHits:{},caveProgress:normalizeCaveProgress(),drops:[],hiding:{zone:null,episode:0}};
  if(!value||value.version!==1||!Array.isArray(value.depleted)||!Array.isArray(value.felled)||!Array.isArray(value.buildings)||value.depleted.length>30000||value.felled.length>10000||value.buildings.length>500)return null;
  const ids=a=>a.every(id=>typeof id==='string'&&id.length<150)?[...new Set(a)]:null;
  const depleted=ids(value.depleted),felled=ids(value.felled);if(!depleted||!felled)return null;
  const buildings=[];
  for(const b of value.buildings){if(!b||typeof b.id!=='string'||typeof b.type!=='string'||![b.x,b.y,b.z,b.rotation].every(finite)||Math.abs(b.x)>888||Math.abs(b.z)>888||Math.abs(b.y)>600)return null;
    const contents=Array.isArray(b.contents)?b.contents.map(s=>({...s})):Object.entries(b.contents||{}).filter(([,n])=>n>0).map(([id,count],i)=>({uid:`legacy${i}`,id,count}));
    if(contents.length>100||contents.some(s=>!s||typeof s.id!=='string'||typeof s.uid!=='string'||!Number.isInteger(s.count)||s.count<1||s.count>9999||s.durability!==undefined&&!finite(s.durability)||s.expiresAt!==undefined&&!finite(s.expiresAt)))return null;
    buildings.push({id:b.id.slice(0,150),type:b.type.slice(0,80),x:b.x,y:b.y,z:b.z,rotation:b.rotation,fuel:clamp(b.fuel||0,0,7200),open:!!b.open,contents});}
  const treeHits={};for(const [id,n] of Object.entries(value.treeHits||{}).slice(0,10000)){if(!Number.isInteger(n)||n<0||n>12)return null;treeHits[id]=n;}
  const rockHits={};if(value.rockHits!==undefined&&(!value.rockHits||typeof value.rockHits!=='object'||Array.isArray(value.rockHits)||Object.keys(value.rockHits).length>30000))return null;
  for(const [id,n] of Object.entries(value.rockHits||{})){if(id.length>150||!Number.isInteger(n)||n<1||n>3)return null;rockHits[id]=n;}
  const caveProgress=normalizeCaveProgress(value.caveProgress);if(!caveProgress)return null;
  const drops=Array.isArray(value.drops)?value.drops.filter(d=>d&&typeof d.id==='string'&&[d.x,d.y,d.z].every(finite)&&d.stack&&typeof d.stack.id==='string'&&Number.isInteger(d.stack.count)&&d.stack.count>0).slice(0,1000).map(d=>({...d,stack:{...d.stack}})):[];
  return {version:1,depleted,felled,buildings,treeHits,rockHits,caveProgress,drops,hiding:{zone:typeof value.hiding?.zone==='string'?value.hiding.zone:null,episode:Number.isSafeInteger(value.hiding?.episode)?Math.max(0,value.hiding.episode):0}};
}

/** Visible resources, build placement and persistent alterations to the wilderness. */
export function createCampWorld({scene,world,state,seed='wilderness',buildings:catalog,onChange=()=>{}}){
  const saved=normalizeCampState(state)||normalizeCampState(),depleted=new Set(saved.depleted),felled=new Set(saved.felled),treeHits={...saved.treeHits};
  const rockHits={...saved.rockHits};let caveProgress=createCaveProgress({seed,state:saved.caveProgress});
  const root=new THREE.Group();root.name='Gathering and player-built camp';scene.add(root);
  const visuals=createCampVisuals({root});
  const placed=[],resources=[],bushes=[],buckets=new Map(),geometries=[],materials=[];
  const textures=[];
  function scan(path,color=true,repeat=1){if(typeof document==='undefined')return null;const t=new THREE.TextureLoader().load(new URL(path,import.meta.url).href);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(repeat,repeat);t.colorSpace=color?THREE.SRGBColorSpace:THREE.NoColorSpace;t.anisotropy=4;textures.push(t);return t;}
  const rockScan={map:scan('./assets/materials/rock-albedo.jpg'),normalMap:scan('./assets/materials/rock-normal.jpg',false),normalScale:new THREE.Vector2(.45,.45)},woodScan={map:scan('./assets/foliage/pine-bark_diff.jpg'),normalMap:scan('./assets/foliage/pine-bark_nor_gl.jpg',false),normalScale:new THREE.Vector2(.35,.35)};
  const matrix=new THREE.Matrix4(),q=new THREE.Quaternion(),scale=new THREE.Vector3(),position=new THREE.Vector3(),up=new THREE.Vector3(0,1,0);
  const stone=new THREE.IcosahedronGeometry(1,1),twig=new THREE.CylinderGeometry(.045,.07,1,6),plant=forageGeometry(),fireGeometry=new THREE.ConeGeometry(.55,.9,5),crystal=new THREE.ConeGeometry(.30,1.2,6);
  geometries.push(stone,twig,plant,fireGeometry,crystal);
  // Reuse the bundled leaf image. Pure geometry fixtures need no image loader.
  const leafMap=typeof document!=='undefined'?new THREE.TextureLoader().load(new URL('./assets/foliage/jungle-broadleaf-v1.png',import.meta.url).href):null;
  if(leafMap){leafMap.colorSpace=THREE.SRGBColorSpace;leafMap.anisotropy=4;}
  for(const [id,color] of Object.entries(MATERIALS)){
    const material=new THREE.MeshStandardMaterial({color,roughness:ORES.has(id)?.67:.94,metalness:ORES.has(id)?.16:0,emissive:id==='cave_ore'?0x12363b:id==='frost_crystal'?0x0c232b:0,...(PLANTS.has(id)?{map:leafMap,alphaTest:leafMap?.25:0,side:THREE.DoubleSide,vertexColors:true}:id==='branch'?woodScan:{...rockScan,flatShading:true})});materials.push(material);
    const improved=visuals.resourceVisual(id);
    const mesh=new THREE.InstancedMesh(improved?.geometry||(id==='branch'?twig:PLANTS.has(id)?plant:['cave_ore','frost_crystal'].includes(id)?crystal:stone),improved?.material||material,id==='stone'?640:320);mesh.name=`Gatherable ${id}`;mesh.count=0;mesh.castShadow=true;mesh.receiveShadow=true;mesh.frustumCulled=false;root.add(mesh);buckets.set(id,mesh);
  }
  let cell='',target=null,placement=null,buildRotation=0,ghost=null,lastPlayer=null,hideId=saved.hiding.zone,hideEpisode=saved.hiding.episode;
  const drops=saved.drops.map(d=>({...d,stack:{...d.stack}}));
  for(const id of felled)world.setTreeFelled?.(id,true);
  const wood=new THREE.MeshStandardMaterial({...woodScan,color:0xc2ac88,roughness:1}),rock=new THREE.MeshStandardMaterial({...rockScan,color:0xb6b3a7,roughness:1}),thatch=new THREE.MeshStandardMaterial({...woodScan,color:0xb3af7c,roughness:1});materials.push(wood,rock,thatch);
  const box=new THREE.BoxGeometry(1,1,1),pole=new THREE.CylinderGeometry(1,1,1,8);geometries.push(box,pole);
  function piece(group,geometry,material,x,y,z,sx,sy,sz,rz=0){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.rotation.z=rz;m.castShadow=m.receiveShadow=true;group.add(m);return m;}
  function buildingView(b,preview=false){return visuals.createBuilding(b,preview);}
  function buildingColliders(b){for(let i=world.colliders.length-1;i>=0;i--)if(world.colliders[i].campId===b.id)world.colliders.splice(i,1);
    if(!/wall|door|palisade|furnace|chest/.test(b.type)||b.type==='door'&&b.open)return;
    const wall=/wall|door|palisade/.test(b.type),offsets=b.type==='doorframe'?[-1.2,-.9,.9,1.2]:wall?[-1.2,-.6,0,.6,1.2]:[0];
    for(const offset of offsets)world.colliders.push({campId:b.id,x:b.x+Math.cos(b.rotation)*offset,z:b.z-Math.sin(b.rotation)*offset,radius:wall?.33:.7,baseY:b.y,height:wall?2.45:1.3});}
  function addBuilding(b){if(!catalog[b.type])return;const v=buildingView(b);placed.push({...b,view:v});buildingColliders(b);}
  saved.buildings.forEach(addBuilding);
  function snapshot(){return{version:1,depleted:[...depleted],felled:[...felled],treeHits:{...treeHits},rockHits:{...rockHits},caveProgress:caveProgress.snapshot(),hiding:{zone:hideId,episode:hideEpisode},drops:drops.map(({view,...d})=>({...d,stack:{...d.stack}})),buildings:placed.map(({view,...b})=>({...b,contents:b.contents.map(s=>({...s}))}))};}
  function applyNetworkState(value){
    const next=normalizeCampState(value);if(!next)return false;
    let collisionChanged=false;
    const newFelled=new Set(next.felled);for(const id of felled)if(!newFelled.has(id)){world.setTreeFelled?.(id,false);collisionChanged=true;}
    for(const id of newFelled)if(!felled.has(id)){world.setTreeFelled?.(id,true);collisionChanged=true;}
    felled.clear();newFelled.forEach(id=>felled.add(id));depleted.clear();next.depleted.forEach(id=>depleted.add(id));
    for(const key of Object.keys(treeHits))delete treeHits[key];Object.assign(treeHits,next.treeHits);
    for(const key of Object.keys(rockHits))delete rockHits[key];Object.assign(rockHits,next.rockHits);
    caveProgress=createCaveProgress({seed,state:next.caveProgress});
    const ids=new Set(next.buildings.map(b=>b.id));for(let i=placed.length-1;i>=0;i--)if(!ids.has(placed[i].id)){const b=placed[i];root.remove(b.view);placed.splice(i,1);for(let j=world.colliders.length-1;j>=0;j--)if(world.colliders[j].campId===b.id)world.colliders.splice(j,1);collisionChanged=true;}
    for(const b of next.buildings){const current=placed.find(p=>p.id===b.id);if(!current){addBuilding(b);collisionChanged=true;}else{const oldOpen=current.open;Object.assign(current,b);if(oldOpen!==current.open){buildingColliders(current);collisionChanged=true;}visuals.updateBuilding(current,0);}}
    for(const d of drops)root.remove(d.view);drops.length=0;for(const d of next.drops){const added={...d,stack:{...d.stack}};drops.push(added);dropView(added);}
    cell='';return collisionChanged;
  }
  function regenerate(player){
    const cx=Math.floor(player.x/20),cz=Math.floor(player.z/20),next=`${cx},${cz}`;if(next===cell)return;cell=next;resources.length=0;bushes.length=0;
    const counts={};for(const mesh of buckets.values())mesh.count=0;
    for(let ix=cx-5;ix<=cx+5;ix++)for(let iz=cz-5;iz<=cz+5;iz++)for(let j=0;j<2;j++){
      const x=ix*20+2+hash(ix,iz,3+j)*16,z=iz*20+2+hash(ix,iz,7+j)*16;if(Math.abs(x)>885||Math.abs(z)>885)continue;
      const biome=biomeAt(x,z).id,pool=POOLS[biome]||POOLS.valley,item=pool[Math.floor(hash(ix,iz,12+j)*pool.length)],id=`g:${ix}:${iz}:${j}`;
      if(depleted.has(id))continue;const y=world.groundHeight(x,z);if(y<2||world.hazardAt?.(x,z)?.kind==='lava')continue;
      if(world.colliders.some(c=>Math.hypot(c.x-x,c.z-z)<c.radius+.7))continue;
      if(biome==='cave'&&!caveWalkableAt(x,z,1.25))continue;
      const ore=ORES.has(item),mineable=item==='stone'&&hash(ix,iz,41+j)>.35,r=mineable?1.05:ore?.7:PLANTS.has(item)?.55:.3,node={id,item,x,y,z,radius:r,count:ore?3:FOOD.has(item)?3:item==='fiber'?4:2,mineable};resources.push(node);if(item==='berries'||item==='fiber')bushes.push({id,x,z,radius:item==='berries'?1.8:1.2});
      const mesh=buckets.get(item),n=counts[item]||0;if(!mesh||n>=320)continue;
      position.set(x,y+(PLANTS.has(item)?.015:item==='branch'?.06:r*.6),z);q.setFromAxisAngle(up,hash(ix,iz,j)*Math.PI*2);
      if(item==='branch'){q.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),1.48));scale.set(1,1.1,1);}else scale.set(r,r*(ore?1.2:1),r);
      matrix.compose(position,q,scale);mesh.setMatrixAt(n,matrix);counts[item]=n+1;
    }
    // Independent loose-stone scatter keeps first tools accessible. Original
    // gathering IDs are unchanged, so existing depleted nodes stay collected.
    // Two hand-sized fieldstone clusters per clear 20m cell, each with several
    // deterministic candidate positions to avoid roots, cliffs and deep water.
    const normal=new THREE.Vector3(),tilt=new THREE.Quaternion(),yaw=new THREE.Quaternion();
    for(let ix=cx-5;ix<=cx+5;ix++)for(let iz=cz-5;iz<=cz+5;iz++)for(let j=0;j<2;j++){
      const id=`loose-stone:${ix}:${iz}:${j}`;if(depleted.has(id))continue;
      for(let attempt=0;attempt<8;attempt++){
        const x=ix*20+1.5+hash(ix,iz,101+j*29+attempt)*17,z=iz*20+1.5+hash(ix,iz,307+j*31+attempt)*17;
        if(Math.abs(x)>885||Math.abs(z)>885)continue;
        const biome=biomeAt(x,z).id,y=world.groundHeight(x,z),hazard=world.hazardAt?.(x,z);
        if(['cave','ocean'].includes(biome)||!finite(y)||y<2.3||(hazard?.kind||hazard?.type)==='lava')continue;
        if(world.colliders.some(c=>Math.hypot(c.x-x,c.z-z)<c.radius+1.05))continue;
        if(resources.some(n=>Math.hypot(n.x-x,n.z-z)<n.radius+1))continue;
        const r=.38+hash(ix,iz,701+j)*.11,heights=[world.groundHeight(x-r,z),world.groundHeight(x+r,z),world.groundHeight(x,z-r),world.groundHeight(x,z+r)];
        if(heights.some(h=>!finite(h)||h<2.15)||Math.max(...heights)-Math.min(...heights)>.65)continue;
        const mesh=buckets.get('stone'),n=counts.stone||0;if(n>=mesh.instanceMatrix.count)break;
        resources.push({id,item:'stone',x,y,z,radius:r,count:2,mineable:false,loose:true});
        normal.set(heights[0]-heights[1],2*r,heights[2]-heights[3]).normalize();
        tilt.setFromUnitVectors(up,normal);yaw.setFromAxisAngle(up,hash(ix,iz,811+j)*Math.PI*2);q.copy(tilt).multiply(yaw);
        position.set(x,y,z).addScaledVector(normal,r*.61);scale.set(r,r,r);matrix.compose(position,q,scale);mesh.setMatrixAt(n,matrix);
        mesh.setColorAt(n,new THREE.Color(1.24,1.23,1.19));counts.stone=n+1;break;
      }
    }
    for(const deposit of CAVE_DEPOSITS){const vein={...deposit,item:deposit.item||deposit.kind};if(depleted.has(vein.id)||Math.abs(vein.x-player.x)>110||Math.abs(vein.z-player.z)>110)continue;
      const y=world.groundHeight(vein.x,vein.z);if(!finite(y)||y<2||world.colliders.some(c=>Math.hypot(c.x-vein.x,c.z-vein.z)<c.radius+.7))continue;
      const node={...vein,y,radius:.85,count:vein.amount||8};resources.push(node);const mesh=buckets.get(vein.item),n=counts[vein.item]||0;if(!mesh||n>=320)continue;
      position.set(vein.x,y+.38,vein.z);q.setFromAxisAngle(up,hash(vein.x,vein.z)*Math.PI*2);scale.set(.85,.9,.75);matrix.compose(position,q,scale);mesh.setMatrixAt(n,matrix);counts[vein.item]=n+1;
    }
    if(!caveProgress.snapshot().rewardClaimed&&Math.hypot(player.x-MAZE_REWARD_POSITION.x,player.z-MAZE_REWARD_POSITION.z)<110){
      const p=MAZE_REWARD_POSITION,y=world.groundHeight(p.x,p.z),node={id:`reward:${CAVE_ID}`,item:'cave_ore',reward:true,x:p.x,y,z:p.z,radius:1.15,count:0};resources.push(node);
      const mesh=buckets.get('cave_ore'),n=counts.cave_ore||0;position.set(p.x,y+.65,p.z);q.identity();scale.set(1.4,1.25,1.4);matrix.compose(position,q,scale);mesh.setMatrixAt(n,matrix);counts.cave_ore=n+1;
    }
    for(const [id,mesh] of buckets){mesh.count=counts[id]||0;mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;}
  }
  function nearby(player,range=3.6){
    const items=[];const add=(o,kind,r=.35)=>{const distance=Math.hypot(o.x-player.x,o.z-player.z)-r;if(distance<=range&&Math.abs((o.y??world.groundHeight(o.x,o.z))-player.y)<3.5)items.push({...o,kind,distance});};
    for(const n of resources)add(n,n.reward?'reward':'resource',n.radius);
    for(const d of drops)add({...d,item:d.stack.id},'drop',.3);
    // Root meshes are deliberately buried across their footprint. Interaction
    // height follows the standing terrain instead of the lowest buried root.
    for(const t of world.gatherTrees||[]){if(!felled.has(t.id))add({...t,y:world.groundHeight(t.x,t.z),item:'wood',count:2},'tree',t.radius);}
    for(const b of placed)add(b,'building',.8);
    return items.sort((a,b)=>a.distance-b.distance||Number(b.type==='door')-Number(a.type==='door'));
  }
  function chooseTarget(player,direction){const near=nearby(player);return near.find(o=>{const dx=o.x-player.x,dz=o.z-player.z,len=Math.hypot(dx,dz);if(isInsideCave(player.x,player.z,player.y)){for(let d=.3;d<len;d+=.45)if(!caveWalkableAt(player.x+dx*d/len,player.z+dz*d/len,.1))return false;}return len<1.2||(dx*direction.x+dz*direction.z)/len>.35;})||null;}
  function takeResource(node,{mined=false}={}){if(node.kind==='tree'){
    if(felled.has(node.id))return{felled:false};
    treeHits[node.id]=(treeHits[node.id]||0)+1;
    if(treeHits[node.id]>=6){felled.add(node.id);world.setTreeFelled?.(node.id,true);onChange();return{felled:true,loot:{bark:3,resin:1}};}
  }else{
    if(depleted.has(node.id))return{felled:false};
    if(node.mineable){if(!mined)return{felled:false};rockHits[node.id]=(rockHits[node.id]||0)+1;if(rockHits[node.id]<3){onChange();return{felled:false,mined:true};}}
    depleted.add(node.id);cell='';onChange();
    const rare=node.mineable&&mined?rareOreAt(seed,node.id):null;
    return{felled:false,mined:node.mineable,rareOre:rare,loot:rare?{[rare]:1}:undefined};
  }onChange();return{felled:false};}
  function visitCave(player){return caveProgress.visit(isInsideCave(player.x,player.z,player.y));}
  function claimCaveReward(){const claimed=caveProgress.claim();if(claimed){cell='';onChange();}return claimed;}
  function concealment(player){const zone=[...bushes,...(world.bushZones||[])].find(b=>Math.hypot(b.x-player.x,b.z-player.z)<b.radius);const next=zone?.id||null;if(next!==hideId){hideId=next;hideEpisode++;}return{concealed:!!zone,hidingId:zone?`${zone.id}:${hideEpisode}`:null};}
  function selectBuild(type){placement=type&&catalog[type]?type:null;if(ghost){root.remove(ghost);ghost.userData.previewMaterial?.dispose();ghost=null;}if(placement)ghost=buildingView({type,x:0,y:0,z:0,rotation:buildRotation},true);}
  function buildSpot(player,direction){
    let x=player.x+direction.x*4,z=player.z+direction.z*4;const type=placement||'',foundation=/foundation|floor/.test(type);let parent=null;
    if(foundation){x=Math.round(x/3)*3;z=Math.round(z/3)*3;}
    else if(catalog[type]?.requiresFoundation){parent=placed.filter(b=>/foundation|floor/.test(b.type)).sort((a,b)=>Math.hypot(a.x-x,a.z-z)-Math.hypot(b.x-x,b.z-z))[0];if(parent&&Math.hypot(parent.x-x,parent.z-z)<4){x=parent.x;z=parent.z;if(/wall|door/.test(type)){x+=Math.sin(buildRotation)*1.48;z+=Math.cos(buildRotation)*1.48;}}else parent=null;}
    const y=parent?parent.y+.17:world.groundHeight(x,z),samples=[world.groundHeight(x-1,z-1),world.groundHeight(x+1,z-1),world.groundHeight(x-1,z+1),world.groundHeight(x+1,z+1)];
    let reason='';if(placed.length>=500)reason='Your camp has reached 500 structures.';
    else if(type==='fish_trap'?(y>=1.9||y<.55):(y<2.1||world.hazardAt?.(x,z)?.kind==='lava'))reason=type==='fish_trap'?'Choose shallow river water.':'Choose dry, solid ground.';
    else if(Math.max(...samples)-Math.min(...samples)>1.3&&!parent)reason='The ground is too steep.';
    else if(catalog[type]?.requiresFoundation&&!parent)reason='Place this on a foundation.';
    else if(world.colliders.some(c=>!c.campId&&Math.hypot(c.x-x,c.z-z)<c.radius+.5))reason='Clear the tree or rock first.';
    else if(placed.some(b=>b.type===type&&Math.hypot(b.x-x,b.z-z)<.75&&Math.abs(b.rotation-buildRotation)<.1))reason='That space is occupied.';
    return {x,y,z,rotation:buildRotation,type,valid:!reason,reason};
  }
  function placeBuilding(spot){if(!spot?.valid||!catalog[spot.type])return false;addBuilding({id:globalThis.crypto?.randomUUID?.()||`build-${Date.now()}-${placed.length}`,type:spot.type,x:spot.x,y:spot.y,z:spot.z,rotation:spot.rotation,fuel:0,open:false,contents:[]});onChange();return true;}
  function stations(player){return placed.filter(b=>Math.hypot(b.x-player.x,b.z-player.z)<7&&(!/campfire/.test(b.type)||b.fuel>0)).map(b=>catalog[b.type]?.providesStation).filter(Boolean);}
  function blocking(x,z){for(const b of placed){if(!/wall|door|palisade|furnace|chest|storage/.test(b.type)||(b.type==='door'&&b.open))continue;const dx=x-b.x,dz=z-b.z,c=Math.cos(b.rotation),s=Math.sin(b.rotation),lx=c*dx-s*dz,lz=s*dx+c*dz;if(b.type==='doorframe'&&Math.abs(lx)<.56)continue;if(/wall|door|palisade/.test(b.type)?Math.abs(lx)<1.6&&Math.abs(lz)<.33:Math.hypot(dx,dz)<.95)return true;}return false;}
  function groundHeight(x,z){let y=world.groundHeight(x,z);for(const b of placed)if(/foundation|floor/.test(b.type)&&Math.abs(x-b.x)<1.5&&Math.abs(z-b.z)<1.5)y=Math.max(y,b.y+.17);return y;}
  function interactBuilding(id,{fuel=0,toggle=false}={}){const b=placed.find(x=>x.id===id);if(!b)return false;if(fuel)b.fuel=Math.min(7200,b.fuel+fuel);if(toggle&&b.type==='door'){b.open=!b.open;if(b.view.userData.door)b.view.userData.door.rotation.y=b.open?Math.PI/2:0;buildingColliders(b);}onChange();return true;}
  function drop(stack,p){const d={id:globalThis.crypto.randomUUID(),stack:{...stack},x:p.x,y:world.groundHeight(p.x,p.z),z:p.z};drops.push(d);dropView(d);return d;}
  function dropView(d){d.view=piece(root,stone,thatch,d.x,d.y+.14,d.z,.23,.16,.2);}
  drops.forEach(dropView);
  function pickup(id){const i=drops.findIndex(d=>d.id===id);if(i<0)return null;const d=drops[i];root.remove(d.view);drops.splice(i,1);return d.stack;}
  function storage(id){return placed.find(b=>b.id===id)?.contents||null;}
  function update(dt,player,direction){lastPlayer=player;regenerate(player);target=chooseTarget(player,direction);let spot=null;
    if(ghost){spot=buildSpot(player,direction);ghost.position.set(spot.x,spot.y,spot.z);ghost.rotation.y=spot.rotation;ghost.userData.previewMaterial.color.setHex(spot.valid?0x8fc79a:0xcf7565);}
    for(const b of placed){
      b.view.visible=Math.hypot(b.x-player.x,b.z-player.z)<180;
      if(b.type==='fish_trap'){b.fuel+=dt;if(b.fuel>=120&&b.contents.length<5){b.fuel-=120;b.contents.push({uid:globalThis.crypto.randomUUID(),id:'raw_fish',count:1,expiresAt:(player.survivalTime||0)+ITEMS.raw_fish.shelfLife});}}
      else if(b.fuel>0)b.fuel=Math.max(0,b.fuel-dt);
      visuals.updateBuilding(b,player.survivalTime||0);
    }
    return {target,spot,concealment:concealment(player),stations:stations(player),nearFire:placed.some(b=>b.type==='campfire'&&b.fuel>0&&Math.hypot(b.x-player.x,b.z-player.z)<6),sheltered:placed.some(b=>/roof|shelter/.test(b.type)&&Math.hypot(b.x-player.x,b.z-player.z)<2.5),bedroll:placed.some(b=>b.type==='bedroll'&&Math.hypot(b.x-player.x,b.z-player.z)<2)};
  }
  return{update,snapshot,applyNetworkState,nearby,getResourceNodes:()=>resources.map(n=>({...n})),takeResource,visitCave,claimCaveReward,selectBuild,placeBuilding,buildSpot,drop,pickup,rotate(){buildRotation=(buildRotation+Math.PI/2)%(Math.PI*2);},get selectedBuild(){return placement;},stations,blocking,groundHeight,interactBuilding,storage,concealment,getBuildings:()=>placed,getDiagnostics:()=>({resources:resources.length,depleted:depleted.size,felled:felled.size,buildings:placed.length,cave:caveProgress.snapshot(),minedRocks:Object.keys(rockHits).length}),dispose(){visuals.dispose();root.removeFromParent();for(let i=world.colliders.length-1;i>=0;i--)if(world.colliders[i].campId)world.colliders.splice(i,1);leafMap?.dispose();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());}};
}

