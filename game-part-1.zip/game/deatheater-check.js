import {createDeatheaterEncounters,normalizeDeatheaterState,DEATHEATER_SPEED,DEATHEATER_DAMAGE} from './deatheater-encounters.js';
import {createJourneyStore,SAVE_KEY,DEATH_KEY} from './journey-store.js';

const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const near=(a,b,tolerance=1e-6)=>Math.abs(a-b)<=tolerance;
const copy=value=>JSON.parse(JSON.stringify(value));
const player={x:0,y:10,z:0};
const flat=()=>10;
function fixture(options={}) {
  const events=[],changes=[],damage=[];
  const config={heightAt:flat,stormBlendAt:()=>1,seed:'visible-storm-check',colliders:[],
    onEvent:event=>events.push(event),onChange:(state,event)=>changes.push({state,event}),
    onDamage:(amount,cause,active)=>damage.push({amount,cause,active}),...options};
  return {ai:createDeatheaterEncounters(config),config,events,changes,damage};
}
function advance(ai,seconds,p=player) {
  let remaining=seconds;
  while(remaining>1e-8){const dt=Math.min(.05,remaining);ai.update(dt,p);remaining-=dt;}
}
function activeFixture(options={}) {const f=fixture(options);assert(f.ai.forceEncounter(player),'Fixture failed to start.');return f;}
function poseFixture(stage,position,extra={},options={}) {
  const f=activeFixture(options),state=f.ai.snapshot();
  Object.assign(state.active,{stage,remaining:{circling:4,approaching:2.4,diving:3,recovering:4,retreating:5}[stage],position:{...position},goal:{x:0,y:11.45,z:0},lockedTarget:stage==='diving'?{x:0,y:11.45,z:0}:null,...extra});
  assert(normalizeDeatheaterState(state)!==null,'Test fixture created invalid state.');
  f.ai=createDeatheaterEncounters({...f.config,state});f.events.length=0;f.changes.length=0;return f;
}
function memoryStorage() {
  const map=new Map();return {getItem:key=>map.has(key)?map.get(key):null,setItem:(key,value)=>map.set(key,String(value)),removeItem:key=>map.delete(key)};
}
function journeyData(deatheater) {return {player:{x:0,z:0,yaw:0,pitch:0},health:100,survivedSeconds:0,discovered:[],waypoint:null,deatheater};}

export const deatheaterChecks=[
  ['The storm core threshold is strictly above 0.55',()=>{
    const edge=fixture({stormBlendAt:()=>.55});advance(edge.ai,10);assert(!edge.ai.snapshot().warningIssued&&!edge.ai.getActive().length,'The exact boundary triggered a hunt.');
    const inside=fixture({stormBlendAt:()=>.55001});inside.ai.update(.05,player);assert(inside.ai.snapshot().warningIssued,'The core did not issue a warning.');
  }],
  ['Eight seconds of warning precede a visible four-second circle',()=>{
    const f=fixture();advance(f.ai,7.95);assert(!f.ai.getActive().length,'Predator appeared before its warning elapsed.');
    advance(f.ai,.05);assert(f.ai.getActive()[0]?.stage==='circling','Warning did not create the circle.');
    advance(f.ai,3.95);assert(f.ai.getActive()[0]?.stage==='circling','The overhead telegraph ended early.');
    advance(f.ai,.05);assert(f.ai.getActive()[0]?.stage==='approaching','The circle never transitioned to approach.');
  }],
  ['Leaving the storm edge cancels and resets a pending warning',()=>{
    let blend=1;const f=fixture({stormBlendAt:()=>blend});advance(f.ai,6);blend=.29;f.ai.update(.05,player);
    assert(!f.ai.snapshot().warningIssued&&f.ai.snapshot().warningRemaining===8,'Warning persisted after leaving the storm.');
    assert(f.events.some(e=>e.type==='warning-cancelled'),'No cancellation event was emitted.');
    blend=1;advance(f.ai,7.9);assert(!f.ai.getActive().length,'Reentry skipped the warning.');
  }],
  ['Only one predator can be active at a time',()=>{
    const f=activeFixture(),id=f.ai.getActive()[0].id;assert(f.ai.forceEncounter(player)===false,'A second active predator was permitted.');
    assert(f.ai.getActive().length===1&&f.ai.getActive()[0].id===id,'The original active predator was replaced.');
  }],
  ['Each deterministic hunt lasts 60–90 seconds',()=>{
    const durations=new Set();
    for(let i=0;i<30;i++){const f=activeFixture({seed:`storm-duration-${i}`}),seconds=f.ai.getActive()[0].huntRemaining;assert(seconds>=60&&seconds<=90,'Hunt duration is outside 60–90 seconds.');durations.add(seconds);}
    assert(durations.size===30,'Independent journeys reused one fixed hunt duration.');
    assert(activeFixture({seed:'repeat'}).ai.getActive()[0].huntRemaining===activeFixture({seed:'repeat'}).ai.getActive()[0].huntRemaining,'The same seed rerolled a hunt duration.');
  }],
  ['Unobstructed approach speed is 11m/s, faster than sprinting',()=>{
    const f=poseFixture('approaching',{x:50,y:20,z:0}),before=f.ai.getActive()[0].position;f.ai.update(.05,player);const after=f.ai.getActive()[0].position;
    assert(near(Math.hypot(after.x-before.x,after.y-before.y,after.z-before.z)/.05,DEATHEATER_SPEED),'Approach speed is not 11m/s.');assert(DEATHEATER_SPEED>7.2,'A sprint outruns the airborne predator.');
  }],
  ['The approach locks a head-height target during its last 0.65s',()=>{
    const f=poseFixture('approaching',{x:25,y:25,z:0});advance(f.ai,1.7);assert(f.ai.getActive()[0].lockedTarget===null,'Target locked before the late approach.');
    advance(f.ai,.05);const locked=f.ai.getActive()[0].lockedTarget;assert(locked&&near(locked.y,11.45),'Late lock did not aim at head height.');
    advance(f.ai,.65,{x:8,y:10,z:6});const a=f.ai.getActive()[0];assert(a.stage==='diving'&&a.lockedTarget.x===0&&a.lockedTarget.z===0,'Locked dive followed a sidestepping player.');
  }],
  ['A complete real flight cycle delivers a fatal 100-damage dive to an exposed player',()=>{
    const f=activeFixture();advance(f.ai,12);assert(f.damage.length>=1,'The full circle, approach and dive missed a stationary exposed player.');
    assert(DEATHEATER_DAMAGE===100&&f.damage.every(hit=>hit.amount===100&&hit.cause==='Deatheater'),'A successful dive was not fatal to a player with full health.');
  }],
  ['A sideways dodge after target lock escapes the committed dive',()=>{
    const f=poseFixture('diving',{x:0,y:17.95,z:0});advance(f.ai,3,{x:6,y:10,z:0});assert(f.damage.length===0,'The committed dive tracked a six-metre sidestep.');
    assert(!f.ai.getActive()[0].struck&&!f.events.some(event=>event.type==='strike'),'A missed dive was falsely recorded as a successful capture.');
  }],
  ['Swept dive contact catches a player between two non-contact endpoints',()=>{
    const from={x:-.275,y:11.45,z:1.64},goal={x:10,y:11.45,z:1.64};
    const f=poseFixture('diving',from,{goal,lockedTarget:{...goal},heading:-Math.PI/2});
    assert(Math.hypot(from.x,from.z)>1.65,'The sweep fixture already began in direct contact.');
    f.ai.update(.05,player);const to=f.ai.getActive()[0].position;
    assert(Math.hypot(to.x,to.z)>1.65&&from.x<0&&to.x>0,'The dive did not cross the player between clear endpoints.');
    assert(f.damage.length===1&&f.damage[0].amount===100,'A swept contact between frames failed to produce the fatal dive.');
  }],
  ['A dive passing above the player does not become a remote fatal capture',()=>{
    const goal={x:10,y:14,z:0},f=poseFixture('diving',{x:-2,y:14,z:0},{goal,lockedTarget:{...goal},heading:-Math.PI/2});
    advance(f.ai,.5);assert(f.ai.getActive()[0].position.x>0,'The high pass never crossed the player horizontally.');
    assert(f.damage.length===0&&!f.ai.getActive()[0].struck&&!f.events.some(event=>event.type==='strike'),'Horizontal proximity swallowed the player without head-height contact.');
  }],
  ['A real dive can capture a floating swimmer without entering the water',()=>{
    const target={x:0,y:2.95,z:0},f=poseFixture('diving',{x:0,y:3.5,z:.2},{goal:{...target},lockedTarget:{...target}},{heightAt:()=>-4});
    f.ai.update(.05,{x:0,y:.75,z:0});
    assert(f.damage.length===1&&f.damage[0].amount===100,'Using the swimmer’s feet height prevented a valid dive contact above the surface.');
    assert(f.ai.getActive()[0].position.y>=2.9,'The swimmer capture required the creature to submerge.');
  }],
  ['Contact outside the diving stage never causes damage',()=>{
    for(const stage of ['circling','approaching','recovering','retreating']){
      const f=poseFixture(stage,{x:0,y:11.45,z:0});f.ai.update(.05,player);assert(f.damage.length===0,`${stage} caused contact damage outside the strike window.`);
    }
  }],
  ['Each successful dive deals 100 damage once and cannot repeat its strike after reload',()=>{
    const f=poseFixture('diving',{x:0,y:11.8,z:.2});f.ai.update(.05,player);assert(f.damage.length===1&&f.damage[0].amount===DEATHEATER_DAMAGE,'A direct dive did not strike.');
    const saved=f.ai.snapshot();assert(saved.active.struck,'Strike flag was not stored.');
    const reloadedDamage=[],restored=createDeatheaterEncounters({...f.config,state:copy(saved),onDamage:(...args)=>reloadedDamage.push(args)});
    advance(f.ai,1.5);advance(restored,1.5);
    assert(f.damage.length===1&&!reloadedDamage.length,'Continuing or reloading repeated the same dive’s fatal strike.');
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(f.ai.snapshot()),'The persisted spent dive resumed a different flight trajectory.');
  }],
  ['A thin trunk between predator and player blocks the strike',()=>{
    const f=poseFixture('diving',{x:-.9,y:11.45,z:0},{goal:{x:.4,y:11.45,z:0},lockedTarget:{x:.4,y:11.45,z:0}},{colliders:[{x:0,z:0,radius:.1,height:8}]});
    f.ai.update(.05,{x:.4,y:10,z:0});assert(f.damage.length===0,'A strike passed through a thin intervening trunk.');
  }],
  ['The fatal-damage callback sees a valid already-spent strike',()=>{
    let ai,callbackState=null;const f=poseFixture('diving',{x:0,y:11.8,z:.2},{},{onDamage:()=>{callbackState=ai.snapshot();}});ai=f.ai;ai.update(.05,player);
    assert(callbackState?.active.struck&&normalizeDeatheaterState(callbackState)!==null,'Fatal callback observed a missing strike flag or invalid state.');
  }],
  ['Flight stays above water and follows the minimum clearance',()=>{
    const f=poseFixture('diving',{x:0,y:3.05,z:0},{goal:{x:0,y:2.95,z:0},lockedTarget:{x:0,y:2.95,z:0}},{heightAt:()=>-4});
    for(let i=0;i<70;i++){f.ai.update(.05,{x:0,y:0,z:0});assert(f.ai.getActive()[0].position.y>=2.9-1e-6,'The predator submerged or tunneled through the water floor.');}
  }],
  ['Abrupt terrain blocks a sweep without teleporting flight height',()=>{
    const terrain=x=>x>=0?40:10;
    const f=poseFixture('recovering',{x:-2,y:12,z:0},{goal:{x:12,y:12,z:0}},{heightAt:terrain});
    for(let i=0;i<70;i++){
      const before=f.ai.getActive()[0].position;f.ai.update(.05,player);const after=f.ai.getActive()[0].position;
      assert(after.y>=Math.max(2,terrain(after.x))+ .9-1e-6,'Flight entered the cliff.');
      assert(Math.hypot(after.x-before.x,after.y-before.y,after.z-before.z)<=.55+1e-6,'Terrain avoidance teleported the creature.');
    }
  }],
  ['Swept collision avoidance does not enter a rock cylinder',()=>{
    const obstacle={x:0,z:0,radius:2,height:8};
    const f=poseFixture('recovering',{x:-5,y:12,z:0},{goal:{x:12,y:12,z:0}},{colliders:[obstacle]});
    for(let i=0;i<65;i++){f.ai.update(.05,player);const p=f.ai.getActive()[0].position;if(p.y<18.72)assert(Math.hypot(p.x,p.z)>=2.72-1e-6,'Flight entered the expanded rock collision radius.');}
  }],
  ['Low stones allow overhead flight while blocking a low swoop',()=>{
    const lowRock={x:0,z:0,radius:2,height:.3};
    const high=poseFixture('recovering',{x:-5,y:16,z:0},{goal:{x:12,y:16,z:0}},{colliders:[lowRock]});
    advance(high.ai,1);const overhead=high.ai.getActive()[0].position;
    assert(near(overhead.x,6)&&near(overhead.z,0),'A low stone became an aerial column.');
    const low=poseFixture('recovering',{x:-4,y:10.95,z:0},{goal:{x:12,y:10.95,z:0}},{colliders:[lowRock]});
    for(let i=0;i<45;i++){low.ai.update(.05,player);const p=low.ai.getActive()[0].position;if(p.y<11.02)assert(Math.hypot(p.x,p.z)>=2.72-1e-6,'A low flight passed through a stone.');}
    const unknown=poseFixture('recovering',{x:-5,y:18,z:0},{goal:{x:12,y:18,z:0}},{colliders:[{x:0,z:0,radius:2}]});
    advance(unknown.ai,1);assert(near(unknown.ai.getActive()[0].position.x,6),'A collider without height used an unbounded aerial column.');
  }],
  ['Ascending pose uses positive pitch and local minus-Z heading',()=>{
    const f=poseFixture('recovering',{x:0,y:15,z:0},{goal:{x:10,y:25,z:0}});f.ai.update(.05,player);const a=f.ai.getActive()[0];
    assert(a.pitch>0&&near(a.heading,-Math.PI/2),'Pose does not match the renderer’s local forward/up convention.');
  }],
  ['All stage transitions preserve continuous position',()=>{
    const f=activeFixture();let previous=f.ai.getActive()[0],transitions=0;
    for(let i=0;i<650;i++){f.ai.update(.05,player);const next=f.ai.getActive()[0];assert(Math.hypot(next.position.x-previous.position.x,next.position.y-previous.position.y,next.position.z-previous.position.z)<=.6+1e-6,'A stage transition teleported the predator.');if(next.stage!==previous.stage)transitions++;previous=next;}
    assert(transitions>=8,'The fixture did not exercise repeated flight stage changes.');
  }],
  ['Four seconds below the outer threshold starts retreat',()=>{
    let blend=.12;const f=activeFixture({stormBlendAt:()=>blend});advance(f.ai,4.1);assert(f.ai.getActive()[0].stage!=='retreating','The exact outer boundary counted as outside.');
    blend=.119;advance(f.ai,3.95);assert(f.ai.getActive()[0].stage!=='retreating','Retreat began before four seconds outside.');
    advance(f.ai,.05);assert(f.ai.getActive()[0].stage==='retreating','Leaving the storm did not initiate retreat.');
  }],
  ['An expired hunt departs and persists a 45–75s cooldown',()=>{
    const f=activeFixture(),duration=f.ai.getActive()[0].huntRemaining;advance(f.ai,duration);
    assert(f.ai.getActive()[0].stage==='retreating','Hunt did not expire at its saved duration.');advance(f.ai,5.1);
    const saved=f.ai.snapshot();assert(saved.active===null&&saved.cooldown>=44.8&&saved.cooldown<=75,'Departure did not start the bounded cooldown.');
    const restored=createDeatheaterEncounters({...f.config,state:saved});advance(restored,5);assert(!restored.getActive().length&&!restored.snapshot().warningIssued,'Reload skipped the departure cooldown.');
  }],
  ['No update means no movement, damage or elapsed encounter time',async()=>{
    const f=activeFixture(),before=JSON.stringify(f.ai.snapshot());await new Promise(resolve=>setTimeout(resolve,60));for(let i=0;i<20;i++)f.ai.getActive();
    assert(JSON.stringify(f.ai.snapshot())===before&&f.damage.length===0,'Controller advanced during pause.');
  }],
  ['Invalid updates do nothing and one stalled frame is capped at 0.25s',()=>{
    const f=activeFixture(),before=JSON.stringify(f.ai.snapshot());for(const dt of [-1,0,NaN,Infinity])f.ai.update(dt,player);f.ai.update(.05,{x:NaN,y:10,z:0});
    assert(JSON.stringify(f.ai.snapshot())===before,'Invalid update altered state.');f.ai.update(99,player);assert(near(f.ai.snapshot().clock,.25),'A stalled frame fast-forwarded the whole hunt.');
  }],
  ['Reload preserves random draws, lock, pose and every simulation clock',()=>{
    const f=activeFixture();advance(f.ai,6.1);const saved=f.ai.snapshot();
    const restored=createDeatheaterEncounters({...f.config,seed:'must-not-reroll',state:copy(saved)});
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(saved),'Reload changed essential state.');
    for(let i=0;i<150;i++){const p={x:i*.02,y:10,z:2};f.ai.update(.05,p);restored.update(.05,p);}
    assert(JSON.stringify(restored.snapshot())===JSON.stringify(f.ai.snapshot()),'Resumed flight diverged from uninterrupted simulation.');
  }],
  ['Snapshots cannot mutate the controller and malformed state is rejected',()=>{
    const f=activeFixture(),saved=f.ai.snapshot(),original=JSON.stringify(saved);saved.active.position.x=200;saved.active.goal.y=900;saved.active.orbitCenter.x=900;
    assert(JSON.stringify(f.ai.snapshot())===original,'A caller mutated live state through a snapshot.');
    assert(normalizeDeatheaterState(undefined)===undefined&&normalizeDeatheaterState(null)===null,'Absent and invalid states are not distinguished.');
    for(const patch of [{clock:-1},{cooldown:76},{warningRemaining:9},{encounterIndex:1.5},{active:{...f.ai.getActive()[0],stage:'biting'}},{active:{...f.ai.getActive()[0],position:{x:NaN,y:4,z:0}}}])assert(normalizeDeatheaterState({...f.ai.snapshot(),...patch})===null,'Malformed state was accepted.');
  }],
  ['Journey storage round-trips the active Deatheater state',()=>{
    const f=activeFixture();advance(f.ai,6.1);const state=f.ai.snapshot(),store=createJourneyStore(memoryStorage()),started=store.begin(journeyData(state));
    assert(started.persisted&&JSON.stringify(store.read().deatheater)===JSON.stringify(state),'Journey store stripped or changed the flight state.');
  }],
  ['Journey validation rejects malformed predator payloads',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),started=store.begin(journeyData(activeFixture().ai.snapshot()));
    const bad={...started.record,deatheater:{...started.record.deatheater,clock:-1}};
    assert(store.save(bad)===null,'An invalid encounter snapshot was saved.');storage.setItem(SAVE_KEY,JSON.stringify(bad));assert(store.read()===null,'A malformed saved encounter was resumed.');
  }],
  ['A stale tab cannot rewind Deatheater clocks or restore lost health',()=>{
    const storage=memoryStorage(),first=createJourneyStore(storage),other=createJourneyStore(storage),f=activeFixture();
    const started=first.begin(journeyData(f.ai.snapshot())).record;advance(f.ai,3);
    const fresh=first.save({...started,health:72,deatheater:f.ai.snapshot()});
    const stale=other.save({...started,health:100});assert(stale.health===72&&stale.deatheater.clock===fresh.deatheater.clock,'A stale tab restored health or rewound the active hunt.');
  }],
  ['A fatal strike creates an immutable death lock with its spent swoop',()=>{
    const store=createJourneyStore(memoryStorage()),f=poseFixture('diving',{x:0,y:11.8,z:.2});
    const life=store.begin(journeyData(f.ai.snapshot())).record;let ai,endResult;
    ai=createDeatheaterEncounters({...f.config,state:f.ai.snapshot(),onDamage:()=>{endResult=store.end({...life,deatheater:ai.snapshot()},'Killed by a Deatheater');}});
    ai.update(.05,player);assert(endResult?.persisted&&endResult.record.deatheater.active.struck,'Fatal strike was not persisted before death.');
    assert(store.read()===null&&store.isDead(life.runId)&&store.save(life)===null,'The fatal encounter could be restored as a living journey.');
  }],
  ['A real dive ends a full-health journey before the swallowing presentation begins',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),otherTab=createJourneyStore(storage);let ai,life,endResult,contactRecord=null;
    const f=activeFixture({onDamage:(amount,cause,active)=>{
      assert(amount===100&&cause==='Deatheater','The live flight callback did not deliver fatal Deatheater damage.');
      contactRecord=active;
      endResult=store.end({...life,deatheater:ai.snapshot()},'Gobbled by a Deatheater');
    }});ai=f.ai;life=store.begin(journeyData(ai.snapshot())).record;const stale=otherTab.read();
    assert(life.health===100,'The integration fixture did not begin at full health.');
    for(let i=0;i<260&&!endResult;i++)ai.update(.05,player);
    assert(endResult?.persisted&&contactRecord?.stage==='diving'&&contactRecord.struck,'The actual flight failed to commit a spent fatal dive.');
    const dead=endResult.record;
    assert(dead.health===0&&dead.status==='dead'&&dead.deatheater.active.struck,'A full-health survivor remained alive at the start of the swallowing presentation.');
    assert(store.read()===null&&createJourneyStore(storage).read()===null&&otherTab.save(stale)===null,'Continue or a stale tab could revive the captured player.');
    const tombstones=JSON.parse(storage.getItem(DEATH_KEY));assert(tombstones[life.runId]?.status==='dead','The successful dive failed to write permanent death history.');
  }],
];

export async function runDeatheaterChecks(onResult=()=>{}) {
  const results=[];
  for(const [name,check] of deatheaterChecks){const start=performance.now();let result;try{await check();result={name,passed:true,elapsed:performance.now()-start};}catch(error){result={name,passed:false,error:error.message,elapsed:performance.now()-start};}results.push(result);onResult(result);await new Promise(resolve=>setTimeout(resolve,0));}
  return results;
}

if(typeof document!=='undefined') {
  const button=document.getElementById('run-checks'),list=document.getElementById('results'),summary=document.getElementById('summary');
  button?.addEventListener('click',async()=>{
    button.disabled=true;list.replaceChildren();summary.textContent='Running real encounter and memory-only persistence checks…';
    const results=await runDeatheaterChecks(result=>{const row=document.createElement('li');row.className=result.passed?'pass':'fail';const badge=document.createElement('strong');badge.textContent=result.passed?'PASS':'FAIL';const title=document.createElement('span');title.textContent=result.name;row.append(badge,title);if(!result.passed){const detail=document.createElement('p');detail.textContent=result.error;row.append(detail);}list.append(row);summary.textContent=`${list.children.length} / ${deatheaterChecks.length} checks complete`;});
    const failed=results.filter(result=>!result.passed).length;summary.textContent=`${results.length-failed} passed · ${failed} failed · Journey save untouched`;button.disabled=false;
  });
}
