import * as THREE from './vendor/three.module.js';
import { loadRealMaterials } from './real-materials.js';
import { loadRealFoliage } from './real-foliage.js';
import { createRiverSurface } from './river-surface.js';
import { createAlpineBackdrop } from './alpine-background.js';
import { createForestDetails } from './forest-details.js';
import { createCanopyMask, createTerrainMaterial, createWeatheredStoneMaterial, clipPineShoot } from './landscape-materials.js';
import { forestBlendAt, stormBlendAt, glowBlendAt, biomeAt, iceBlendAt, lavaBlendAt, beachBlendAt, caveBlendAt, CAVE_ENTRANCE, LAVA_CENTER, STORM_CENTER, GLOW_CENTER } from './biomes.js';
import {riverBankDistanceAt} from './river-network.js';
import {createGlowBiome} from './glow-biome.js';
import {WORLD_SIZE,WATER_LEVEL,TERRAIN_SEGMENTS,heightAt,riverX,terrainVertex,terrainGridHeight,embeddedTreeHeight,legacyHeightAt,hazardAt} from './terrain-surface.js';
import {createExpandedBiomes} from './expanded-biomes.js';
import {createTreeInstanceRegistry} from './tree-instances.js';
import { createRainforest } from './rainforest.js';
import { createStormBiome } from './storm-biome.js';
import { createPineTreeGeometry, applyPineWind } from './pine-tree.js';
import {createBurrowpeedDens} from './burrowpeed-encounters.js';

export {WORLD_SIZE,WATER_LEVEL,heightAt,riverX,hazardAt} from './terrain-surface.js';
export const spawn = { x: -65, z: 95, yaw: -0.40 };

const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const smooth = (a, b, v) => { const t = clamp((v - a) / (b - a)); return t * t * (3 - 2 * t); };
const mix = (a, b, t) => a + (b - a) * t;
function random(seed) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let n = Math.imul(seed ^ seed >>> 15, 1 | seed); n = n + Math.imul(n ^ n >>> 7, 61 | n) ^ n; return ((n ^ n >>> 14) >>> 0) / 4294967296; };
}
const hash = (x, z) => { const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453123; return n - Math.floor(n); };
function noise(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
  const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
  return mix(mix(hash(ix, iz), hash(ix + 1, iz), u), mix(hash(ix, iz + 1), hash(ix + 1, iz + 1), u), v);
}
function fbm(x, z) { return noise(x, z) * .58 + noise(x * 2.03 + 4.2, z * 2.03) * .28 + noise(x * 4.07, z * 4.07 - 7.6) * .14; }
const riverWidth = z => 10.4 + Math.sin(z * .021) * 1.25;
const crossingX = riverX(30);

export const landmarks = [
  { id: 'trailhead', name: 'Pine Hollow', x: spawn.x, z: spawn.z, radius: 14, description: 'A sheltered natural clearing opens onto the river valley.' },
  { id: 'river-crossing', name: 'River Shallows', x: crossingX, z: 30, radius: 18, description: 'A broad gravel shoal brings the cold river within wading depth.' },
  { id: 'high-ridge', name: 'Overlook Ridge', x: -148, z: -175, radius: 22, description: 'An exposed ridge with a view over the wilderness.' },
  { id: 'cedar-grove', name: 'Whispering Grove', x: 94, z: -75, radius: 22, description: 'Tall evergreens shelter a quiet woodland clearing.' },
  { id: 'river-wreck', name: 'River Wreck', x: riverX(-35), z: -35, radius: 24, description: 'A broken aircraft rests in the cold river beside the survivor’s landing.' },
  { id: 'rainforest-heart', name: 'Rainforest Heart', x: -210, z: -40, radius: 20, description: 'Giant trees, hanging vines, and deep shade shelter the Teethpeed.' },
  { id: 'storm-heart', name: 'Stormlands', ...STORM_CENTER, radius: 22, description: 'A permanent hurricane rages above the far north. Purple scars split the dead trees. This is the most hostile wilderness.' },
  {id:'glowhaven',name:'Glowhaven',...GLOW_CENTER,radius:22,description:'Luminous trees and drifting jellyfish shelter peaceful wildlife. Hostile creatures cannot follow you into this refuge.'},
  {id:'crystal-cavern',name:'Hollowroot Cave Entrance',...CAVE_ENTRANCE,radius:18,description:'A descending limestone passage enters an underground maze of mineral seams, blind chambers and ancient geodes.'},
  {id:'ember-caldera',name:'Ember Caldera',x:488,z:-342,radius:22,description:'Black basalt surrounds an active lake of molten lava. The glowing surface burns.'},
  {id:'frostbound-highlands',name:'Frostbound Highlands',x:-545,z:-570,radius:24,description:'Wind-carved snowfields and blue ice lie beyond the northern ridges.'},
  {id:'sundrift-coast',name:'Sundrift Coast',x:250,z:535,radius:24,description:'Pale sand and palms line an open sea with deep swimmable water.'},
];
const survivorBank = { x: riverX(-25) - 27, z: -25 };

export function surfaceAt(x, z) {
  const biome=biomeAt(x,z).id;
  if(hazardAt(x,z))return 'lava';
  if (heightAt(x, z) < WATER_LEVEL) return 'water';
  if(biome==='ice')return 'snow';
  if(biome==='beach')return 'sand';
  if(biome==='cave'||biome==='lava')return 'rock';
  if (heightAt(x, z) > 49 || stormBlendAt(x,z)>.55 || fbm(x * .04, z * .04) > .76) return 'rock';
  return 'grass';
}

function canvasTexture(size, draw, repeat = 1) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = size;
  const context = canvas.getContext('2d'); draw(context, size);
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping; texture.repeat.set(repeat, repeat);
  texture.anisotropy = 4; return texture;
}
function soilTexture() {
  const rng = random(2306);
  return canvasTexture(512, (ctx, n) => {
    ctx.fillStyle = '#b7b3a1'; ctx.fillRect(0, 0, n, n);
    for (let i = 0; i < 27000; i++) {
      const v = Math.floor(115 + rng() * 115); ctx.fillStyle = `rgba(${v},${v - 5},${v - 15},${.08 + rng() * .28})`;
      const r = .3 + rng() * 2.2; ctx.fillRect(rng() * n, rng() * n, r, r * .7);
    }
    for (let i = 0; i < 3800; i++) {
      const x = rng() * n, y = rng() * n;
      ctx.strokeStyle = rng() > .5 ? '#83836a66' : '#d5c9a34d'; ctx.lineWidth = .45 + rng();
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + rng() * 5 - 2.5, y - 1 - rng() * 7); ctx.stroke();
    }
    for (let i = 0; i < 950; i++) {
      const x = rng() * n, y = rng() * n, length = 2 + rng() * 9, angle = rng() * Math.PI * 2;
      ctx.strokeStyle = ['#766b4c88', '#a5946388', '#5c604b66'][i % 3]; ctx.lineWidth = .45 + rng() * .8;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length); ctx.stroke();
      if (i % 4 === 0) {
        ctx.fillStyle = '#c6bba282'; ctx.beginPath(); ctx.ellipse(x + 1, y - 1, 1 + rng() * 2.7, .5 + rng(), angle, 0, Math.PI * 2); ctx.fill();
      }
    }
  }, 92);
}
function barkTexture() {
  const rng = random(7620);
  return canvasTexture(256, (ctx, n) => {
    ctx.fillStyle = '#7a6e5a'; ctx.fillRect(0, 0, n, n);
    for (let i = 0; i < 440; i++) {
      const x = rng() * n, y = rng() * n, w = .5 + rng() * 6, h = 4 + rng() * 74;
      ctx.fillStyle = ['#4f4a40', '#96846a', '#675b4a', '#b09b7b'][i % 4]; ctx.globalAlpha = .3 + rng() * .45;
      ctx.fillRect(x, y, w, h); ctx.fillStyle = '#282e29'; ctx.fillRect(x + w, y, .7, h);
    }
    ctx.globalAlpha = 1;
  });
}
function needleTexture() {
  const rng = random(6301);
  return canvasTexture(256, (ctx, n) => {
    ctx.clearRect(0, 0, n, n);
    ctx.lineCap = 'round'; ctx.strokeStyle = '#766f43'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(12, 130); ctx.quadraticCurveTo(126, 125, 248, 128); ctx.stroke();
    for (let i = 0; i < 38; i++) {
      const x = 12 + i * 5.9, extent = Math.sin((i + 2) / 42 * Math.PI) * (57 + rng() * 39);
      for (const side of [-1, 1]) {
        const endX = x + 29 + rng() * 13, endY = 128 + side * extent;
        ctx.strokeStyle = '#536c42'; ctx.lineWidth = 3.3;
        ctx.beginPath(); ctx.moveTo(x, 128); ctx.lineTo(endX, endY); ctx.stroke();
        for (let j = 0; j < 17; j++) {
          const f = j / 17, bx = mix(x, endX, f), by = mix(128, endY, f);
          const length = 7 + rng() * 12;
          ctx.strokeStyle = ['#68804f', '#839060', '#4e6944', '#a2ab72'][Math.floor(rng() * 4)]; ctx.lineWidth = 1.1 + rng() * 1.5;
          for (let k = 0; k < 3; k++) {
            const angle = -1.05 + rng() * 2.3;
            ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + Math.cos(angle) * length, by + side * Math.sin(angle) * length); ctx.stroke();
          }
        }
      }
    }
  });
}
function groundCoverTexture() {
  const rng = random(590);
  return canvasTexture(256, (ctx, n) => {
    ctx.clearRect(0, 0, n, n); ctx.lineCap = 'round';
    ctx.strokeStyle = '#7b8e55'; ctx.lineWidth = 2.1;
    ctx.beginPath(); ctx.moveTo(127, 256); ctx.quadraticCurveTo(133, 118, 127, 9); ctx.stroke();
    for (let j = 1; j < 26; j++) {
      const t = j / 27, x = 128 + Math.sin(t * Math.PI) * 3, y = 253 - t * 242;
      const span = Math.pow(Math.sin(t * Math.PI), .85) * (66 + rng() * 19);
      for (const s of [-1, 1]) {
        const endX = x + s * span, endY = y - 13 - span * .22;
        ctx.fillStyle = ['#76905a', '#8b9f65', '#5b784b', '#9bab71'][j % 4];
        ctx.beginPath(); ctx.moveTo(x, y + 2); ctx.quadraticCurveTo(x + span * s * .5, y + 4, endX, endY);
        ctx.quadraticCurveTo(x + span * s * .44, y - 18, x, y - 2); ctx.fill();
        ctx.strokeStyle = '#aec08766'; ctx.lineWidth = .6; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(endX, endY); ctx.stroke();
        for (let k = 1; k < 8; k++) {
          const q = k / 9, lx = mix(x, endX, q), ly = mix(y, endY, q);
          ctx.strokeStyle = '#d2d8a03d'; ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(lx + s * 5, ly - 3); ctx.stroke();
        }
      }
    }
  });
}
function quadGeometry(quads) {
  const positions = [], uvs = [], indices = [];
  for (const corners of quads) {
    const base = positions.length / 3;
    for (const p of corners) positions.push(...p);
    uvs.push(0, 0, 1, 0, 1, 1, 0, 1); indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); g.setIndex(indices); g.computeVertexNormals(); return g;
}
function coverGeometry() {
  const quads = [];
  for (let i = 0; i < 7; i++) {
    const a = i * Math.PI * 2 / 7 + Math.sin(i * 8.1) * .16, ux = Math.cos(a), uz = Math.sin(a), vx = -uz, vz = ux;
    const spread = .57 + Math.sin(i * 4.8) * .18, rise = .53 + Math.cos(i * 3.1) * .2, width = .23 + Math.sin(i * 9.3) * .06;
    quads.push([
      [-vx * width, .015, -vz * width], [vx * width, .015, vz * width],
      [ux * spread + vx * width, rise, uz * spread + vz * width],
      [ux * spread - vx * width, rise, uz * spread - vz * width],
    ]);
  }
  return quadGeometry(quads);
}
function addWind(material, windClock, strength, height, fine = true) {
  material.onBeforeCompile = shader => {
    shader.uniforms.uWindTime = windClock;
    shader.vertexShader = 'uniform float uWindTime;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `
      #include <begin_vertex>
      vec3 treeAnchor = vec3(0.0);
      #ifdef USE_INSTANCING
        treeAnchor = instanceMatrix[3].xyz;
      #endif
      float branchHeight = clamp(position.y / ${height.toFixed(2)}, 0.0, 1.0);
      float windPhase = treeAnchor.x * .029 + treeAnchor.z * .017;
      float gust = .55 + .45 * sin(uWindTime * .37 + windPhase * .73);
      float sway = sin(uWindTime * .78 + windPhase) + .27 * sin(uWindTime * 1.61 + windPhase * 2.1);
      transformed.x += sway * gust * branchHeight * branchHeight * ${strength.toFixed(3)};
      transformed.z += cos(uWindTime * .64 + windPhase) * branchHeight * branchHeight * ${(strength * .46).toFixed(3)};
      ${fine ? `float flutter = sin(uWindTime * 2.45 + position.x * 3.1 + position.z * 2.8 + windPhase);
      transformed.y += flutter * length(position.xz) * .018 * gust;
      transformed.x += sin(uWindTime * 3.0 + position.y * 2.8 + windPhase) * branchHeight * ${(strength * .08).toFixed(3)};` : ''}
    `);
  };
  material.customProgramCacheKey = () => `wilderness-wind-${strength}-${height}-${fine}`;
}

export async function createWorld(scene) {
  const [scans, foliage] = await Promise.all([loadRealMaterials(), loadRealFoliage()]);
  const group = new THREE.Group(); group.name = 'Scars of the Wild — wilderness'; scene.add(group);
  const colliders = [], disposables = [], windClock = { value: 0 }, rng = random(918244),treeRegistry=createTreeInstanceRegistry(),treeBatches=[];
  const add = mesh => { group.add(mesh); return mesh; };
  const own = value => { disposables.push(value); return value; };

  for (const texture of [...Object.values(scans.ground),...Object.values(scans.dirt),...Object.values(scans.rock),...foliage.textures]) own(texture);
  for (const texture of Object.values(scans.ground)) texture.repeat.set(WORLD_SIZE / 2.2,WORLD_SIZE / 2.2);
  for (const texture of Object.values(scans.rock)) texture.repeat.set(1.3,1.3);
  const groundTexture = scans.ground.map;
  const terrain = own(new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, TERRAIN_SEGMENTS, TERRAIN_SEGMENTS)); terrain.rotateX(-Math.PI / 2);
  const positions = terrain.attributes.position, colors = new Float32Array(positions.count * 3), rockBlend = new Float32Array(positions.count), dirtBlend = new Float32Array(positions.count), biomeWeights=new Float32Array(positions.count*3), color = new THREE.Color();
  const meadow = new THREE.Color('#bfc0aa'), forestFloor = new THREE.Color('#c3bfaf'), soil = new THREE.Color('#d6cbbc'), rock = new THREE.Color('#c7cbbf'), rainforestSoil = new THREE.Color('#c9bcab'), stormSoil = new THREE.Color('#716778'), glowSoil=new THREE.Color('#729185'),caveSoil=new THREE.Color('#847560');
  for (let i = 0; i < positions.count; i++) {
    const ix=i%(TERRAIN_SEGMENTS+1),iz=Math.floor(i/(TERRAIN_SEGMENTS+1)),x=terrainVertex(ix),z=terrainVertex(iz),h=terrainGridHeight(ix,iz);positions.setXYZ(i,x,h,z);
    const slope = Math.hypot(heightAt(x + 1, z) - h, heightAt(x, z + 1) - h);
    color.copy(forestFloor).lerp(meadow, fbm(x * .035, z * .035));
    color.lerp(soil, (1 - smooth(2.4, 5.5, h)) * .8);
    color.lerp(rock, Math.max(smooth(.52, 1.2, slope) * .65, smooth(50, 83, h) * .65));
    color.lerp(rainforestSoil,forestBlendAt(x,z)*.78);color.lerp(glowSoil,glowBlendAt(x,z)*.60);
    color.lerp(stormSoil,stormBlendAt(x,z)*(.77+noise(x*.06,z*.06)*.17));
    const caveApron=(1-smooth(0,22,x-CAVE_ENTRANCE.x))*(1-smooth(9,20,Math.abs(z-CAVE_ENTRANCE.z)))*smooth(-35,0,x-CAVE_ENTRANCE.x);
    const caveFloor=Math.max(caveBlendAt(x,z),caveApron);color.lerp(caveSoil,caveFloor*.92);
    color.multiplyScalar(.91 + noise(x * .045, z * .045) * .12); color.toArray(colors, i * 3);
    dirtBlend[i] = clamp(.48 + forestBlendAt(x,z)*.24 + (fbm(x*.043,z*.043)-.5)*.18);
    rockBlend[i] = Math.max(smooth(.38,.94,slope)*.88,smooth(43,76,h)*.88, (1-smooth(2.6,5.2,h))*.84,stormBlendAt(x,z)*(.62+noise(x*.037,z*.037)*.29));
    // Push the existing soil shader fully past its blend threshold under the
    // cave; no photographed grass remains between its gravel and bare dirt.
    dirtBlend[i]=mix(dirtBlend[i],1.25,caveFloor);rockBlend[i]=Math.max(rockBlend[i],caveFloor*(.40+noise(x*.11,z*.11)*.27));
    biomeWeights.set([iceBlendAt(x,z),beachBlendAt(x,z),lavaBlendAt(x,z)],i*3);
  }
  terrain.setAttribute('color', new THREE.BufferAttribute(colors, 3)); terrain.setAttribute('rockBlend',new THREE.BufferAttribute(rockBlend,1)); terrain.setAttribute('dirtBlend',new THREE.BufferAttribute(dirtBlend,1));terrain.setAttribute('biomeWeights',new THREE.BufferAttribute(biomeWeights,3)); terrain.computeVertexNormals();
  const glowWeights=new Float32Array(positions.count);for(let i=0;i<positions.count;i++)glowWeights[i]=glowBlendAt(positions.getX(i),positions.getZ(i));terrain.setAttribute('glowWeight',new THREE.BufferAttribute(glowWeights,1));
  const canopyUniform = {value: null};own({dispose(){canopyUniform.value?.dispose();canopyUniform.value=null;}});
  const groundMaterial = own(createTerrainMaterial(scans, canopyUniform));
  const compileTerrain=groundMaterial.onBeforeCompile;
  groundMaterial.onBeforeCompile=shader=>{compileTerrain(shader);shader.vertexShader='attribute vec3 biomeWeights;varying vec3 vBiomeWeights;\n'+shader.vertexShader;shader.vertexShader=shader.vertexShader.replace('vRockBlend = rockBlend;','vBiomeWeights=biomeWeights;vRockBlend = rockBlend;').replace('uv * 444.444','uv * 1000.0').replace('uv * 615.384615','uv * 1384.615385');shader.fragmentShader='varying vec3 vBiomeWeights;\n'+shader.fragmentShader;shader.fragmentShader=shader.fragmentShader.replace('float floorMacro =',`float biomeGrain=terrainNoise(vTerrainPoint.xz*8.0);diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.75,.84,.88)*(.85+biomeGrain*.16),vBiomeWeights.x);diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.59,.48,.29)*(.78+biomeGrain*.23),vBiomeWeights.y);diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.105,.088,.080)*(.7+biomeGrain*.4),vBiomeWeights.z);float floorMacro =`);};
  const compileBiomes=groundMaterial.onBeforeCompile;
  groundMaterial.onBeforeCompile=s=>{compileBiomes(s);s.vertexShader='attribute float glowWeight;varying float vGlowWeight;\n'+s.vertexShader;s.vertexShader=s.vertexShader.replace('vRockBlend = rockBlend;','vGlowWeight=glowWeight;vRockBlend = rockBlend;');s.fragmentShader='varying float vGlowWeight;\n'+s.fragmentShader;s.fragmentShader=s.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
    float mossLace=pow(max(0.0,1.0-abs(sin(vTerrainPoint.x*11.0+sin(vTerrainPoint.z*9.0)*2.3))),24.0)*smoothstep(.50,.73,terrainNoise(vTerrainPoint.xz*.6));
    totalEmissiveRadiance+=vec3(.05,.34,.23)*mossLace*vGlowWeight;
  `);};
  groundMaterial.customProgramCacheKey=()=> 'expanded-nine-biome-terrain-v2';
  // Shared vertex buffers, separate indexed tiles: frustum culling does not
  // submit the entire 1.8km heightfield for every ground-level view.
  const terrainChunks=[],sourceIndices=terrain.index.array;
  for(let cz=0;cz<9;cz++)for(let cx=0;cx<9;cx++){
    const indices=[],geometry=own(new THREE.BufferGeometry()),box=new THREE.Box3();
    for(const [name,attribute]of Object.entries(terrain.attributes))geometry.setAttribute(name,attribute);
    for(let z=cz*60;z<(cz+1)*60;z++)for(let x=cx*60;x<(cx+1)*60;x++){const start=(z*TERRAIN_SEGMENTS+x)*6;for(let n=0;n<6;n++)indices.push(sourceIndices[start+n]);}
    for(let z=cz*60;z<=(cz+1)*60;z++)for(let x=cx*60;x<=(cx+1)*60;x++)box.expandByPoint(new THREE.Vector3(terrainVertex(x),terrainGridHeight(x,z),terrainVertex(z)));
    geometry.setIndex(indices);geometry.boundingBox=box;geometry.boundingSphere=box.getBoundingSphere(new THREE.Sphere());
    const mesh=add(new THREE.Mesh(geometry,groundMaterial));mesh.name=`Terrain ${cx},${cz}`;mesh.receiveShadow=true;terrainChunks.push(mesh);
  }
  const rainforest = own(createRainforest({group,heightAt,placementHeightAt:legacyHeightAt,forestBlendAt,foliage,rockMaps:scans.rock}));
  colliders.push(...rainforest.colliders);
  const storm = own(createStormBiome({group,heightAt,stormBlendAt,foliage,rockMaps:scans.rock}));
  colliders.push(...storm.colliders);
  const glow=own(createGlowBiome({group,heightAt,foliage,rockMaps:scans.rock}));colliders.push(...glow.colliders);

  const trunkMaterial = own(new THREE.MeshStandardMaterial({ ...foliage.bark, color:'#f1eadb', normalScale:new THREE.Vector2(.85,.85), roughness:1 }));
  applyPineWind(trunkMaterial, windClock);
  const foliageMaterial = own(new THREE.MeshStandardMaterial({ ...foliage.pine, color:'#ffffff', alphaTest:.10, side:THREE.DoubleSide, roughness:.95, normalScale:new THREE.Vector2(.65,.65), emissive:'#34452a', emissiveIntensity:.065, alphaToCoverage:true }));
  applyPineWind(foliageMaterial, windClock, true);
  clipPineShoot(foliageMaterial);
  const pine = createPineTreeGeometry();
  const trunkGeometry = own(pine.woodGeometry), foliageGeometry = own(pine.foliageGeometry);
  const treeLocations = [], desiredTrees = 470;
  for (let attempt = 0; attempt < 20000 && treeLocations.length < desiredTrees; attempt++) {
    const x = (rng() - .5) * 748, z = (rng() - .5) * 748, h = heightAt(x, z);
    const isClearing = landmarks.some(l => Math.hypot(x - l.x, z - l.z) < (l.id === 'cedar-grove' ? 12 : l.id === 'trailhead' ? 14 : 8));
    if (h < 5 || h > 76 || isClearing || Math.hypot(x - survivorBank.x, z - survivorBank.z) < 8) continue;
    if (noise(x * .022, z * .022) < .24 || treeLocations.some(p => Math.hypot(p.x - x, p.z - z) < 5)) continue;
    treeLocations.push({ x, z, h, scale: .64 + rng() * .85, angle: rng() * Math.PI * 2, tint: .72 + rng() * .34 });
  }
  // Denser, taller trees frame the near view and the grove landmark.
  for (let i = 0; i < 62; i++) {
    const a = rng() * Math.PI * 2, r = 18 + rng() * 56, base = i < 32 ? spawn : landmarks[3];
    const x = base.x + Math.cos(a) * r, z = base.z + Math.sin(a) * r, h = heightAt(x, z);
    if (h < 5 || Math.hypot(x - survivorBank.x, z - survivorBank.z) < 8 || treeLocations.some(p => Math.hypot(p.x - x, p.z - z) < 5)) continue;
    treeLocations.push({ x, z, h, scale: .9 + rng() * .65, angle: rng() * Math.PI * 2, tint: .83 + rng() * .27 });
  }
  for(let i=0;i<145;i++) {
    const z=-118+rng()*195,side=i%2?1:-1,x=riverX(z)+side*(26+rng()*65),h=heightAt(x,z);
    if(h<4.4||Math.hypot(x-survivorBank.x,z-survivorBank.z)<9||treeLocations.some(p=>Math.hypot(p.x-x,p.z-z)<3.8))continue;
    treeLocations.push({x,z,h,scale:i%4===0?.24+rng()*.25:.65+rng()*.72,angle:rng()*Math.PI*2,tint:.82+rng()*.22});
  }
  // Conifers thin into the storm border and give way to its shattered deadwood.
  for(let i=treeLocations.length-1;i>=0;i--){const p=treeLocations[i],stormWeight=stormBlendAt(p.x,p.z);if(riverBankDistanceAt(p.x,p.z)<2.5||glowBlendAt(p.x,p.z)>.28||forestBlendAt(p.x,p.z)>.45||stormWeight>.55||stormWeight>.1&&hash(p.x+19,p.z-7)<stormWeight)treeLocations.splice(i,1);}
  treeLocations.forEach((tree,i)=>tree.id=`pine-${String(i).padStart(4,'0')}`);
  const outerRng=random(629773);let outerTrees=0;
  for(let attempt=0;attempt<16000&&outerTrees<620;attempt++){
    const x=(outerRng()-.5)*1730,z=(outerRng()-.5)*1730,h=heightAt(x,z),biome=biomeAt(x,z).id;
    if(Math.max(Math.abs(x),Math.abs(z))<395||!['valley','ice'].includes(biome)||h<4||iceBlendAt(x,z)>.70||caveBlendAt(x,z)>.01||Math.hypot(x-CAVE_ENTRANCE.x,z-CAVE_ENTRANCE.z)<24)continue;
    if(Math.hypot(heightAt(x+1,z)-heightAt(x-1,z),heightAt(x,z+1)-heightAt(x,z-1))/2>.85||treeLocations.some(p=>Math.hypot(p.x-x,p.z-z)<8))continue;
    treeLocations.push({id:`pine-outer-${String(outerTrees++).padStart(4,'0')}`,x,z,h,scale:.6+outerRng()*.8,angle:outerRng()*Math.PI*2,tint:.81+outerRng()*.24});
  }
  for(const tree of treeLocations){tree.radius=.35*tree.scale;tree.h=embeddedTreeHeight(tree.x,tree.z,.48*tree.scale);tree.y=tree.h;tree.kind='pine';tree.felled=false;}
  const dummy = new THREE.Object3D();
  const pineCells=new Map();for(const tree of treeLocations){const key=`${Math.floor(tree.x/160)},${Math.floor(tree.z/160)}`;if(!pineCells.has(key))pineCells.set(key,[]);pineCells.get(key).push(tree);}
  const trunkDepth = own(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking}));
  applyPineWind(trunkDepth, windClock);
  const canopyDepth = own(new THREE.MeshDepthMaterial({ alphaMap:foliage.pine.alphaMap, alphaTest:.12, depthPacking:THREE.RGBADepthPacking, side:THREE.DoubleSide }));
  applyPineWind(canopyDepth, windClock, true);
  clipPineShoot(canopyDepth);
  for(const [key,points]of pineCells){
    const trunks=own(add(new THREE.InstancedMesh(trunkGeometry,trunkMaterial,points.length))),crowns=own(add(new THREE.InstancedMesh(foliageGeometry,foliageMaterial,points.length)));
    trunks.name=`Pine wood ${key}`;crowns.name=`Pine canopy ${key}`;trunks.customDepthMaterial=trunkDepth;crowns.customDepthMaterial=canopyDepth;
    for(const mesh of [trunks,crowns]){mesh.castShadow=true;mesh.receiveShadow=true;treeBatches.push(mesh);}
    points.forEach((tree,i)=>{dummy.position.set(tree.x,tree.h-.06,tree.z);dummy.rotation.set(0,tree.angle,(hash(tree.x,tree.z)-.5)*.035);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();for(const mesh of [trunks,crowns]){mesh.setMatrixAt(i,dummy.matrix);treeRegistry.register(tree.id,mesh,i,dummy.matrix);}color.setRGB(tree.tint,tree.tint*.99,tree.tint*.92);crowns.setColorAt(i,color);colliders.push({x:tree.x,z:tree.z,radius:tree.radius,height:16*tree.scale,treeId:tree.id});});
    trunks.computeBoundingSphere();crowns.computeBoundingSphere();
  }

  const distantFernMaps = {};
  for (const [key,value] of Object.entries(foliage.fern)) {
    const copy=own(value.clone());copy.flipY=true;copy.repeat.set(.278,.874);copy.offset.set(.005,.028);distantFernMaps[key]=copy;
  }
  const coverMaterial = own(new THREE.MeshStandardMaterial({ ...distantFernMaps, color:'#ffffff', alphaTest:.4, side:THREE.DoubleSide, roughness:1, normalScale:new THREE.Vector2(.55,.55), emissive:'#344325', emissiveIntensity:.04, alphaToCoverage:true }));
  addWind(coverMaterial, windClock, .12, 1.1);
  const brushLocations = [];
  for (let i = 0; i < 5200; i++) {
    const nearby = i < 3600, base = nearby ? (i % 4 === 0 ? landmarks[3] : i % 4 === 1 ? spawn : survivorBank) : { x: 0, z: 0 };
    const range = nearby ? 205 : 690, x = base.x + (rng() - .5) * range, z = base.z + (rng() - .5) * range;
    const h = heightAt(x, z);
    if (Math.abs(x) > 380 || Math.abs(z) > 380 || h < 2.6 || h > 65 || rng() < .14) continue;
    const scale = rng() > .87 ? .65 + rng() * .48 : .18 + rng() * .52;
    brushLocations.push({ x, z, h, scale, angle: rng() * Math.PI * 2 });
  }
  for(let i=0;i<2600;i++) {
    const z=-120+rng()*195,side=i%2?1:-1,x=riverX(z)+side*(17+rng()*55),h=heightAt(x,z);
    if(h<2.5)continue;
    brushLocations.push({x,z,h,scale:.4+rng()*.87,angle:rng()*Math.PI*2});
  }
  for(let i=brushLocations.length-1;i>=0;i--){const p=brushLocations[i],stormWeight=stormBlendAt(p.x,p.z);if(riverBankDistanceAt(p.x,p.z)<.6||glowBlendAt(p.x,p.z)>.3||stormWeight>.55||stormWeight>.1&&hash(p.x+43,p.z-16)<stormWeight)brushLocations.splice(i,1);}
  const detailedBrush = [...brushLocations].sort((a,b)=>Math.hypot(a.x-survivorBank.x,a.z-survivorBank.z)-Math.hypot(b.x-survivorBank.x,b.z-survivorBank.z)).slice(0,300);
  const detailedSet = new Set(detailedBrush), distantBrush=brushLocations.filter(p=>!detailedSet.has(p));
  const cover = add(new THREE.InstancedMesh(own(coverGeometry()), coverMaterial, distantBrush.length));
  distantBrush.forEach((p, i) => {
    dummy.position.set(p.x, p.h - .03, p.z); dummy.rotation.set(0, p.angle, 0); dummy.scale.set(p.scale * (1 + rng() * .6), p.scale, p.scale); dummy.updateMatrix(); cover.setMatrixAt(i, dummy.matrix);
    color.setRGB(.73 + rng() * .27, .81 + rng() * .22, .67 + rng() * .23); cover.setColorAt(i, color);
  });
  cover.receiveShadow = true;
  const realFernMaterial = own(new THREE.MeshStandardMaterial({...foliage.fern,color:'#ffffff',side:THREE.DoubleSide,alphaTest:.4,normalScale:new THREE.Vector2(.7,.7),roughness:1,emissive:'#263d18',emissiveIntensity:.035,alphaToCoverage:true}));
  addWind(realFernMaterial,windClock,.055,.3);
  for(let variant=0;variant<2;variant++) {
    const points=detailedBrush.filter((p,i)=>i%2===variant),geometry=own(foliage.fernGeometries[variant]);
    const ferns=add(new THREE.InstancedMesh(geometry,realFernMaterial,points.length));
    points.forEach((p,i)=>{
      dummy.position.set(p.x,p.h+.015,p.z);dummy.rotation.set(0,p.angle,0);dummy.scale.setScalar(1.3+p.scale*1.6);dummy.updateMatrix();ferns.setMatrixAt(i,dummy.matrix);
      const tint=.9+rng()*.15;ferns.setColorAt(i,new THREE.Color(tint,tint,tint*.97));
    });ferns.receiveShadow=true;
  }
  const grassMaterial=own(new THREE.MeshStandardMaterial({...foliage.grass,color:'#ecf0d9',alphaTest:.10,side:THREE.DoubleSide,roughness:1,normalScale:new THREE.Vector2(.4,.4),emissive:'#526035',emissiveIntensity:.14,alphaToCoverage:true}));
  addWind(grassMaterial,windClock,.009,.08);
  const grassPoints=[];
  for(let i=0;i<18500;i++) {
    const z=-118+rng()*186,side=i%2?1:-1,x=riverX(z)+side*(15.5+Math.pow(rng(),1.35)*63),h=heightAt(x,z);
    if(h<2.3)continue;
    grassPoints.push({x,z,h,scale:2.7+rng()*4.6,angle:rng()*Math.PI*2});
  }
  for(let i=grassPoints.length-1;i>=0;i--){const p=grassPoints[i],stormWeight=stormBlendAt(p.x,p.z);if(riverBankDistanceAt(p.x,p.z)<.3||glowBlendAt(p.x,p.z)>.3||stormWeight>.55||stormWeight>.1&&hash(p.x+12,p.z-31)<stormWeight)grassPoints.splice(i,1);}
  for(let variant=0;variant<2;variant++) {
    const points=grassPoints.filter((p,i)=>i%2===variant),geometry=own(foliage.grassGeometries[variant]);
    const grasses=add(new THREE.InstancedMesh(geometry,grassMaterial,points.length));
    points.forEach((p,i)=>{
      dummy.position.set(p.x,p.h+.012,p.z);dummy.rotation.set(0,p.angle,0);dummy.scale.set(p.scale*1.55,p.scale*.86,p.scale*1.55);dummy.updateMatrix();grasses.setMatrixAt(i,dummy.matrix);
      const tint=.77+rng()*.26;grasses.setColorAt(i,new THREE.Color(tint,tint,.78*tint));
    });grasses.receiveShadow=true;
  }

  // Boulders have independent facet variation and buried bases, avoiding repeated spheres.
  const stoneMaterial = own(createWeatheredStoneMaterial(scans.rock));
  const boulderGeometry = own(new THREE.IcosahedronGeometry(1, 3)), bp = boulderGeometry.attributes.position;
  for (let i = 0; i < bp.count; i++) { const x = bp.getX(i), y = bp.getY(i), z = bp.getZ(i), r = .78 + noise(x * 8 + z * 3, y * 9) * .42; bp.setXYZ(i, x * r, y * r, z * r); } boulderGeometry.computeVertexNormals();
  const boulderLocations = [];
  for (let i = 0; i < 280; i++) {
    const riverStone = i < 130, z = (rng() - .5) * 730, x = riverStone ? riverX(z) + (rng() > .5 ? 1 : -1) * (13 + rng() * 14) : (rng() - .5) * 730;
    if (riverBankDistanceAt(x,z)<1.4 || glowBlendAt(x,z)>.3 || stormBlendAt(x,z)>.55 || Math.hypot(x - survivorBank.x, z - survivorBank.z) < 8 || landmarks.some(l => Math.hypot(x - l.x, z - l.z) < 10)) continue;
    boulderLocations.push({ x, z, h: heightAt(x, z), scale: riverStone ? .4 + rng() * 1.5 : 1 + rng() * 3 });
  }
  const boulders = add(new THREE.InstancedMesh(boulderGeometry, stoneMaterial, boulderLocations.length));
  boulderLocations.forEach((p, i) => {
    dummy.position.set(p.x, p.h + p.scale * .22, p.z); dummy.rotation.set(rng() * .35, rng() * 6.28, rng() * .3); dummy.scale.set(p.scale * 1.1, p.scale * .75, p.scale * (.8 + rng() * .5)); dummy.updateMatrix(); boulders.setMatrixAt(i, dummy.matrix);
    color.setRGB(.82 + rng() * .25, .84 + rng() * .25, .78 + rng() * .23); boulders.setColorAt(i, color);
    colliders.push({ x: p.x, z: p.z, radius: p.scale * .88, height:2*p.scale });
  });
  boulders.castShadow = true; boulders.receiveShadow = true;

  const pebbleGeometry = own(new THREE.IcosahedronGeometry(1, 0));
  const pebblePoints = [], leafPoints = [];
  for (let i = 0; i < 4300; i++) {
    const base = i % 5 < 3 ? survivorBank : i % 5 === 3 ? spawn : landmarks[3];
    const spread = i < 1700 ? 64 : 188, x = base.x + (rng() - .5) * spread, z = base.z + (rng() - .5) * spread, h = heightAt(x, z);
    if (h < 2.15 || h > 72) continue;
    const point = { x, z, h, size: .035 + rng() * .14, angle: rng() * Math.PI * 2 };
    (i % 3 === 0 ? pebblePoints : leafPoints).push(point);
  }
  const pebbles = add(new THREE.InstancedMesh(pebbleGeometry, stoneMaterial, pebblePoints.length));
  pebblePoints.forEach((p, i) => {
    dummy.position.set(p.x, p.h + p.size * .11, p.z); dummy.rotation.set(rng() * 1.5, p.angle, rng()); dummy.scale.set(p.size * 1.3, p.size * .49, p.size); dummy.updateMatrix(); pebbles.setMatrixAt(i, dummy.matrix);
    const tint = .7 + rng() * .37; pebbles.setColorAt(i, new THREE.Color(tint, tint * .98, tint * .87));
  }); pebbles.receiveShadow = true;
  const leafGeometry = own(new THREE.BufferGeometry());
  leafGeometry.setAttribute('position', new THREE.Float32BufferAttribute([-.22,0,-.8, -.48,.025,-.05, -.14,0,.62, .4,0,.16, .16,.02,-.55, 0,.08,0], 3));
  leafGeometry.setIndex([0,1,5,1,2,5,2,3,5,3,4,5,4,0,5]); leafGeometry.computeVertexNormals();
  const litterMaterial = own(new THREE.MeshStandardMaterial({ color: '#c0af7b', roughness: 1, side: THREE.DoubleSide }));
  const leafLitter = add(new THREE.InstancedMesh(leafGeometry, litterMaterial, leafPoints.length));
  leafPoints.forEach((p, i) => {
    dummy.position.set(p.x, p.h + .018, p.z); dummy.rotation.set(0, p.angle, 0); dummy.scale.setScalar(.1 + p.size); dummy.updateMatrix(); leafLitter.setMatrixAt(i, dummy.matrix);
    color.set(['#655d3d', '#998659', '#72754b', '#9a714f'][i % 4]); leafLitter.setColorAt(i, color);
  }); leafLitter.receiveShadow = true;

  const river = own(createRiverSurface({heightAt, riverX, waterLevel: WATER_LEVEL, WORLD_SIZE, time: windClock}));
  add(river.mesh);
  const forestDetails = own(createForestDetails({group, heightAt, riverX, waterLevel: WATER_LEVEL, foliage, rockMaps: scans.rock}));
  const expanded=own(createExpandedBiomes({group,heightAt,rockMaps:scans.rock,foliage,waterLevel:WATER_LEVEL}));
  colliders.push(...expanded.colliders);

  // Naturally broken deadwood: curved trunks and uneven, splintered ends.
  const fallenLogGeometry = own(new THREE.CylinderGeometry(.29, .38, 7, 11, 6));
  const logVertices=fallenLogGeometry.attributes.position;
  for(let i=0;i<logVertices.count;i++) {
    const x=logVertices.getX(i),y=logVertices.getY(i),z=logVertices.getZ(i),angle=Math.atan2(z,x),radius=Math.hypot(x,z);
    const brokenEnd=Math.abs(y)>3.4?Math.sign(y)*(Math.sin(angle*3.0)*.19+Math.sin(angle*7.0+.6)*.10)*Math.min(1,radius/.27):0;
    logVertices.setXYZ(i,x+Math.sin(y*.72)*.10,y+brokenEnd,z+Math.sin(y*.47+1)*.07);
  }
  fallenLogGeometry.computeVertexNormals();
  const fallenLogMaterial = own(new THREE.MeshStandardMaterial({...foliage.bark,color:'#e6dece',normalScale:new THREE.Vector2(.85,.85),roughness:1}));
  for (const [x, z, rotation] of [[-83, 92, .7], [111, -66, 2.2], [-160, -160, .4]]) {
    const log = new THREE.Mesh(fallenLogGeometry, fallenLogMaterial); log.position.set(x, heightAt(x, z) + .34, z); log.rotation.set(Math.PI / 2, 0, rotation); log.castShadow = true; log.receiveShadow = true; group.add(log);
    for (let i = -3; i <= 3; i++) colliders.push({ x: x - Math.sin(rotation) * i, z: z + Math.cos(rotation) * i, radius: .52, height:1.2 });
  }

  const gatherTrees=[...treeLocations,...rainforest.trees,...storm.trees,...expanded.trees,...glow.trees];
  // Fix all 50 ambush sites against the untouched landscape before a saved camp
  // can fell trees or append player-built colliders to this mutable array.
  const burrowDens=createBurrowpeedDens({heightAt,biomeAt,colliders});
  const encounterTrees=[...rainforest.trees],soundTrees=[...treeLocations.map(tree=>({...tree,height:16*tree.scale})),...rainforest.trees,...storm.trees,...expanded.trees,...glow.trees];
  const canopyTrees=()=>gatherTrees.filter(t=>!t.felled).map(t=>({...t,scale:t.kind==='rainforest'?3.3:t.kind==='glow'?2.7:t.kind==='storm'?.8:t.scale||1.4}));
  canopyUniform.value=createCanopyMask(canopyTrees(),WORLD_SIZE);
  const treeColliders=new Map();for(const collider of colliders)if(collider.treeId){if(!treeColliders.has(collider.treeId))treeColliders.set(collider.treeId,[]);treeColliders.get(collider.treeId).push(collider);}
  const bushZones=brushLocations.filter((p,i)=>p.scale>.5&&i%9===0).map((p,i)=>({id:`brush-${String(i).padStart(4,'0')}`,x:p.x,z:p.z,y:p.h,radius:1.2+p.scale*.8}));
  let canopyDirty=false;
  function setTreeFelled(id,value=true){
    const tree=gatherTrees.find(p=>p.id===id);if(!tree||tree.felled===!!value)return false;
    const changed=treeRegistry.setTreeFelled(id,value)||rainforest.setTreeFelled(id,value)||storm.setTreeFelled(id,value)||expanded.setTreeFelled(id,value)||glow.setTreeFelled(id,value);if(!changed)return false;
    tree.felled=!!value;for(const p of soundTrees)if(p.id===id)p.felled=!!value;
    if(value){for(let i=colliders.length-1;i>=0;i--)if(colliders[i].treeId===id)colliders.splice(i,1);const index=encounterTrees.findIndex(p=>p.id===id);if(index>=0)encounterTrees.splice(index,1);}
    else{colliders.push(...(treeColliders.get(id)||[]));if(tree.kind==='rainforest'&&!encounterTrees.some(p=>p.id===id))encounterTrees.push(tree);}
    canopyDirty=true;return true;
  }
  return {
    colliders,
    encounterTrees,
    valleyTrees:treeLocations,
    soundTrees,gatherTrees,bushZones,burrowDens,resourceNodes:expanded.resourceNodes,setTreeFelled,hazardAt,glowDiagnostics:glow.diagnostics,
    groundHeight:heightAt,
    update(time, dt, cameraPosition) {
      windClock.value=time;forestDetails.update(time,cameraPosition);rainforest.update(time,cameraPosition);storm.update(time,cameraPosition);expanded.update(time,cameraPosition);glow.update(time,cameraPosition);
      for(const mesh of treeBatches){const center=mesh.boundingSphere?.center;mesh.visible=!cameraPosition||!center||Math.hypot(cameraPosition.x-center.x,cameraPosition.z-center.z)<620+mesh.boundingSphere.radius;}
      for(const mesh of terrainChunks){const center=mesh.geometry.boundingSphere.center;mesh.visible=!cameraPosition||Math.hypot(cameraPosition.x-center.x,cameraPosition.z-center.z)<1050;}
      if(canopyDirty){const previous=canopyUniform.value;canopyUniform.value=createCanopyMask(canopyTrees(),WORLD_SIZE);previous?.dispose();canopyDirty=false;}
    },
    dispose() { scene.remove(group); for (const value of disposables) value.dispose(); },
  };
}
