import * as THREE from './vendor/three.module.js';
import {GLOW_CENTER,glowBlendAt} from './biomes.js';
import {embeddedTreeHeight} from './terrain-surface.js';
import {riverBankDistanceAt} from './river-network.js';
import {giantGeometry,wind} from './rainforest.js';
import {createTreeInstanceRegistry} from './tree-instances.js';
import {createForestFlowers} from './woodland-flowers.js';

// Fungal filaments live in the bark and leaf veins, retaining photographed
// surface detail instead of replacing whole trees with uniform neon colors.
function livingLight(material,clock,{leaf=false}={}){
  const before=material.onBeforeCompile,oldKey=material.customProgramCacheKey();
  material.onBeforeCompile=s=>{before(s);s.uniforms.glowTime=clock;
    s.vertexShader='varying vec3 vGlowPoint;\n'+s.vertexShader;
    s.vertexShader=s.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvGlowPoint=position;');
    s.fragmentShader='varying vec3 vGlowPoint;uniform float glowTime;\n'+s.fragmentShader;
    s.fragmentShader=s.fragmentShader.replace('#include <emissivemap_fragment>',`#include <emissivemap_fragment>
      float thread=abs(sin(vGlowPoint.x*12.0+sin(vGlowPoint.y*2.3+vGlowPoint.z*4.0)*1.3));
      float lace=pow(max(0.0,1.0-thread),14.0);
      float breath=.90+.10*sin(glowTime*.45+vGlowPoint.y*.3);
      ${leaf?`float vein=pow(max(0.0,1.0-abs(vLeafUv.x-.5)*35.0),3.0);
      totalEmissiveRadiance*= (.07+vein*.45+lace*.33)*breath;`:`totalEmissiveRadiance*=(.028+lace*.54)*breath;`}
    `);};material.customProgramCacheKey=()=>oldKey+`-living-light-${leaf}`;
}

export function createGlowBiome({group,heightAt,foliage,rockMaps}){
  const root=new THREE.Group();root.name='Glowhaven — luminous sanctuary';group.add(root);
  const owned=[],own=x=>(owned.push(x),x),clock={value:0},registry=createTreeInstanceRegistry(),trees=[],colliders=[],dummy=new THREE.Object3D(),meshes=[];
  let seed=822319;const rng=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  const slope=(x,z)=>Math.hypot(heightAt(x+1,z)-heightAt(x-1,z),heightAt(x,z+1)-heightAt(x,z-1))/2;
  for(let attempt=0;attempt<9000&&trees.length<128;attempt++){
    const x=GLOW_CENTER.x+(rng()*2-1)*175,z=GLOW_CENTER.z+(rng()*2-1)*160,radius=.8+rng()*.55;
    if(glowBlendAt(x,z)<.48||heightAt(x,z)<4||slope(x,z)>.8||riverBankDistanceAt(x,z)<radius*2.8||Math.hypot(x-GLOW_CENTER.x,z-GLOW_CENTER.z)<9||trees.some(t=>Math.hypot(x-t.x,z-t.z)<14))continue;
    const h=embeddedTreeHeight(x,z,radius*2.6);const tree={id:`glow-tree-${String(trees.length).padStart(3,'0')}`,kind:'glow',x,z,h,y:h,radius,height:23+rng()*13,angle:rng()*Math.PI*2,felled:false};
    trees.push(tree);colliders.push({x,z,radius,height:tree.height,treeId:tree.id});
  }
  const bark=own(new THREE.MeshStandardMaterial({...foliage.bark,color:'#81988e',normalScale:new THREE.Vector2(.95,.95),roughness:.9,vertexColors:true,emissive:'#63ffd6',emissiveIntensity:1.0}));wind(bark,clock);livingLight(bark,clock);
  const leaf=own(new THREE.MeshStandardMaterial({map:foliage.broadleaf,bumpMap:foliage.broadleaf,bumpScale:.009,color:'#adcebe',vertexColors:true,alphaTest:.38,side:THREE.DoubleSide,roughness:.7,emissive:'#6ee5cf',emissiveIntensity:.95}));wind(leaf,clock,{leaves:true});livingLight(leaf,clock,{leaf:true});
  const depth=own(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking}));wind(depth,clock);
  const leafDepth=own(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking,map:foliage.broadleaf,alphaTest:.38,side:THREE.DoubleSide}));wind(leafDepth,clock);
  function instances(g,m,points,transform,{tree=false,cast=false}={}){
    const mesh=own(new THREE.InstancedMesh(g,m,points.length));points.forEach((p,i)=>{transform(p,dummy);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);if(tree)registry.register(p.id,mesh,i,dummy.matrix);});mesh.computeBoundingSphere();mesh.castShadow=cast;mesh.receiveShadow=true;root.add(mesh);meshes.push(mesh);return mesh;
  }
  const treeTransform=(p,d)=>{d.position.set(p.x,p.h-.06,p.z);d.rotation.set(0,p.angle,0);d.scale.set(p.radius,p.height/42,p.radius);};
  for(let v=0;v<2;v++){
    const g=giantGeometry(v,{leafCount:384,vineCount:6}),points=trees.filter((_,i)=>i%2===v);
    for(const [geometry,material,depthMaterial]of[[g.wood,bark,depth],[g.leaves,leaf,leafDepth],[g.vines.wood,bark,depth],[g.vines.leaves,leaf,leafDepth]]){
      instances(own(geometry),material,points,treeTransform,{tree:true,cast:true}).customDepthMaterial=depthMaterial;
    }
  }
  const floorPoints=[],mushrooms=[],stones=[];
  for(let i=0;i<4800;i++){
    const x=GLOW_CENTER.x+(rng()*2-1)*175,z=GLOW_CENTER.z+(rng()*2-1)*160,h=heightAt(x,z);
    if(glowBlendAt(x,z)<.5||h<3||riverBankDistanceAt(x,z)<1||slope(x,z)>.9||trees.some(t=>Math.hypot(x-t.x,z-t.z)<t.radius*1.3))continue;
    const p={x,z,h,angle:rng()*Math.PI*2,scale:.45+rng()*.85};
    if(i%9===0)stones.push(p);else if(i%3===0)mushrooms.push(p);else {p.scale*=1.45;floorPoints.push(p);}
  }
  const fern=own(new THREE.MeshStandardMaterial({...foliage.fern,color:'#91c4af',alphaTest:.12,side:THREE.DoubleSide,roughness:.88,emissive:'#43aa84',emissiveIntensity:.18}));
  const floorTransform=(p,d)=>{d.position.set(p.x,p.h,p.z);d.rotation.set(0,p.angle,0);d.scale.setScalar(p.scale);};
  for(let i=0;i<2;i++)instances(foliage.fernGeometries[i],fern,floorPoints.filter((_,n)=>n%2===i),floorTransform);
  const stone=own(new THREE.MeshStandardMaterial({...rockMaps,color:'#6b8c89',roughness:.85,emissive:'#2ea085',emissiveIntensity:.10}));
  instances(own(new THREE.IcosahedronGeometry(1,2)),stone,stones,(p,d)=>{floorTransform(p,d);d.position.y+=p.scale*.06;d.scale.set(p.scale,p.scale*.23,p.scale*.8);},{cast:true});
  const cap=own(new THREE.LatheGeometry([new THREE.Vector2(0,.26),new THREE.Vector2(.12,.26),new THREE.Vector2(.28,.27),new THREE.Vector2(.25,.34),new THREE.Vector2(.16,.41),new THREE.Vector2(.05,.445),new THREE.Vector2(0,.44)],12));
  const stem=own(new THREE.CylinderGeometry(.018,.027,.30,6));stem.translate(0,.15,0);
  const stemMat=own(new THREE.MeshStandardMaterial({color:'#adcfc8',roughness:.76,emissive:'#47babb',emissiveIntensity:.17}));
  const capMat=own(new THREE.MeshStandardMaterial({color:'#619db0',roughness:.52,emissive:'#68edf5',emissiveIntensity:1.15,side:THREE.DoubleSide}));
  instances(stem,stemMat,mushrooms,floorTransform);instances(cap,capMat,mushrooms,floorTransform);
  const flowers=own(createForestFlowers({root,heightAt,blendAt:glowBlendAt,center:GLOW_CENTER,spread:{x:175,z:160},count:850,seed:5712,glowing:true}));
  // Soft particles provide a small halo without filling the refuge with lights.
  const moteGeometry=own(new THREE.BufferGeometry()),motePositions=[];
  for(let i=0;i<520;i++){const p=mushrooms[i%mushrooms.length];if(p)motePositions.push(p.x,p.h+.6+rng()*5.3,p.z);}
  moteGeometry.setAttribute('position',new THREE.Float32BufferAttribute(motePositions,3));
  const moteMaterial=own(new THREE.ShaderMaterial({uniforms:{time:clock},transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
    vertexShader:`uniform float time;varying float sparkle;void main(){vec3 p=position;p.x+=sin(time*.25+position.z)*.65;p.y+=sin(time*.36+position.x)*.3;sparkle=.5+.5*sin(time*.6+position.x*2.0);vec4 mv=modelViewMatrix*vec4(p,1.0);gl_Position=projectionMatrix*mv;gl_PointSize=clamp(65.0/max(1.0,-mv.z),1.5,9.0);}`,
    fragmentShader:`varying float sparkle;void main(){float r=length(gl_PointCoord-.5)*2.0;float a=pow(max(0.0,1.0-r),2.0)*(.3+sparkle*.6);gl_FragColor=vec4(.35,.94,.82,a);}`}));
  root.add(new THREE.Points(moteGeometry,moteMaterial));
  return{trees,colliders,diagnostics:{trees:trees.length,mushrooms:mushrooms.length,ferns:floorPoints.length,flowers:flowers.points.length,motes:motePositions.length/3},
    setTreeFelled(id,value){const changed=registry.setTreeFelled(id,value);if(changed)trees.find(t=>t.id===id).felled=!!value;return changed;},
    update(t,camera){clock.value=t;flowers.update(t,camera);root.visible=!camera||Math.hypot(camera.x-GLOW_CENTER.x,camera.z-GLOW_CENTER.z)<760;},
    dispose(){group.remove(root);for(const resource of owned)resource.dispose();}};
}
