import * as THREE from './vendor/three.module.js';

/**
 * Clear, cold water for a river strip, optionally carrying actual terrain depth.
 * UV.x runs from bank to bank; position.xz is measured in world metres.
 * Passing the shared windClock as `time` requires no separate update loop.
 */
export function createRiverMaterial({
  time = {value: 0},
  deepColor = '#20342d',
  shallowColor = '#626047',
  depthAttribute = false,
  deltaFade = false
} = {}) {
  const material = new THREE.MeshPhysicalMaterial({
    color: '#ffffff',
    metalness: 0,
    roughness: .19,
    ior: 1.333,
    specularIntensity: 1,
    specularColor: '#ffffff',
    envMapIntensity: 1,
    transparent: true,
    opacity: 1,
    depthWrite: false,
    side: THREE.DoubleSide,
    forceSinglePass: true,
    dithering: true
  });
  material.name = 'Cold alpine river';
  if (depthAttribute) material.defines = {...material.defines, RIVER_HAS_DEPTH: 1};
  if (deltaFade) material.defines = {...material.defines, RIVER_OCEAN_DELTA: 1};
  // This also offers a small animation API when a shared clock is unavailable.
  material.userData.flowTime = time;
  material.userData.setTime = seconds => { if (Number.isFinite(seconds)) time.value = seconds; };
  material.customProgramCacheKey = () => `connected-river-v3-depth-${depthAttribute ? 1 : 0}-delta-${deltaFade ? 1 : 0}`;
  material.onBeforeCompile = shader => {
    shader.uniforms.uRiverTime = time;
    shader.uniforms.uRiverDeep = {value: new THREE.Color(deepColor)};
    shader.uniforms.uRiverShallow = {value: new THREE.Color(shallowColor)};
    shader.vertexShader = `
      varying vec2 vRiverBankUv;
      varying vec3 vRiverWorld;
      #ifdef RIVER_HAS_DEPTH
        attribute float waterDepth;
        attribute vec2 riverCurrent;
        varying float vRiverWaterDepth;
        varying vec2 vRiverCurrent;
      #endif
    ` + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `
      #include <begin_vertex>
      vRiverBankUv = uv;
      vRiverWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;
      #ifdef RIVER_HAS_DEPTH
        vRiverWaterDepth = waterDepth;
        vRiverCurrent = riverCurrent;
      #endif
    `);
    shader.fragmentShader = `
      uniform float uRiverTime;
      uniform vec3 uRiverDeep;
      uniform vec3 uRiverShallow;
      varying vec2 vRiverBankUv;
      varying vec3 vRiverWorld;
      #ifdef RIVER_HAS_DEPTH
        varying float vRiverWaterDepth;
        varying vec2 vRiverCurrent;
      #endif

      float riverHash(vec2 p) {
        vec3 p3 = fract(vec3(p.xyx) * .1031);
        p3 += dot(p3, p3.yzx + 33.33);
        return fract((p3.x + p3.y) * p3.z);
      }
      // Value noise and its analytic derivatives: no normal textures or extra renders.
      vec3 riverNoise(vec2 p) {
        vec2 cell = floor(p), f = fract(p);
        vec2 u = f * f * (3.0 - 2.0 * f);
        vec2 du = 6.0 * f * (1.0 - f);
        float a = riverHash(cell);
        float b = riverHash(cell + vec2(1.0, 0.0));
        float c = riverHash(cell + vec2(0.0, 1.0));
        float d = riverHash(cell + vec2(1.0, 1.0));
        float across = a - b - c + d;
        float value = a + (b - a) * u.x + (c - a) * u.y + across * u.x * u.y;
        vec2 derivative = vec2(b - a + across * u.y, c - a + across * u.x) * du;
        return vec3(value, derivative);
      }
    ` + shader.fragmentShader;
    shader.fragmentShader = shader.fragmentShader.replace('#include <color_fragment>', `
      #include <color_fragment>
      vec2 riverWorldPoint = vRiverWorld.xz;
      // Follow the meandering channel without accumulating distortion over long sessions.
      vec2 riverPoint = vec2((vRiverBankUv.x - .5) * 26.8, vRiverWorld.z);
      float riverTime = uRiverTime;
      float bankDistance = clamp(1.0 - abs(vRiverBankUv.x * 2.0 - 1.0), 0.0, 1.0);
      float riverMetres = 1.62 * smoothstep(.025, .61, bankDistance);
      vec2 riverCurrentDirection = vec2(0.0, -1.0);
      #ifdef RIVER_HAS_DEPTH
        riverMetres = max(0.0, vRiverWaterDepth);
        riverCurrentDirection = normalize(vRiverCurrent);
        riverPoint.y = -dot(vRiverWorld.xz, riverCurrentDirection);
      #endif
      float riverDepth = smoothstep(.10, 1.72, riverMetres);
      float riverMacro = riverNoise(riverWorldPoint * .085 + vec2(0.0, riverTime * .035)).x;

      // A slow curl field makes little eddies in shallow water instead of drawn foam rings.
      vec3 riverCurl = riverNoise(riverPoint * vec2(.28, .19) + vec2(29.4, 13.7));
      float riverEddyPhase = sin(riverTime * .37 + riverMacro * 8.4) * .65 + sin(riverTime * .23 + riverCurl.x * 11.0) * .35;
      vec2 riverEddy = vec2(riverCurl.z, -riverCurl.y) * riverEddyPhase * (.62 - .42 * riverDepth);
      riverPoint += riverEddy;

      // Independent scales and directions break up regular cross-river banding.
      vec3 riverA = riverNoise(vec2(riverPoint.x * .72, riverPoint.y * 1.65 + riverTime * 1.17));
      vec3 riverB = riverNoise(vec2(riverPoint.x * 2.55 + riverPoint.y * .62 + 17.3,
                                    riverPoint.y * 2.70 - riverPoint.x * .63 + riverTime * 2.1));
      vec3 riverC = riverNoise(vec2(riverPoint.x * 6.3 - riverPoint.y * 1.4 + 51.1,
                                    riverPoint.y * 7.7 + riverPoint.x * 1.8 + riverTime * 4.3));
      vec2 riverSlope = riverA.yz * vec2(.72, 1.65) * .032;
      riverSlope += vec2(2.55 * riverB.y - .63 * riverB.z, .62 * riverB.y + 2.70 * riverB.z) * .011;
      riverSlope += vec2(6.3 * riverC.y + 1.8 * riverC.z, -1.4 * riverC.y + 7.7 * riverC.z) * .0026;
      riverSlope *= .57 + .50 * riverMacro;
      // Screen-space attenuation stops tiny distant ripples from sparkling or aliasing.
      float riverPixelSize = max(length(dFdx(riverWorldPoint)), length(dFdy(riverWorldPoint)));
      riverSlope *= 1.0 - .68 * smoothstep(.15, 1.0, riverPixelSize);
      vec2 riverAcrossDirection = vec2(-riverCurrentDirection.y, riverCurrentDirection.x);
      riverSlope = riverAcrossDirection * riverSlope.x - riverCurrentDirection * riverSlope.y;
      vec3 riverTint = mix(uRiverShallow, uRiverDeep, riverDepth);
      diffuseColor.rgb *= riverTint * (.94 + .11 * riverMacro);

      // Shallows reveal the existing riverbed. At grazing angles reflection dominates.
      vec3 riverSurface = normalize(vec3(-riverSlope.x, 1.0, -riverSlope.y));
      vec3 riverView = normalize(cameraPosition - vRiverWorld);
      float riverFresnel = pow(1.0 - clamp(abs(dot(riverSurface, riverView)), 0.0, 1.0), 5.0);
      float riverAbsorption = mix(.17, .91, riverDepth);
      float shoreCoverage = smoothstep(0.0, .09, riverMetres);
      // Soften the surface strip's very outside edge while preserving its existing footprint.
      shoreCoverage *= smoothstep(0.0, .025, bankDistance);
      diffuseColor.a *= mix(riverAbsorption, .98, riverFresnel) * shoreCoverage;
      #ifdef RIVER_OCEAN_DELTA
        diffuseColor.a *= 1.0 - smoothstep(480.0, 529.0, vRiverWorld.z);
      #endif
    `);
    shader.fragmentShader = shader.fragmentShader.replace('#include <roughnessmap_fragment>', `
      #include <roughnessmap_fragment>
      roughnessFactor = clamp(roughnessFactor + (riverMacro - .5) * .065 + (1.0 - riverDepth) * .035, .13, .29);
    `);
    shader.fragmentShader = shader.fragmentShader.replace('#include <normal_fragment_maps>', `
      #include <normal_fragment_maps>
      // PBR sunlight and the scene's HDR sky produce highlights from the moving surface.
      // No white foam streaks or painted specular highlights are added to the water colour.
      vec3 riverViewSlope = mat3(viewMatrix) * vec3(-riverSlope.x, 0.0, -riverSlope.y);
      normal = normalize(normal + riverViewSlope * faceDirection);
    `);
  };
  return material;
}
