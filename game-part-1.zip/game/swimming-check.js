import {SWIM_DEPTH,SWIM_SPEED,FAST_SWIM_SPEED,getWaterState,canTraverseGround,stepPlayerVertical,getPlayerLocomotion} from './player-motion.js';
import {createJourneyStore,SAVE_KEY} from './journey-store.js';
import {createTeethpeedEncounters} from './teethpeed-encounters.js';

const assert=(condition,message)=>{if(!condition)throw new Error(message);};
const near=(a,b,tolerance=1e-7)=>Math.abs(a-b)<=tolerance;
const WATER=2,FLOAT=.75;
function memoryStorage() {const values=new Map();return {getItem:key=>values.has(key)?values.get(key):null,setItem:(key,value)=>values.set(key,String(value)),removeItem:key=>values.delete(key)};}
function life(motion={footY:FLOAT,verticalSpeed:0,grounded:false}) {return {player:{x:0,z:0,yaw:.2,pitch:-.1},health:78,survivedSeconds:85,discovered:[],waypoint:null,motion};}
function vertical(state,floor,dt=.05,waterLevel=WATER) {return stepPlayerVertical({...state,floor,dt,waterLevel});}
function fallTo(floor,initial={footY:20,verticalSpeed:0,grounded:false}) {
  let state=initial,peakImpact=0,entries=0;
  for(let i=0;i<300;i++) {
    state=vertical(state,floor);peakImpact=Math.max(peakImpact,state.impactSpeed||0);entries+=state.enteredWater?1:0;
    assert([state.footY,state.verticalSpeed,state.impactSpeed].every(Number.isFinite),'Fall integration produced a non-finite value.');
    if(state.swimming||state.grounded)return {state,peakImpact,entries};
  }
  throw new Error('The falling player never reached support.');
}
function creatureFixture() {
  const heightAt=x=>x>2?-3:2.4,damage=[],config={trees:[{id:'riverbank-tree',x:-8,z:0,h:2.4,height:32,radius:1.2}],heightAt,colliders:[],forestBlendAt:()=>1,seed:'swimming-ground-only',onDamage:(amount,cause)=>damage.push({amount,cause})};
  const ai=createTeethpeedEncounters(config);assert(ai.forceEncounter('riverbank-tree'),'The riverbank fixture could not start.');
  let remaining=ai.getActive()[0].descent.total;
  while(remaining>1e-8){const dt=Math.min(.05,remaining);ai.update(dt,{x:-3,y:2.4,z:0});remaining-=dt;}
  assert(ai.getActive()[0].stage==='attacking','The riverbank creature did not acquire its visible player.');
  return {ai,config,damage,heightAt};
}

export const swimmingChecks=[
  ['Water changes from wading to swimming at the 1.25m depth boundary',()=>{
    assert(SWIM_DEPTH===1.25,'The intended swimming depth changed.');
    const shallow=getWaterState({floor:.7501,footY:.7501,waterLevel:WATER}),boundary=getWaterState({floor:.75,footY:.75,waterLevel:WATER}),deep=getWaterState({floor:.7499,footY:.75,waterLevel:WATER});
    assert(shallow.wading&&!shallow.swimming,'Water just shallower than 1.25m was classified as swimming.');
    assert(boundary.swimming&&deep.swimming&&!boundary.wading,'The exact depth boundary did not begin swimming.');
    assert(near(boundary.depth,1.25),'Water depth was not measured from the riverbed.');
  }],
  ['Dry land and an airborne player above deep water are not swimming',()=>{
    const dry=getWaterState({floor:3,footY:3,waterLevel:WATER}),airborne=getWaterState({floor:-8,footY:12,waterLevel:WATER});
    assert(!dry.swimming&&!dry.wading&&dry.depth===0,'Dry terrain was classified as water.');
    assert(!airborne.swimming&&!airborne.wading,'A player in the air was already swimming.');
  }],
  ['Floating height stays tied to the water surface across different riverbed depths',()=>{
    for(const floor of [-1,-8,-50]){const water=getWaterState({floor,footY:FLOAT,waterLevel:WATER});assert(water.swimming&&near(water.supportY,FLOAT),'A deeper riverbed pulled floating support downward.');}
    const raised=getWaterState({floor:0,footY:3.75,waterLevel:5});assert(raised.swimming&&near(raised.supportY,3.75),'Floating support ignored a different water level.');
    assert(FLOAT+1.65>WATER,'The normal eye height would remain under the water surface.');
  }],
  ['Walking off a bank enters floating motion and releases ground support',()=>{
    const entered=fallTo(-5,{footY:2.4,verticalSpeed:0,grounded:true});
    assert(entered.state.swimming&&!entered.state.grounded&&near(entered.state.footY,FLOAT),'Stepping off the bank did not transition to floating.');
    assert(entered.state.verticalSpeed===0&&entered.peakImpact===0,'Water entry kept falling velocity or reported a ground impact.');
    assert(entered.entries===1,'Entering deep water did not report one water-entry transition.');
  }],
  ['Stable swimming never sinks, re-enters the water, or accumulates falling speed',()=>{
    let state={footY:FLOAT,verticalSpeed:0,grounded:false};
    for(let i=0;i<200;i++){state=vertical(state,-20);assert(state.swimming&&!state.grounded&&near(state.footY,FLOAT)&&state.verticalSpeed===0,'A resting swimmer sank or acquired ground support.');assert(!state.enteredWater&&state.impactSpeed===0,'Stable floating repeated entry or impact effects.');}
  }],
  ['A steep underwater riverbed does not block horizontal swimming',()=>{
    assert(canTraverseGround({floor:-45,fromFloor:-1,footY:FLOAT,fromX:0,fromZ:0,x:.13,z:0,waterLevel:WATER}),'A downward riverbed cliff blocked a surface swimmer.');
    assert(canTraverseGround({floor:-1,fromFloor:-45,footY:FLOAT,fromX:0,fromZ:0,x:.13,z:0,waterLevel:WATER}),'An underwater upslope blocked a surface swimmer.');
  }],
  ['Surface swimming cannot climb a steep dry bank',()=>{
    assert(!canTraverseGround({floor:3.2,fromFloor:-5,footY:FLOAT,fromX:0,fromZ:0,x:.13,z:0,waterLevel:WATER}),'Swimming bypassed the steep dry-bank slope limit.');
    assert(!canTraverseGround({floor:8,fromFloor:3,footY:3,fromX:0,fromZ:0,x:.20,z:0,waterLevel:WATER}),'The new water support weakened normal cliff collision.');
  }],
  ['A gentle shore allows swimming, then wading, then a grounded dry exit',()=>{
    let floor=.5,x=0,state={footY:FLOAT,verticalSpeed:0,grounded:false},sawWading=false;
    for(const nextFloor of [.9,1.1,1.3,1.5,1.7,1.9,2.1]) {
      const nextX=x+.30;assert(canTraverseGround({floor:nextFloor,fromFloor:floor,footY:state.footY,fromX:x,fromZ:0,x:nextX,z:0,waterLevel:WATER}),'A gentle natural bank was impassable.');
      state=vertical(state,nextFloor);sawWading ||= state.wading;floor=nextFloor;x=nextX;
    }
    assert(sawWading&&state.grounded&&!state.swimming&&!state.wading&&near(state.footY,2.1),'The swimmer could not transition back to dry walking.');
  }],
  ['A high fall into deep water stops at the surface without ground-impact damage',()=>{
    const result=fallTo(-12,{footY:35,verticalSpeed:-8,grounded:false});
    assert(result.state.swimming&&near(result.state.footY,FLOAT),'The high water landing fell through the surface.');
    assert(result.peakImpact===0&&result.entries===1,'Deep-water contact was treated as a hard ground landing.');
  }],
  ['Shallow water still reports a hard landing on its riverbed',()=>{
    const result=fallTo(1.55,{footY:35,verticalSpeed:-8,grounded:false});
    assert(result.state.grounded&&!result.state.swimming&&near(result.state.footY,1.55),'Shallow water incorrectly provided deep-water buoyancy.');
    assert(result.peakImpact>20,'A hard fall into shallow water lost its impact speed.');
  }],
  ['Dry-land fall injuries retain the existing impact calculation',()=>{
    const result=fallTo(4,{footY:25,verticalSpeed:0,grounded:false});
    assert(result.state.grounded&&!result.state.swimming&&result.peakImpact>18,'Dry landing no longer reports the falling player’s impact.');
    assert(result.entries===0,'Dry landing emitted a water-entry event.');
  }],
  ['Normal and fast swimming use 2.6m/s and 4m/s with stamina limits',()=>{
    const normal=getPlayerLocomotion({swimming:true,moving:true,stamina:80,dt:.25});
    const fast=getPlayerLocomotion({swimming:true,moving:true,fastRequested:true,stamina:80,dt:.25});
    assert(SWIM_SPEED===2.6&&FAST_SWIM_SPEED===4&&normal.speed===2.6&&fast.speed===4&&fast.fast,'Swimming speeds do not match the player controls.');
    assert(fast.stamina<80&&normal.stamina>80,'Fast swimming did not consume stamina or ordinary swimming failed to recover it.');
    const exhausted=getPlayerLocomotion({swimming:true,moving:true,fastRequested:true,stamina:0,dt:.05});
    assert(!exhausted.fast&&exhausted.speed===2.6,'An exhausted swimmer retained fast speed.');
  }],
  ['Wading and land movement keep their distinct speeds',()=>{
    const wade=getPlayerLocomotion({wading:true,moving:true,fastRequested:true,stamina:80,dt:.25});
    const walk=getPlayerLocomotion({moving:true,stamina:80,dt:.25}),sprint=getPlayerLocomotion({moving:true,fastRequested:true,stamina:80,dt:.25});
    assert(wade.speed===2.2&&!wade.fast&&wade.stamina>=80,'Wading incorrectly used swimming or sprint mechanics.');
    assert(walk.speed===4.2&&sprint.speed===7.2&&sprint.stamina<80,'Land walking/sprinting changed with swimming.');
  }],
  ['Holding fast movement while stationary does not drain swimming stamina',()=>{
    const result=getPlayerLocomotion({swimming:true,moving:false,fastRequested:true,stamina:50,dt:.25});
    assert(!result.fast&&result.stamina>=50,'A stationary swimmer drained fast-movement stamina.');
  }],
  ['A zero-time update does not move or rescue a paused underwater state',()=>{
    const paused={footY:-4,verticalSpeed:-3,grounded:true},after=vertical(paused,-4,0);
    assert(after.footY===paused.footY&&after.verticalSpeed===paused.verticalSpeed&&after.grounded===paused.grounded,'A paused update advanced or repaired vertical motion.');
    const resumed=vertical(paused,-4,.05);assert(resumed.swimming&&near(resumed.footY,FLOAT),'Positive-time resumption did not recover an old grounded riverbed state.');
  }],
  ['A stalled frame has the same bounded fall step as 0.25 seconds',()=>{
    const input={footY:20,verticalSpeed:-4,grounded:false};
    const long=vertical(input,-8,30),bounded=vertical(input,-8,.25);
    assert(near(long.footY,bounded.footY)&&near(long.verticalSpeed,bounded.verticalSpeed),'A delayed frame fast-forwarded the entire fall.');
    assert(!long.swimming,'One stalled frame teleported the airborne player into swimming.');
  }],
  ['Withholding updates preserves paused floating state',async()=>{
    const floating=vertical({footY:FLOAT,verticalSpeed:0,grounded:false},-8),before=JSON.stringify(floating);
    await new Promise(resolve=>setTimeout(resolve,60));for(let i=0;i<10;i++)getWaterState({floor:-8,footY:floating.footY,waterLevel:WATER});
    assert(JSON.stringify(floating)===before,'A read-only water query or elapsed wall time changed a paused swimmer.');
  }],
  ['A floating journey survives real save/read and resumes the same motion',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),initial=store.begin(life()).record;
    const floating=vertical(initial.motion,-7);const saved=store.save({...initial,motion:{footY:floating.footY,verticalSpeed:floating.verticalSpeed,grounded:floating.grounded}});
    assert(saved,'The journey store rejected a floating player.');
    const loaded=createJourneyStore(storage).read();assert(loaded.health===78&&!loaded.motion.grounded&&near(loaded.motion.footY,FLOAT),'Reload changed health or discarded swimming motion.');
    let uninterrupted=floating,resumed=loaded.motion;
    for(let i=0;i<40;i++){uninterrupted=vertical(uninterrupted,-7);resumed=vertical(resumed,-7);assert(JSON.stringify(resumed)===JSON.stringify(uninterrupted),'Restored swimming diverged from uninterrupted floating.');}
  }],
  ['A legacy underwater save can resume safely without optional motion fields',()=>{
    const storage=memoryStorage(),legacy={version:1,player:{x:0,z:0,yaw:0,pitch:0},discovered:[],waypoint:null,savedAt:12345};
    storage.setItem(SAVE_KEY,JSON.stringify(legacy));const loaded=createJourneyStore(storage).read();
    assert(loaded&&loaded.health===100&&loaded.motion===undefined,'The compatible legacy journey could not be read.');
    const resumed=vertical({footY:-4,verticalSpeed:0,grounded:true},-4);
    assert(resumed.swimming&&!resumed.grounded&&near(resumed.footY,FLOAT)&&resumed.impactSpeed===0,'A legacy riverbed position remained submerged or caused a false landing injury.');
  }],
  ['An airborne save over water retains its fall until real water contact',()=>{
    const storage=memoryStorage(),store=createJourneyStore(storage),motion={footY:12,verticalSpeed:-9,grounded:false},started=store.begin(life(motion)).record;
    store.save(started);const restored=createJourneyStore(storage).read();assert(restored.motion.verticalSpeed===-9&&restored.motion.footY===12,'Saving over water erased the fall.');
    const expected=fallTo(-8,motion),actual=fallTo(-8,restored.motion);
    assert(JSON.stringify(actual)===JSON.stringify(expected)&&actual.state.swimming,'The restored airborne player reached a different water landing.');
  }],
  ['A saved upward shore jump stays airborne near the floating support plane',()=>{
    const motion={footY:.8,verticalSpeed:5,grounded:false},expected=vertical(motion,.38);
    assert(!expected.swimming&&!expected.grounded&&expected.verticalSpeed>0&&expected.footY>motion.footY,'A rising shore jump was snapped into floating motion.');
    const storage=memoryStorage(),store=createJourneyStore(storage),started=store.begin(life(motion)).record;
    assert(store.save(started),'The journey store rejected a rising shore jump.');
    const loaded=createJourneyStore(storage).read();
    assert(loaded.motion.footY===.8&&loaded.motion.verticalSpeed===5&&!loaded.motion.grounded,'Saving or loading discarded the upward motion near the water surface.');
    const resumed=vertical(loaded.motion,.38);
    assert(JSON.stringify(resumed)===JSON.stringify(expected)&&!resumed.swimming,'Restored upward motion followed a different trajectory or became a swimmer.');
  }],
  ['A river-crossing player remains out of reach of a ground-only Teethpeed',()=>{
    const f=creatureFixture();
    for(let i=0;i<200;i++) {
      const player={x:8+i*.012,y:FLOAT,z:0};f.ai.update(.05,player);const a=f.ai.getActive()[0];
      assert(['attacking','hunting'].includes(a.stage),'The active riverbank encounter disappeared or became a swimming creature.');
      assert(a.position.x<=2&&f.heightAt(a.position.x)>=1.18&&near(a.position.y,f.heightAt(a.position.x)),'The Teethpeed left its valid ground or entered deep water.');
    }
    assert(f.damage.length===0,'A ground-only creature damaged the player across the river.');
  }],
  ['Hunting a remembered location across the river cannot make Teethpeed swim',()=>{
    const f=creatureFixture(),snapshot=f.ai.snapshot(),a=snapshot.active[0];
    Object.assign(a,{stage:'hunting',position:{x:0,y:2.4,z:0},lastKnownPlayer:{x:9,y:FLOAT,z:0},searchTarget:{x:9,y:FLOAT,z:0},sightLostFor:0,sightFoundFor:0});
    const ai=createTeethpeedEncounters({...f.config,state:snapshot});
    for(let i=0;i<120;i++) {
      ai.update(.05,{x:9,y:FLOAT,z:0});const p=ai.getActive()[0].position;
      assert(p.x<=2&&p.y>=1.18,'A remembered/search target beyond the river bypassed the creature ground-only rule.');
    }
    assert(f.damage.length===0,'Searching across deep water created a remote bite.');
  }],
];

export async function runSwimmingChecks(onResult=()=>{}) {
  const results=[];
  for(const [name,check] of swimmingChecks){let result;try{await check();result={name,passed:true};}catch(error){result={name,passed:false,error:error.message};}results.push(result);onResult(result);await new Promise(resolve=>setTimeout(resolve,0));}
  return results;
}
if(typeof document!=='undefined') {
  const button=document.getElementById('run-checks'),list=document.getElementById('results'),summary=document.getElementById('summary');
  button?.addEventListener('click',async()=>{
    button.disabled=true;list.replaceChildren();summary.textContent='Running isolated movement, creature and journey checks…';
    const results=await runSwimmingChecks(result=>{const row=document.createElement('li');row.className=result.passed?'pass':'fail';const badge=document.createElement('strong');badge.textContent=result.passed?'PASS':'FAIL';const title=document.createElement('span');title.textContent=result.name;row.append(badge,title);if(!result.passed){const detail=document.createElement('p');detail.textContent=result.error;row.append(detail);}list.append(row);summary.textContent=`${list.children.length} / ${swimmingChecks.length} checks complete`;});
    const failed=results.filter(result=>!result.passed).length;summary.textContent=`${results.length-failed} passed · ${failed} failed · Journey save untouched`;button.disabled=false;button.textContent='Run checks again';
  });
}
