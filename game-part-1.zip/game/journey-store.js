import { normalizeEncounterState } from './teethpeed-encounters.js';
import { normalizeDeatheaterState } from './deatheater-encounters.js';
import { normalizeTripState } from './trip-risk.js';
import { normalizePhase3State } from './phase3-state.js';
import { WORLD_SIZE } from './terrain-surface.js';
import { normalizeCharacterProfile } from './character-profile.js';

export const SAVE_KEY = 'scars-of-the-wild.world.v1';
export const DEATH_KEY = 'scars-of-the-wild.deaths.v1';

const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const finite = Number.isFinite;
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const runIdOf = value => typeof value?.runId === 'string' && value.runId.trim()
  ? value.runId.trim()
  : `legacy-${finite(value?.savedAt) ? Math.trunc(value.savedAt) : 0}`;

function newRunId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  const bytes = new Uint8Array(16);
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function normalize(value, {runId, dead = false} = {}) {
  if (!object(value) || (value.version !== undefined && value.version !== 1)) return null;
  if (!dead && value.status !== undefined && value.status !== 'alive') return null;
  const player = value.player;
  if (!object(player) || ![player.x, player.z, player.yaw, player.pitch].every(finite)) return null;
  if (Math.abs(player.x) > WORLD_SIZE/2-12 || Math.abs(player.z) > WORLD_SIZE/2-12 || Math.abs(player.pitch) > 1.25) return null;
  const health = dead ? 0 : value.health === undefined ? 100 : value.health;
  const survivedSeconds = value.survivedSeconds === undefined ? 0 : value.survivedSeconds;
  if (!finite(health) || (!dead && health <= 0) || !finite(survivedSeconds) || survivedSeconds < 0) return null;
  const waypoint = value.waypoint;
  const motion = value.motion;
  if (motion !== undefined && (!object(motion) || !finite(motion.footY) || motion.footY < -250 || motion.footY > 600 || !finite(motion.verticalSpeed) || motion.verticalSpeed < -120 || motion.verticalSpeed > 20 || typeof motion.grounded !== 'boolean')) return null;
  const record = {
    version: 1,
    runId: runId || runIdOf(value),
    status: dead ? 'dead' : 'alive',
    player: {x: player.x, z: player.z, yaw: player.yaw, pitch: player.pitch},
    discovered: [...new Set((Array.isArray(value.discovered) ? value.discovered : []).filter(id => typeof id === 'string'))],
    waypoint: object(waypoint) && [waypoint.x, waypoint.z].every(finite) && Math.abs(waypoint.x) <= WORLD_SIZE/2 && Math.abs(waypoint.z) <= WORLD_SIZE/2
      ? {x: waypoint.x, z: waypoint.z} : null,
    health,
    survivedSeconds,
    savedAt: finite(value.savedAt) && value.savedAt >= 0 ? value.savedAt : 0,
  };
  if (motion !== undefined) record.motion = {footY: motion.footY, verticalSpeed: motion.verticalSpeed, grounded: motion.grounded};
  if (value.character !== undefined) record.character = normalizeCharacterProfile(value.character);
  const encounters=normalizeEncounterState(value.encounters);
  if(encounters===null)return null;
  if(encounters!==undefined)record.encounters=encounters;
  const deatheater=normalizeDeatheaterState(value.deatheater);
  if(deatheater===null)return null;
  if(deatheater!==undefined)record.deatheater=deatheater;
  const trips=normalizeTripState(value.trips);
  if(trips===null)return null;
  if(trips!==undefined)record.trips=trips;
  const phase3=normalizePhase3State(value.phase3);if(phase3===null)return null;if(phase3!==undefined)record.phase3=phase3;
  return record;
}

function mergeTrips(previous, incoming) {
  if (!previous) return incoming;
  if (!incoming || previous.seed !== incoming.seed) return previous;
  // Stale tabs cannot erase completed rolls, including safe rolls. Keep the
  // original ledger first if its bounded capacity has already been reached.
  const resolved = new Set(previous.resolved);
  for (const key of incoming.resolved) {
    if (resolved.size >= 50000) break;
    resolved.add(key);
  }
  return { version: 1, seed: previous.seed, resolved: [...resolved] };
}

function mergeBurrowers(previous, incoming) {
  if (!previous) return incoming;
  if (!incoming || previous.seed !== incoming.seed) return previous;
  const records = new Map(previous.records.map(record => [record.denId, record]));
  const stageOrder = {emerging: 0, chasing: 1, burrowing: 2, returning: 3, buried: 4, dead: 5};
  for (const next of incoming.records) {
    const before = records.get(next.denId);
    if (!before) { records.set(next.denId, next); continue; }
    const newer = next.cycle > before.cycle || next.cycle === before.cycle &&
      (stageOrder[next.stage] > stageOrder[before.stage] || next.stage === before.stage &&
        (next.revision > before.revision || next.revision === before.revision && incoming.clock > previous.clock));
    // Den identities never respawn after death. Returning underground does not
    // heal a surviving animal, and a stale tab cannot restore harvested remains.
    const selected = before.stage === 'dead' ? before : next.stage === 'dead' ? next : newer ? next : before;
    const merged = {...selected, revision: Math.max(before.revision, next.revision),
      health: Math.min(before.health, next.health), harvested: before.harvested || next.harvested};
    if (before.cycle === next.cycle && before.stage === next.stage) {
      merged.remaining = Math.min(before.remaining, next.remaining);
      merged.elapsed = Math.max(before.elapsed, next.elapsed);
      merged.progress = Math.max(before.progress, next.progress);
      merged.cooldown = Math.min(before.cooldown, next.cooldown);
      if (before.stage === 'buried') merged.armed = before.armed || next.armed;
    }
    records.set(next.denId, merged);
  }
  return {version: 1, seed: previous.seed, clock: Math.max(previous.clock, incoming.clock),
    revision: Math.max(previous.revision, incoming.revision), records: [...records.values()]};
}

export class JourneyStorageError extends Error {
  constructor(operation, cause) {
    super(`Journey storage failed while ${operation}.`, {cause});
    this.name = 'JourneyStorageError';
    this.operation = operation;
  }
}

/** Synchronous persistence with an immutable death history and a local death lock. */
export function createJourneyStore(storage) {
  const localDeaths = new Map();
  let lastError = null;

  function failure(operation, cause) {
    const error = cause instanceof JourneyStorageError ? cause : new JourneyStorageError(operation, cause);
    lastError = error;
    return error;
  }

  function get(key, operation) {
    try { return storage.getItem(key); }
    catch (error) { throw failure(operation, error); }
  }

  function put(key, value, operation) {
    try { storage.setItem(key, JSON.stringify(value)); }
    catch (error) { throw failure(operation, error); }
  }

  function current() {
    const raw = get(SAVE_KEY, 'reading the current journey');
    if (raw === null) return null;
    try { const value = JSON.parse(raw); return object(value) ? value : null; }
    catch { return null; }
  }

  function deaths() {
    const raw = get(DEATH_KEY, 'reading the death history');
    if (raw === null) return Object.create(null);
    try {
      const value = JSON.parse(raw);
      if (!object(value)) throw new TypeError('Death history is not a dictionary.');
      return Object.assign(Object.create(null), value);
    } catch (error) {
      // An unreadable history must never be replaced with an empty history.
      throw failure('reading the death history', error);
    }
  }

  function dead(runId) {
    if (typeof runId !== 'string' || !runId.trim()) return false;
    runId = runId.trim();
    if (localDeaths.has(runId)) return true;
    if (own(deaths(), runId)) return true;
    const saved = current();
    return !!saved && runIdOf(saved) === runId && (saved.status === 'dead' || finite(saved.health) && saved.health <= 0);
  }

  function read() {
    lastError = null;
    const raw = current();
    if (!raw || raw.version !== 1) return null;
    const record = normalize(raw);
    if (!record || dead(record.runId)) return null;
    return record;
  }

  function begin(data) {
    lastError = null;
    const record = normalize({...data, version: 1, status: 'alive'}, {runId: newRunId()});
    if (!record) throw new TypeError('A new journey needs a valid player position, positive health and nonnegative survival time.');
    record.savedAt = Date.now();
    try {
      // Read first so a corrupt or inaccessible death history is not silently ignored.
      deaths();
      put(SAVE_KEY, record, 'starting a new journey');
      return {record, persisted: true};
    } catch (error) {
      failure('starting a new journey', error);
      return {record, persisted: false};
    }
  }

  function save(data) {
    lastError = null;
    if (!object(data) || typeof data.runId !== 'string' || !data.runId.trim()) return null;
    const record = normalize(data);
    if (!record || dead(record.runId)) return null;
    const stored = current();
    const previous = normalize(stored);
    if (!previous || previous.runId !== record.runId || dead(previous.runId)) return null;
    const burrowers = mergeBurrowers(previous.phase3?.burrowers, record.phase3?.burrowers);
    const newerSurvival=(record.phase3?.survival?.revision??-1)>(previous.phase3?.survival?.revision??-1);
    record.health = newerSurvival?Math.min(100,record.health):Math.min(previous.health, record.health);
    if(previous.phase3&&(record.phase3?.survival?.revision??-1)<(previous.phase3.survival?.revision??-1))record.phase3=previous.phase3;
    if(burrowers!==undefined&&record.phase3)record.phase3.burrowers=burrowers;
    if(previous.phase3?.world?.caveProgress&&record.phase3?.world){
      const before=previous.phase3.world.caveProgress,after=record.phase3.world.caveProgress;
      if(!after||before.revision>after.revision)record.phase3.world.caveProgress={...before};
      else record.phase3.world.caveProgress={...after,entries:Math.max(before.entries,after.entries),lastBearEntry:Math.max(before.lastBearEntry,after.lastBearEntry),rewardClaimed:before.rewardClaimed||after.rewardClaimed};
    }
    record.survivedSeconds = Math.max(previous.survivedSeconds, record.survivedSeconds);
    record.discovered = [...new Set([...previous.discovered, ...record.discovered])];
    if (record.motion === undefined && previous.motion !== undefined) record.motion = {...previous.motion};
    if (record.character === undefined && previous.character !== undefined) record.character = {...previous.character};
    if(previous.encounters && (!record.encounters || (previous.encounters.clock||0)>(record.encounters.clock||0)))record.encounters=previous.encounters;
    if(previous.deatheater && (!record.deatheater || previous.deatheater.clock>record.deatheater.clock))record.deatheater=previous.deatheater;
    const trips=mergeTrips(previous.trips,record.trips);
    if(trips!==undefined)record.trips=trips;
    record.savedAt = Date.now();
    put(SAVE_KEY, record, 'saving the current journey');
    // A tombstone takes precedence even if another tab dies around this write.
    if (dead(record.runId)) return null;
    return record;
  }

  function end(data, cause = 'Your journey ended.') {
    lastError = null;
    if (!object(data) || typeof data.runId !== 'string' || !data.runId.trim()) throw new TypeError('Ending a journey requires its runId.');
    const record = normalize(data, {dead: true});
    if (!record) throw new TypeError('Ending a journey requires a valid player snapshot.');
    const previousDeath = localDeaths.get(record.runId);
    record.savedAt = Date.now();
    record.diedAt = previousDeath?.diedAt || record.savedAt;
    record.cause = previousDeath?.cause || String(cause || 'Your journey ended.').slice(0, 300);
    // Lock before touching storage: even a quota/security error cannot revive this run.
    localDeaths.set(record.runId, {...record});

    let persisted = true;
    let stored = null;
    try {
      stored = current();
      if (stored && runIdOf(stored) === record.runId && finite(stored.survivedSeconds)) {
        record.survivedSeconds = Math.max(record.survivedSeconds, stored.survivedSeconds);
        const trips=mergeTrips(normalizeTripState(stored.trips)||undefined,record.trips);
        if(trips!==undefined)record.trips=trips;
      }
    } catch { persisted = false; }

    try {
      const history = deaths();
      if (!own(history, record.runId)) {
        history[record.runId] = {runId: record.runId, status: 'dead', cause: record.cause, diedAt: record.diedAt, survivedSeconds: record.survivedSeconds};
        put(DEATH_KEY, history, 'recording permanent death');
      } else if (object(history[record.runId])) {
        record.diedAt = history[record.runId].diedAt || record.diedAt;
        record.cause = history[record.runId].cause || record.cause;
        if (finite(history[record.runId].survivedSeconds)) record.survivedSeconds = Math.max(record.survivedSeconds, history[record.runId].survivedSeconds);
      }
    } catch { persisted = false; }

    // A stale tab may end its old run, but cannot replace a newer living journey.
    try {
      const latest = current();
      if (latest && runIdOf(latest) === record.runId) put(SAVE_KEY, record, 'saving the ended journey');
    } catch { persisted = false; }
    localDeaths.set(record.runId, {...record});
    return {record, persisted};
  }

  return {
    read,
    begin,
    save,
    end,
    isDead(runId) { lastError = null; return dead(runId); },
    get lastError() { return lastError; },
  };
}
