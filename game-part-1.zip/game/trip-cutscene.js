import * as THREE from './vendor/three.module.js';
import { createTeethpeedModel } from './teethpeed-model.js';
import { createDeatheaterModel } from './deatheater-model.js';
import { normalizeCharacterProfile, SKIN_TONES, CLOTHING_COLORS, HAIR_COLORS } from './character-profile.js';

export const TRIP_CUTSCENE_TIMING=Object.freeze({
  teethpeed:Object.freeze({duration:6.2,groundImpact:1.35,strike:4.45}),
  deatheater:Object.freeze({duration:7.8,groundImpact:1.35,strike:4.65,grab:4.65,swallowStart:5.08,swallowEnd:6.78}),
  deatheaterDive:Object.freeze({duration:4.8,groundImpact:null,strike:.52,grab:.52,swallowStart:1.05,swallowEnd:3.1})
});
const clamp=(value,a=0,b=1)=>Math.max(a,Math.min(b,value));
const smooth=value=>{value=clamp(value);return value*value*(3-2*value);};
const mix=THREE.MathUtils.lerp,UP=new THREE.Vector3(0,1,0);
const hash=(a,b=0)=>{const n=Math.sin(a*127.1+b*311.7)*43758.5453;return n-Math.floor(n);};

function clothTexture(){
  const size=64,data=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const i=(y*size+x)*4,thread=(x%3===0?-13:0)+(y%3===0?8:0),v=clamp(224+thread+(hash(x,y)-.5)*20,0,255);
    data[i]=data[i+1]=data[i+2]=v;data[i+3]=255;
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
  texture.colorSpace=THREE.SRGBColorSpace;texture.repeat.set(5,8);texture.needsUpdate=true;return texture;
}

function garmentGeometry(seed=0,torso=false){
  const positions=[],uv=[],indices=[],rows=14,sides=22;
  for(let row=0;row<=rows;row++)for(let side=0;side<=sides;side++){
    const t=row/rows,a=side/sides*Math.PI*2;
    const taper=torso?(.84+.13*Math.sin(t*Math.PI*.75)):(.74+.22*Math.sin(t*Math.PI));
    const fold=Math.sin(t*33+a*3+seed)*.019+Math.sin(t*17-a*5+seed)*.011;
    const radius=taper+fold*Math.sin(t*Math.PI);
    positions.push(Math.cos(a)*radius,t-.5,Math.sin(a)*radius);
    uv.push(side/sides,t);
    if(row<rows&&side<sides){const n=row*(sides+1)+side;indices.push(n,n+sides+1,n+1,n+1,n+sides+1,n+sides+2);}
  }
  for(const row of [0,rows]){
    const center=positions.length/3;positions.push(0,row/rows-.5,0);uv.push(.5,row/rows);
    for(let side=0;side<sides;side++){
      const n=row*(sides+1)+side;
      if(row===0)indices.push(center,n+1,n);else indices.push(center,n,n+1);
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}

function makeSurvivor(heightAt,characterProfile){
  const group=new THREE.Group();group.name='Fallen wilderness survivor';
  const resources=new Set(),own=value=>(resources.add(value),value),cloth=own(clothTexture());
  const shirt=own(new THREE.MeshStandardMaterial({color:'#666a60',map:cloth,bumpMap:cloth,bumpScale:.004,roughness:.96}));
  const trousers=own(new THREE.MeshStandardMaterial({color:'#514c40',map:cloth,bumpMap:cloth,bumpScale:.0035,roughness:.94}));
  const skin=own(new THREE.MeshStandardMaterial({color:'#8b715b',roughness:.84,metalness:0}));
  const boot=own(new THREE.MeshStandardMaterial({color:'#302d26',roughness:.86,metalness:0}));
  const sole=own(new THREE.MeshStandardMaterial({color:'#22211d',roughness:.98}));
  const seam=own(new THREE.MeshStandardMaterial({color:'#43483e',map:cloth,roughness:1}));
  const hair=own(new THREE.MeshStandardMaterial({color:'#292721',roughness:1}));
  const limbGeometry=own(garmentGeometry(2)),bodyGeometry=own(garmentGeometry(8,true));
  const sphere=own(new THREE.SphereGeometry(1,20,14));
  const mesh=(geometry,material,name)=>{const part=new THREE.Mesh(geometry,material);part.name=name;part.castShadow=part.receiveShadow=true;group.add(part);return part;};
  const body=mesh(bodyGeometry,shirt,'Worn overshirt'),hips=mesh(bodyGeometry,trousers,'Trouser hips');
  const neck=mesh(limbGeometry,skin,'Neck');
  const headGeometry=own(new THREE.SphereGeometry(1,26,18));
  const hp=headGeometry.attributes.position;
  for(let i=0;i<hp.count;i++){
    const y=hp.getY(i),taper=y<0?1+y*.16:1;
    hp.setXYZ(i,hp.getX(i)*taper,hp.getY(i),hp.getZ(i)*(hp.getZ(i)<0?.88:1));
  }
  headGeometry.computeVertexNormals();
  const head=mesh(headGeometry,skin,'Turned-away head');
  const hairGeometry=own(new THREE.SphereGeometry(1,24,14,0,Math.PI*2,0,Math.PI*.67));
  const scalp=mesh(hairGeometry,hair,'Short dark hair');
  const tiedHair=mesh(sphere,hair,'Tied survivor hair'),sweptHair=mesh(sphere,hair,'Swept survivor hair');
  const shirtPlacket=mesh(limbGeometry,seam,'Weathered shirt seam');
  const limbs=[];
  for(const side of [-1,1])limbs.push({
    side,upperArm:mesh(limbGeometry,shirt,'Tapered sleeve'),forearm:mesh(limbGeometry,shirt,'Folded sleeve'),
    rolledSleeve:mesh(limbGeometry,shirt,'Rolled upper forearm sleeve'),cuff:mesh(limbGeometry,seam,'Sleeve cuff'),
    hand:mesh(sphere,skin,'Relaxed hand'),thigh:mesh(limbGeometry,trousers,'Trouser thigh'),shin:mesh(limbGeometry,trousers,'Trouser calf'),
    knee:mesh(sphere,trousers,'Bent trouser knee'),shoe:mesh(sphere,boot,'Worn leather boot'),sole:mesh(sphere,sole,'Boot sole')
  });
  let profile,buildWidth=1,buildDepth=1;
  function setProfile(value){
    profile=normalizeCharacterProfile(value);
    skin.color.set(SKIN_TONES[profile.skinTone].color);shirt.color.set(CLOTHING_COLORS[profile.topColor].color);
    seam.color.copy(shirt.color).multiplyScalar(.68);hair.color.set(HAIR_COLORS[profile.hairColor].color);
    buildWidth=profile.bodyType==='slender'?.88:profile.bodyType==='broad'?1.14:1;
    buildDepth=profile.bodyType==='slender'?.93:profile.bodyType==='broad'?1.08:1;
    scalp.visible=profile.hairStyle!=='shaved';tiedHair.visible=profile.hairStyle==='tied';sweptHair.visible=profile.hairStyle==='swept';
    for(const limb of limbs){limb.forearm.material=profile.sleeve==='rolled'?skin:shirt;limb.rolledSleeve.visible=profile.sleeve==='rolled';}
    return {...profile};
  }
  setProfile(characterProfile);
  const matrix=new THREE.Matrix4(),rotation=new THREE.Quaternion(),point=new THREE.Vector3(),delta=new THREE.Vector3(),scale=new THREE.Vector3(1,1,1);
  const local=(x,y,z)=>new THREE.Vector3(x*buildWidth,y,z*buildDepth).applyMatrix4(matrix);
  function terrainPoint(p,radius=.03){p.y=Math.max(p.y,heightAt(p.x,p.z)+radius);return p;}
  function place(part,p,s){part.position.copy(p);part.quaternion.copy(rotation);part.scale.set(...s);}
  function link(part,a,b,radius,depth=radius){delta.subVectors(b,a);part.position.copy(a).add(b).multiplyScalar(.5);part.quaternion.setFromUnitVectors(UP,delta.clone().normalize());part.scale.set(radius,Math.max(.015,delta.length()),depth);}
  function pose(origin,yaw,time,struck,{standing=false,capture=0}={}){
    group.position.set(0,0,0);group.quaternion.identity();group.scale.set(1,1,1);
    const tuck=smooth(capture),stumble=standing?0:smooth(time/.65),fall=standing?0:smooth((time-.42)/.93),settle=standing?0:smooth((time-1.35)/.4);
    const along=mix(0,1.05,fall),x=origin.x-Math.sin(yaw)*along,z=origin.z-Math.cos(yaw)*along;
    const floor=standing?origin.y:heightAt(x,z),impact=standing?0:Math.sin(clamp((time-1.35)/.30)*Math.PI)*.025;
    const pitch=standing?0:-mix(.08,1.48,fall)+Math.sin(time*8)*.055*(1-fall)*stumble;
    rotation.setFromEuler(new THREE.Euler(pitch,yaw,mix(-.045,.075,fall),'YXZ'));
    point.set(x,floor+mix(.92,.155,fall)+impact,z);matrix.compose(point,rotation,scale);
    place(body,local(0,.32,0),[.255*buildWidth,.61,.151*buildDepth]);place(hips,local(0,-.025,.012),[.205*buildWidth,.20,.145*buildDepth]);
    place(neck,local(0,.66,.006),[.060,.115,.054]);place(head,local(0,.785,-.018),[.105,.13,.115]);
    place(scalp,local(0,.809,-.012),[.108,.123,.114]);place(shirtPlacket,local(0,.34,-.143),[.009,.48,.003]);
    place(tiedHair,local(0,.80,.104),[.065,.068,.060]);place(sweptHair,local(-.025,.878,-.057),[.092,.041,.086]);
    for(const limb of limbs){
      const s=limb.side,kick=s>0?Math.sin(stumble*Math.PI)*.19:0;
      const shoulder=local(s*.235,.50,0),elbow=terrainPoint(local(s*mix(mix(.28,.42,fall),.255,tuck),mix(mix(.19,.27,fall),.25,tuck),mix(mix(.025,-.055,fall)-stumble*(1-fall)*.22,-.17,tuck)),.07);
      const wrist=terrainPoint(local(s*mix(mix(.26,.45,fall),.20,tuck),mix(mix(-.035,.55,fall),0,tuck),mix(mix(-.045,-.12,fall)-stumble*(1-fall)*.34,-.03,tuck)),.042);
      link(limb.upperArm,shoulder,elbow,.071*buildWidth,.061*buildDepth);link(limb.forearm,elbow,wrist,.057*buildWidth,.047*buildDepth);
      link(limb.rolledSleeve,elbow,elbow.clone().lerp(wrist,.35),.060*buildWidth,.050*buildDepth);
      const cuffAt=profile.sleeve==='rolled'?.35:.93;
      link(limb.cuff,elbow.clone().lerp(wrist,cuffAt-.06),elbow.clone().lerp(wrist,cuffAt+.015),.061*buildWidth,.051*buildDepth);
      place(limb.hand,wrist,[.047,.085,.026]);
      const hip=local(s*.11,-.015,.008),knee=terrainPoint(local(s*mix(.11,.15,fall),-.43,mix(.025,.07,fall)+kick),.075);
      const ankle=terrainPoint(local(s*mix(.11,.19,fall),mix(-.82,-.79,fall),mix(0,.085,fall)-kick*.65),.07);
      link(limb.thigh,hip,knee,.095*buildWidth,.088*buildDepth);link(limb.shin,knee,ankle,.074*buildWidth,.065*buildDepth);place(limb.knee,knee,[.086*buildWidth,.09,.084*buildDepth]);
      const foot=terrainPoint(local(s*mix(.11,.19,fall),mix(-.874,-.835,fall),mix(-.085,.04,fall)-kick*.65),.066);
      place(limb.shoe,foot,[.080,.071,.156]);place(limb.sole,terrainPoint(foot.clone().add(new THREE.Vector3(0,-.048,0)),.016),[.082,.025,.16]);
    }
    // The final stillness communicates the fatal strike without visible injury.
    if(struck&&settle>=1){body.scale.y=.606;}
    return {hip:point.clone(),head:head.position.clone(),chest:body.position.clone(),feet:limbs.map(limb=>limb.shoe.position.clone())};
  }
  const mouthClip=new THREE.Plane();let clipping=false;
  function setClipping(value,center,outward){
    if(value)mouthClip.setFromNormalAndCoplanarPoint(outward,center);
    if(clipping===value)return;clipping=value;
    for(const resource of resources)if(resource.isMaterial){resource.clippingPlanes=value?[mouthClip]:null;resource.clipShadows=value;resource.needsUpdate=true;}
  }
  function capturePose(basePose,mouth,amount,alignment){
    const inward=mouth.outward.clone().negate(),axis=basePose.head.clone().sub(basePose.hip).normalize();
    const turn=new THREE.Quaternion().setFromUnitVectors(axis,inward),blended=new THREE.Quaternion().slerp(turn,smooth(alignment));
    const headPosition=mouth.center.clone().addScaledVector(inward,mix(-.12,2.5,smooth(amount)));
    group.quaternion.copy(blended);group.position.copy(headPosition).sub(basePose.head.clone().applyQuaternion(blended));group.scale.set(1,1,1);
    const transform=p=>p.clone().applyQuaternion(blended).add(group.position);
    setClipping(true,mouth.center,mouth.outward);
    group.updateMatrixWorld(true);let outsideExtent=-Infinity;
    for(const part of group.children){
      if(!part.isMesh||!part.visible)continue;if(!part.geometry.boundingSphere)part.geometry.computeBoundingSphere();
      const bounds=part.geometry.boundingSphere,center=bounds.center.clone().applyMatrix4(part.matrixWorld);
      const radius=bounds.radius*Math.max(part.scale.x,part.scale.y,part.scale.z);
      outsideExtent=Math.max(outsideExtent,mouth.outward.dot(center.sub(mouth.center))+radius);
    }
    return {hip:transform(basePose.hip),head:transform(basePose.head),chest:transform(basePose.chest),feet:basePose.feet.map(transform),fullyInside:outsideExtent<=0,outsideExtent};
  }
  return {group,pose,capturePose,setProfile,clearCapture(){setClipping(false);group.position.set(0,0,0);group.quaternion.identity();},dispose(){group.removeFromParent();for(const resource of resources)resource.dispose();group.clear();}};
}

function shadowTexture(){
  const size=64,data=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const dx=(x-size/2)/(size/2),dy=(y-size/2)/(size/2),r=Math.sqrt(dx*dx+dy*dy),i=(y*size+x)*4;
    data[i]=data[i+1]=data[i+2]=0;data[i+3]=Math.round(Math.pow(clamp(1-r),1.6)*255);
  }
  const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);texture.needsUpdate=true;return texture;
}

/** Presentation only: the caller owns the chance roll, lethal result, and save state. */
export function createTripCutscene({scene,camera,heightAt,surfaceTexture,characterProfile,reducedMotion=()=>false,onEvent=()=>{}}){
  const floor=(x,z)=>{const y=heightAt(x,z);return Number.isFinite(y)?y:0;};
  const survivor=makeSurvivor(floor,characterProfile),root=new THREE.Group();root.name='Fatal stumble cinematic';root.visible=false;scene.add(root);root.add(survivor.group);
  const shadowMap=shadowTexture(),shadowGeometry=new THREE.PlaneGeometry(1,1),shadowMaterial=new THREE.MeshBasicMaterial({map:shadowMap,transparent:true,opacity:0,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,side:THREE.DoubleSide});
  const shadow=new THREE.Mesh(shadowGeometry,shadowMaterial);shadow.name='Passing wing shadow';shadow.rotation.x=-Math.PI/2;root.add(shadow);
  let teethpeed=null,deatheater=null,deatheaterAnchor=null,active=false,kind='teethpeed',entry='trip',time=0,disposed=false,completed=false,started=false;
  let origin={x:0,y:0,z:0,yaw:0},creatureStart=null,lastCreature=null,pose=null,currentMouth=null,swallowProgress=0,initialCreatureOrientation=null,creatureAnimationTime=0;
  const initialCameraPosition=new THREE.Vector3(),initialCameraQuaternion=new THREE.Quaternion(),events=new Set();
  const lookMatrix=new THREE.Matrix4(),lookQuaternion=new THREE.Quaternion(),target=new THREE.Vector3(),externalCamera=new THREE.Vector3();
  const timings=()=>kind==='deatheater'&&entry==='dive'?TRIP_CUTSCENE_TIMING.deatheaterDive:TRIP_CUTSCENE_TIMING[kind];
  const world=(x,y,z)=>new THREE.Vector3(origin.x+Math.cos(origin.yaw)*x+Math.sin(origin.yaw)*z,y,origin.z-Math.sin(origin.yaw)*x+Math.cos(origin.yaw)*z);
  const groundPoint=(x,z,lift=0)=>{const p=world(x,0,z);p.y=floor(p.x,p.z)+lift;return p;};
  const motionOff=()=>typeof reducedMotion==='function'?!!reducedMotion():!!reducedMotion;
  function emit(type,eventTime=time){if(events.has(type))return;events.add(type);onEvent({type,kind,entry,time:eventTime,position:pose?.chest?{x:pose.chest.x,y:pose.chest.y,z:pose.chest.z}:{x:origin.x,y:origin.y,z:origin.z}});}
  function getState(){
    const timing=timings(),fadeStart=kind==='deatheater'?timing.swallowEnd+.34:timing.strike+.38;
    const fade=completed?1:smooth((time-fadeStart)/(timing.duration-fadeStart-.16));
    let stage=entry==='dive'?'diving':time<.42?'trip':time<timing.groundImpact?'falling':'approach';
    if(kind==='teethpeed'&&time>=timing.strike)stage='strike';
    if(kind==='deatheater'){
      if(time>=timing.grab)stage='captured';
      if(time>=timing.swallowStart)stage='swallowing';
      if(time>=timing.swallowEnd)stage='escape';
    }
    return {active,kind,entry,time,duration:timing.duration,stage:completed?'finished':stage,fade,
      captured:kind==='deatheater'&&time>=timing.grab,swallowProgress,survivorVisible:root.visible&&survivor.group.visible,
      survivorScale:survivor.group.scale.toArray(),fullySwallowed:!!pose?.fullyInside};
  }
  function mouthPose(){
    deatheaterAnchor.updateMatrixWorld(true);
    const result=deatheater.getMouthPose?.();
    if(result?.center&&result?.outward)return {center:new THREE.Vector3(result.center.x,result.center.y,result.center.z),outward:new THREE.Vector3(result.outward.x,result.outward.y,result.outward.z).normalize(),radius:result.radius};
    return {center:deatheaterAnchor.position.clone(),outward:new THREE.Vector3(0,0,-1).applyQuaternion(deatheaterAnchor.quaternion),radius:.4};
  }
  function creaturePose(dt){
    const timing=timings(),struck=time>=timing.strike;
    if(kind==='teethpeed'){
      const approach=smooth((time-.3)/3.55),lunge=smooth((time-(timing.strike-.45))/.45);
      const stalk=groundPoint(.88,-.60),bite=groundPoint(.18,-1.61);
      const p=creatureStart.clone().lerp(stalk,approach).lerp(bite,lunge);p.y=floor(p.x,p.z);
      teethpeed.group.position.copy(p);
      const focus=groundPoint(0,-1.79),heading=Math.atan2(p.x-focus.x,p.z-focus.z);
      teethpeed.group.rotation.set(0,heading,0,'YXZ');
      const speed=dt>0&&lastCreature?Math.min(6,p.distanceTo(lastCreature)/dt):0;
      const c=Math.cos(heading),s=Math.sin(heading),snap=clamp((time-(timing.strike-.28))/.22);
      const attack=struck?Math.max(.08,1-(time-timing.strike)*6):snap;
      teethpeed.animate({time,speed,climbing:false,attacking:attack,groundAt:(x,z)=>floor(p.x+c*x+s*z,p.z-s*x+c*z)-p.y});
      lastCreature=p.clone();shadow.visible=false;
    } else {
      const approach=entry==='dive'?smooth(time/timing.grab):Math.pow(clamp((time-1.7)/(timing.grab-1.7)),2.7);
      const localOutward=new THREE.Vector3(-.10,-.78,-.62).normalize(),outward=localOutward.applyAxisAngle(UP,origin.yaw),inward=outward.clone().negate();
      const contact=pose.head.clone().addScaledVector(inward,.12);
      const opening=entry==='dive'?creatureStart.clone():world(4.8+Math.sin(time*1.1)*1.6,origin.y+11.5,5.5-time*.6);
      const p=opening.lerp(contact,approach),capture=1-smooth((time-timing.swallowEnd)/.32);
      const captureLift=smooth((time-timing.grab)/.52),escape=smooth((time-(timing.swallowEnd+.32))/(timing.duration-timing.swallowEnd-.38));
      if(time>=timing.grab){
        p.copy(contact).add(new THREE.Vector3(0,captureLift*2.55,0));
        p.add(world(.28,0,.32).sub(world(0,0,0)).multiplyScalar(captureLift));
        p.lerp(world(8.5,origin.y+8.5,10),escape);
      }
      deatheaterAnchor.position.copy(p);
      const captureTurn=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(p,p.clone().add(outward),UP));
      const incomingTurn=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(p,pose.head,UP));
      if(entry==='dive'&&initialCreatureOrientation)deatheaterAnchor.quaternion.slerpQuaternions(initialCreatureOrientation,captureTurn,smooth(time/timing.grab));
      else deatheaterAnchor.quaternion.slerpQuaternions(incomingTurn,captureTurn,smooth((time-(timing.grab-.38))/.38));
      if(escape>0){lookMatrix.lookAt(p,world(12,origin.y+10,14),UP);deatheaterAnchor.quaternion.slerp(new THREE.Quaternion().setFromRotationMatrix(lookMatrix),smooth(escape*2));}
      const speed=dt>0&&lastCreature?Math.min(30,p.distanceTo(lastCreature)/dt):entry==='dive'?15:12;
      const gape=smooth((time-(timing.grab-.38))/.38)*capture;
      deatheater.animate({time:creatureAnimationTime+time,speed,stage:time<timing.grab?'diving':'recovering',attacking:time<timing.grab&&approach>.55?1:0,capture:gape,swallowing:swallowProgress});
      currentMouth=mouthPose();
      // The animated lip plane stays attached to the captured head while the body is lifted.
      if(time>=timing.grab&&escape===0){deatheaterAnchor.position.add(p.clone().sub(currentMouth.center));currentMouth=mouthPose();}
      if(time>=timing.grab){
        pose=survivor.capturePose(pose,currentMouth,swallowProgress,(time-timing.grab)/.72);
        survivor.group.visible=!(swallowProgress>=1&&pose.fullyInside);
      }
      lastCreature=deatheaterAnchor.position.clone();
      shadow.visible=true;shadow.position.set(p.x,floor(p.x,p.z)+.018,p.z);shadow.scale.set(8.5,3.2,1);shadowMaterial.opacity=(.13+smooth((time-.2)/.6)*.24)*(1-escape);
    }
  }
  function frame(dt=0){
    const timing=timings();root.visible=true;survivor.group.visible=time>(entry==='dive'?.10:.14);
    swallowProgress=kind==='deatheater'?clamp((time-timing.swallowStart)/(timing.swallowEnd-timing.swallowStart)):0;
    pose=survivor.pose(origin,origin.yaw,time,time>=timing.strike,{standing:entry==='dive',capture:kind==='deatheater'?smooth((time-timing.grab)/.55):0});
    creaturePose(dt);
    const close=kind==='teethpeed'?smooth((time-2.45)/1.55):0;
    externalCamera.copy(groundPoint(mix(-2.9,-.92,close),mix(-2.2,-2.65,close),mix(.78,.44,close)));
    if(kind==='deatheater')externalCamera.copy(world(-3.8,origin.y+2.4,-4.7));
    target.copy(pose.chest).lerp(pose.head,kind==='teethpeed'?.5:.24);target.y=Math.max(target.y,floor(target.x,target.z)+.18);
    if(kind==='deatheater'&&currentMouth&&time>=timing.grab){target.lerp(currentMouth.center,swallowProgress>=1?1:.45);}
    const enter=smooth(time/(entry==='dive'?.46:.78));camera.position.lerpVectors(initialCameraPosition,externalCamera,enter);
    camera.position.y=Math.max(camera.position.y,floor(camera.position.x,camera.position.z)+.14);
    lookMatrix.lookAt(camera.position,target,UP);lookQuaternion.setFromRotationMatrix(lookMatrix);camera.quaternion.slerpQuaternions(initialCameraQuaternion,lookQuaternion,enter);
    if(!motionOff()){
      const groundShake=entry==='trip'?Math.exp(-Math.max(0,time-timing.groundImpact)*10)*(time>=timing.groundImpact?1:0):0;
      const strikeShake=Math.exp(-Math.max(0,time-timing.strike)*9)*(time>=timing.strike?1:0),shake=groundShake*.018+strikeShake*.023;
      camera.position.x+=Math.sin(time*77)*shake;camera.position.y+=Math.cos(time*61)*shake*.55;
    }
  }
  function start({kind:requestedKind='teethpeed',entry:requestedEntry='trip',player={},creature=null}={}){
    if(disposed)return false;kind=requestedKind==='deatheater'?'deatheater':'teethpeed';
    entry=kind==='deatheater'&&requestedEntry==='dive'?'dive':'trip';
    origin={x:Number.isFinite(player.x)?player.x:camera.position.x,z:Number.isFinite(player.z)?player.z:camera.position.z,yaw:Number.isFinite(player.yaw)?player.yaw:0};origin.y=entry==='dive'&&Number.isFinite(player.y)?player.y:floor(origin.x,origin.z);
    initialCameraPosition.copy(camera.position);initialCameraQuaternion.copy(camera.quaternion);events.clear();time=0;completed=false;active=true;started=true;lastCreature=null;currentMouth=null;swallowProgress=0;survivor.clearCapture();
    initialCreatureOrientation=null;creatureAnimationTime=kind==='deatheater'&&Number.isFinite(creature?.animationTime)?Math.max(0,creature.animationTime):0;
    const orientation=creature?.orientation;
    if(entry==='dive'&&orientation&&[orientation.x,orientation.y,orientation.z,orientation.w].every(Number.isFinite)){
      const suppliedTurn=new THREE.Quaternion(orientation.x,orientation.y,orientation.z,orientation.w);
      if(suppliedTurn.lengthSq()>.00000001)initialCreatureOrientation=suppliedTurn.normalize();
    }
    if(entry==='dive'&&!initialCreatureOrientation&&Number.isFinite(creature?.heading))initialCreatureOrientation=new THREE.Quaternion().setFromEuler(new THREE.Euler(Number.isFinite(creature.pitch)?creature.pitch:0,creature.heading,Number.isFinite(creature.bank)?creature.bank:0,'YXZ'));
    if(!teethpeed&&kind==='teethpeed'){teethpeed=createTeethpeedModel({surfaceTexture});root.add(teethpeed.group);}
    if(!deatheater&&kind==='deatheater'){
      deatheater=createDeatheaterModel();deatheaterAnchor=new THREE.Group();deatheaterAnchor.name='Fatal Deatheater mouth anchor';
      deatheater.group.position.set(0,-.065,1.295);deatheaterAnchor.add(deatheater.group);root.add(deatheaterAnchor);
    }
    if(teethpeed)teethpeed.group.visible=kind==='teethpeed';if(deatheaterAnchor)deatheaterAnchor.visible=kind==='deatheater';
    creatureStart=groundPoint(2,6.5);
    const supplied=creature?.position;
    if(kind==='teethpeed'&&supplied&&[supplied.x,supplied.z].every(Number.isFinite)){
      const distance=Math.hypot(supplied.x-origin.x,supplied.z-origin.z);
      if(distance>2.5&&distance<11)creatureStart.set(supplied.x,floor(supplied.x,supplied.z),supplied.z);
    }
    if(kind==='deatheater'){
      creatureStart=world(2.2,origin.y+3.5,2.5);
      if(supplied&&[supplied.x,supplied.y,supplied.z].every(Number.isFinite)&&(entry==='dive'||Math.hypot(supplied.x-origin.x,supplied.z-origin.z)<40))creatureStart.set(supplied.x,supplied.y,supplied.z);
    }
    frame(0);if(entry==='trip')emit('trip');return true;
  }
  function update(dt){
    if(disposed||!active)return completed;
    if(!Number.isFinite(dt)||dt<=0)return false;
    const previous=time;time=Math.min(timings().duration,time+dt);frame(dt);
    if(entry==='trip'&&previous<timings().groundImpact&&time>=timings().groundImpact)emit('ground-impact',timings().groundImpact);
    if(previous<timings().strike&&time>=timings().strike)emit('strike',timings().strike);
    if(kind==='deatheater'&&previous<timings().grab&&time>=timings().grab)emit('grab',timings().grab);
    if(kind==='deatheater'&&previous<timings().swallowEnd&&time>=timings().swallowEnd)emit('swallow',timings().swallowEnd);
    if(time>=timings().duration){completed=true;active=false;emit('finished');root.visible=false;}
    return completed;
  }
  function finish(){if(disposed)return;time=timings().duration;completed=true;active=false;root.visible=false;if(started)emit('finished');}
  function dispose(){
    if(disposed)return;finish();disposed=true;teethpeed?.dispose();deatheater?.dispose();survivor.dispose();
    shadowGeometry.dispose();shadowMaterial.dispose();shadowMap.dispose();root.removeFromParent();root.clear();
  }
  return {start,update,getState,finish,setProfile(value){if(disposed)return null;const profile=survivor.setProfile(value);if(active)frame(0);return profile;},dispose};
}
