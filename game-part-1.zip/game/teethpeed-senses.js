export const TEETHPEED_DETECTION_RADIUS = 10;

const finite = Number.isFinite;
const EPSILON = 1e-8;
const DEFAULT_TERRAIN_SPACING = .5;
const MAX_TERRAIN_SAMPLES = 2048;
const flatGround = () => 0;

const validHorizontalPosition = point => point && finite(point.x) && finite(point.z);
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

function anchor(point, heightAt) {
  if (!validHorizontalPosition(point)) return null;
  const y = finite(point.y) ? point.y : heightAt(point.x, point.z);
  return finite(y) ? { x: point.x, y, z: point.z } : null;
}

function sightRay({ position, player, heightAt = flatGround, originEyeHeight = .25, playerEyeHeight = 1.1 }) {
  if (typeof heightAt !== 'function') return null;
  const origin = anchor(position, heightAt), target = anchor(player, heightAt);
  if (!origin || !target) return null;
  origin.y += finite(originEyeHeight) ? Math.max(0, originEyeHeight) : .25;
  target.y += finite(playerEyeHeight) ? Math.max(0, playerEyeHeight) : 1.1;
  const dx = target.x - origin.x, dy = target.y - origin.y, dz = target.z - origin.z;
  const length = Math.hypot(dx, dy, dz), horizontalLength = Math.hypot(dx, dz);
  if (![origin.y, target.y, length, horizontalLength].every(finite)) return null;
  return { origin, target, dx, dy, dz, length, horizontalLength, heightAt };
}

function sameTree(collider, tree) {
  if (!tree) return false;
  const colliderId = collider.treeId ?? collider.id, treeId = tree.treeId ?? tree.id;
  if (colliderId !== undefined && treeId !== undefined && String(colliderId) === String(treeId)) return true;
  return validHorizontalPosition(tree) && Math.hypot(collider.x - tree.x, collider.z - tree.z) <= .01;
}

function skipCollider(collider, ray, options, base, top) {
  const ignored = options.ignoreCollider;
  if (ignored === collider || typeof ignored === 'function' && ignored(collider)) return true;
  if (options.excludeTreeId !== undefined && options.excludeTreeId !== null) {
    const id = collider.treeId ?? collider.id;
    if (id !== undefined && String(id) === String(options.excludeTreeId)) return true;
  }
  // Rainforest collision cylinders use the full basal radius, so an animal on
  // the narrower upper bark can begin inside its own collision cylinder. Only
  // the explicitly supplied origin tree is exempt; other cover remains solid.
  if (sameTree(collider, options.originTree)) {
    const { origin } = ray;
    const rx=origin.x-collider.x,rz=origin.z-collider.z;
    // Only an outward-facing ray can leave its own bark. A ray aimed through
    // the trunk or underneath the animal's belly must still meet solid cover.
    const outward=rx*ray.dx+rz*ray.dz>=-.02*Math.max(1,Math.hypot(rx,rz));
    return outward&&Math.hypot(origin.x - collider.x, origin.z - collider.z) <= collider.radius + .10
      && origin.y >= base - .01 && origin.y <= top + .01;
  }
  return false;
}

function cylinderBlocks(collider, ray, base, top) {
  const { origin, dx, dy, dz } = ray;
  const ox = origin.x - collider.x, oz = origin.z - collider.z;
  const horizontalLength2 = dx * dx + dz * dz, radius2 = collider.radius * collider.radius;
  let entry = 0, exit = 1;
  if (horizontalLength2 <= EPSILON) {
    if (ox * ox + oz * oz > radius2 + EPSILON) return false;
  } else {
    // Solve the entire horizontal segment against the cylinder. Examining every
    // supplied collider avoids missing a narrow blocker between spatial cells.
    const projection = ox * dx + oz * dz;
    const closestT = -projection / horizontalLength2;
    const closestX = ox + dx * closestT, closestZ = oz + dz * closestT;
    const crossSection = radius2 - closestX * closestX - closestZ * closestZ;
    if (crossSection < -EPSILON) return false;
    const halfInterval = Math.sqrt(Math.max(0, crossSection) / horizontalLength2);
    entry = Math.max(entry, closestT - halfInterval);
    exit = Math.min(exit, closestT + halfInterval);
    if (exit < entry - EPSILON) return false;
  }
  if (Math.abs(dy) <= EPSILON) {
    if (origin.y < base - EPSILON || origin.y > top + EPSILON) return false;
  } else {
    const atBase = (base - origin.y) / dy, atTop = (top - origin.y) / dy;
    entry = Math.max(entry, Math.min(atBase, atTop));
    exit = Math.min(exit, Math.max(atBase, atTop));
    if (exit < entry - EPSILON) return false;
  }
  // Ignore only a centimeter of contact at an endpoint. A trunk entered near
  // the observer and continuing into the ray still blocks a ground pursuit.
  const endpointMargin = Math.min(.02, .01 / Math.max(ray.length, .01));
  return exit > endpointMargin && entry < 1 - endpointMargin;
}

function unobstructed(ray, options) {
  if (!ray) return false;
  if(ray.origin.y<ray.heightAt(ray.origin.x,ray.origin.z)-.04||ray.target.y<ray.heightAt(ray.target.x,ray.target.z)-.04)return false;
  if (ray.length <= EPSILON) return true;
  const colliders = Array.isArray(options.colliders) ? options.colliders : [];
  const minX = Math.min(ray.origin.x, ray.target.x), maxX = Math.max(ray.origin.x, ray.target.x);
  const minZ = Math.min(ray.origin.z, ray.target.z), maxZ = Math.max(ray.origin.z, ray.target.z);
  for (const collider of colliders) {
    if (!collider || ![collider.x, collider.z, collider.radius, collider.height].every(finite)
      || collider.radius <= 0 || collider.height <= 0) continue;
    if (collider.x + collider.radius < minX || collider.x - collider.radius > maxX
      || collider.z + collider.radius < minZ || collider.z - collider.radius > maxZ) continue;
    const base = finite(collider.baseY) ? collider.baseY : ray.heightAt(collider.x, collider.z);
    if (!finite(base)) continue;
    const top = base + collider.height;
    if (!finite(top) || skipCollider(collider, ray, options, base, top)) continue;
    if (cylinderBlocks(collider, ray, base, top)) return false;
  }
  const requestedSpacing = options.terrainSpacing;
  const spacing = finite(requestedSpacing) && requestedSpacing > 0
    ? Math.max(.1, requestedSpacing) : DEFAULT_TERRAIN_SPACING;
  const sampleCount = clamp(Math.ceil(ray.horizontalLength / spacing), 1, MAX_TERRAIN_SAMPLES);
  for (let i = 0; i < sampleCount; i++) {
    const t = (i + .5) / sampleCount;
    const x = ray.origin.x + ray.dx * t, z = ray.origin.z + ray.dz * t;
    const terrain = ray.heightAt(x, z), eyeLine = ray.origin.y + ray.dy * t;
    if (!finite(terrain) || terrain > eyeLine - .015) return false;
  }
  return true;
}

/**
 * Pure visibility query. position/player are feet or attachment anchors. Finite
 * cylinder heights are measured above heightAt(x,z), or an explicit baseY.
 * Unknown-height colliders are not treated as infinitely tall obstacles.
 * originTree may exempt the spawning trunk; omit it during ground hunting.
 */
export function hasTeethpeedLineOfSight(options = {}) {
  return unobstructed(sightRay(options), options);
}

/** Horizontal proximity and three-dimensional sight are independent senses. */
export function evaluateTeethpeedSenses(options = {}) {
  const { position, player } = options;
  const distance = validHorizontalPosition(position) && validHorizontalPosition(player)
    ? Math.hypot(player.x - position.x, player.z - position.z) : Infinity;
  const requestedRadius = options.detectionRadius;
  const radius = finite(requestedRadius) && requestedRadius >= 0 ? requestedRadius : TEETHPEED_DETECTION_RADIUS;
  return {
    distance,
    withinDetection: finite(distance) && distance <= radius + EPSILON,
    lineOfSight: unobstructed(sightRay(options), options),
  };
}
