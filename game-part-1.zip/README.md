# Scars of the Wild — Single Player

Play at https://caspian5348.github.io/scars-of-the-wild/

An independent snapshot of the browser survival game. Single-player gameplay runs entirely in the browser; no Node.js server is needed on GitHub Pages. Saves remain in the current browser and do not transfer from localhost. Multiplayer is disabled in this edition.

Asset attribution and licenses: [credits](game/asset-credits.md).
